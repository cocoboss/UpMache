﻿namespace PressingForm
{
    partial class SerialSettingForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            cb_com = new ComboBox();
            cb_lv = new ComboBox();
            label2 = new Label();
            cb_very = new ComboBox();
            label3 = new Label();
            cb_data = new ComboBox();
            label4 = new Label();
            cb_stop = new ComboBox();
            label5 = new Label();
            button1 = new Button();
            button2 = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(27, 33);
            label1.Name = "label1";
            label1.Size = new Size(82, 41);
            label1.TabIndex = 0;
            label1.Text = "串口";
            // 
            // cb_com
            // 
            cb_com.FormattingEnabled = true;
            cb_com.Items.AddRange(new object[] { "COM1", "COM2", "COM3", "COM4", "COM5", "COM6", "COM7", "COM8", "COM9", "COM10", "COM11", "COM12" });
            cb_com.Location = new Point(288, 30);
            cb_com.Name = "cb_com";
            cb_com.Size = new Size(242, 49);
            cb_com.TabIndex = 1;
            // 
            // cb_lv
            // 
            cb_lv.FormattingEnabled = true;
            cb_lv.Items.AddRange(new object[] { "1200", "4800", "9600", "38400", "115200" });
            cb_lv.Location = new Point(288, 110);
            cb_lv.Name = "cb_lv";
            cb_lv.Size = new Size(242, 49);
            cb_lv.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(27, 113);
            label2.Name = "label2";
            label2.Size = new Size(114, 41);
            label2.TabIndex = 2;
            label2.Text = "波特率";
            // 
            // cb_very
            // 
            cb_very.FormattingEnabled = true;
            cb_very.Items.AddRange(new object[] { "NONE", "ODD", "EVEN" });
            cb_very.Location = new Point(288, 194);
            cb_very.Name = "cb_very";
            cb_very.Size = new Size(242, 49);
            cb_very.TabIndex = 5;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(27, 197);
            label3.Name = "label3";
            label3.Size = new Size(114, 41);
            label3.TabIndex = 4;
            label3.Text = "校验位";
            // 
            // cb_data
            // 
            cb_data.FormattingEnabled = true;
            cb_data.Items.AddRange(new object[] { "8", "7", "6" });
            cb_data.Location = new Point(288, 282);
            cb_data.Name = "cb_data";
            cb_data.Size = new Size(242, 49);
            cb_data.TabIndex = 7;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(27, 285);
            label4.Name = "label4";
            label4.Size = new Size(114, 41);
            label4.TabIndex = 6;
            label4.Text = "数据位";
            // 
            // cb_stop
            // 
            cb_stop.FormattingEnabled = true;
            cb_stop.Items.AddRange(new object[] { "1", "2" });
            cb_stop.Location = new Point(288, 364);
            cb_stop.Name = "cb_stop";
            cb_stop.Size = new Size(242, 49);
            cb_stop.TabIndex = 9;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(27, 367);
            label5.Name = "label5";
            label5.Size = new Size(114, 41);
            label5.TabIndex = 8;
            label5.Text = "停止位";
            // 
            // button1
            // 
            button1.Location = new Point(162, 465);
            button1.Name = "button1";
            button1.Size = new Size(150, 46);
            button1.TabIndex = 10;
            button1.Text = "确定";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(380, 465);
            button2.Name = "button2";
            button2.Size = new Size(150, 46);
            button2.TabIndex = 11;
            button2.Text = "退出";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // SerialSettingForm
            // 
            AutoScaleDimensions = new SizeF(19F, 41F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(559, 546);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(cb_stop);
            Controls.Add(label5);
            Controls.Add(cb_data);
            Controls.Add(label4);
            Controls.Add(cb_very);
            Controls.Add(label3);
            Controls.Add(cb_lv);
            Controls.Add(label2);
            Controls.Add(cb_com);
            Controls.Add(label1);
            Name = "SerialSettingForm";
            Text = "S串口设置界面";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private ComboBox cb_com;
        private ComboBox cb_lv;
        private Label label2;
        private ComboBox cb_very;
        private Label label3;
        private ComboBox cb_data;
        private Label label4;
        private ComboBox cb_stop;
        private Label label5;
        private Button button1;
        private Button button2;
    }
}