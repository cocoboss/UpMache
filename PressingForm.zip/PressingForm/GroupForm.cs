﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PressingForm
{
    public partial class GroupForm : Form
    {
        public GroupForm()
        {
            InitializeComponent();
        }

        private void GroupForm_Load(object sender, EventArgs e)
        {
            tabControl1.TabPages.Clear();
            InitTabPage();
            //if (DevManage.Instance().userMgn.perCurrent.rightBarItem.Keys.Contains(this.Name))
            //{
            //    if (DevManage.Instance().userMgn.perCurrent.rightBarItem[this.Name] != Em_Right.Write)
            //    {
            //        DevManage.Instance().ControlEnable(false, this.Controls);
            //    }
            //    else
            //    {
            //        DevManage.Instance().ControlEnable(true, this.Controls);
            //    }
            //}
        }

        void InitTabPage()
        {
            DataConfig cfg = ProManage.Instance().data;
            if (cfg.addrGroupLst.Count <= 0)
                return;
            for (int i = 0; i < cfg.addrGroupLst.Count; i++)
            {
                AddrGroups group = cfg.addrGroupLst[i];
                TabPage tab = new TabPage();
                tab.Text = group.name;
                tab.Name = group.name;
                UnitForm page = new UnitForm(group);
                page.Dock = DockStyle.Fill;
                page.Name = group.name;
                page.TopLevel = false;
                tab.Controls.Add(page);
                tabControl1.TabPages.Add(tab);
                page.Show();
            }
            UpdateAddrCmb(0);
        }
        private void UpdateAddrCmb(int index)
        {
            if (index < 0)
                return;
            cmb_Addr.Items.Clear();
            cmb_Addr.SelectedIndex = -1;
            cmb_Addr.Text = "";
            AddrGroups group = ProManage.Instance().data.addrGroupLst[index];
            for (int i = 0; i < group.unitLst.Count; i++)
            {
                if (group.unitLst[i].Name.Length > 0)
                {
                    cmb_Addr.Items.Add(group.unitLst[i].Name);
                }
            }
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateAddrCmb(tabControl1.SelectedIndex);
        }

        private void btn_read_Click(object sender, EventArgs e)
        {
            int nSelGroup = tabControl1.SelectedIndex;
            int addrIndex = cmb_Addr.SelectedIndex;
            //PlcConfigs cfg = DevManage.Instance().plcpfg;
            DataConfig cfg = ProManage.Instance().data;
            if (addrIndex != -1)
            {
                DataUint unit = cfg.addrGroupLst[nSelGroup].unitLst[addrIndex];
                try
                {
                    if (!cfg.ReadUnit(ref unit))
                    {
                        MessageBox.Show("读取失败", "错误提示");
                    }
                }
                catch (Exception ex)
                {

                }
                txt_data.Text = unit.Data;
            }
        }

        private void btn_write_Click(object sender, EventArgs e)
        {
            int nSelGroup = tabControl1.SelectedIndex;
            int addrIndex = cmb_Addr.SelectedIndex;
            //PlcConfigs cfg = DevManage.Instance().plcpfg;
            DataConfig cfg = ProManage.Instance().data;
            if (addrIndex != -1)
            {
                DataUint unit = cfg.addrGroupLst[nSelGroup].unitLst[addrIndex];
                unit.Data = txt_data.Text.Trim();
                try
                {
                    if (!cfg.WriteUnit(ref unit))
                    {
                        MessageBox.Show("写入失败", "错误提示");
                    }
                }
                catch (Exception ex)
                {

                }
            }
        }

        private void btn_SaveCurr_Click(object sender, EventArgs e)
        {
            //PlcConfigs cfg = DevManage.Instance().plcpfg;
            DataConfig cfg = ProManage.Instance().data;
            for (int i = 0; i < tabControl1.TabPages.Count; i++)
            {
                TabPage page = (tabControl1.TabPages[i]);
                UnitForm settingPage = (UnitForm)(page.Controls[0]);
                AddrGroups group = settingPage.GetGroupData();
                cfg.ReadGroup(ref group);
                cfg.addrGroupLst[i] = group;
            }
            if (cfg.Save())
            {
                MessageBox.Show("保存成功");
            }
        }
    }
}
