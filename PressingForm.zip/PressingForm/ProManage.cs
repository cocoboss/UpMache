﻿using System;
using System.Collections.Generic;
using System.DirectoryServices.ActiveDirectory;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace PressingForm
{
    public class ProManage
    {
        private static ProManage instance = new ProManage();
        private static object objlock = new object();
        private static object objlockPro = new object();
        private static object logobjlock = new object();
        private Thread mThread;
        public PlcClient plc;
        public SerialCommHelper serial1;
        public SerialCommHelper serial2;
        public Action<string> logHelper;
        public Action<string> barcodehelper;
        public DataConfig data;
        public bool exit = false;
        public static ProManage Instance()
        {
            if (instance == null)
            {
                lock (objlock)
                {
                    if (instance == null)
                        instance = new ProManage();
                }
            }
            return instance;
        }

        public ProManage()
        {
        }
        public void ConnToPort(ref SerialCommHelper port, Action<string> act, string portStr)
        {
            List<string> strList = portStr.Split(',').ToList();
            if (strList.Count < 5)
            {
                port = null;
                return;
            }
            port = new SerialCommHelper(strList[0], int.Parse(strList[1]), (Parity)Enum.Parse(typeof(Parity), strList[2]), int.Parse(strList[3]), (StopBits)Enum.Parse(typeof(StopBits), strList[4]));
            port.sttrLeng = data.barleng;
            if (port.Open())
            {
                logHelper?.Invoke($"串口{portStr}连接成功");
            }
            else
            {
                logHelper?.Invoke($"串口{portStr}连接失败，检查COM口是否被占用");
            }
            port.DataReceived = act;
        }
        public void Init()
        {
            try
            {
                data = FileDeal.LoadFile();
                if (data == null)
                    return;

                logHelper?.Invoke("网口连接成功：" + data.clientStrings);
                ConnToPort(ref serial2, DealServesMsg, data.serialStrings2);

                mThread = new Thread(new ThreadStart(Do_Thread_Work));
                mThread.Priority = ThreadPriority.AboveNormal;
                mThread.Start();

            }
            catch (ArgumentNullException e)
            {
                string msg1 = $"串口连接失败,请检查串口配置是否正确,{e.Message}+{e.StackTrace}";
                logHelper?.Invoke(msg1);
            }
            catch (Exception ex)
            {
                string msg1 = $"网口或者串口连接失败,{ex.Message}+{ex.StackTrace}";
                logHelper?.Invoke(msg1);
            }
        }
        public void DealServesMsg(string msg)
        {
            logHelper?.Invoke(msg);
        }
        public void Do_Thread_Work()
        {
            RecordLog("开启扫描线程");
            while (!exit)
            {
                if (plc.IsConnect)
                {

                    ReadSigGroup();
                }

                Thread.Sleep(10);
            }
        }

        public void ReadSigGroup()
        {
            //AddrGroups group = plcpfg.dirGroup[sysParam.sysParam["trigger"]];


            //if (Plc.ReadGroup(ref group))
            //{
            //    plcpfg.dirGroup[sysParam.sysParam["trigger"]] = group;
            //    for (int i = 0; i < group.unitLst.Count; i++)
            //    {
            //        if (group.unitLst[i].Data != group.unitLst[i].OldData)
            //        {
            //            string strLog = $"{group.unitLst[i].Name}:{group.unitLst[i].OldData}-->{group.unitLst[i].Data}";
            //            WriteLog(strLog);
            //            group.unitLst[i].OldData = group.unitLst[i].Data;
            //            if (group.unitLst[i].Data == "1")
            //            {
            //                StatusActionAsync(group.unitLst[i]);
            //                RaiseSigStatus(group.unitLst[i].Name, EM_SigStatus.ON.ToString());
            //            }
            //            else
            //            {
            //                RaiseSigStatus(group.unitLst[i].Name, EM_SigStatus.OFF.ToString());
            //            }
            //        }
            //    }
            //}

        }

        public async void StatusActionAsync(DataUint unit)
        {
            await Task.Run(() =>
            {
                StatusAction(unit);
            });
        }

        public void StatusAction(DataUint unit)
        {
            switch (unit.Name.Trim())
            {
                case "上料触发信号":
                    //BarCodeOn();
                    break;
                case "下料触发信号":
                    //BarCodeOff();
                    break;
                //case "PLC用户登录触发":
                //    PlcLogin();
                //    Write(unit.Name.Trim(), ((int)Em_OtherStatus.Reset).ToString());
                //    break;

                //case "设备请求触发信号":
                //    EquipmentRun();
                //    Write(unit.Name.Trim(), ((int)Em_OtherStatus.Reset).ToString());
                //    break;
                default:
                    break;
            }
        }


        public void RecordLog(string msg)
        {
            try
            {
                lock (logobjlock)
                {
                    string dateTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                    string dateTimefile = DateTime.Now.ToString("yyyy-MM-dd");
                    msg = "[" + dateTime + "]: " + msg;
                    string path = Global.exePath + "\\log";
                    if (string.IsNullOrEmpty(path))
                    {
                        path = "D:\\log";
                    }
                    path = path + "\\" + DateTime.Now.ToString("yyyy-MM");
                    if (!Directory.Exists(path))
                    {
                        Directory.CreateDirectory(path);
                    }
                    path = path + "\\" + dateTimefile + "log.txt";
                    using (StreamWriter sw = new StreamWriter(path, true))
                    {
                        sw.WriteLine(msg);
                        sw.Flush();
                        sw.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("write log is fail: " + ex.ToString());
            }
        }


        public bool WriteUnit(ref DataUint data)
        {
            return false;
        }
        public bool ReadUnit(ref DataUint data)
        {
            return false;
        }
        public bool ReadGroup(ref AddrGroups group)
        {

            if (group.leng <= 0)
            {
                return false;
            }
            else
            {
                //plc.ReadGroup(ref group);
            }
            return true;
        }
        public bool Save()
        {
            FileDeal.SaveFile(data);
            return true;
        }

    }
}
