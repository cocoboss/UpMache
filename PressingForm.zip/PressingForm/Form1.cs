namespace PressingForm
{
    public partial class Form1 : Form
    {
        public PlcClient plc;
        public Form1()
        {
            InitializeComponent();
            plc = new PlcClient();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (plc.IsConnect)
            {
                var context=plc.Read(txt_addr.Text.Trim());
                lst_log.Items.Add(context);
            }else
            {
                button3.Enabled = true;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (plc.IsConnect)
            {
                var context = plc.Write(txt_addr.Text.Trim(),ushort.Parse(txt_value.Text));
                lst_log.Items.Add(context);
            }
            else
            {
                button3.Enabled = true;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            button3.Enabled = false;
            if (plc.Open($"{cb_com.Text},9600"))
            {
                MessageBox.Show("Connected success");
                
            }
            else
            {
                MessageBox.Show("Failed to connect");
                button3.Enabled = true;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cb_com.Items.Clear();
            for (int i = 0; i < 12; i++)
            {
                cb_com.Items.Add("COM" + i.ToString());
            }
            cb_com.SelectedIndex = 0;
        }
    }
}
