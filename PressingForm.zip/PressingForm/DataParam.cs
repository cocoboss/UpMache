﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace PressingForm
{
    public class DataConfig
    {
        public DataConfig() { }

        public string serialStrings1 { get; set; } = "";
        public string serialStrings2 { get; set; } = "";

        public int barleng { get; set; } = 15;
        public string clientStrings { get; set; } = "";


        public string plcPort { get; set; }
        public string barCodePort { get; set; }

        public string mesIp { get; set; }
        public List<AddrGroups> addrGroupLst = new List<AddrGroups>();

        public bool WriteUnit(ref DataUint data)
        {
            return false;
        }
        public bool ReadUnit(ref DataUint data)
        {
            return false;
        }
        public bool ReadGroup(ref AddrGroups group)
        {

            if (group.leng <= 0)
            {
                return false;
            }
            else
            {
                //plc.ReadGroup(ref group);
            }
            return true;
        }
        public bool Save()
        {
            FileDeal.SaveFile(this);
            return true;
            //bool rult = false;
            //PlcConfigAccess pa = new PlcConfigAccess();
            //foreach (var group in addrGroupLst)
            //{
            //    for (int i = 0; i < group.unitLst.Count; i++)
            //    {
            //        PlcConfig pfg = new PlcConfig();
            //        pfg.address = group.unitLst[i].Prefix + group.unitLst[i].Addr.ToString();
            //        pfg.name = group.unitLst[i].Name;
            //        pfg.paramId = group.unitLst[i].bandField;
            //        pfg.oldData = group.unitLst[i].OldData;
            //        pfg.data = group.unitLst[i].Data;
            //        pfg.dataType = group.unitLst[i].type.ToString();
            //        pfg.unitNum = group.unitLst[i].unitNum;
            //        pfg.remark = group.unitLst[i].vairsName;
            //        rult = pa.Update(pfg) > 0 ? true : false;
            //    }
            //}
            //return rult;
        }
    }

    public class FileDeal
    {
        public static DataConfig dataConfig = new DataConfig();
        public static string inipath = Global.exePath + "\\cfg\\" + ConfigurationManager.AppSettings["inipath"];
        //public FileDeal()
        //{
        //    inipath = Global.exePath+"\\" + ConfigurationManager.AppSettings["inipath"];
        //    //inipath = dataConfig.other.exePath+inipath;
        //}
        [DllImport("kernel32", CharSet = CharSet.Unicode)]
        public static extern long WritePrivateProfileString(string section, string key, string val, string filePath);
        [DllImport("kernel32", CharSet = CharSet.Unicode)]
        public static extern int GetPrivateProfileString(string section, string key, string def, StringBuilder retVal, int size, string filePath);

        public static void FileWrite(DataConfig dataConfig, string path)
        {
            try
            {
                if (!Directory.Exists(Path.GetDirectoryName(path)))
                {
                    Directory.CreateDirectory(Path.GetDirectoryName(path));
                }
                if (Directory.Exists(Path.GetDirectoryName(path)) && dataConfig != null)
                {
                    string json = JsonConvert.SerializeObject(dataConfig, Newtonsoft.Json.Formatting.Indented);
                    File.WriteAllText(path, json);
                }
            }
            catch (Exception e)
            {

            }

        }
        public static DataConfig FileRead(string filePath)
        {
            DataConfig dataConfig = null;
            try
            {
                if (Directory.Exists(Path.GetDirectoryName(filePath)))
                {
                    string jsonContent = File.ReadAllText(filePath);
                    dataConfig = JsonConvert.DeserializeObject<DataConfig>(jsonContent);
                }

            }
            catch (Exception ex)
            {
                dataConfig = new DataConfig(); 
            }
            return dataConfig;
        }
        public static DataConfig LoadFile()
        {
            dataConfig = FileRead(inipath);
            return dataConfig;
        }
        public static void SaveFile(DataConfig dataConfigs)
        {
            FileWrite(dataConfigs, inipath);
        }
    }
}
