﻿namespace PressingForm
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txt_addr = new TextBox();
            button1 = new Button();
            txt_value = new TextBox();
            button2 = new Button();
            lst_log = new ListBox();
            cb_com = new ComboBox();
            label2 = new Label();
            button3 = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(24, 102);
            label1.Name = "label1";
            label1.Size = new Size(114, 41);
            label1.TabIndex = 0;
            label1.Text = "地址：";
            // 
            // txt_addr
            // 
            txt_addr.Location = new Point(160, 99);
            txt_addr.Name = "txt_addr";
            txt_addr.Size = new Size(200, 48);
            txt_addr.TabIndex = 1;
            // 
            // button1
            // 
            button1.Location = new Point(422, 102);
            button1.Name = "button1";
            button1.Size = new Size(150, 46);
            button1.TabIndex = 2;
            button1.Text = "读取";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // txt_value
            // 
            txt_value.Location = new Point(160, 178);
            txt_value.Name = "txt_value";
            txt_value.Size = new Size(200, 48);
            txt_value.TabIndex = 3;
            // 
            // button2
            // 
            button2.Location = new Point(422, 178);
            button2.Name = "button2";
            button2.Size = new Size(150, 46);
            button2.TabIndex = 4;
            button2.Text = "写入";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // lst_log
            // 
            lst_log.FormattingEnabled = true;
            lst_log.Location = new Point(669, 62);
            lst_log.Name = "lst_log";
            lst_log.Size = new Size(354, 332);
            lst_log.TabIndex = 5;
            // 
            // cb_com
            // 
            cb_com.FormattingEnabled = true;
            cb_com.Location = new Point(195, 25);
            cb_com.Name = "cb_com";
            cb_com.Size = new Size(242, 49);
            cb_com.TabIndex = 6;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(35, 31);
            label2.Name = "label2";
            label2.Size = new Size(128, 41);
            label2.TabIndex = 7;
            label2.Text = "COM口";
            // 
            // button3
            // 
            button3.Location = new Point(490, 28);
            button3.Name = "button3";
            button3.Size = new Size(150, 46);
            button3.TabIndex = 8;
            button3.Text = "连接";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(19F, 41F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1056, 667);
            Controls.Add(button3);
            Controls.Add(label2);
            Controls.Add(cb_com);
            Controls.Add(lst_log);
            Controls.Add(button2);
            Controls.Add(txt_value);
            Controls.Add(button1);
            Controls.Add(txt_addr);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txt_addr;
        private Button button1;
        private TextBox txt_value;
        private Button button2;
        private ListBox lst_log;
        private ComboBox cb_com;
        private Label label2;
        private Button button3;
    }
}
