﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HslCommunication.ModBus;
using HslCommunication;
using System.IO.Ports;

namespace PressingForm
{
    public class PlcClient
    {
        private ModbusRtu client;
        public PlcClient() { }
        public bool Open(string PortData)
        {
            try
            {
                List<string> portList = PortData.Split(',').ToList();
                if (portList != null && portList.Count >= 2)
                {
                    client = new ModbusRtu();
                    client.SerialPortInni(portList[0], Convert.ToInt32(portList[1]));                           // 端口号
                    client.Open();
                    Thread.Sleep(100);
                    return client.IsOpen();
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        public bool IsConnect
        {
            get
            {
                if(client == null)
                {
                    return false;
                }
                return client.IsOpen();
            }
        }

        public void Close()
        {
            if (client != null)
            {
                client.Close();
            }
        }

        public object Read(string address, ushort length=1)
        {
            if (client != null && client.IsOpen())
            {
                var read = client.Read(address, length);
                if (read.IsSuccess)
                {
                    return read.Content;
                }
                else
                {
                    return null;
                }
            }
            else
            {
                return null;
            }
        }
        public bool Write(string address, ushort values)
        {
            if (client != null && client.IsOpen())
            {
                var write = client.Write(address, values);
                return write.IsSuccess;
            }
            else
            {
                return false;
            }
        }
    }

    public class SocketClient
    {
        public SocketClient()
        {
        }
    }
    public class SocketServer
    {

        public SocketServer()
        {
        }
    }
}
