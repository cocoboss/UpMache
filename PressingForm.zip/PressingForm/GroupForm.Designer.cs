﻿namespace PressingForm
{
    partial class GroupForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            tabControl1 = new TabControl();
            tabPage1 = new TabPage();
            tabPage2 = new TabPage();
            panel2 = new Panel();
            btn_SaveCurr = new Button();
            btn_write = new Button();
            btn_read = new Button();
            txt_data = new TextBox();
            label2 = new Label();
            cmb_Addr = new ComboBox();
            label1 = new Label();
            panel1.SuspendLayout();
            tabControl1.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Controls.Add(tabControl1);
            panel1.Location = new Point(12, 12);
            panel1.Name = "panel1";
            panel1.Size = new Size(1467, 719);
            panel1.TabIndex = 0;
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Dock = DockStyle.Fill;
            tabControl1.Location = new Point(0, 0);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(1467, 719);
            tabControl1.TabIndex = 0;
            tabControl1.SelectedIndexChanged += tabControl1_SelectedIndexChanged;
            // 
            // tabPage1
            // 
            tabPage1.Location = new Point(8, 55);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(1451, 656);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "tabPage1";
            tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            tabPage2.Location = new Point(8, 55);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(1451, 656);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "tabPage2";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            panel2.Controls.Add(btn_SaveCurr);
            panel2.Controls.Add(btn_write);
            panel2.Controls.Add(btn_read);
            panel2.Controls.Add(txt_data);
            panel2.Controls.Add(label2);
            panel2.Controls.Add(cmb_Addr);
            panel2.Controls.Add(label1);
            panel2.Location = new Point(12, 759);
            panel2.Name = "panel2";
            panel2.Size = new Size(1467, 102);
            panel2.TabIndex = 1;
            // 
            // btn_SaveCurr
            // 
            btn_SaveCurr.Location = new Point(1168, 31);
            btn_SaveCurr.Name = "btn_SaveCurr";
            btn_SaveCurr.Size = new Size(257, 46);
            btn_SaveCurr.TabIndex = 6;
            btn_SaveCurr.Text = "保存当前页数据";
            btn_SaveCurr.UseVisualStyleBackColor = true;
            btn_SaveCurr.Click += btn_SaveCurr_Click;
            // 
            // btn_write
            // 
            btn_write.Location = new Point(997, 31);
            btn_write.Name = "btn_write";
            btn_write.Size = new Size(141, 46);
            btn_write.TabIndex = 5;
            btn_write.Text = "写入";
            btn_write.UseVisualStyleBackColor = true;
            btn_write.Click += btn_write_Click;
            // 
            // btn_read
            // 
            btn_read.Location = new Point(826, 31);
            btn_read.Name = "btn_read";
            btn_read.Size = new Size(141, 46);
            btn_read.TabIndex = 4;
            btn_read.Text = "读取";
            btn_read.UseVisualStyleBackColor = true;
            btn_read.Click += btn_read_Click;
            // 
            // txt_data
            // 
            txt_data.Location = new Point(491, 29);
            txt_data.Name = "txt_data";
            txt_data.Size = new Size(246, 48);
            txt_data.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(395, 31);
            label2.Name = "label2";
            label2.Size = new Size(90, 41);
            label2.TabIndex = 2;
            label2.Text = "数据:";
            // 
            // cmb_Addr
            // 
            cmb_Addr.FormattingEnabled = true;
            cmb_Addr.Location = new Point(118, 28);
            cmb_Addr.Name = "cmb_Addr";
            cmb_Addr.Size = new Size(242, 49);
            cmb_Addr.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(22, 31);
            label1.Name = "label1";
            label1.Size = new Size(90, 41);
            label1.TabIndex = 0;
            label1.Text = "地址:";
            // 
            // GroupForm
            // 
            AutoScaleDimensions = new SizeF(19F, 41F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1501, 884);
            Controls.Add(panel2);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "GroupForm";
            Text = "GroupForm";
            Load += GroupForm_Load;
            panel1.ResumeLayout(false);
            tabControl1.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private TabControl tabControl1;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private Panel panel2;
        private ComboBox cmb_Addr;
        private Label label1;
        private Button btn_SaveCurr;
        private Button btn_write;
        private Button btn_read;
        private TextBox txt_data;
        private Label label2;
    }
}