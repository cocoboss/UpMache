﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PressingForm
{
    public partial class UnitForm : Form
    {
        public Color OddRowBackClr = Color.FromArgb(119, 220, 250);
        public Color EvenRowBackClr = Color.FromArgb(142, 223, 251);
        public Color FontColor = SystemColors.Info;
        public Color listBackColor = Color.FromArgb(119, 211, 253);
        private AddrGroups group = null;
        private bool rightRole = false;
        public UnitForm(AddrGroups groupParam, bool temp = true)
        {
            this.group = groupParam;
            rightRole = temp;
            InitializeComponent();
        }

        private void UnitForm_Load(object sender, EventArgs e)
        {
            //if (DevManage.Instance().userMgn.perCurrent.rightBarItem.Keys.Contains(this.Name))
            //{
            //    if (DevManage.Instance().userMgn.perCurrent.rightBarItem[this.Name] != Em_Right.Write)
            //    {
            //        DevManage.Instance().ControlEnable(false, this.Controls);
            //    }
            //    else
            //    {
            //        DevManage.Instance().ControlEnable(true, this.Controls);
            //    }
            //}
            ReflashGridData(group);
        }


        public void ReflashGridData(AddrGroups groupData)
        {
            dataGrid.Rows.Clear();
            DataGridViewComboBoxColumn cmbox = dataGrid.Columns["数据类型"] as DataGridViewComboBoxColumn;
            cmbox.Items.AddRange(Enum.GetNames(typeof(em_DataType)));
            dataGrid.Columns[0].ReadOnly = true;
            if (!rightRole)
            {
                foreach (DataGridViewColumn item in dataGrid.Columns)
                {
                    item.ReadOnly = !rightRole;
                }
            }
            for (int i = 0; i < groupData.unitLst.Count; i++)
            {
                DataUint unit = groupData.unitLst[i];
                if (unit.Name.Length == 0)
                    continue;
                dataGrid.Rows.Insert(i, unit.Name, unit.Addr, unit.unitNum, null, unit.vairsName, unit.bandField);
                DataGridViewRow rowData = dataGrid.Rows[i];
                DataGridViewComboBoxCell combox = rowData.Cells[3] as DataGridViewComboBoxCell;
                rowData.Cells[3].Value = combox.Items[(int)unit.type];

                if (i % 2 == 0)
                {
                    dataGrid.Rows[i].DefaultCellStyle.BackColor = OddRowBackClr;
                }
                else
                {
                    dataGrid.Rows[i].DefaultCellStyle.BackColor = EvenRowBackClr;
                }

            }
        }


        public AddrGroups GetGroupData()
        {
            for (int i = 0; i < dataGrid.Rows.Count - 1; i++)
            {
                DataGridViewRow dateRow = dataGrid.Rows[i];

                group.unitLst[i].Name = IsEmptyOrNull(dateRow.Cells[0].Value).ToString().Trim();
                try
                {
                    group.unitLst[i].Addr = Convert.ToInt32(IsEmptyOrNull(dateRow.Cells[1].Value).ToString());
                }
                catch
                {
                    group.unitLst[i].Addr = 0;
                }
                try
                {
                    group.unitLst[i].unitNum = Convert.ToInt32(IsEmptyOrNull(dateRow.Cells[2].Value).ToString());
                }
                catch
                {
                    group.unitLst[i].unitNum = 0;
                }

                group.unitLst[i].bandField = IsEmptyOrNull(dateRow.Cells[5].Value).ToString().Trim();
                group.unitLst[i].type = (em_DataType)((em_DataType)Enum.Parse(typeof(em_DataType), (string)dateRow.Cells[3].Value));
                group.unitLst[i].vairsName = IsEmptyOrNull(dateRow.Cells[4].Value).ToString().Trim();
            }
            return group;
        }


        public object IsEmptyOrNull(object obj)
        {
            if (string.IsNullOrEmpty(obj.ToString()))
                return "";
            else
                return obj;
        }
    }
}
