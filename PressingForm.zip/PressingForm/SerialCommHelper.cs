﻿using System;
using System.IO.Ports;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PressingForm
{
    /// <summary>
    /// 封装串口通信的轻量助手类，提供打开/关闭、发送、接收事件以及异常回调。
    /// </summary>
    public sealed class SerialCommHelper : IDisposable
    {
        private readonly SerialPort _port;
        private readonly object _sync = new();
        public int sttrLeng = 15;
        public int timeout = 500;
        public uint sendTime = 0;
        /// <summary>
        /// 当收到文本数据时触发（使用指定编码解码）。
        /// </summary>
        public  Action<string>? DataReceived;

        /// <summary>
        /// 当收到原始字节数据时触发。
        /// </summary>
        public event EventHandler<byte[]?>? BytesReceived;

        /// <summary>
        /// 当发生串口错误时触发。
        /// </summary>
        public event EventHandler<Exception>? ErrorOccurred;

        /// <summary>
        /// 是否已打开。
        /// </summary>
        public bool IsOpen => _port.IsOpen;

        /// <summary>
        /// 构造并初始化串口（不自动打开）。
        /// </summary>
        public SerialCommHelper(string portName, int baudRate = 9600,
            Parity parity = Parity.None, int dataBits = 8, StopBits stopBits = StopBits.One,
            Handshake handshake = Handshake.None)
        {
            _port = new SerialPort(portName, baudRate, parity, dataBits, stopBits)
            {
                Handshake = handshake,
                Encoding = Encoding.UTF8,
                ReadTimeout = -1,
                WriteTimeout = -1
            };

            _port.DataReceived += OnDataReceived;
            _port.ErrorReceived += OnErrorReceived;
        }

        /// <summary>
        /// 使用已存在的 SerialPort 实例包装（不会替换事件处理）。
        /// </summary>
        public SerialCommHelper(SerialPort port)
        {
            _port = port ?? throw new ArgumentNullException(nameof(port));
            _port.DataReceived += OnDataReceived;
            _port.ErrorReceived += OnErrorReceived;
        }

        /// <summary>
        /// 打开串口（如果尚未打开）。
        /// </summary>
        public bool Open()
        {
            lock (_sync)
            {
                if (!_port.IsOpen)
                {
                    _port.Open();
                }
            }
            return _port.IsOpen;
        }

        /// <summary>
        /// 关闭串口（如果已打开）。
        /// </summary>
        public void Close()
        {
            lock (_sync)
            {
                if (_port.IsOpen)
                {
                    _port.Close();
                }
            }
        }

        /// <summary>
        /// 异步写入字节到串口（基于 BaseStream）。
        /// </summary>
        public async Task WriteAsync(byte[] buffer, int offset = 0, int count = -1, CancellationToken cancellationToken = default)
        {
            if (buffer is null) throw new ArgumentNullException(nameof(buffer));
            if (count == -1) count = buffer.Length - offset;
            if (!_port.IsOpen) throw new InvalidOperationException("Serial port is not open.");

            // SerialPort.BaseStream 支持异步操作
            try
            {
                lock (_sync)
                {
                    // Ensure no concurrent open/close races. Actual write uses BaseStream asynchronously.
                }
                sendTime = Global.timeGetTime();
                await _port.BaseStream.WriteAsync(buffer, offset, count, cancellationToken).ConfigureAwait(false);
                await _port.BaseStream.FlushAsync(cancellationToken).ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                ErrorOccurred?.Invoke(this, ex);
                throw;
            }
        }

        /// <summary>
        /// 异步写入文本（使用指定编码）。
        /// </summary>
        public Task WriteAsync(string text, Encoding? encoding = null, CancellationToken cancellationToken = default)
        {
            if (text is null) throw new ArgumentNullException(nameof(text));
            encoding ??= _port.Encoding ?? Encoding.UTF8;
            var bytes = encoding.GetBytes(text);
            return WriteAsync(bytes, 0, bytes.Length, cancellationToken);
        }
        /// <summary>
        /// 发送 16 进制字符串，并在末尾追加 CRLF（例如 "01 FF 0A" 或 "01FF0A"）。
        /// </summary>
        public Task SendHexLineAsync(string hexString, CancellationToken cancellationToken = default)
        {
            if (hexString is null) throw new ArgumentNullException(nameof(hexString));
            var payload = HexStringToBytes(hexString);
            // 追加 CRLF
            var withCrLf = new byte[payload.Length + 2];
            Array.Copy(payload, 0, withCrLf, 0, payload.Length);
            withCrLf[withCrLf.Length - 2] = 0x0D;
            withCrLf[withCrLf.Length - 1] = 0x0A;
            return WriteAsync(withCrLf, 0, withCrLf.Length, cancellationToken);
        }
        private static byte[] HexStringToBytes(string hex)
        {
            // 允许空格、"-"、"0x" 前缀
            var cleaned = hex.Replace("0x", "", StringComparison.OrdinalIgnoreCase)
                             .Replace("-", "")
                             .Replace(" ", "")
                             .Trim();
            if (cleaned.Length == 0) return Array.Empty<byte>();
            if (cleaned.Length % 2 != 0) throw new FormatException("Hex string length must be even.");

            var result = new byte[cleaned.Length / 2];
            for (int i = 0; i < result.Length; i++)
            {
                string pair = cleaned.Substring(i * 2, 2);
                if (!byte.TryParse(pair, System.Globalization.NumberStyles.HexNumber, null, out byte b))
                    throw new FormatException($"Invalid hex pair '{pair}'");
                result[i] = b;
            }
            return result;
        }

        public bool IsTimeOut(uint curtime,int outTime)
        {
            
            if (sendTime!=0 && curtime - sendTime > outTime)
            {
                sendTime = 0;
                DataReceived?.Invoke("TIMEOUT");
                return true;
            }else
            {
                //ProManage.Instance().RecordLog($"{Global.timeGetTime()}-{sendTime}");
                return false;
            }
            
        }

        private void OnDataReceived(object? sender, SerialDataReceivedEventArgs e)
        {
            try
            {
                //读取当前可用字节
                int toRead;
                lock (_sync)
                {
                    toRead = _port.BytesToRead;
                }
                
                //if (IsTimeOut(Global.timeGetTime(), timeout)) return;
                if (toRead <= 0)
                {
                    if (!IsTimeOut(Global.timeGetTime(), timeout))
                        return;
                }
                Thread.Sleep(50);//延时50ms，等待数据接收完整
                if(toRead< sttrLeng)
                {
                    return;
                }
                toRead = _port.BytesToRead;
                //var buffer = new byte[toRead];
                var buffer = new byte[1024];
                int read = 0;

                // 使用同步 Read 来避免与 BaseStream 冲突（DataReceived 回调通常在非 UI 线程）
                lock (_sync)
                {
                    //read = _port.Read(buffer, 0, toRead);
                    read = _port.Read(buffer, 0, buffer.Length);
                }

                if (read > 0)
                {
                    //BytesReceived?.Invoke(this, read == buffer.Length ? buffer : SubArray(buffer, 0, read));
                    // 按当前编码触发文本事件
                    try
                    {
                        var text = _port.Encoding.GetString(buffer, 0, read);
                        //var text = _port.ReadExisting();
                        if(text.Contains(","))
                        {
                            sendTime = 0;
                        }else
                        {
                            if (IsTimeOut(Global.timeGetTime(), timeout)) return;
                        }
                        DataReceived?.Invoke(text);
                    }
                    catch
                    {
                        // 忽略文本解码错误（接收原始字节仍可用）
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorOccurred?.Invoke(this, ex);
            }
        }

        private void OnErrorReceived(object? sender, SerialErrorReceivedEventArgs e)
        {
            ErrorOccurred?.Invoke(this, new IOException($"Serial port error: {e.EventType}"));
        }

        private static T[] SubArray<T>(T[] data, int index, int length)
        {
            var result = new T[length];
            Array.Copy(data, index, result, 0, length);
            return result;
        }

        /// <summary>
        /// 释放并注销事件。
        /// </summary>
        public void Dispose()
        {
            lock (_sync)
            {
                try
                {
                    _port.DataReceived -= OnDataReceived;
                    _port.ErrorReceived -= OnErrorReceived;
                    if (_port.IsOpen)
                    {
                        _port.Close();
                    }
                    _port.Dispose();
                }
                catch
                {
                    // 忽略 Dispose 时的异常
                }
            }
            GC.SuppressFinalize(this);
        }
    }
}