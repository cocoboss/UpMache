﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PressingForm
{
    public partial class SerialSettingForm : Form
    {
        public List<string> SerialComList = new List<string>()
        {
            "COM1",
            "COM2",
            "COM3",
            "COM4",
            "COM5",
            "COM6",
            "COM7",
            "COM8",
            "COM9",
            "COM10",
            "COM11",
            "COM12",
        };
        public List<string> SerialLvList = new List<string>()
        {
            "9600",
            "19200",
            "38400",
            "57600",
            "115200",
        };
        public List<string> SerialVeryList = new List<string>()
        {
            "None",
            "Odd",
            "Even",
            "Mark",
            "Space",
        };
        public List<string> SerialDataList = new List<string>()
        {
            //"5",
            "6",
            "7",
            "8",
        };
        public List<string> SerialStopList = new List<string>()
        {
            "1",
            //"1.5",
            "2",
        };
        public string _SerialStrings = "";
        public SerialSettingForm()
        {
            InitializeComponent();
            LoadSetting();
        }
        public SerialSettingForm(string temp)
        {
            InitializeComponent();
            _SerialStrings = temp;
            LoadSetting();
        }

        public void LoadSetting()
        {
            cb_com.Items.Clear();
            cb_lv.Items.Clear();
            cb_very.Items.Clear();
            cb_data.Items.Clear();
            cb_stop.Items.Clear();

            cb_com.Items.AddRange(SerialComList.ToArray());
            cb_lv.Items.AddRange(SerialLvList.ToArray());
            cb_very.Items.AddRange(SerialVeryList.ToArray());
            cb_data.Items.AddRange(SerialDataList.ToArray());
            cb_stop.Items.AddRange(SerialStopList.ToArray());
            if (string.IsNullOrEmpty(_SerialStrings))
            {
                cb_com.SelectedIndex = 0;
                cb_lv.SelectedIndex = 0;
                cb_very.SelectedIndex = 0;
                cb_data.SelectedIndex = 0;
                cb_stop.SelectedIndex = 0;
            }
            else
            {
                List<string> serialStr = _SerialStrings.Split(',').ToList();
                if (serialStr != null && serialStr.Count >= 5)
                {
                    cb_com.SelectedIndex = SerialComList.IndexOf(serialStr[0]);
                    cb_lv.SelectedIndex = SerialLvList.IndexOf(serialStr[1]);
                    cb_very.SelectedIndex = SerialVeryList.IndexOf(serialStr[2]);
                    cb_data.SelectedIndex = SerialDataList.IndexOf(serialStr[3]);
                    cb_stop.SelectedIndex = SerialStopList.IndexOf(serialStr[4]);
                }
            }
        }

        public void SaveSetting()
        {
            _SerialStrings = $"{cb_com.SelectedItem},{cb_lv.SelectedItem},{cb_very.SelectedItem},{cb_data.SelectedItem},{cb_stop.SelectedItem}";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SaveSetting();
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
