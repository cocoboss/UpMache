﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PressingForm
{
    public partial class SettingForm : Form
    {
        private string serialStr1 = "";
        private string serialStr2 = "";
        //private string clientStr = "";

        public SettingForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (ProManage.Instance().data != null)
            {
                SerialSettingForm form = new SerialSettingForm(ProManage.Instance().data.serialStrings1);
                form.ShowDialog();
                serialStr1 = form._SerialStrings;
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (ProManage.Instance().data != null)
            {
                SerialSettingForm form = new SerialSettingForm(ProManage.Instance().data.serialStrings2);
                form.ShowDialog();
                serialStr2 = form._SerialStrings;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DataConfig data = new DataConfig();
            data.serialStrings1 = serialStr1;
            data.serialStrings2 = serialStr2;
            data.barleng = int.Parse(leg_txt.Text.Trim());
            data.clientStrings = conn_txt.Text.Trim();
            if (ProManage.Instance().data != data)
            {
                ProManage.Instance().data = data;
                FileDeal.SaveFile(data);
            }
            this.Close();
        }

        private void SettingForm_Load(object sender, EventArgs e)
        {
            if (ProManage.Instance().data != null)
            {
                serialStr1 = ProManage.Instance().data.serialStrings1;
                serialStr2 = ProManage.Instance().data.serialStrings2;
                conn_txt.Text = ProManage.Instance().data.clientStrings;
                leg_txt.Text = ProManage.Instance().data.barleng.ToString();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (ProManage.Instance().data != null)
            {
                GroupForm form = new GroupForm();
                form.ShowDialog();
            }
        }
    }
}
