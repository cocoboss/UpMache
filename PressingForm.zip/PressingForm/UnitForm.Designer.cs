﻿namespace PressingForm
{
    partial class UnitForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGrid = new DataGridView();
            名称 = new DataGridViewTextBoxColumn();
            地址 = new DataGridViewTextBoxColumn();
            数据长度 = new DataGridViewTextBoxColumn();
            数据类型 = new DataGridViewTextBoxColumn();
            变量名 = new DataGridViewTextBoxColumn();
            绑定ID = new DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)dataGrid).BeginInit();
            SuspendLayout();
            // 
            // dataGrid
            // 
            dataGrid.BackgroundColor = Color.White;
            dataGrid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGrid.Columns.AddRange(new DataGridViewColumn[] { 名称, 地址, 数据长度, 数据类型, 变量名, 绑定ID });
            dataGrid.Dock = DockStyle.Fill;
            dataGrid.Location = new Point(0, 0);
            dataGrid.Name = "dataGrid";
            dataGrid.RowHeadersWidth = 82;
            dataGrid.Size = new Size(823, 480);
            dataGrid.TabIndex = 0;
            // 
            // 名称
            // 
            名称.HeaderText = "名称";
            名称.MinimumWidth = 10;
            名称.Name = "名称";
            名称.Width = 200;
            // 
            // 地址
            // 
            地址.HeaderText = "地址";
            地址.MinimumWidth = 10;
            地址.Name = "地址";
            地址.Width = 200;
            // 
            // 数据长度
            // 
            数据长度.HeaderText = "数据长度";
            数据长度.MinimumWidth = 10;
            数据长度.Name = "数据长度";
            数据长度.Width = 200;
            // 
            // 数据类型
            // 
            数据类型.HeaderText = "数据类型";
            数据类型.MinimumWidth = 10;
            数据类型.Name = "数据类型";
            数据类型.Width = 200;
            // 
            // 变量名
            // 
            变量名.HeaderText = "变量名";
            变量名.MinimumWidth = 10;
            变量名.Name = "变量名";
            变量名.Width = 200;
            // 
            // 绑定ID
            // 
            绑定ID.HeaderText = "绑定ID";
            绑定ID.MinimumWidth = 10;
            绑定ID.Name = "绑定ID";
            绑定ID.Width = 200;
            // 
            // UnitForm
            // 
            AutoScaleDimensions = new SizeF(19F, 41F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(823, 480);
            Controls.Add(dataGrid);
            FormBorderStyle = FormBorderStyle.None;
            Name = "UnitForm";
            Text = "UnitForm";
            Load += UnitForm_Load;
            ((System.ComponentModel.ISupportInitialize)dataGrid).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dataGrid;
        private DataGridViewTextBoxColumn 名称;
        private DataGridViewTextBoxColumn 地址;
        private DataGridViewTextBoxColumn 数据长度;
        private DataGridViewTextBoxColumn 数据类型;
        private DataGridViewTextBoxColumn 变量名;
        private DataGridViewTextBoxColumn 绑定ID;
    }
}