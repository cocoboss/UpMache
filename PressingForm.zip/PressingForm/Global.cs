﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
namespace PressingForm
{
    public class Global
    {
        public static string exePath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
        [DllImport("winmm")]
        public static extern uint timeGetTime();
        [DllImport("winmm")]
        public static extern void timeBeginPeriod(int t);
        [DllImport("winmm")]
        public static extern void timeEndPeriod(int t);

        private static object lockobj = new object();
        public static Dictionary<int, string> LodPosIni(string path)
        {
            Dictionary<int, string> Dicpos = new Dictionary<int, string>();
            if (File.Exists(path))
            {
                var datas = File.ReadAllLines(path);
                foreach (var item in datas)
                {
                    var line = item.Trim();
                    if (!string.IsNullOrEmpty(line) && line.Contains("="))
                    {
                        var fir = line.Split('=');
                        if (int.TryParse(fir[0], out int no))
                        {
                            if (!Dicpos.ContainsKey(no))
                                Dicpos.Add(no, fir[1]);
                        }
                    }
                }
            }
            return Dicpos;
        }
        public static List<string> ToList(Dictionary<int, string> item)
        {
            var list = new List<string>();
            foreach (var item2 in item)
            {
                list.Add(item2.Value);
            }
            return list;
        }
        public static void ControlInvocke(Control contrl, Action act)
        {
            // DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            if (contrl.InvokeRequired)
            {
                contrl.Invoke(act);
            }
            else
            {
                act();
            }
        }

        public static bool DataSave(string strFilePath, string strBufferLine)
        {
            try
            {
                lock (lockobj)
                {

                    using (StreamWriter strmWriterObj = new StreamWriter(strFilePath, true, System.Text.Encoding.UTF8))
                    {
                        strmWriterObj.WriteLine(strBufferLine);
                        strmWriterObj.Flush();
                        strmWriterObj.Close();
                    }
                }
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }
        public static string ConnectionString
        {
            get
            {
                return $"Data Source ={exePath}\\cfg\\" + ConfigurationManager.AppSettings["dbfile"];
            }
        }

        /// <summary>
        /// 权限控制
        /// </summary>
        /// <param name="type">是否有读取或写入或都没有的操作权限</param>
        /// <param name="item">在这个控件内都受限制</param>
        public static void ControlEnable(bool type, Control.ControlCollection item)
        {
            if (item.Count > 0)
            {
                for (int i = 0; i < item.Count; i++)
                {
                    item[i].Enabled = type;
                    ControlEnable(type, item[i].Controls);
                }
            }
        }

        public static bool MonitorMethod(Action method, int timeoutMs)
        {
            Stopwatch stopwatch = Stopwatch.StartNew();
            method();
            stopwatch.Stop();

            return stopwatch.ElapsedMilliseconds > timeoutMs;
        }

        /// <summary>
        /// 异步监测一个异步/同步方法是否在指定超时时间内完成（默认 500ms）。
        /// 返回值：如果在超时内完成则返回 true；若超时未完成则返回 false（方法仍可能在后台继续运行）。
        /// statusCallback 在到达 timeoutMs 时间点被调用，参数表示此时方法是否已完成（true = 已完成）。
        /// 如果被监测的方法在超时内完成并抛出异常，该异常会在此方法 await 时向上抛出。
        /// </summary>
        public static async Task<bool> MonitorCompletionAsync(Func<Task> work, int timeoutMs = 500, Action<bool>? statusCallback = null, CancellationToken cancellationToken = default)
        {
            if (work == null) throw new ArgumentNullException(nameof(work));
            // 在线程池中启动被监测任务（避免阻塞调用线程）
            //var workTask = Task.Run(() => work(), cancellationToken).Unwrap();
            var workTask = work();
            var delayTask = Task.Delay(timeoutMs, cancellationToken);

            // 等待任意一个先完成
            var first = await Task.WhenAny(workTask, delayTask).ConfigureAwait(false);
            bool finishedAtCheck = first == workTask;

            // 回调通知在 timeoutMs 时是否已完成（回调自己应处理异常）
            try
            {
                statusCallback?.Invoke(finishedAtCheck);
            }
            catch
            {
                return false;
                // 忽略回调内异常，避免影响监测逻辑
            }

            if (finishedAtCheck)
            {
                // 在这里等待以便将异常/结果传播给调用者
                await workTask.ConfigureAwait(false);
            }

            return finishedAtCheck;
        }

        /// <summary>
        /// 同步方法的便利重载：将 Action 包装为任务并调用上面的 MonitorCompletionAsync。
        /// </summary>
        public static Task<bool> MonitorCompletionAsync(Action action, int timeoutMs = 500, Action<bool>? statusCallback = null, CancellationToken cancellationToken = default)
        {
            if (action == null) throw new ArgumentNullException(nameof(action));
            return MonitorCompletionAsync(() => Task.Run(action, cancellationToken), timeoutMs, statusCallback, cancellationToken);
        }

        /// <summary>
        /// 在指定超时时间内监测并在超时后请求取消被监测任务（被监测任务需支持 CancellationToken）。
        /// 返回值：如果在 timeoutMs 内完成返回 true；否则返回 false（并尝试请求取消）。
        /// statusCallback 在 timeoutMs 到达时被调用，参数表示该时刻是否已完成（true = 已完成）。
        /// </summary>
        public static async Task<bool> MonitorAndCancelAsync(Func<CancellationToken, Task> work, int timeoutMs = 500, Action<bool>? statusCallback = null, CancellationToken cancellationToken = default)
        {
            if (work == null) throw new ArgumentNullException(nameof(work));

            // 可链接外部传入的 cancellationToken，以便调用方也能取消整个监测流程
            using var cts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);

            // 在线程池中启动被监测任务，传入可取消的 token
            var workTask = Task.Run(() => work(cts.Token), CancellationToken.None);

            // 用于超时检测的延迟（不接受外部取消，保证在指定时间点触发检查）
            var delayTask = Task.Delay(timeoutMs, CancellationToken.None);

            var first = await Task.WhenAny(workTask, delayTask).ConfigureAwait(false);
            bool finishedAtCheck = first == workTask;

            try
            {
                statusCallback?.Invoke(finishedAtCheck);
            }
            catch
            {
                // 忽略回调异常
            }

            if (!finishedAtCheck)
            {
                // 超时：请求取消（依赖被测方法响应 token）
                try
                {
                    cts.Cancel();
                }
                catch
                {
                    // 忽略 Cancel 异常
                }

                // 给被测任务一点“缓冲”时间来响应取消（可调整或移除）
                var grace = Task.Delay(100, CancellationToken.None);
                await Task.WhenAny(workTask, grace).ConfigureAwait(false);

                // 无论被测任务是否真的停止，都返回 false 表示未在 timeoutMs 内完成
                return false;
            }
            else
            {
                // 在超时前完成：等待以便将异常传播给调用方
                await workTask.ConfigureAwait(false);
                return true;
            }
        }

        /// <summary>
        /// 方便重载：同步方法（接受 CancellationToken）包装成 Task 并调用 MonitorAndCancelAsync。
        /// </summary>
        public static Task<bool> MonitorAndCancelAsync(Action<CancellationToken> action, int timeoutMs = 500, Action<bool>? statusCallback = null, CancellationToken cancellationToken = default)
        {
            if (action == null) throw new ArgumentNullException(nameof(action));
            return MonitorAndCancelAsync(ct => Task.Run(() => action(ct), CancellationToken.None), timeoutMs, statusCallback, cancellationToken);
        }

        //public static void SaveConfig(string key, string val)
        //{
        //    string configPath = AppDomain.CurrentDomain.SetupInformation.ConfigurationFile;

        //    // 加载配置文件
        //    ExeConfigurationFileMap fileMap = new ExeConfigurationFileMap { ExeConfigFilename = configPath };
        //    Configuration config = ConfigurationManager.OpenMappedExeConfiguration(fileMap, ConfigurationUserLevel.None);

        //    // 检查该配置项是否存在，如果存在则修改它，否则添加它
        //    if (config.AppSettings.Settings[key] != null)
        //    {
        //        config.AppSettings.Settings[key].Value = val;
        //    }
        //    else
        //    {
        //        config.AppSettings.Settings.Add(key, val);
        //    }

        //    // 保存修改后的配置文件
        //    config.Save(ConfigurationSaveMode.Modified);

        //    // 强制重新加载配置节以反映更改（可选）
        //    ConfigurationManager.RefreshSection("appSettings");
        //}
    }
}
