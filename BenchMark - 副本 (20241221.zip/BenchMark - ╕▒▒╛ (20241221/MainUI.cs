﻿//using csLTDMC;
//using DXT_VisionToolBase.Factory;
//using DXT_VisionToolBase.Frm;
//using DXT_VisionToolBase.Manager;
//using DXT_VisionToolBase.Scheduling;
//using DXTCommonUtil;
//using DXTCommonUtil.UI;
//using DXTCommonUtil.Setting;
//using HalconDotNet;
//using ScreeningMachine.Common;
//using ScreeningMachine.Data;
//using ScreeningMachine.Manager;
//using ScreeningMachine.Properties;
//using ScreeningMachine.UI;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//using NPOI.HSSF.UserModel;
//using NPOI.SS.Formula.Functions;
//using NPOI.SS.UserModel;
//using NPOI.XSSF.UserModel;
//using Org.BouncyCastle.Bcpg;
//using MessageBox = System.Windows.Forms.MessageBox;
using Size = System.Drawing.Size;
//using NPOI.OpenXmlFormats.Vml;
//using System.Data.Entity;
using System.Reflection;

namespace BenchMark
{
    public partial class MainUI : Form
    {
        //AutoSizeFormClass autoSizePanel3 = new AutoSizeFormClass();
        //AutoSizeFormClass autoSizePanel4 = new AutoSizeFormClass();
        //public SMCameraHandle cameraHandle = new SMCameraHandle();
        public int tiggerMode = 1;//0内触发，1外触发
        private static MainUI _Instance;
        //private static EquipmentUI IO;
        //private RunState runState = RunState.RunState_Stop;
        //private FunMenu funMenu1 = new FunMenu();
        //private WorkUI workUI = new WorkUI();
        //private ParameteUI parameteUI = new ParameteUI();
        //private Datashow datashow = new Datashow();
        private float oldWidth;
        private float oldHeight;
        //public SMProjectData projectData = new SMProjectData();
        public bool closingprocess = false;
        bool loading = false;
        #region 临时保存

        UserControl panel4Control = null;
        UserControl panel2Control = null;
        private bool uirun = false; //解决启动 MainUI_Resize（）报错
        string beformessage = "1";
        string alarmmesage = "";
        string machinemessage = "";
        string postionmessage = "";
        string packingmessage = "";

        List<string> CCD0 = new List<string>();
        List<string> CCD1 = new List<string>();
        List<string> CCD2 = new List<string>();
        List<string> CCD3 = new List<string>();
        List<string> CCD4 = new List<string>();
        List<string> CCD5 = new List<string>();
        List<string> CCD6 = new List<string>();
        List<string> CCD7 = new List<string>();
        List<string> CCD8 = new List<string>();
        List<List<string>> CCDS = new List<List<string>>();
        #endregion
        public static string DateString()
        {
            DateTime date = DateTime.Now;
            string tmp = "" + date.Year;
            tmp += (date.Month < 10 ? "0" : "") + date.Month;
            tmp += (date.Day < 10 ? "0" : "") + date.Day;
            return tmp;
        }
        public MainUI()
        {
            Stopwatch watch = new Stopwatch();
            watch.Restart();
            //SplashScreen.Splasher.AppName = IniStatus.Instance.ProjectName;
            //SplashScreen.Splasher.Icon = Image.FromFile(@"Vison.ico");
            //SplashScreen.Splasher.Show();

            _Instance = this;
            InitializeComponent();
            CCDS.Add(CCD0);
            CCDS.Add(CCD1);
            CCDS.Add(CCD2);
            //CCDS.Add(CCD3);
            //CCDS.Add(CCD4);
            //CCDS.Add(CCD5);
            //CCDS.Add(CCD6);
            //CCDS.Add(CCD7);
            //CCDS.Add(CCD8);
            SetStyle(ControlStyles.UserPaint, true);
            SetStyle(ControlStyles.AllPaintingInWmPaint, true); // 禁止擦除背景.
            SetStyle(ControlStyles.DoubleBuffer, true); // 双缓冲

            //Machine.param = new SMDataMachineParam();

            //SetStyle();
            //SoftKey.D8 mD8 = new SoftKey.D8();
            //string KeyPath = "";
            //int LastErr = mD8.FindD8(0, "7E05333B522C0108", ref KeyPath);
            //if (LastErr != 0)
            //{
            //    LogHelper.Error(LastErr.ToString());
            //    MessageHelper.ShowTips("请联系管理员!!!");
            //    Process.GetCurrentProcess().Kill();
            //    return;
            //}
            //LastErr = new SoftKey.CRun().LimitDateTest(KeyPath);
            //if (LastErr != 0)
            //{
            //    LogHelper.Error(LastErr.ToString());
            //    MessageHelper.ShowTips("请联系管理员!!!");
            //    Process.GetCurrentProcess().Kill();
            //    return;
            //}
            //int cuttentTime = int.Parse(DateString());//现在的时间
            //if ((cuttentTime >= 20240708 || cuttentTime < 20240508))
            //{

            //    MessageHelper.ShowTips("请联系管理员!!!");
            //    Process.GetCurrentProcess().Kill();
            //    return;

            //}
            //panel2.Controls.Add(funMenu1);
            //funMenu1.RegistConfig(Environment.CurrentDirectory + "/Config/FunMenu.json");
            //autoSizePanel3.controllInitializeSize(panel3);
            //autoSizePanel4.controllInitializeSize(panel4);
            SubscribeEvent();

            Width = SystemInformation.WorkingArea.Width;
            Height = SystemInformation.WorkingArea.Height;

            //if (IniStatus.Instance.LastProjectFile != "")
            //{
            //    if (FileOptHelp.FileExist(IniStatus.Instance.LastProjectFile))
            //    {
            //        LoadProject(IniStatus.Instance.LastProjectFile);

            //        if (IniStatus.Instance.EnableDeepLearn)
            //        {
            //            if (!cameraHandle.CheckEnableDeepLearnInit())
            //            {
            //                MessageHelper.ShowTips("项目启动出错了, 请重新启动!!!");
            //                Process.GetCurrentProcess().Kill();
            //                return;
            //            }
            //        }
            //    }
            //}

            ////this.frmDataResultShow.Visible = false;
            //if (projectData == null || projectData.SMDataCount() == 0)
            //{
            //    tsmiNew_Click(null, null); //初始化数据 相当于新建数据
            //}
            //else
            //{
            //    cameraHandle.Start();
            //}

            //this.lblCOMPANY.Text = IniStatus.Instance.FactoryName;
            InitUI();
            label_user.Text = "当前操作权限 : " + "" + "操作员";
            //datashow.PgdShowData(projectData.GetSMDataByName("Machine.station"));
            //datashow.PgdShow();
            uirun = true;
            //Machine.Initialize();

            this.timer1.Enabled = true;
            this.timer1.Stop();
            //this.timer1.Interval = IniStatus.Instance.ShowRefreshRate;
            this.timer1.Start();

            BindTestButton();
            //EventMgr.Instance.DispatchEvent("相机数量修改");
            //LogHelper.Info("启动用时 " + watch.ElapsedMilliseconds);
        }

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams paras = base.CreateParams;
                paras.ExStyle |= 0x02000000;
                return paras;
            }
        }

        //public CameraSetting GetCurProjectDataCameraSetting()
        //{
        //    return projectData.CameraSetting;
        //}

        //public RunState RunState
        //{
        //    get { return runState; }
        //}


        public void BindTestButton()
        {
            //EventMgr.Instance.AddEventListener("连续测试", (a, b) =>
            //{
            //    if (!Machine.inited) return;
            //    Machine.Camerastop();
            //    Machine.Cameralianxu(Machine.cameraID);
            //});
            //EventMgr.Instance.AddEventListener("单次测试", (a, b) =>
            //{
            //    if (!Machine.inited) return;
            //    Machine.Camerastop();
            //    Machine.Cameraone(Machine.cameraID);
            //});
            //EventMgr.Instance.AddEventListener("关闭相机", (a, b) =>
            //{
            //    if (!Machine.inited) return;
            //    Machine.Camerastop();
            //});
            //EventMgr.Instance.AddEventListener("机器自动启动", (a, b) => { btnStart_Click(null, null); });
            //EventMgr.Instance.AddEventListener("机器自动停止", (a, b) => { btnStop_Click(null, null); });
            ////EventMgr.Instance.AddEventListener("激磁", (a, b) => { Machine.motionControlCard.AxisEnable(true); });
            ////EventMgr.Instance.AddEventListener("释放", (a, b) => { Machine.motionControlCard.AxisEnable(false); });
            //EventMgr.Instance.AddEventListener("单个文件测试", (a, b) =>
            //{
            //    string fileName = b as string;
            //    HObject hBmp;
            //    HTuple hv_Width = new HTuple(), hv_Height = new HTuple();
            //    HOperatorSet.GenEmptyObj(out hBmp);
            //    hBmp.Dispose();
            //    HOperatorSet.ReadImage(out hBmp, fileName);

            //    var optList = cameraHandle.GetAllOpt2();

            //    {
            //        Action<int> fun = (int index) =>
            //        {
            //            string result = optList[index].Apply(hBmp, true);
            //            EventMgr.Instance.DispatchEvent("NormalSample",
            //                new SMCameraSimpleData { hBmp = hBmp, index = index, bOK = result == "OK" });
            //        };
            //        fun(Machine.cameraID);
            //    }
            //});

            //EventMgr.Instance.AddEventListener("相机数量修改", (a, b) =>
            //{
            //    var cameraSetting = MainUI.Instance.GetCurProjectDataCameraSetting();
            //    int cameraCount = cameraSetting.Count;
            //    IniStatus.Instance.CamearCount = cameraSetting.Count;
            //    for (int i = 0; i < cameraCount; i++)
            //    {
            //        projectData.AddSMDataByName("CCD" + (i + 1), OptCode.OptCode_VisionScreening);
            //    }

            //    CameraUIBinding();
            //});
        }

        //public HWndUnit getWndUnitByIndex(int index)
        //{
        //    return this.workUI.getWndUnitByIndex(index);
        //}

        void UpdatePanel4(UserControl control)
        {
            if (control == null || panel4Control == control)
            {
                return;
            }

            panel4Control = control;
            this.panel4.Controls.Clear();
            this.panel4.Controls.Add(control);
            control.Size = this.panel4.Size;
            control.Anchor =
                ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top |
                                                        System.Windows.Forms.AnchorStyles.Bottom)
                                                       | System.Windows.Forms.AnchorStyles.Left)
                                                      | System.Windows.Forms.AnchorStyles.Right)));
        }

        void UpdatePanel2(UserControl control)
        {
            //if (control == null || panel2Control == control)
            //{
            //    return;
            //}

            //panel2Control = control;
            //this.panel2.Controls.Clear();
            //this.panel2.Controls.Add(control);
            //control.Size = this.panel2.Size;
            //control.Anchor =
            //    ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top |
            //                                            System.Windows.Forms.AnchorStyles.Bottom)
            //                                           | System.Windows.Forms.AnchorStyles.Left)
            //                                          | System.Windows.Forms.AnchorStyles.Right)));
        }

        void SubscribeEvent()
        {
            //EventMgr.Instance.AddEventListener("UpdataMainPanel", this.UpdataMainPanel);
        }

        public static MainUI Instance
        {
            get
            {
                if (_Instance == null)
                {
                    _Instance = new MainUI();
                }

                return _Instance;
            }
        }

        void SetStyle()
        {
            SetButtonMouseOverState(this.btnClose);
            //SetButtonMouseOverState(this.btn_max);
            //SetButtonMouseOverState(this.btn_min);
        }


        private void MainUI_Shown(object sender, EventArgs e)
        {
            this.oldHeight = this.Height;
            this.oldWidth = this.Width;

            //SplashScreen.Splasher.Close();
        }

        void UpdataMainPanel(string name, Object uData)
        {
            //ChildMenu childMenu = uData as ChildMenu;
            //if (childMenu != null)
            //{
            //    SMDataBase proData = null;
            //    bool bSava = false;
            //    switch (childMenu.optCode)
            //    {
            //        case OptCode.OptCode_VisionScreening:
            //            {
            //                proData = projectData.AddSMDataByName("" + childMenu.name, childMenu.optCode);
            //                cameraHandle.SetupVisionData2(childMenu.relevanceCameraID, proData as SMVisionData);
            //                Machine.cameraID = childMenu.relevanceCameraID;
            //                Machine.cameraindx = childMenu.relevanceCameraID;
            //                cameraHandle.Start();
            //                cameraHandle.StartAsynTask();
            //                bSava = true;
            //            }
            //            break;
            //    }

            //    if (proData == null)
            //    {
            //        return;
            //    }

            //    if (childMenu.optType == OptType.OptType_Window)
            //    {
            //        Form form = proData.GetStandAloneWnd();
            //        form.ShowDialog();
            //        if (bSava)
            //        {
            //            if (MessageBox.Show("是否保存当前设置？", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) ==
            //                DialogResult.Yes)
            //            {
            //                btnSave_Click(null, null);
            //            }
            //        }
            //    }
            //    else
            //    {
            //        UserControl control = proData.GetImplantWnd();
            //        UpdatePanel4(control);
            //    }
            //}
        }


        void InitUI()
        {
            //funMenu1.Anchor =
            //    ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top |
            //                                            System.Windows.Forms.AnchorStyles.Bottom)
            //                                           | System.Windows.Forms.AnchorStyles.Left)
            //                                          | System.Windows.Forms.AnchorStyles.Right)));
            //funMenu1.Size = panel2.Size;
            //funMenu1.InitMenu();
            //UpdatePanel4(workUI);
            //UpdatePanel2(datashow);
        }

        #region 菜单和工具条

        private void btn_min_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        /// <summary>
        /// 窗体缩放事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void menuStrip1_DoubleClick(object sender, EventArgs e)
        {
            if (this.MinimumSize == this.MaximumSize && this.MinimumSize != new Size(0, 0))
                return;

            if (this.WindowState == FormWindowState.Normal)
            {
                this.WindowState = FormWindowState.Maximized;
                //  btn_max.BackgroundImage = Resources.max;
            }
            else if (this.WindowState == FormWindowState.Maximized)
            {
                this.WindowState = FormWindowState.Normal;
                //  btn_max.BackgroundImage = Resources.max2;
            }
        }

        private void MainUI_Resize(object sender, EventArgs e)
        {
            if (uirun)
            {
                //workUI.Size = this.panel4.Size;
                //funMenu1.Size = this.panel2.Size;
                //autoSizePanel3.controlAutoSize(this.panel3);
                ////autoSizePanel4.controlAutoSize(this.panel4);
                //panel4Control.Size = this.panel4.Size;
                ////panel4Control.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                //| System.Windows.Forms.AnchorStyles.Left)
                //| System.Windows.Forms.AnchorStyles.Right)));
            }
        }

        void SetButtonMouseOverState(Button btn)
        {
            btn.FlatAppearance.MouseOverBackColor = Color.Transparent;
            btn.FlatAppearance.MouseDownBackColor = Color.Transparent;
        }

        #endregion

        #region 窗体拖动

        private static bool IsDrag = false;
        private int enterX;
        private int enterY;

        private void setForm_MouseDown(object sender, MouseEventArgs e)
        {
            IsDrag = true;
            enterX = e.Location.X;
            enterY = e.Location.Y;
        }

        private void setForm_MouseUp(object sender, MouseEventArgs e)
        {
            IsDrag = false;
            enterX = 0;
            enterY = 0;
        }

        private void setForm_MouseMove(object sender, MouseEventArgs e)
        {
            if (IsDrag)
            {
                Left += e.Location.X - enterX;
                Top += e.Location.Y - enterY;
            }
        }

        #endregion

        #region 窗体缩放

        private const int WM_NCHITTEST = 0x0084; //鼠标在窗体客户区（除标题栏和边框以外的部分）时发送的信息
        const int HTLEFT = 10; //左变
        const int HTRIGHT = 11; //右边
        const int HTTOP = 12;
        const int HTTOPLEFT = 13; //左上
        const int HTTOPRIGHT = 14; //右上
        const int HTBOTTOM = 15; //下
        const int HTBOTTOMLEFT = 0x10; //左下
        const int HTBOTTOMRIGHT = 17; //右下

        System.Drawing.Point vPoint = System.Drawing.Point.Empty;

        //自定义边框拉伸
        protected override void WndProc(ref Message m)
        {
            try
            {
                base.WndProc(ref m);
                switch (m.Msg)
                {
                    case WM_NCHITTEST:
                        vPoint = new System.Drawing.Point((int)m.LParam & 0xFFFF, (int)m.LParam >> 16 & 0xFFFF);
                        vPoint = PointToClient(vPoint);
                        if (vPoint.X <= 5)
                            if (vPoint.Y <= 5)
                                m.Result = (IntPtr)HTTOPLEFT; //左上
                            else if (vPoint.Y >= this.ClientSize.Height - 5)
                                m.Result = (IntPtr)HTBOTTOMLEFT; //左下
                            else
                                m.Result = (IntPtr)HTLEFT; //左边
                        else if (vPoint.X >= this.ClientSize.Width - 5)
                            if (vPoint.Y <= 5)
                                m.Result = (IntPtr)HTTOPRIGHT; //右上
                            else if (vPoint.Y >= this.ClientSize.Height - 5)
                                m.Result = (IntPtr)HTBOTTOMRIGHT; //右下
                            else
                                m.Result = (IntPtr)HTRIGHT; //右
                        else if (vPoint.Y <= 5)
                            m.Result = (IntPtr)HTTOP; //上
                        else if (vPoint.Y >= this.ClientSize.Height - 5)
                            m.Result = (IntPtr)HTBOTTOM; //下

                        else
                        {
                            base.WndProc(ref m); //如果去掉这一行代码,窗体将失去MouseMove..等事件
                            System.Drawing.Point
                                lpint = new System.Drawing.Point(
                                    (int)m.LParam); //可以得到鼠标坐标,这样就可以决定怎么处理这个消息了,是移动窗体,还是缩放,以及向哪向的缩放

                            m.Result = (IntPtr)0x2; //托动HTCAPTION=2 <0x2>
                        }

                        break;
                }
            }
            catch
            {
            }
        }

        #endregion


        /// <summary>
        /// 数据统计
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
            //if (runState != RunState.RunState_Stop)
            //{
            //    //MessageHelper.ShowTips("已经在运行了");
            //    return;
            //}

            ////cameraHandle.Test();
            //runState = RunState.RunState_Statistics;
            //datashow.PgdShowData(Machine.station);
            //UpdatePanel2(datashow);
            //UpdatePanel4(workUI);
            //if (!Machine.runState)
            //{
            //    cameraHandle.Start();
            //    Machine.Runstart();
            //}
        }

        /// <summary>
        /// 数据保存
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button2_Click(object sender, EventArgs e)
        {
            //if (runState == RunState.RunState_Stop)
            //{
            //    //MessageHelper.ShowTips("已经在停止了");
            //    return;
            //}

            Stop_opt();
            //DataCollectionHandle.Instance.SaveData();
        }


        private int LastStatisticsTime = 0;
        //async void RefreshStatistics()
        //{


            //if (!Machine.runState || !IniStatus.Instance.SaveStatisticTotalData)
            //{
            //    return;

            //}

            //DateTime currentTime = new System.DateTime();
            //if (currentTime.Millisecond - LastStatisticsTime > 1000)
            //{
            //    LastStatisticsTime = currentTime.Millisecond;
            //}
            //else
            //{
            //    LogHelper.Debug(string.Format("RefreshStatistics  < 5000 {0}   {1}", currentTime.Millisecond - LastStatisticsTime, IniStatus.Instance.SaveStatisticTotalData));
            //    return;
            //}

            //LogHelper.Debug("RefreshStatistics Enter");
            //var dt = new DataTable();
            //List<String> opNames = new List<string>() { "产品料号", "总数", "合格率%", "产能(个/分钟)", "峰值(个/分钟)", " NG数量", " OK数量", " 回收数量" };
            //foreach (var name in opNames)
            //{
            //    DataColumn dc1 = new DataColumn(name);
            //    dt.Columns.Add(dc1);
            //}

            //DataRow drTop = dt.NewRow();
            //drTop[0] = Machine.station.partNumber;
            //drTop[1] = Machine.station.totalCount;
            //drTop[2] = Machine.station.passRate;
            //drTop[3] = Machine.station.outputCount;
            //drTop[4] = Machine.station.PeakCount;
            //drTop[5] = Machine.station.zhuanpan_1_NG_count;
            //drTop[6] = Machine.station.zhuanpan_1_OK_count;
            //drTop[7] = Machine.station.zhuanpan_1_Recovery_count;

            //dt.Rows.Add(drTop);
            //LogHelper.Info("RefreshStatistics Start");

            //IWorkbook workbook;
            //ISheet sheet;
            //if (FileOptHelp.FileExist(IniStatus.Instance.StatisticsShowSavePath))
            //{
            //    using (FileStream streamF = new FileStream(IniStatus.Instance.StatisticsShowSavePath, FileMode.Append,
            //               FileAccess.ReadWrite))
            //    {
            //        workbook = new XSSFWorkbook(streamF);
            //        sheet = workbook.GetSheetAt(0);
            //    }
            //}
            //else
            //{
            //    string fileExt = Path.GetExtension(IniStatus.Instance.StatisticsShowSavePath).ToLower();
            //    if (fileExt == ".xlsx")
            //    {
            //        workbook = new XSSFWorkbook();
            //    }
            //    else if (fileExt == ".xls")
            //    {
            //        workbook = new HSSFWorkbook();
            //    }
            //    else
            //    {
            //        workbook = null;
            //    }

            //    if (workbook == null)
            //    {
            //        return;
            //    }

            //    sheet = workbook.CreateSheet("Sheet1");
            //    //表头  
            //    IRow row = sheet.CreateRow(0);
            //    for (int i = 0; i < opNames.Count; i++)
            //    {
            //        ICell cell = row.CreateCell(i);
            //        cell.SetCellValue(opNames[i]);
            //        sheet.SetColumnWidth(i, (int)(2.5 * 256));
            //    }

            //    sheet.SetColumnWidth(0, 4 * 256);
            //    sheet.SetMargin(MarginType.LeftMargin | MarginType.TopMargin, 0);
            //    //sheet.SetZoom(80, 100);



            //}


            //for (int i = 0; i < dt.Rows.Count; i++)
            //{
            //    IRow row1 = sheet.CreateRow(i + 1);
            //    for (int j = 0; j < dt.Columns.Count; j++)
            //    {
            //        ICell cell = row1.CreateCell(j);
            //        cell.SetCellValue(dt.Rows[i][j].ToString());
            //    }
            //}

            ////转为字节数组  
            //MemoryStream stream = new MemoryStream();
            //workbook.Write(stream);
            //var buf = stream.ToArray();

            ////保存为Excel文件  
            //using (FileStream fs = new FileStream(IniStatus.Instance.StatisticsShowSavePath, FileMode.Append, FileAccess.Write))
            //{
            //    var writeTask = Task.Factory.FromAsync(fs.BeginWrite, fs.EndWrite, buf, 0, buf.Length, null);

            //    await writeTask;
            //}

            //LogHelper.Info("RefreshStatistics End");
        //}

        private void Timer_Tick(object sender, EventArgs e)
        {
            //if (Machine.resetrun)
            //{
            //    Machine.resetrun = false;
            //    this.timer1.Stop();
            //    //this.timer1.Interval = IniStatus.Instance.ShowRefreshRate;
            //    this.timer1.Start();

            //    g_tool2NG_samll.Clear();
            //    g_tool2Total.Clear();
            //    g_tool2NG.Clear();
            //    g_tool2NGRatio.Clear();
            //    g_tool2NGRatio_more.Clear();
            //    g_tool2NG_more.Clear();

            //    Machine.MachineInitialize();
            //    cameraHandle.ClearTempData();
            //    Machine.Camerastop();

            //    datashow.PgdShowData(Machine.station);
            //    UpdatePanel2(datashow);
            //    UpdatePanel4(workUI);
            //    //CameraUIBinding(); //界面邦定
            //    parameteUI.Hide();
            //    if (IO != null)
            //    {
            //        IO.Close();
            //    }

            //    if (!Machine.runState)
            //    {
            //        cameraHandle.Start();
            //        Machine.Runstart();
            //    }


            //}

            //packingmessage = "";



            //datashow.PgdShowData(Machine.station);
            //alarmmesage = "报警信息：" + Machine.alarmmesage;
            //if (alarmmesage != "")
            //{
            //    alarmmesage = "报警信息：" + Machine.alarmmesage;
            //}
            //else
            //{
            //    alarmmesage = "";
            //}

            //if (!Machine.runState)
            //{
            //    machinemessage = "设备状态：机器停止运行！" + packingmessage;
            //    double encPos = Machine.zhuanpan.GetEncPos();
            //    postionmessage = string.Concat("当前位置：", encPos.ToString());

            //}
            //else
            //{
            //    machinemessage = "设备状态：机器正在运行！" + packingmessage;
            //    postionmessage = string.Concat("当前位置：", Machine.zhuanpan1_NowPos.ToString());

            //}

            //if (alarmmesage != beformessage)
            //{
            //    labmessage.Text = alarmmesage;
            //    beformessage = alarmmesage;
            //}

            //labpos.Text = string.Concat(new string[] { "产品宽度：", Machine.dMCSort.pieceWidth.ToString(), "    ", postionmessage, "    相机运行时间：", SMCameraHandle.GetVisionTime() });
            ////labpos.Text = "    " + postionmessage + "    相机运行时间：" + SMCameraHandle.GetVisionTime();
            //labinformation.Text = machinemessage;
            //Machine.PassRate();

            //RefreshStatistics();
        }

        private void 统计数据清零ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //if (MessageBox.Show("是否确定机器统计数据清零？", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) ==
            //    DialogResult.Yes)
            //{
            //    cameraHandle.ClearData();
            //    Machine.ParamClearData();
            //}
        }


        private void 数据统计ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //if (runState != RunState.RunState_Stop)
            //{
            //    //MessageHelper.ShowTips("已经在运行了");
            //    return;
            //}

            ////cameraHandle.Test();
            //runState = RunState.RunState_Statistics;
            //datashow.PgdShowData(Machine.station);
            //UpdatePanel2(datashow);
            //UpdatePanel4(workUI);
            //if (!Machine.runState)
            //{
            //    cameraHandle.Start();
            //    Machine.Runstart();
            //}
        }

        private void 数据保存ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //if (runState == RunState.RunState_Statistics)
            //{
            //    //MessageHelper.ShowTips("已经在停止了");
            //    return;
            //}

            //Stop_opt();
            //DataCollectionHandle.Instance.SaveData();
        }

        private void MainUI_Load(object sender, EventArgs e)
        {
            // labmessage.Text="信息：软件已打开请加载项目或则新建项目！";
        }


        Dictionary<string, double> g_tool2Total = new Dictionary<string, double>();
        Dictionary<string, double> g_tool2NG = new Dictionary<string, double>();
        Dictionary<string, double> g_tool2NG_more = new Dictionary<string, double>();
        Dictionary<string, double> g_tool2NGRatio = new Dictionary<string, double>();
        Dictionary<string, double> g_tool2NGRatio_more = new Dictionary<string, double>();
        Dictionary<string, double> g_tool2NG_samll = new Dictionary<string, double>();
        //List<ShowResultObj> preShowResultObjList = new List<ShowResultObj>();

        private void timer1_Tick(object sender, EventArgs e)
        {
            //try
            //{
            //    int cameraCount = IniStatus.Instance.CamearCount;
            //    Dictionary<string, double> tool2Total = new Dictionary<string, double>();
            //    Dictionary<string, double> tool2NG = new Dictionary<string, double>();
            //    Dictionary<string, double> tool2Ratio = new Dictionary<string, double>();
            //    ShowResultObj item = null;
            //    if (runState == RunState.RunState_Stop)
            //    {
            //        if (this.timer1.Interval != 100)
            //        {
            //            this.timer1.Stop();
            //            this.timer1.Interval = 100;
            //            this.timer1.Start();
            //        }

            //        if (preShowResultObjList.Count == 0)
            //        {
            //            for (int i = 0; i < cameraCount; i++)
            //            {
            //                preShowResultObjList.Add(null);
            //            }
            //        }

            //        for (int i = 0; i < cameraCount; i++)
            //        {
            //            item = null;
            //            while (true)
            //            {
            //                var item_1 = ShowResultManager.GetShowResultObj(i);
            //                if (item_1 != null)
            //                {
            //                    if (item != null)
            //                    {
            //                        item.Clear();
            //                        item = null;
            //                    }

            //                    item = item_1;
            //                    if (this.frmDataResultShow.Visible)
            //                    {
            //                        foreach (var data in item_1.DataResultList)
            //                        {
            //                            string toolName = data.toolName + "_" + data.toolParamName + "_" + data.guid;
            //                            if (!tool2Total.ContainsKey(toolName))
            //                            {
            //                                tool2Total.Add(toolName, 0);
            //                                tool2NG.Add(toolName, 0);
            //                                tool2Ratio.Add(toolName, 0);
            //                            }

            //                            tool2Total[toolName]++;
            //                            if (!data.isOK)
            //                            {
            //                                tool2NG[toolName]++;
            //                            }
            //                        }
            //                    }
            //                }
            //                else
            //                {
            //                    break;
            //                }
            //            }

            //            if (this.frmDataResultShow.Visible && item != null)
            //            {
            //                foreach (var data in tool2Total)
            //                {
            //                    tool2Ratio[data.Key] = data.Value != 0 ? tool2NG[data.Key] / data.Value : 0;
            //                }

            //                EventMgr.Instance.DispatchEvent("DataResultShow",
            //                    new DataResultShowNotify { item = item, tool2Ratio = tool2Ratio, cameraID = i });
            //            }
            //        }

            //        return;
            //    }

            //    if (this.frmDataResultShow.Visible)
            //    {
            //        this.frmDataResultShow.ClearData();
            //    }
            //    string strData = "";
            //    for (int i = 0; i < cameraCount; i++)
            //    {
            //        item = null;
            //        while (true)
            //        {
            //            var item_1 = ShowResultManager.GetShowResultObj(i);
            //            if (item_1 != null)
            //            {
            //                if (item != null)
            //                {
            //                    item.Clear();
            //                    item = null;
            //                }

            //                item = item_1;
            //                if (this.frmDataResultShow.Visible)
            //                {

            //                    foreach (var data in item_1.DataResultList)
            //                    {

            //                        string toolName = data.toolName + "_" + data.toolParamName + "_" + data.guid;
            //                        if (!g_tool2Total.ContainsKey(toolName))
            //                        {
            //                            g_tool2Total.Add(toolName, 0);
            //                            g_tool2NG.Add(toolName, 0);
            //                            g_tool2NGRatio.Add(toolName, 0);
            //                            g_tool2NGRatio_more.Add(toolName, 0);
            //                            g_tool2NG_samll.Add(toolName, 0);
            //                            g_tool2NG_more.Add(toolName, 0);
            //                        }

            //                        g_tool2Total[toolName]++;
            //                        if (!data.isOK)
            //                        {
            //                            g_tool2NG[toolName]++;
            //                            try
            //                            {
            //                                double curValue = double.Parse(data.toolParamValue == null
            //                                    ? "0"
            //                                    : data.toolParamValue);
            //                                double maxValue = double.Parse(data.toolMax);
            //                                double minValue = double.Parse(data.toolMin);
            //                                if (curValue > maxValue)
            //                                {
            //                                    g_tool2NG_more[toolName]++;
            //                                }
            //                                else if (curValue < minValue)
            //                                {
            //                                    g_tool2NG_samll[toolName]++;
            //                                }

            //                            }
            //                            catch
            //                            {
            //                            }
            //                        }
            //                    }
            //                }
            //            }
            //            else
            //            {
            //                break;
            //            }
            //        }

            //        if (this.frmDataResultShow.Visible)
            //        {
            //            bool useOld = true;
            //            if (item != null)
            //            {
            //                strData = "";
            //                if (ckbSaveData.Checked)
            //                {
            //                    if (CCDS[i].Count == 0)
            //                    {
            //                        foreach (var data in item.DataResultList)
            //                        {
            //                            strData = strData + "上限," + data.toolParamName + ",下限,";
            //                        }
            //                        CCDS[i].Add(strData);
            //                    }
            //                    strData = "";
            //                    if (CCDS[i].Count != 0)
            //                    {
            //                        foreach (var data in item.DataResultList)
            //                        {
            //                            strData = strData + data.toolMax + "," + data.toolParamValue + "," + data.toolMin + ",";
            //                        }
            //                        CCDS[i].Add(strData);
            //                    }
            //                }
            //                foreach (var data in g_tool2Total)
            //                {
            //                    g_tool2NGRatio[data.Key] = data.Value != 0
            //                        ? Math.Round(g_tool2NG[data.Key] * 100 / data.Value, 2)
            //                        : 0.00;
            //                }

            //                if (item.DataResultList.Count > 0)
            //                {
            //                    useOld = false;
            //                    this.frmDataResultShow.addShowData(item, g_tool2NGRatio, g_tool2NG_more,
            //                        g_tool2NG_samll);
            //                    preShowResultObjList[i] = item;
            //                }
            //            }

            //            if (useOld && preShowResultObjList[i] != null)
            //            {
            //                this.frmDataResultShow.addShowData(preShowResultObjList[i], g_tool2NGRatio, g_tool2NG_more,
            //                    g_tool2NG_samll);
            //            }

            //            //this.frmDataResultShow.addShowData(null, g_tool2NGRatio, g_tool2NGRatio_more);
            //        }

            //        if (item != null)
            //        {
            //            ShowResultManager.ShowResult(getWndUnitByIndex(i).HWndCtrl, item);
            //        }
            //    }

            //    if (this.frmDataResultShow.Visible)
            //    {
            //        this.frmDataResultShow.Finished();
            //    }

            //    GC.Collect();
            //}
            //catch
            //{
            //}
        }


        private void btnStart_Click(object sender, EventArgs e)
        {
            //if (Machine.runState)
            //{
            //    return;
            //}
            //this.timer1.Stop();
            ////this.timer1.Interval = IniStatus.Instance.ShowRefreshRate;
            //this.timer1.Start();
            //Machine.NgTime.Restart();
            //g_tool2NG_samll.Clear();
            //g_tool2Total.Clear();
            //g_tool2NG.Clear();
            //g_tool2NGRatio.Clear();
            //g_tool2NGRatio_more.Clear();
            //g_tool2NG_more.Clear();

            //cameraHandle.ClearTempData();
            //Machine.Camerastop();

            //datashow.PgdShowData(Machine.station);
            //UpdatePanel2(datashow);
            //UpdatePanel4(workUI);
            ////CameraUIBinding(); //界面邦定

            //if (IO != null)
            //{
            //    IO.Close();
            //}

            //if (!Machine.runState)
            //{
            //    cameraHandle.Start();
            //    Machine.Runstart();
            //}

            //if (runState != RunState.RunState_Stop)
            //{
            //    //LogHelper.Info("已经在运行了");
            //    return;
            //}

            //runState = RunState.RunState_Running;
            //cameraHandle.StartAsynTask();
            //Instance.cameraHandle.CameraIniSetSoftwareTrigger();
        }

        void Stop_opt()
        {
            //runState = RunState.RunState_Stop;
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            //Machine.runState = false;
            ////Machine.motionControlCard.Stop(0);
            //Machine.ccdStep = 1;
            //if (runState == RunState.RunState_Stop)
            //{
            //    return;
            //}
            //preShowResultObjList.Clear();
            //Machine.Camerastop();
            //Stop_opt();
            //Machine.runState = false;
            //Machine.RunStop();
            //cameraHandle.ClearData();
            //cameraHandle.StopAsynTask();
            //LogHelper.Info("#########################################停止运行###########################################################");
            //// StopDataSave();

            //if (runState != RunState.RunState_Stop)
            //{
            //    //preShowResultObjList.Clear();
            //    Machine.Camerastop();
            //    Stop_opt();
            //    Machine.runState = false;
            //    Machine.RunStop();
            //    cameraHandle.ClearData();
            //    cameraHandle.StopAsynTask();
            //    //LogHelper.Info("#########################################停止运行###########################################################");
            //}
        }
        private void StopDataSave()
        {
            string dir = Path.GetDirectoryName(@"Record\");
            System.IO.Directory.CreateDirectory(dir);
            if (!File.Exists(@"Record\" + DateTime.Now.ToString("yyyy-MM-dd") + ".csv"))
            {
                DataSave(@"Record\" + DateTime.Now.ToString("yyyy-MM-dd") + ".csv", "产品料号,总数,合格率,产能(个/分钟),峰值(个/分钟),NG数量,OK数量,回收数量,时间");
            }
            //DataSave(@"Record\" + DateTime.Now.ToString("yyyy-MM-dd") + ".csv",
            //      Machine.station.partNumber.ToString() + "," + Machine.station.totalCount.ToString() + ","
            //    + Machine.station.passRate.ToString() + "," + Machine.station.outputCount.ToString() + ","
            //    + Machine.station.PeakCount.ToString() + "," + Machine.station.zhuanpan_1_NG_count.ToString() + ","
            //    + Machine.station.zhuanpan_1_OK_count.ToString() + "," + Machine.station.zhuanpan_1_Recovery_count.ToString() + ","
            //    + DateTime.Now.ToString());
            //frmDataResultShow.dataGridViewToCSV(@"Record\" + DateTime.Now.ToString("yyyy-MM-dd") + ".csv");

        }
        public void DataSave()
        {
            //int cameraCount = IniStatus.Instance.CamearCount;
            //string dir = Path.GetDirectoryName("Report\\T" + Machine.station.partNumber.ToString() + "\\");

            //System.IO.Directory.CreateDirectory(dir);
            //for (int i = 0; i < cameraCount; i++)
            //{
            //    for (int j = 0; j < CCDS[i].Count; j++)
            //    {
            //        string path = "Report\\T" + Machine.station.partNumber.ToString() + "\\CCD" + (i + 1).ToString() + ".csv";
            //        DataSave(path, CCDS[i][j]);
            //    }
            //    CCDS[i].Clear();
            //}

        }
        public static bool DataSave(string strFilePath, string strBufferLine)
        {
            try
            {

                using (StreamWriter strmWriterObj = new StreamWriter(strFilePath, true, System.Text.Encoding.UTF8))
                {
                    strmWriterObj.WriteLine(strBufferLine);

                }
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }
        private void btnBackHome_Click(object sender, EventArgs e)
        {
            //if (MessageBox.Show("是否确定机器初始化？", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) ==
            //    DialogResult.Yes)
            //{
            //    Machine.MachineInitialize();
            //    cameraHandle.ClearTempData();
            //}
        }

        private void btnDischarge_Click(object sender, EventArgs e)
        {
            //if (MessageBox.Show("是否确定机器初始化？", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) ==
            //    DialogResult.Yes)
            //{
            //    Machine.ResetStart();
            //}
        }

        private void btnDataClear_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("是否确定机器统计数据清零？", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) ==
                DialogResult.Yes)
            {
                ////int cameraCount = IniStatus.Instance.CamearCount;
                //for (int i = 0; i < cameraCount; i++)
                //{
                //    CCDS[i].Clear();
                //}
                //cameraHandle.ClearData();
                //Machine.ParamClearData();
            }
        }

        /// <summary>
        /// 视觉设置
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnVision_Click(object sender, EventArgs e)
        {
            if (closingprocess)
            {
                return;
            }

            //if (Machine.runState)
            {
                return;
            }

            //if (StatusManger.Instance.IsChecker)
            //{
            //}
            //else
            //{
            //    frmLogin Frame_Login = new frmLogin();
            //    bool isLogin = false;
            //    if (Frame_Login.ShowDialog() != DialogResult.OK)
            //    {
            //        isLogin = false;
            //        return;
            //    }
            //    else
            //    {
            //        isLogin = true;
            //    }
            //}

            //UpdatePanel4(workUI);
            //UpdatePanel2(funMenu1);
            //cameraHandle.SetupVisionData2();
        }

        /// <summary>
        /// 参数设置
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnPerformance_Click(object sender, EventArgs e)
        {
            try
            {
                //if (closingprocess)
                //{
                //    return;
                //}

                //if (Machine.runState)
                //{
                //    return;
                //}

                //Machine.dMCSort.SortStop();
                //IO = new EquipmentUI();
                //cameraHandle.Start();
                //IO.ShowDialog();
            }
            catch
            {
                MessageBox.Show("数据出错，请重新新建工程或加载工程！");
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (closingprocess)
            {
                return;
            }

            //if (FileOptHelp.FileExist(IniStatus.Instance.LastProjectFile))
            //{
            //    try
            //    {
            //        projectData.SaveProject(IniStatus.Instance.LastProjectFile);
            //        MessageHelper.ShowTips("配置保存成功");
            //    }
            //    catch (Exception ex)
            //    {
            //        MessageHelper.ShowTips("配置保存失败");
            //    }
            //}
            //else
            //{
            //    tsmiSave_Click(null, null);
            //}
        }

        private void tsmiQuickSetting_Click(object sender, EventArgs e)
        {
            //if (Machine.runState)
            {
                return;
            }

            //if (StatusManger.Instance.IsChecker)
            //{
            //}
            //else
            //{
            //    frmLogin Frame_Login = new frmLogin();
            //    bool isLogin = false;
            //    if (Frame_Login.ShowDialog() != DialogResult.OK)
            //    {
            //        isLogin = false;
            //        return;
            //    }
            //    else
            //    {
            //        isLogin = true;
            //    }
            //}

            //frmEditParam factory = new frmEditParam();
            //var optList = cameraHandle.GetAllOpt();
            //for (int i = 0; i < optList.Count; i++)
            //{
            //    factory.addShowData(optList[i]);
            //}

            //factory.ShowDialog();
        }

        private void btnUser_Click(object sender, EventArgs e)
        {
            //frmLogin Frame_Login = new frmLogin();
            //bool isLogin = false;
            //if (Frame_Login.ShowDialog() != DialogResult.OK)
            //{
            //    isLogin = false;
            //}
            //else
            //{
            //    isLogin = true;
            //}

            //EventMgr.Instance.DispatchEvent("LoginStateChanged");
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            //if (MessageBox.Show("是否确定关闭程序？", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) ==
            //    DialogResult.Yes)
            //{
                closingprocess = true;
                var task = Task.Run(async delegate
                {
                    await Task.Delay(500);
                    CloseProcess();
                });
            //}
        }

        public void CloseProcess()
        {

            //this.Close();
            //EventMgr.Instance.DispatchEvent("关闭程序");
            //Machine.motionControlCard.Stop ();
            //Machine.motionControlCard.ClosedBoard();
            // Machine.smcameraHandle.Stop();
            Process.GetCurrentProcess().Kill();
        }

        #region 菜单事件

        void LoadProject(string filePath)
        {
            //loading = true;
            //projectData = null;
            //projectData = BinarySerializerHelp.DeserializeObject(filePath) as SMProjectData;

            //if (projectData != null)
            //{
            //    try
            //    {
            //        projectData.SerializeInit();
            //        Machine.param = projectData.GetSMDataByName("Machine.param") as SMDataMachineParam;
            //        Machine.station = projectData.GetSMDataByName("Machine.station") as SMDataMachineStation;
            //        if (IniStatus.Instance.IsEditModel)
            //        {
            //            CameraUIBinding();//界面邦定???? 深度学习模块加载非常耗时 需要提前加载
            //        }
            //        LogHelper.Info("加载工程文件成功 " + filePath);
            //        InitUI();
            //        if (IniStatus.Instance.LastProjectFile != filePath)
            //        {
            //            IniStatus.Instance.LastProjectFile = filePath;
            //            IniStatus.Instance.SaveINI();
            //        }

            //        Machine.station.partNumber = Path.GetFileNameWithoutExtension(filePath);
            //        string iniPath = Application.StartupPath + "\\user.ini";
            //        for (int i = 0; i < 8; i++)
            //        {

            //            SMCameraHandle.cameraEnableSaves[i] = Convert.ToInt32(INIHelp.GetValue(iniPath, "camera", "camera" + (i + 1).ToString() + "EnableSaveImg", "0"));

            //        }
            //        checkBox_AI.Checked = IniStatus.Instance.IsEditModel;
            //    }
            //    catch
            //    {
            //Machine.param = new SMDataMachineParam();
            //        Machine.station = new SMDataMachineStation();
            //        IniStatus.Instance.LastProjectFile = "";
            //        IniStatus.Instance.SaveINI();
            //    }

            //}
            //else
            //{
            //    LogHelper.Warn("加载工程文件失败 " + filePath);
            //}

            //loading = false;
        }

        public void CameraUIBinding() //界面邦定
        {
            //var bindCameraDataMap = funMenu1.GetRelevanceCameraNames();
            //foreach (var item in bindCameraDataMap)
            //{
            //    var Data = projectData.GetSMDataByName(item.Key);
            //    if (Data != null && Data is SMVisionData)
            //    {
            //        cameraHandle.SetupVisionData(item.Value, Data as SMVisionData);
            //    }
            //}
        }

        private void tsmiNew_Click(object sender, EventArgs e)
        {
            //loading = true;
            //projectData = null;
            //projectData = new SMProjectData();
            //projectData.AddSMDataByName("Machine.param", OptCode.OptCode_MachineParam);
            //projectData.AddSMDataByName("Machine.station", OptCode.OptCode_MachineStation);
            ////Machine.param = projectData.GetSMDataByName("Machine.param") as SMDataMachineParam;
            ////Machine.station = projectData.GetSMDataByName("Machine.station") as SMDataMachineStation;
            //InitUI();
            //cameraHandle.Start();
            //IniStatus.Instance.LastProjectFile = "";
            //IniStatus.Instance.SaveINI();
            //checkBox_AI.Checked = IniStatus.Instance.IsEditModel;
            //loading = false;
        }

        private void tsmiNew2_Click(object sender, EventArgs e)
        {
            string DataPath = Environment.CurrentDirectory + "\\Data";
            //FileOptHelp.CreateDir(DataPath);
            openFileDialog1.InitialDirectory = DataPath;
            openFileDialog1.Filter = "prjdl prjsm (*.prjdl)|*.prjsm";
            openFileDialog1.FilterIndex = 2;
            openFileDialog1.RestoreDirectory = true;
            openFileDialog1.InitialDirectory = DataPath + "\\";
            try
            {
                //if (openFileDialog1.ShowDialog() == DialogResult.OK)
                //{
                //    LoadProject(openFileDialog1.FileName);
                //    cameraHandle.Start();
                //}
            }
            catch (Exception exception)
            {
                //MessageHelper.ShowTips("请选择正确的文件!");
                return;
            }

            //IniStatus.Instance.LastProjectFile = "";
            //IniStatus.Instance.SaveINI();

            //if (runState != RunState.RunState_Stop)
            //{
            //    Stop_opt();
            //}
        }

        private void tsmiOpen_Click(object sender, EventArgs e)
        {
            if (closingprocess)
            {
                return;
            }

            string DataPath = Environment.CurrentDirectory + "\\Data";
            //FileOptHelp.CreateDir(DataPath);
            openFileDialog1.InitialDirectory = DataPath;
            openFileDialog1.Filter = "prjdl prjsm (*.prjdl)|*.prjsm";
            openFileDialog1.FilterIndex = 2;
            openFileDialog1.RestoreDirectory = true;
            openFileDialog1.InitialDirectory = DataPath + "\\";
            //try
            //{
            //    if (openFileDialog1.ShowDialog() == DialogResult.OK)
            //    {
            //        LoadProject(openFileDialog1.FileName);
            //        cameraHandle.Start();
            //        labmessage.Text = "加载文件：" + openFileDialog1.FileName;
            //    }
            //}
            //catch (Exception exception)
            //{
            //    //MessageHelper.ShowTips("请选择正确的文件!");
            //}

            //if (runState != RunState.RunState_Stop)
            //{
            //    Stop_opt();
            //}
        }

        private void tsmiSave_Click(object sender, EventArgs e)
        {
            //SoftKey.D8 mD8 = new SoftKey.D8();
            //string KeyPath = "";
            //int LastErr = mD8.FindD8(0, "7E05333B522C0108", ref KeyPath);
            //if (LastErr != 0)
            //{
            //    //LogHelper.Error(LastErr.ToString());
            //    //MessageHelper.ShowTips("请联系管理员!!!");
            //    //Process.GetCurrentProcess().Kill();
            //    return;
            //}


            ////test how to call your custom function:LimitDate

            //LastErr = new SoftKey.CRun().LimitDateTest(KeyPath);
            //if (LastErr != 0)
            //{
            //    //LogHelper.Error(LastErr.ToString());
            //    //MessageHelper.ShowTips("请联系管理员!!!");
            //    //Process.GetCurrentProcess().Kill();
            //    return;
            //}

            //string DataPath = Environment.CurrentDirectory + "\\Data";
            //FileOptHelp.CreateDir(DataPath);
            //saveFileDialog1.Filter = "prjsm files (*.prjsm)|*.prjsm";
            //saveFileDialog1.FilterIndex = 2;
            //saveFileDialog1.RestoreDirectory = true;
            //saveFileDialog1.InitialDirectory = DataPath + "\\";
            //if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            //{
            //    projectData.SaveProject(saveFileDialog1.FileName);

            //    if (IniStatus.Instance.LastProjectFile != saveFileDialog1.FileName)
            //    {
            //        IniStatus.Instance.LastProjectFile = saveFileDialog1.FileName;
            //        IniStatus.Instance.SaveINI();
            //    }

            //    Machine.station.partNumber = Path.GetFileNameWithoutExtension(saveFileDialog1.FileName);
            //}
            //else
            //{
            //    MessageHelper.ShowTips("请选择正确的文件!");
            //}
        }

        #endregion

        private void tsmiAboutUs_Click(object sender, EventArgs e)
        {
            //frmAbout frm_About = new frmAbout();
            //frm_About.ShowDialog();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
        }

        private void btn_jichi_Click(object sender, EventArgs e)
        {
            //Machine.motionControlCard.AxisEnable(true);
        }

        private void btn_shifang_Click(object sender, EventArgs e)
        {
            //Machine.motionControlCard.AxisEnable(false);
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            //Machine.ResetAlarm();
        }

        private void checkBox_AI_CheckedChanged(object sender, EventArgs e)
        {
            if (loading) return;
            //IniStatus.Instance.IsEditModel = checkBox_AI.Checked;
            //IniStatus.Instance.SaveINI();
        }

        private void button1_Click_2(object sender, EventArgs e)
        {
            //CameraUIBinding();
        }

        private void label_user_Click(object sender, EventArgs e)
        {

        }

        private void 数据报表ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //if (Machine.runState)
            //{
            //    return;
            //}
            //WaitUI waitUI = new WaitUI();
            //waitUI.ShowDialog();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            //HomeUI homeUI = new HomeUI();
            //homeUI.ShowDialog();
        }

        private void btn_jichi_Click_1(object sender, EventArgs e)
        {
            //Machine.zhuanpan.AxisEnable(true);
        }

        private void btn_shifang_Click_1(object sender, EventArgs e)
        {
            //Machine.zhuanpan.AxisEnable(false);
        }
    }
}