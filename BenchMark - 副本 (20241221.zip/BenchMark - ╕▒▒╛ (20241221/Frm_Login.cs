﻿ 

using System.Drawing;
using System.Security.Permissions;
using System.Windows.Forms;
using System;
using AutoPressBrakeMachine.Classes;
using lswLaserBaseLibray;

namespace AutoPressBrakeMachine
{
    public partial class Frm_Login : Form
    {
        #region Fields

        private readonly Timer tmrFadeIn;
        private bool aeroShadow;

        #endregion
        #region Constants

        /// <summary>
        /// Allows minimizing from taskbar.
        /// </summary>
        private const int WS_MINIMIZEBOX = 0x20000;

        /// <summary>
        /// Paints all descendants of a window in bottom-to-top painting order
        /// using double-buffering.
        /// </summary>
        private const int WS_EX_COMPOSITED = 0x02000000;

        #endregion

        public Frm_Login()
        {
            InitializeComponent();

            Animator.AnimationType = AnimatorNS.AnimationType.Transparent;
            Animator.Interval = 100;
            Animator.MaxAnimationTime = 1000;
            Animator.TimeStep = 0.2F;

            XR_Button_Login.Enabled = false;
            text_user.TextChanged += ValidateInput;
            text_pass.TextChanged += ValidateInput;

            var customFont = FontLoader.SetFont(22, FontStyle.Regular, GraphicsUnit.Point, 1);
            XR_TitleLabel_Welcome.Font = customFont;
            //XR_TitleLabel_LoginTo.Font = customFont;
            Opacity = 0;

            tmrFadeIn = new Timer
            {
                Interval = 100,
                Enabled  = true,
            };

            tmrFadeIn.Tick += FadeIn_Tick;
        }

        double Opacity1 = 0;
        private void FadeIn_Tick(object sender, EventArgs e)
        {
            // Increase the form opacity value until it reaches 1 (or 100%).
            // After that, stop the timer and disable it.
            Opacity1 += 0.3;
            if (Opacity1<1)
            {
                Opacity = Opacity1;
            }
            else
            {
                Opacity =1;
            }
           
            if (Opacity >= 1)
            {
                tmrFadeIn.Stop();
                tmrFadeIn.Enabled = false;
                tmrFadeIn.Tick -= FadeIn_Tick;
            }
        }

        #region Form Events

        private void Frm_Login_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Unsubscribe previously used events
            tmrFadeIn.Tick -= FadeIn_Tick;
            text_user.TextChanged -= ValidateInput;
            text_pass.TextChanged -= ValidateInput;
        }

        private void Frm_Login_Shown(object sender, EventArgs e)
        {
            // Animate the controls that have the property [Visible = False] after the form has
            // been fully loaded and became visible. This code can be added to the {Form_Load}
            // event. However, it may cause the form to flicker when the software is launched.
            foreach (Control item in XR_RightPanel.Controls)
            {
                if (item.Visible != true)
                    Animator.Show(item);
            };
        }

        public static bool UserLogin()
        {
            var form = new Frm_Login();
            var isLogin = form.ShowDialog() == DialogResult.OK;
            form.Dispose();
            return isLogin;
        }

        private void btn_close_Click(object sender, EventArgs e)
        {
            this.Close();
            this.DialogResult = DialogResult.Cancel;
        }

        private void text_user_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                this.SelectNextControl((Control)sender, true, true, true, true);
            }
        }

        #endregion

        /// <summary>
        /// Checks if the Desktop Window Manager is enabled.
        /// </summary>
        private static bool IsDwmCompositionEnabled()
        {
            // Only Windows Vista and up
            // NOTE: DWM composition is always enabled as of Windows 8
            if (Environment.OSVersion.Version.Major < 6)
                return false;
            
            bool isEnabled;
            NativeMethods.DwmIsCompositionEnabled(out isEnabled);
            
            return isEnabled;
        }

        private void ValidateInput(object sender, EventArgs e)
        {
            XR_Button_Login.Enabled = !(text_user.Text == string.Empty ||
                                        text_pass.Text == string.Empty);
        }

        private void Wait(int seconds)
        {
            if (seconds < 1)
                return;

            var timeToWait = DateTime.Now.AddSeconds(seconds);
            while (DateTime.Now < timeToWait)
                System.Windows.Forms.Application.DoEvents();
        }

        // Just simulate a login process...
        private void XR_Button_Login_Click(object sender, EventArgs e)
        {
            text_user.Enabled = false;
            text_pass.Enabled = false;
            XR_Button_Login.Enabled = false;

            Animator.Hide(XR_Button_Login, true, AnimatorNS.Animation.HorizSlide);
            Animator.Show(XR_Label_LoggingIn);
            if (UserManager.DoLogin(text_user.Text, text_pass.Text))
            {
                //if (!UserManager.GetSoftLicenceIsOk())
                //{
                //    this.DialogResult = DialogResult.Cancel;
                //    MessageBox.Show("使用次数已经到达上限，请联系供应商！");
                //    return;
                //}
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            else
            {
                //Wait(2);
                MessageBox.Show("用户或密码错误！");
                // this.DialogResult = DialogResult.No;
                Animator.Hide(XR_Label_LoggingIn, true);
                Animator.Show(XR_Button_Login, true, AnimatorNS.Animation.HorizSlide);

                text_user.Enabled = true;
                text_pass.Enabled = true;
                XR_Button_Login.Enabled = true;
            }
        }

        // Modify the parameters of the form's handle (unmanaged code).
        protected override CreateParams CreateParams
        {
            get
            {
                new SecurityPermission(SecurityPermissionFlag.UnmanagedCode).Demand();
                aeroShadow = IsDwmCompositionEnabled();

                var cp = base.CreateParams;

                // WS_MINIMIZEBOX   : allows minimizing the software from the taskbar
                // WS_EX_COMPOSITED : paints bottom-to-top. Reduces flicker greatly

                cp.Style |= WS_MINIMIZEBOX;
                cp.ExStyle |= WS_EX_COMPOSITED;

                return cp;
            }
        }

        protected override void WndProc(ref Message m)
        {
            switch ((NativeMethods.WindowsMessages)m.Msg)
            {
                case NativeMethods.WindowsMessages.WM_NCPAINT:
                    if (aeroShadow)
                    {
                        var ncAttr = NativeMethods.DWMWINDOWATTRIBUTE.DWMWA_NCRENDERING_POLICY;
                        var dwAttrPntr = 2;
                        NativeMethods.DwmSetWindowAttribute(Handle, ncAttr, ref dwAttrPntr, 4);

                        var margins = new NativeMethods.MARGINS()
                        {
                            cyBottomHeight = 1,
                            cxLeftWidth    = 1,
                            cxRightWidth   = 1,
                            cyTopHeight    = 1
                        };

                        NativeMethods.DwmExtendFrameIntoClientArea(Handle, ref margins);
                    }
                    break;
                case NativeMethods.WindowsMessages.WM_NCACTIVATE:
                    // Change the title bar text color according to whether the
                    // window is active or inactive
                    if (m.WParam == IntPtr.Zero)
                        XR_Container.TitleBarTextColor = Color.DarkGray;
                    else
                        XR_Container.TitleBarTextColor = Color.Gainsboro;
                    break;
            }
            base.WndProc(ref m);
        }

        private void xRails_Button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}