﻿
namespace BenchMark
{
    partial class IOForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.di_gb = new System.Windows.Forms.GroupBox();
            this.tp_in = new System.Windows.Forms.TableLayoutPanel();
            this.do_gb = new System.Windows.Forms.GroupBox();
            this.tp_out = new System.Windows.Forms.TableLayoutPanel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.di_gb.SuspendLayout();
            this.do_gb.SuspendLayout();
            this.SuspendLayout();
            // 
            // di_gb
            // 
            this.di_gb.Controls.Add(this.tp_in);
            this.di_gb.Location = new System.Drawing.Point(26, 10);
            this.di_gb.Margin = new System.Windows.Forms.Padding(2);
            this.di_gb.Name = "di_gb";
            this.di_gb.Padding = new System.Windows.Forms.Padding(2);
            this.di_gb.Size = new System.Drawing.Size(200, 583);
            this.di_gb.TabIndex = 0;
            this.di_gb.TabStop = false;
            this.di_gb.Text = "输入IO";
            // 
            // tp_in
            // 
            this.tp_in.ColumnCount = 1;
            this.tp_in.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tp_in.Location = new System.Drawing.Point(4, 19);
            this.tp_in.Margin = new System.Windows.Forms.Padding(2);
            this.tp_in.Name = "tp_in";
            this.tp_in.RowCount = 1;
            this.tp_in.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tp_in.Size = new System.Drawing.Size(177, 559);
            this.tp_in.TabIndex = 0;
            // 
            // do_gb
            // 
            this.do_gb.Controls.Add(this.tp_out);
            this.do_gb.Location = new System.Drawing.Point(316, 10);
            this.do_gb.Margin = new System.Windows.Forms.Padding(2);
            this.do_gb.Name = "do_gb";
            this.do_gb.Padding = new System.Windows.Forms.Padding(2);
            this.do_gb.Size = new System.Drawing.Size(212, 583);
            this.do_gb.TabIndex = 1;
            this.do_gb.TabStop = false;
            this.do_gb.Text = "输出IO";
            // 
            // tp_out
            // 
            this.tp_out.ColumnCount = 1;
            this.tp_out.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tp_out.Location = new System.Drawing.Point(4, 19);
            this.tp_out.Margin = new System.Windows.Forms.Padding(2);
            this.tp_out.Name = "tp_out";
            this.tp_out.RowCount = 1;
            this.tp_out.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tp_out.Size = new System.Drawing.Size(188, 559);
            this.tp_out.TabIndex = 1;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 2000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // IOForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 633);
            this.Controls.Add(this.do_gb);
            this.Controls.Add(this.di_gb);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "IOForm";
            this.Text = "IOForm";
            this.Load += new System.EventHandler(this.IOForm_Load);
            this.di_gb.ResumeLayout(false);
            this.do_gb.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox di_gb;
        private System.Windows.Forms.GroupBox do_gb;
        private System.Windows.Forms.TableLayoutPanel tp_in;
        private System.Windows.Forms.TableLayoutPanel tp_out;
        private System.Windows.Forms.Timer timer1;
    }
}