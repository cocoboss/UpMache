﻿
namespace BenchMark
{
    partial class ParamForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.ListViewItem listViewItem1 = new System.Windows.Forms.ListViewItem(new string[] {
            "2D初始位置",
            "121",
            "212",
            "321"}, -1);
            System.Windows.Forms.ListViewItem listViewItem2 = new System.Windows.Forms.ListViewItem(new string[] {
            "2D结束位置",
            "0",
            "0",
            "0"}, -1);
            System.Windows.Forms.ListViewItem listViewItem3 = new System.Windows.Forms.ListViewItem(new string[] {
            "3D1初始位置",
            "0",
            "0",
            "0"}, -1);
            System.Windows.Forms.ListViewItem listViewItem4 = new System.Windows.Forms.ListViewItem(new string[] {
            "3D1结束位置",
            "0",
            "0",
            "0"}, -1);
            System.Windows.Forms.ListViewItem listViewItem5 = new System.Windows.Forms.ListViewItem(new string[] {
            "3D2初始位置",
            "0",
            "0",
            "0"}, -1);
            System.Windows.Forms.ListViewItem listViewItem6 = new System.Windows.Forms.ListViewItem(new string[] {
            "3D2结束位置",
            "0",
            "0",
            "0"}, -1);
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.txt_time5 = new System.Windows.Forms.TextBox();
            this.label62 = new System.Windows.Forms.Label();
            this.txt_pvmm5 = new System.Windows.Forms.TextBox();
            this.label63 = new System.Windows.Forms.Label();
            this.txt_rightLimt5 = new System.Windows.Forms.TextBox();
            this.label64 = new System.Windows.Forms.Label();
            this.txt_leftLimt5 = new System.Windows.Forms.TextBox();
            this.label65 = new System.Windows.Forms.Label();
            this.txt_dec5 = new System.Windows.Forms.TextBox();
            this.label66 = new System.Windows.Forms.Label();
            this.txt_val5 = new System.Windows.Forms.TextBox();
            this.label67 = new System.Windows.Forms.Label();
            this.txt_acc5 = new System.Windows.Forms.TextBox();
            this.label68 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.txt_time4 = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.txt_pvmm4 = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.txt_rightLimt4 = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.txt_leftLimt4 = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.txt_dec4 = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.txt_val4 = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.txt_acc4 = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txt_time3 = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.txt_pvmm3 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txt_rightLimt3 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txt_leftLimt3 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txt_dec3 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txt_val3 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.txt_acc3 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txt_time2 = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.txt_pvmm2 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_rightLimt2 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txt_leftLimt2 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txt_dec2 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_val2 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txt_acc2 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txt_time1 = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.txt_pvmm1 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_rightLimt1 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_leftLimt1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_dec1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_val1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_acc1 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.ZhouParam = new System.Windows.Forms.TabPage();
            this.OtherParam = new System.Windows.Forms.TabPage();
            this.txt_buz2 = new System.Windows.Forms.TextBox();
            this.txt_buz1 = new System.Windows.Forms.TextBox();
            this.chk_buz = new System.Windows.Forms.CheckBox();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.txt_3d2y = new System.Windows.Forms.TextBox();
            this.label57 = new System.Windows.Forms.Label();
            this.txt_3d2x = new System.Windows.Forms.TextBox();
            this.label58 = new System.Windows.Forms.Label();
            this.txt_3d1y = new System.Windows.Forms.TextBox();
            this.label56 = new System.Windows.Forms.Label();
            this.txt_3d1x = new System.Windows.Forms.TextBox();
            this.label55 = new System.Windows.Forms.Label();
            this.chk_sip = new System.Windows.Forms.CheckBox();
            this.txt_runnum = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.label37 = new System.Windows.Forms.Label();
            this.txt_delyTime = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.label35 = new System.Windows.Forms.Label();
            this.txt_3Ddis = new System.Windows.Forms.TextBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.btn_bd = new System.Windows.Forms.Button();
            this.txt_bdnum = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.txt_bdbc = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.txt_bdpos = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.txt_3DVal = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.lst_poss = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.button2 = new System.Windows.Forms.Button();
            this.btn_look = new System.Windows.Forms.Button();
            this.txt_log = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.txt_smt = new System.Windows.Forms.TextBox();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.label72 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.ckb_g = new System.Windows.Forms.CheckBox();
            this.txt_g_dis = new System.Windows.Forms.TextBox();
            this.label73 = new System.Windows.Forms.Label();
            this.cb_jackAir2 = new System.Windows.Forms.ComboBox();
            this.cb_jackAir = new System.Windows.Forms.ComboBox();
            this.label69 = new System.Windows.Forms.Label();
            this.cb_blockAir = new System.Windows.Forms.ComboBox();
            this.label70 = new System.Windows.Forms.Label();
            this.txt_gpu = new System.Windows.Forms.TextBox();
            this.label61 = new System.Windows.Forms.Label();
            this.cb_after = new System.Windows.Forms.ComboBox();
            this.label60 = new System.Windows.Forms.Label();
            this.cb_befor = new System.Windows.Forms.ComboBox();
            this.label59 = new System.Windows.Forms.Label();
            this.txt_speed = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.gb_mark = new System.Windows.Forms.GroupBox();
            this.label41 = new System.Windows.Forms.Label();
            this.cb_mark2 = new System.Windows.Forms.ComboBox();
            this.cb_mark1 = new System.Windows.Forms.ComboBox();
            this.label42 = new System.Windows.Forms.Label();
            this.gb_pos = new System.Windows.Forms.GroupBox();
            this.cb_3d2 = new System.Windows.Forms.ComboBox();
            this.label43 = new System.Windows.Forms.Label();
            this.cb_2d = new System.Windows.Forms.ComboBox();
            this.label44 = new System.Windows.Forms.Label();
            this.cb_3d1 = new System.Windows.Forms.ComboBox();
            this.label45 = new System.Windows.Forms.Label();
            this.ckb_mark = new System.Windows.Forms.CheckBox();
            this.ckb_ip = new System.Windows.Forms.CheckBox();
            this.label46 = new System.Windows.Forms.Label();
            this.txt_length = new System.Windows.Forms.TextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.txt_ip = new System.Windows.Forms.TextBox();
            this.label48 = new System.Windows.Forms.Label();
            this.txt_dely_out = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.txt_dely_put = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.txt_dely_in = new System.Windows.Forms.TextBox();
            this.cb_out = new System.Windows.Forms.ComboBox();
            this.label51 = new System.Windows.Forms.Label();
            this.cb_put = new System.Windows.Forms.ComboBox();
            this.label52 = new System.Windows.Forms.Label();
            this.cb_in = new System.Windows.Forms.ComboBox();
            this.label53 = new System.Windows.Forms.Label();
            this.txt_name = new System.Windows.Forms.TextBox();
            this.label54 = new System.Windows.Forms.Label();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.label39 = new System.Windows.Forms.Label();
            this.cb_project = new System.Windows.Forms.ComboBox();
            this.button5 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.chk_smt = new System.Windows.Forms.CheckBox();
            this.panel1.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.ZhouParam.SuspendLayout();
            this.OtherParam.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.gb_mark.SuspendLayout();
            this.gb_pos.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.groupBox11);
            this.panel1.Controls.Add(this.groupBox4);
            this.panel1.Controls.Add(this.groupBox3);
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Location = new System.Drawing.Point(15, 5);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(727, 534);
            this.panel1.TabIndex = 0;
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.txt_time5);
            this.groupBox11.Controls.Add(this.label62);
            this.groupBox11.Controls.Add(this.txt_pvmm5);
            this.groupBox11.Controls.Add(this.label63);
            this.groupBox11.Controls.Add(this.txt_rightLimt5);
            this.groupBox11.Controls.Add(this.label64);
            this.groupBox11.Controls.Add(this.txt_leftLimt5);
            this.groupBox11.Controls.Add(this.label65);
            this.groupBox11.Controls.Add(this.txt_dec5);
            this.groupBox11.Controls.Add(this.label66);
            this.groupBox11.Controls.Add(this.txt_val5);
            this.groupBox11.Controls.Add(this.label67);
            this.groupBox11.Controls.Add(this.txt_acc5);
            this.groupBox11.Controls.Add(this.label68);
            this.groupBox11.Location = new System.Drawing.Point(247, 267);
            this.groupBox11.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox11.Size = new System.Drawing.Size(225, 248);
            this.groupBox11.TabIndex = 38;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "滑轨(G)";
            // 
            // txt_time5
            // 
            this.txt_time5.Location = new System.Drawing.Point(115, 224);
            this.txt_time5.Margin = new System.Windows.Forms.Padding(2);
            this.txt_time5.Name = "txt_time5";
            this.txt_time5.Size = new System.Drawing.Size(97, 21);
            this.txt_time5.TabIndex = 37;
            this.txt_time5.Text = "3";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(14, 226);
            this.label62.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(53, 12);
            this.label62.TabIndex = 36;
            this.label62.Text = "平滑时间";
            // 
            // txt_pvmm5
            // 
            this.txt_pvmm5.Location = new System.Drawing.Point(115, 190);
            this.txt_pvmm5.Margin = new System.Windows.Forms.Padding(2);
            this.txt_pvmm5.Name = "txt_pvmm5";
            this.txt_pvmm5.Size = new System.Drawing.Size(97, 21);
            this.txt_pvmm5.TabIndex = 33;
            this.txt_pvmm5.Text = "8000";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(14, 191);
            this.label63.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(47, 12);
            this.label63.TabIndex = 32;
            this.label63.Text = "脉冲/mm";
            // 
            // txt_rightLimt5
            // 
            this.txt_rightLimt5.Location = new System.Drawing.Point(115, 160);
            this.txt_rightLimt5.Margin = new System.Windows.Forms.Padding(2);
            this.txt_rightLimt5.Name = "txt_rightLimt5";
            this.txt_rightLimt5.Size = new System.Drawing.Size(97, 21);
            this.txt_rightLimt5.TabIndex = 31;
            this.txt_rightLimt5.Text = "8000";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(14, 162);
            this.label64.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(53, 12);
            this.label64.TabIndex = 30;
            this.label64.Text = "软正限位";
            // 
            // txt_leftLimt5
            // 
            this.txt_leftLimt5.Location = new System.Drawing.Point(115, 129);
            this.txt_leftLimt5.Margin = new System.Windows.Forms.Padding(2);
            this.txt_leftLimt5.Name = "txt_leftLimt5";
            this.txt_leftLimt5.Size = new System.Drawing.Size(97, 21);
            this.txt_leftLimt5.TabIndex = 29;
            this.txt_leftLimt5.Text = "-200";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(14, 130);
            this.label65.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(53, 12);
            this.label65.TabIndex = 28;
            this.label65.Text = "软负限位";
            // 
            // txt_dec5
            // 
            this.txt_dec5.Location = new System.Drawing.Point(115, 96);
            this.txt_dec5.Margin = new System.Windows.Forms.Padding(2);
            this.txt_dec5.Name = "txt_dec5";
            this.txt_dec5.Size = new System.Drawing.Size(97, 21);
            this.txt_dec5.TabIndex = 27;
            this.txt_dec5.Text = "0.1";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(14, 98);
            this.label66.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(41, 12);
            this.label66.TabIndex = 26;
            this.label66.Text = "减速度";
            // 
            // txt_val5
            // 
            this.txt_val5.Location = new System.Drawing.Point(115, 26);
            this.txt_val5.Margin = new System.Windows.Forms.Padding(2);
            this.txt_val5.Name = "txt_val5";
            this.txt_val5.Size = new System.Drawing.Size(97, 21);
            this.txt_val5.TabIndex = 25;
            this.txt_val5.Text = "5";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(14, 28);
            this.label67.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(29, 12);
            this.label67.TabIndex = 24;
            this.label67.Text = "速度";
            // 
            // txt_acc5
            // 
            this.txt_acc5.Location = new System.Drawing.Point(115, 62);
            this.txt_acc5.Margin = new System.Windows.Forms.Padding(2);
            this.txt_acc5.Name = "txt_acc5";
            this.txt_acc5.Size = new System.Drawing.Size(97, 21);
            this.txt_acc5.TabIndex = 23;
            this.txt_acc5.Text = "0.1";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(14, 63);
            this.label68.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(41, 12);
            this.label68.TabIndex = 22;
            this.label68.Text = "加速度";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.txt_time4);
            this.groupBox4.Controls.Add(this.label28);
            this.groupBox4.Controls.Add(this.txt_pvmm4);
            this.groupBox4.Controls.Add(this.label19);
            this.groupBox4.Controls.Add(this.txt_rightLimt4);
            this.groupBox4.Controls.Add(this.label20);
            this.groupBox4.Controls.Add(this.txt_leftLimt4);
            this.groupBox4.Controls.Add(this.label21);
            this.groupBox4.Controls.Add(this.txt_dec4);
            this.groupBox4.Controls.Add(this.label22);
            this.groupBox4.Controls.Add(this.txt_val4);
            this.groupBox4.Controls.Add(this.label23);
            this.groupBox4.Controls.Add(this.txt_acc4);
            this.groupBox4.Controls.Add(this.label24);
            this.groupBox4.Location = new System.Drawing.Point(7, 267);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox4.Size = new System.Drawing.Size(225, 248);
            this.groupBox4.TabIndex = 34;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "调宽(K)";
            // 
            // txt_time4
            // 
            this.txt_time4.Location = new System.Drawing.Point(115, 224);
            this.txt_time4.Margin = new System.Windows.Forms.Padding(2);
            this.txt_time4.Name = "txt_time4";
            this.txt_time4.Size = new System.Drawing.Size(97, 21);
            this.txt_time4.TabIndex = 37;
            this.txt_time4.Text = "3";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(14, 226);
            this.label28.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(53, 12);
            this.label28.TabIndex = 36;
            this.label28.Text = "平滑时间";
            // 
            // txt_pvmm4
            // 
            this.txt_pvmm4.Location = new System.Drawing.Point(115, 190);
            this.txt_pvmm4.Margin = new System.Windows.Forms.Padding(2);
            this.txt_pvmm4.Name = "txt_pvmm4";
            this.txt_pvmm4.Size = new System.Drawing.Size(97, 21);
            this.txt_pvmm4.TabIndex = 33;
            this.txt_pvmm4.Text = "8000";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(14, 191);
            this.label19.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(47, 12);
            this.label19.TabIndex = 32;
            this.label19.Text = "脉冲/mm";
            // 
            // txt_rightLimt4
            // 
            this.txt_rightLimt4.Location = new System.Drawing.Point(115, 160);
            this.txt_rightLimt4.Margin = new System.Windows.Forms.Padding(2);
            this.txt_rightLimt4.Name = "txt_rightLimt4";
            this.txt_rightLimt4.Size = new System.Drawing.Size(97, 21);
            this.txt_rightLimt4.TabIndex = 31;
            this.txt_rightLimt4.Text = "8000";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(14, 162);
            this.label20.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(53, 12);
            this.label20.TabIndex = 30;
            this.label20.Text = "软正限位";
            // 
            // txt_leftLimt4
            // 
            this.txt_leftLimt4.Location = new System.Drawing.Point(115, 129);
            this.txt_leftLimt4.Margin = new System.Windows.Forms.Padding(2);
            this.txt_leftLimt4.Name = "txt_leftLimt4";
            this.txt_leftLimt4.Size = new System.Drawing.Size(97, 21);
            this.txt_leftLimt4.TabIndex = 29;
            this.txt_leftLimt4.Text = "-200";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(14, 130);
            this.label21.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(53, 12);
            this.label21.TabIndex = 28;
            this.label21.Text = "软负限位";
            // 
            // txt_dec4
            // 
            this.txt_dec4.Location = new System.Drawing.Point(115, 96);
            this.txt_dec4.Margin = new System.Windows.Forms.Padding(2);
            this.txt_dec4.Name = "txt_dec4";
            this.txt_dec4.Size = new System.Drawing.Size(97, 21);
            this.txt_dec4.TabIndex = 27;
            this.txt_dec4.Text = "0.1";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(14, 98);
            this.label22.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(41, 12);
            this.label22.TabIndex = 26;
            this.label22.Text = "减速度";
            // 
            // txt_val4
            // 
            this.txt_val4.Location = new System.Drawing.Point(115, 26);
            this.txt_val4.Margin = new System.Windows.Forms.Padding(2);
            this.txt_val4.Name = "txt_val4";
            this.txt_val4.Size = new System.Drawing.Size(97, 21);
            this.txt_val4.TabIndex = 25;
            this.txt_val4.Text = "5";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(14, 28);
            this.label23.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(29, 12);
            this.label23.TabIndex = 24;
            this.label23.Text = "速度";
            // 
            // txt_acc4
            // 
            this.txt_acc4.Location = new System.Drawing.Point(115, 62);
            this.txt_acc4.Margin = new System.Windows.Forms.Padding(2);
            this.txt_acc4.Name = "txt_acc4";
            this.txt_acc4.Size = new System.Drawing.Size(97, 21);
            this.txt_acc4.TabIndex = 23;
            this.txt_acc4.Text = "0.1";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(14, 63);
            this.label24.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(41, 12);
            this.label24.TabIndex = 22;
            this.label24.Text = "加速度";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.txt_time3);
            this.groupBox3.Controls.Add(this.label27);
            this.groupBox3.Controls.Add(this.txt_pvmm3);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.txt_rightLimt3);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.txt_leftLimt3);
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Controls.Add(this.txt_dec3);
            this.groupBox3.Controls.Add(this.label16);
            this.groupBox3.Controls.Add(this.txt_val3);
            this.groupBox3.Controls.Add(this.label17);
            this.groupBox3.Controls.Add(this.txt_acc3);
            this.groupBox3.Controls.Add(this.label18);
            this.groupBox3.Location = new System.Drawing.Point(488, 6);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox3.Size = new System.Drawing.Size(225, 248);
            this.groupBox3.TabIndex = 34;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Z轴";
            // 
            // txt_time3
            // 
            this.txt_time3.Location = new System.Drawing.Point(115, 223);
            this.txt_time3.Margin = new System.Windows.Forms.Padding(2);
            this.txt_time3.Name = "txt_time3";
            this.txt_time3.Size = new System.Drawing.Size(97, 21);
            this.txt_time3.TabIndex = 37;
            this.txt_time3.Text = "3";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(14, 225);
            this.label27.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(53, 12);
            this.label27.TabIndex = 36;
            this.label27.Text = "平滑时间";
            // 
            // txt_pvmm3
            // 
            this.txt_pvmm3.Location = new System.Drawing.Point(115, 191);
            this.txt_pvmm3.Margin = new System.Windows.Forms.Padding(2);
            this.txt_pvmm3.Name = "txt_pvmm3";
            this.txt_pvmm3.Size = new System.Drawing.Size(97, 21);
            this.txt_pvmm3.TabIndex = 33;
            this.txt_pvmm3.Text = "8000";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(14, 193);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(47, 12);
            this.label13.TabIndex = 32;
            this.label13.Text = "脉冲/mm";
            // 
            // txt_rightLimt3
            // 
            this.txt_rightLimt3.Location = new System.Drawing.Point(115, 160);
            this.txt_rightLimt3.Margin = new System.Windows.Forms.Padding(2);
            this.txt_rightLimt3.Name = "txt_rightLimt3";
            this.txt_rightLimt3.Size = new System.Drawing.Size(97, 21);
            this.txt_rightLimt3.TabIndex = 31;
            this.txt_rightLimt3.Text = "8000";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(14, 162);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(53, 12);
            this.label14.TabIndex = 30;
            this.label14.Text = "软正限位";
            // 
            // txt_leftLimt3
            // 
            this.txt_leftLimt3.Location = new System.Drawing.Point(115, 129);
            this.txt_leftLimt3.Margin = new System.Windows.Forms.Padding(2);
            this.txt_leftLimt3.Name = "txt_leftLimt3";
            this.txt_leftLimt3.Size = new System.Drawing.Size(97, 21);
            this.txt_leftLimt3.TabIndex = 29;
            this.txt_leftLimt3.Text = "-200";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(14, 130);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(53, 12);
            this.label15.TabIndex = 28;
            this.label15.Text = "软负限位";
            // 
            // txt_dec3
            // 
            this.txt_dec3.Location = new System.Drawing.Point(115, 96);
            this.txt_dec3.Margin = new System.Windows.Forms.Padding(2);
            this.txt_dec3.Name = "txt_dec3";
            this.txt_dec3.Size = new System.Drawing.Size(97, 21);
            this.txt_dec3.TabIndex = 27;
            this.txt_dec3.Text = "0.1";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(14, 98);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(41, 12);
            this.label16.TabIndex = 26;
            this.label16.Text = "减速度";
            // 
            // txt_val3
            // 
            this.txt_val3.Location = new System.Drawing.Point(115, 26);
            this.txt_val3.Margin = new System.Windows.Forms.Padding(2);
            this.txt_val3.Name = "txt_val3";
            this.txt_val3.Size = new System.Drawing.Size(97, 21);
            this.txt_val3.TabIndex = 25;
            this.txt_val3.Text = "5";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(14, 28);
            this.label17.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(29, 12);
            this.label17.TabIndex = 24;
            this.label17.Text = "速度";
            // 
            // txt_acc3
            // 
            this.txt_acc3.Location = new System.Drawing.Point(115, 62);
            this.txt_acc3.Margin = new System.Windows.Forms.Padding(2);
            this.txt_acc3.Name = "txt_acc3";
            this.txt_acc3.Size = new System.Drawing.Size(97, 21);
            this.txt_acc3.TabIndex = 23;
            this.txt_acc3.Text = "0.1";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(14, 63);
            this.label18.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(41, 12);
            this.label18.TabIndex = 22;
            this.label18.Text = "加速度";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txt_time2);
            this.groupBox2.Controls.Add(this.label26);
            this.groupBox2.Controls.Add(this.txt_pvmm2);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.txt_rightLimt2);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.txt_leftLimt2);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.txt_dec2);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.txt_val2);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.txt_acc2);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Location = new System.Drawing.Point(247, 6);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox2.Size = new System.Drawing.Size(225, 248);
            this.groupBox2.TabIndex = 34;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Y轴";
            // 
            // txt_time2
            // 
            this.txt_time2.Location = new System.Drawing.Point(115, 223);
            this.txt_time2.Margin = new System.Windows.Forms.Padding(2);
            this.txt_time2.Name = "txt_time2";
            this.txt_time2.Size = new System.Drawing.Size(97, 21);
            this.txt_time2.TabIndex = 37;
            this.txt_time2.Text = "3";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(14, 225);
            this.label26.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(53, 12);
            this.label26.TabIndex = 36;
            this.label26.Text = "平滑时间";
            // 
            // txt_pvmm2
            // 
            this.txt_pvmm2.Location = new System.Drawing.Point(115, 190);
            this.txt_pvmm2.Margin = new System.Windows.Forms.Padding(2);
            this.txt_pvmm2.Name = "txt_pvmm2";
            this.txt_pvmm2.Size = new System.Drawing.Size(97, 21);
            this.txt_pvmm2.TabIndex = 33;
            this.txt_pvmm2.Text = "8000";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(14, 192);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(47, 12);
            this.label6.TabIndex = 32;
            this.label6.Text = "脉冲/mm";
            // 
            // txt_rightLimt2
            // 
            this.txt_rightLimt2.Location = new System.Drawing.Point(115, 160);
            this.txt_rightLimt2.Margin = new System.Windows.Forms.Padding(2);
            this.txt_rightLimt2.Name = "txt_rightLimt2";
            this.txt_rightLimt2.Size = new System.Drawing.Size(97, 21);
            this.txt_rightLimt2.TabIndex = 31;
            this.txt_rightLimt2.Text = "8000";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(14, 162);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 12);
            this.label7.TabIndex = 30;
            this.label7.Text = "软正限位";
            // 
            // txt_leftLimt2
            // 
            this.txt_leftLimt2.Location = new System.Drawing.Point(115, 129);
            this.txt_leftLimt2.Margin = new System.Windows.Forms.Padding(2);
            this.txt_leftLimt2.Name = "txt_leftLimt2";
            this.txt_leftLimt2.Size = new System.Drawing.Size(97, 21);
            this.txt_leftLimt2.TabIndex = 29;
            this.txt_leftLimt2.Text = "-200";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(14, 130);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 12);
            this.label8.TabIndex = 28;
            this.label8.Text = "软负限位";
            // 
            // txt_dec2
            // 
            this.txt_dec2.Location = new System.Drawing.Point(115, 96);
            this.txt_dec2.Margin = new System.Windows.Forms.Padding(2);
            this.txt_dec2.Name = "txt_dec2";
            this.txt_dec2.Size = new System.Drawing.Size(97, 21);
            this.txt_dec2.TabIndex = 27;
            this.txt_dec2.Text = "0.1";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(14, 98);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(41, 12);
            this.label9.TabIndex = 26;
            this.label9.Text = "减速度";
            // 
            // txt_val2
            // 
            this.txt_val2.Location = new System.Drawing.Point(115, 26);
            this.txt_val2.Margin = new System.Windows.Forms.Padding(2);
            this.txt_val2.Name = "txt_val2";
            this.txt_val2.Size = new System.Drawing.Size(97, 21);
            this.txt_val2.TabIndex = 25;
            this.txt_val2.Text = "5";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(14, 28);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(29, 12);
            this.label11.TabIndex = 24;
            this.label11.Text = "速度";
            // 
            // txt_acc2
            // 
            this.txt_acc2.Location = new System.Drawing.Point(115, 62);
            this.txt_acc2.Margin = new System.Windows.Forms.Padding(2);
            this.txt_acc2.Name = "txt_acc2";
            this.txt_acc2.Size = new System.Drawing.Size(97, 21);
            this.txt_acc2.TabIndex = 23;
            this.txt_acc2.Text = "0.1";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(14, 63);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(41, 12);
            this.label12.TabIndex = 22;
            this.label12.Text = "加速度";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txt_time1);
            this.groupBox1.Controls.Add(this.label25);
            this.groupBox1.Controls.Add(this.txt_pvmm1);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.txt_rightLimt1);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txt_leftLimt1);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txt_dec1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txt_val1);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txt_acc1);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Location = new System.Drawing.Point(7, 6);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox1.Size = new System.Drawing.Size(225, 248);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "X轴";
            // 
            // txt_time1
            // 
            this.txt_time1.Location = new System.Drawing.Point(115, 217);
            this.txt_time1.Margin = new System.Windows.Forms.Padding(2);
            this.txt_time1.Name = "txt_time1";
            this.txt_time1.Size = new System.Drawing.Size(97, 21);
            this.txt_time1.TabIndex = 35;
            this.txt_time1.Text = "3";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(14, 218);
            this.label25.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(53, 12);
            this.label25.TabIndex = 34;
            this.label25.Text = "平滑时间";
            // 
            // txt_pvmm1
            // 
            this.txt_pvmm1.Location = new System.Drawing.Point(115, 190);
            this.txt_pvmm1.Margin = new System.Windows.Forms.Padding(2);
            this.txt_pvmm1.Name = "txt_pvmm1";
            this.txt_pvmm1.Size = new System.Drawing.Size(97, 21);
            this.txt_pvmm1.TabIndex = 33;
            this.txt_pvmm1.Text = "8000";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(14, 191);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(47, 12);
            this.label5.TabIndex = 32;
            this.label5.Text = "脉冲/mm";
            // 
            // txt_rightLimt1
            // 
            this.txt_rightLimt1.Location = new System.Drawing.Point(115, 160);
            this.txt_rightLimt1.Margin = new System.Windows.Forms.Padding(2);
            this.txt_rightLimt1.Name = "txt_rightLimt1";
            this.txt_rightLimt1.Size = new System.Drawing.Size(97, 21);
            this.txt_rightLimt1.TabIndex = 31;
            this.txt_rightLimt1.Text = "8000";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(14, 162);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 12);
            this.label4.TabIndex = 30;
            this.label4.Text = "软正限位";
            // 
            // txt_leftLimt1
            // 
            this.txt_leftLimt1.Location = new System.Drawing.Point(115, 129);
            this.txt_leftLimt1.Margin = new System.Windows.Forms.Padding(2);
            this.txt_leftLimt1.Name = "txt_leftLimt1";
            this.txt_leftLimt1.Size = new System.Drawing.Size(97, 21);
            this.txt_leftLimt1.TabIndex = 29;
            this.txt_leftLimt1.Text = "-200";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(14, 130);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 12);
            this.label3.TabIndex = 28;
            this.label3.Text = "软负限位";
            // 
            // txt_dec1
            // 
            this.txt_dec1.Location = new System.Drawing.Point(115, 96);
            this.txt_dec1.Margin = new System.Windows.Forms.Padding(2);
            this.txt_dec1.Name = "txt_dec1";
            this.txt_dec1.Size = new System.Drawing.Size(97, 21);
            this.txt_dec1.TabIndex = 27;
            this.txt_dec1.Text = "0.1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(14, 98);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 12);
            this.label2.TabIndex = 26;
            this.label2.Text = "减速度";
            // 
            // txt_val1
            // 
            this.txt_val1.Location = new System.Drawing.Point(115, 26);
            this.txt_val1.Margin = new System.Windows.Forms.Padding(2);
            this.txt_val1.Name = "txt_val1";
            this.txt_val1.Size = new System.Drawing.Size(97, 21);
            this.txt_val1.TabIndex = 25;
            this.txt_val1.Text = "5";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 28);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 12);
            this.label1.TabIndex = 24;
            this.label1.Text = "速度";
            // 
            // txt_acc1
            // 
            this.txt_acc1.Location = new System.Drawing.Point(115, 62);
            this.txt_acc1.Margin = new System.Windows.Forms.Padding(2);
            this.txt_acc1.Name = "txt_acc1";
            this.txt_acc1.Size = new System.Drawing.Size(97, 21);
            this.txt_acc1.TabIndex = 23;
            this.txt_acc1.Text = "0.1";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(14, 63);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(41, 12);
            this.label10.TabIndex = 22;
            this.label10.Text = "加速度";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.ZhouParam);
            this.tabControl1.Controls.Add(this.OtherParam);
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Location = new System.Drawing.Point(12, 6);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(755, 565);
            this.tabControl1.TabIndex = 1;
            // 
            // ZhouParam
            // 
            this.ZhouParam.Controls.Add(this.panel1);
            this.ZhouParam.Location = new System.Drawing.Point(4, 22);
            this.ZhouParam.Name = "ZhouParam";
            this.ZhouParam.Padding = new System.Windows.Forms.Padding(3);
            this.ZhouParam.Size = new System.Drawing.Size(747, 539);
            this.ZhouParam.TabIndex = 0;
            this.ZhouParam.Text = "轴参数";
            this.ZhouParam.UseVisualStyleBackColor = true;
            // 
            // OtherParam
            // 
            this.OtherParam.Controls.Add(this.chk_smt);
            this.OtherParam.Controls.Add(this.txt_buz2);
            this.OtherParam.Controls.Add(this.txt_buz1);
            this.OtherParam.Controls.Add(this.chk_buz);
            this.OtherParam.Controls.Add(this.groupBox10);
            this.OtherParam.Controls.Add(this.chk_sip);
            this.OtherParam.Controls.Add(this.txt_runnum);
            this.OtherParam.Controls.Add(this.label38);
            this.OtherParam.Controls.Add(this.groupBox8);
            this.OtherParam.Controls.Add(this.groupBox6);
            this.OtherParam.Controls.Add(this.groupBox5);
            this.OtherParam.Location = new System.Drawing.Point(4, 22);
            this.OtherParam.Name = "OtherParam";
            this.OtherParam.Padding = new System.Windows.Forms.Padding(3);
            this.OtherParam.Size = new System.Drawing.Size(747, 539);
            this.OtherParam.TabIndex = 1;
            this.OtherParam.Text = "杂项";
            this.OtherParam.UseVisualStyleBackColor = true;
            // 
            // txt_buz2
            // 
            this.txt_buz2.Location = new System.Drawing.Point(212, 290);
            this.txt_buz2.Name = "txt_buz2";
            this.txt_buz2.Size = new System.Drawing.Size(80, 21);
            this.txt_buz2.TabIndex = 16;
            this.txt_buz2.Text = "300";
            // 
            // txt_buz1
            // 
            this.txt_buz1.Location = new System.Drawing.Point(126, 290);
            this.txt_buz1.Name = "txt_buz1";
            this.txt_buz1.Size = new System.Drawing.Size(80, 21);
            this.txt_buz1.TabIndex = 15;
            this.txt_buz1.Text = "300";
            // 
            // chk_buz
            // 
            this.chk_buz.AutoSize = true;
            this.chk_buz.Location = new System.Drawing.Point(22, 295);
            this.chk_buz.Name = "chk_buz";
            this.chk_buz.Size = new System.Drawing.Size(96, 16);
            this.chk_buz.TabIndex = 14;
            this.chk_buz.Text = "间断蜂鸣时长";
            this.chk_buz.UseVisualStyleBackColor = true;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.txt_3d2y);
            this.groupBox10.Controls.Add(this.label57);
            this.groupBox10.Controls.Add(this.txt_3d2x);
            this.groupBox10.Controls.Add(this.label58);
            this.groupBox10.Controls.Add(this.txt_3d1y);
            this.groupBox10.Controls.Add(this.label56);
            this.groupBox10.Controls.Add(this.txt_3d1x);
            this.groupBox10.Controls.Add(this.label55);
            this.groupBox10.Location = new System.Drawing.Point(8, 327);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(309, 114);
            this.groupBox10.TabIndex = 13;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "3D偏差值";
            // 
            // txt_3d2y
            // 
            this.txt_3d2y.Location = new System.Drawing.Point(230, 74);
            this.txt_3d2y.Name = "txt_3d2y";
            this.txt_3d2y.Size = new System.Drawing.Size(53, 21);
            this.txt_3d2y.TabIndex = 16;
            this.txt_3d2y.Text = "10";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(172, 77);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(35, 12);
            this.label57.TabIndex = 15;
            this.label57.Text = "3D2_Y";
            // 
            // txt_3d2x
            // 
            this.txt_3d2x.Location = new System.Drawing.Point(75, 74);
            this.txt_3d2x.Name = "txt_3d2x";
            this.txt_3d2x.Size = new System.Drawing.Size(53, 21);
            this.txt_3d2x.TabIndex = 14;
            this.txt_3d2x.Text = "10";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(17, 77);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(35, 12);
            this.label58.TabIndex = 13;
            this.label58.Text = "3D2_X";
            // 
            // txt_3d1y
            // 
            this.txt_3d1y.Location = new System.Drawing.Point(229, 30);
            this.txt_3d1y.Name = "txt_3d1y";
            this.txt_3d1y.Size = new System.Drawing.Size(53, 21);
            this.txt_3d1y.TabIndex = 12;
            this.txt_3d1y.Text = "10";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(171, 33);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(35, 12);
            this.label56.TabIndex = 11;
            this.label56.Text = "3D1_Y";
            // 
            // txt_3d1x
            // 
            this.txt_3d1x.Location = new System.Drawing.Point(74, 30);
            this.txt_3d1x.Name = "txt_3d1x";
            this.txt_3d1x.Size = new System.Drawing.Size(53, 21);
            this.txt_3d1x.TabIndex = 10;
            this.txt_3d1x.Text = "10";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(16, 33);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(35, 12);
            this.label55.TabIndex = 9;
            this.label55.Text = "3D1_X";
            // 
            // chk_sip
            // 
            this.chk_sip.AutoSize = true;
            this.chk_sip.Location = new System.Drawing.Point(22, 263);
            this.chk_sip.Name = "chk_sip";
            this.chk_sip.Size = new System.Drawing.Size(48, 16);
            this.chk_sip.TabIndex = 12;
            this.chk_sip.Text = "直通";
            this.chk_sip.UseVisualStyleBackColor = true;
            // 
            // txt_runnum
            // 
            this.txt_runnum.Location = new System.Drawing.Point(168, 226);
            this.txt_runnum.Name = "txt_runnum";
            this.txt_runnum.Size = new System.Drawing.Size(80, 21);
            this.txt_runnum.TabIndex = 11;
            this.txt_runnum.Text = "3";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(20, 229);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(107, 12);
            this.label38.TabIndex = 10;
            this.label38.Text = "扫描N次失败后跳过";
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.label37);
            this.groupBox8.Controls.Add(this.txt_delyTime);
            this.groupBox8.Controls.Add(this.label36);
            this.groupBox8.Location = new System.Drawing.Point(6, 135);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(311, 69);
            this.groupBox8.TabIndex = 9;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "时间设定";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(248, 31);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(17, 12);
            this.label37.TabIndex = 9;
            this.label37.Text = "ms";
            // 
            // txt_delyTime
            // 
            this.txt_delyTime.Location = new System.Drawing.Point(120, 28);
            this.txt_delyTime.Name = "txt_delyTime";
            this.txt_delyTime.Size = new System.Drawing.Size(122, 21);
            this.txt_delyTime.TabIndex = 8;
            this.txt_delyTime.Text = "2000";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(14, 31);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(77, 12);
            this.label36.TabIndex = 7;
            this.label36.Text = "到位检测延时";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.label35);
            this.groupBox6.Controls.Add(this.txt_3Ddis);
            this.groupBox6.Controls.Add(this.groupBox7);
            this.groupBox6.Controls.Add(this.txt_3DVal);
            this.groupBox6.Controls.Add(this.label31);
            this.groupBox6.Controls.Add(this.button4);
            this.groupBox6.Controls.Add(this.button3);
            this.groupBox6.Controls.Add(this.lst_poss);
            this.groupBox6.Location = new System.Drawing.Point(390, 6);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(357, 470);
            this.groupBox6.TabIndex = 2;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "设置位置";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(17, 306);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(65, 12);
            this.label35.TabIndex = 11;
            this.label35.Text = "3D扫描长度";
            // 
            // txt_3Ddis
            // 
            this.txt_3Ddis.Location = new System.Drawing.Point(119, 303);
            this.txt_3Ddis.Name = "txt_3Ddis";
            this.txt_3Ddis.Size = new System.Drawing.Size(124, 21);
            this.txt_3Ddis.TabIndex = 10;
            this.txt_3Ddis.Text = "90000";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.btn_bd);
            this.groupBox7.Controls.Add(this.txt_bdnum);
            this.groupBox7.Controls.Add(this.label34);
            this.groupBox7.Controls.Add(this.txt_bdbc);
            this.groupBox7.Controls.Add(this.label33);
            this.groupBox7.Controls.Add(this.txt_bdpos);
            this.groupBox7.Controls.Add(this.label32);
            this.groupBox7.Location = new System.Drawing.Point(19, 330);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(228, 134);
            this.groupBox7.TabIndex = 9;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "标定";
            // 
            // btn_bd
            // 
            this.btn_bd.BackColor = System.Drawing.Color.Gray;
            this.btn_bd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bd.ForeColor = System.Drawing.Color.White;
            this.btn_bd.Location = new System.Drawing.Point(124, 105);
            this.btn_bd.Name = "btn_bd";
            this.btn_bd.Size = new System.Drawing.Size(98, 23);
            this.btn_bd.TabIndex = 6;
            this.btn_bd.Text = "开始标定测试";
            this.btn_bd.UseVisualStyleBackColor = false;
            this.btn_bd.Click += new System.EventHandler(this.button5_Click);
            // 
            // txt_bdnum
            // 
            this.txt_bdnum.Location = new System.Drawing.Point(124, 72);
            this.txt_bdnum.Name = "txt_bdnum";
            this.txt_bdnum.Size = new System.Drawing.Size(100, 21);
            this.txt_bdnum.TabIndex = 5;
            this.txt_bdnum.Text = "0";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(7, 75);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(53, 12);
            this.label34.TabIndex = 4;
            this.label34.Text = "移动次数";
            // 
            // txt_bdbc
            // 
            this.txt_bdbc.Location = new System.Drawing.Point(124, 45);
            this.txt_bdbc.Name = "txt_bdbc";
            this.txt_bdbc.Size = new System.Drawing.Size(100, 21);
            this.txt_bdbc.TabIndex = 3;
            this.txt_bdbc.Text = "10000";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(7, 48);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(77, 12);
            this.label33.TabIndex = 2;
            this.label33.Text = "每次移动间距";
            // 
            // txt_bdpos
            // 
            this.txt_bdpos.Location = new System.Drawing.Point(124, 18);
            this.txt_bdpos.Name = "txt_bdpos";
            this.txt_bdpos.Size = new System.Drawing.Size(100, 21);
            this.txt_bdpos.TabIndex = 1;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(7, 21);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(101, 12);
            this.label32.TabIndex = 0;
            this.label32.Text = "选择上面一个位置";
            // 
            // txt_3DVal
            // 
            this.txt_3DVal.Location = new System.Drawing.Point(119, 271);
            this.txt_3DVal.Name = "txt_3DVal";
            this.txt_3DVal.Size = new System.Drawing.Size(124, 21);
            this.txt_3DVal.TabIndex = 8;
            this.txt_3DVal.Text = "10";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(17, 274);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(65, 12);
            this.label31.TabIndex = 7;
            this.label31.Text = "3D扫描速度";
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Gray;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Location = new System.Drawing.Point(239, 30);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(69, 23);
            this.button4.TabIndex = 2;
            this.button4.Text = "执行";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Gray;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(154, 30);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(69, 23);
            this.button3.TabIndex = 1;
            this.button3.Text = "写入";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // lst_poss
            // 
            this.lst_poss.AutoArrange = false;
            this.lst_poss.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4});
            this.lst_poss.FullRowSelect = true;
            this.lst_poss.GridLines = true;
            this.lst_poss.HideSelection = false;
            this.lst_poss.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem1,
            listViewItem2,
            listViewItem3,
            listViewItem4,
            listViewItem5,
            listViewItem6});
            this.lst_poss.Location = new System.Drawing.Point(7, 56);
            this.lst_poss.Name = "lst_poss";
            this.lst_poss.Size = new System.Drawing.Size(344, 198);
            this.lst_poss.TabIndex = 0;
            this.lst_poss.UseCompatibleStateImageBehavior = false;
            this.lst_poss.View = System.Windows.Forms.View.Details;
            this.lst_poss.MouseClick += new System.Windows.Forms.MouseEventHandler(this.lst_poss_MouseClick);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Name";
            this.columnHeader1.Width = 79;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "X";
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Y";
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Z";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.button2);
            this.groupBox5.Controls.Add(this.btn_look);
            this.groupBox5.Controls.Add(this.txt_log);
            this.groupBox5.Controls.Add(this.label29);
            this.groupBox5.Controls.Add(this.label30);
            this.groupBox5.Controls.Add(this.txt_smt);
            this.groupBox5.Location = new System.Drawing.Point(6, 6);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(349, 123);
            this.groupBox5.TabIndex = 1;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "文件路径";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Gray;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(268, 71);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 6;
            this.button2.Text = "浏览";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // btn_look
            // 
            this.btn_look.BackColor = System.Drawing.Color.Gray;
            this.btn_look.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_look.ForeColor = System.Drawing.Color.White;
            this.btn_look.Location = new System.Drawing.Point(268, 30);
            this.btn_look.Name = "btn_look";
            this.btn_look.Size = new System.Drawing.Size(75, 23);
            this.btn_look.TabIndex = 3;
            this.btn_look.Text = "浏览";
            this.btn_look.UseVisualStyleBackColor = false;
            this.btn_look.Click += new System.EventHandler(this.btn_look_Click);
            // 
            // txt_log
            // 
            this.txt_log.Location = new System.Drawing.Point(106, 73);
            this.txt_log.Name = "txt_log";
            this.txt_log.Size = new System.Drawing.Size(136, 21);
            this.txt_log.TabIndex = 5;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(0, 35);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(95, 12);
            this.label29.TabIndex = 0;
            this.label29.Text = "SMT配置文件路径";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(0, 76);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(71, 12);
            this.label30.TabIndex = 4;
            this.label30.Text = "Log保存路径";
            // 
            // txt_smt
            // 
            this.txt_smt.Location = new System.Drawing.Point(106, 32);
            this.txt_smt.Name = "txt_smt";
            this.txt_smt.Size = new System.Drawing.Size(136, 21);
            this.txt_smt.TabIndex = 2;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox9);
            this.tabPage1.Controls.Add(this.button7);
            this.tabPage1.Controls.Add(this.button6);
            this.tabPage1.Controls.Add(this.label39);
            this.tabPage1.Controls.Add(this.cb_project);
            this.tabPage1.Controls.Add(this.button5);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Size = new System.Drawing.Size(747, 539);
            this.tabPage1.TabIndex = 2;
            this.tabPage1.Text = "流程模版";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.label72);
            this.groupBox9.Controls.Add(this.label71);
            this.groupBox9.Controls.Add(this.ckb_g);
            this.groupBox9.Controls.Add(this.txt_g_dis);
            this.groupBox9.Controls.Add(this.label73);
            this.groupBox9.Controls.Add(this.cb_jackAir2);
            this.groupBox9.Controls.Add(this.cb_jackAir);
            this.groupBox9.Controls.Add(this.label69);
            this.groupBox9.Controls.Add(this.cb_blockAir);
            this.groupBox9.Controls.Add(this.label70);
            this.groupBox9.Controls.Add(this.txt_gpu);
            this.groupBox9.Controls.Add(this.label61);
            this.groupBox9.Controls.Add(this.cb_after);
            this.groupBox9.Controls.Add(this.label60);
            this.groupBox9.Controls.Add(this.cb_befor);
            this.groupBox9.Controls.Add(this.label59);
            this.groupBox9.Controls.Add(this.txt_speed);
            this.groupBox9.Controls.Add(this.label40);
            this.groupBox9.Controls.Add(this.gb_mark);
            this.groupBox9.Controls.Add(this.gb_pos);
            this.groupBox9.Controls.Add(this.ckb_mark);
            this.groupBox9.Controls.Add(this.ckb_ip);
            this.groupBox9.Controls.Add(this.label46);
            this.groupBox9.Controls.Add(this.txt_length);
            this.groupBox9.Controls.Add(this.label47);
            this.groupBox9.Controls.Add(this.txt_ip);
            this.groupBox9.Controls.Add(this.label48);
            this.groupBox9.Controls.Add(this.txt_dely_out);
            this.groupBox9.Controls.Add(this.label49);
            this.groupBox9.Controls.Add(this.txt_dely_put);
            this.groupBox9.Controls.Add(this.label50);
            this.groupBox9.Controls.Add(this.txt_dely_in);
            this.groupBox9.Controls.Add(this.cb_out);
            this.groupBox9.Controls.Add(this.label51);
            this.groupBox9.Controls.Add(this.cb_put);
            this.groupBox9.Controls.Add(this.label52);
            this.groupBox9.Controls.Add(this.cb_in);
            this.groupBox9.Controls.Add(this.label53);
            this.groupBox9.Controls.Add(this.txt_name);
            this.groupBox9.Controls.Add(this.label54);
            this.groupBox9.Location = new System.Drawing.Point(23, 13);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(392, 523);
            this.groupBox9.TabIndex = 8;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "流程";
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(272, 422);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(17, 12);
            this.label72.TabIndex = 46;
            this.label72.Text = "mm";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(33, 166);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(101, 12);
            this.label71.TabIndex = 43;
            this.label71.Text = "顶升气缸下降信号";
            // 
            // ckb_g
            // 
            this.ckb_g.AutoSize = true;
            this.ckb_g.Location = new System.Drawing.Point(309, 39);
            this.ckb_g.Name = "ckb_g";
            this.ckb_g.Size = new System.Drawing.Size(72, 16);
            this.ckb_g.TabIndex = 42;
            this.ckb_g.Text = "运轨正向";
            this.ckb_g.UseVisualStyleBackColor = true;
            // 
            // txt_g_dis
            // 
            this.txt_g_dis.Location = new System.Drawing.Point(136, 419);
            this.txt_g_dis.Name = "txt_g_dis";
            this.txt_g_dis.Size = new System.Drawing.Size(121, 21);
            this.txt_g_dis.TabIndex = 45;
            this.txt_g_dis.Text = "0";
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Location = new System.Drawing.Point(24, 422);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(77, 12);
            this.label73.TabIndex = 44;
            this.label73.Text = "运输补偿距离";
            // 
            // cb_jackAir2
            // 
            this.cb_jackAir2.FormattingEnabled = true;
            this.cb_jackAir2.Location = new System.Drawing.Point(135, 164);
            this.cb_jackAir2.Name = "cb_jackAir2";
            this.cb_jackAir2.Size = new System.Drawing.Size(122, 20);
            this.cb_jackAir2.TabIndex = 41;
            // 
            // cb_jackAir
            // 
            this.cb_jackAir.FormattingEnabled = true;
            this.cb_jackAir.Location = new System.Drawing.Point(136, 135);
            this.cb_jackAir.Name = "cb_jackAir";
            this.cb_jackAir.Size = new System.Drawing.Size(120, 20);
            this.cb_jackAir.TabIndex = 40;
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Location = new System.Drawing.Point(33, 138);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(101, 12);
            this.label69.TabIndex = 39;
            this.label69.Text = "顶升气缸上升信号";
            // 
            // cb_blockAir
            // 
            this.cb_blockAir.FormattingEnabled = true;
            this.cb_blockAir.Location = new System.Drawing.Point(135, 499);
            this.cb_blockAir.Name = "cb_blockAir";
            this.cb_blockAir.Size = new System.Drawing.Size(121, 20);
            this.cb_blockAir.TabIndex = 38;
            this.cb_blockAir.Visible = false;
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(32, 502);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(77, 12);
            this.label70.TabIndex = 37;
            this.label70.Text = "阻挡气缸信号";
            this.label70.Visible = false;
            // 
            // txt_gpu
            // 
            this.txt_gpu.Location = new System.Drawing.Point(135, 444);
            this.txt_gpu.Name = "txt_gpu";
            this.txt_gpu.Size = new System.Drawing.Size(121, 21);
            this.txt_gpu.TabIndex = 36;
            this.txt_gpu.Text = "1";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(23, 447);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(47, 12);
            this.label61.TabIndex = 35;
            this.label61.Text = "GPU类型";
            // 
            // cb_after
            // 
            this.cb_after.FormattingEnabled = true;
            this.cb_after.Location = new System.Drawing.Point(136, 213);
            this.cb_after.Name = "cb_after";
            this.cb_after.Size = new System.Drawing.Size(121, 20);
            this.cb_after.TabIndex = 34;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(33, 216);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(77, 12);
            this.label60.TabIndex = 33;
            this.label60.Text = "后机要料信号";
            // 
            // cb_befor
            // 
            this.cb_befor.FormattingEnabled = true;
            this.cb_befor.Location = new System.Drawing.Point(136, 187);
            this.cb_befor.Name = "cb_befor";
            this.cb_befor.Size = new System.Drawing.Size(121, 20);
            this.cb_befor.TabIndex = 32;
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(33, 190);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(77, 12);
            this.label59.TabIndex = 31;
            this.label59.Text = "前机要料信号";
            // 
            // txt_speed
            // 
            this.txt_speed.Location = new System.Drawing.Point(136, 392);
            this.txt_speed.Name = "txt_speed";
            this.txt_speed.Size = new System.Drawing.Size(121, 21);
            this.txt_speed.TabIndex = 30;
            this.txt_speed.Text = "10";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(24, 395);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(65, 12);
            this.label40.TabIndex = 29;
            this.label40.Text = "3D扫描速度";
            // 
            // gb_mark
            // 
            this.gb_mark.Controls.Add(this.label41);
            this.gb_mark.Controls.Add(this.cb_mark2);
            this.gb_mark.Controls.Add(this.cb_mark1);
            this.gb_mark.Controls.Add(this.label42);
            this.gb_mark.Location = new System.Drawing.Point(25, 292);
            this.gb_mark.Name = "gb_mark";
            this.gb_mark.Size = new System.Drawing.Size(241, 71);
            this.gb_mark.TabIndex = 28;
            this.gb_mark.TabStop = false;
            this.gb_mark.Text = "Mark点";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(7, 21);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(47, 12);
            this.label41.TabIndex = 8;
            this.label41.Text = "Mark点1";
            // 
            // cb_mark2
            // 
            this.cb_mark2.FormattingEnabled = true;
            this.cb_mark2.Location = new System.Drawing.Point(110, 44);
            this.cb_mark2.Name = "cb_mark2";
            this.cb_mark2.Size = new System.Drawing.Size(121, 20);
            this.cb_mark2.TabIndex = 11;
            // 
            // cb_mark1
            // 
            this.cb_mark1.FormattingEnabled = true;
            this.cb_mark1.Location = new System.Drawing.Point(110, 18);
            this.cb_mark1.Name = "cb_mark1";
            this.cb_mark1.Size = new System.Drawing.Size(121, 20);
            this.cb_mark1.TabIndex = 9;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(7, 47);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(47, 12);
            this.label42.TabIndex = 10;
            this.label42.Text = "Mark点2";
            // 
            // gb_pos
            // 
            this.gb_pos.Controls.Add(this.cb_3d2);
            this.gb_pos.Controls.Add(this.label43);
            this.gb_pos.Controls.Add(this.cb_2d);
            this.gb_pos.Controls.Add(this.label44);
            this.gb_pos.Controls.Add(this.cb_3d1);
            this.gb_pos.Controls.Add(this.label45);
            this.gb_pos.Location = new System.Drawing.Point(25, 237);
            this.gb_pos.Name = "gb_pos";
            this.gb_pos.Size = new System.Drawing.Size(241, 51);
            this.gb_pos.TabIndex = 27;
            this.gb_pos.TabStop = false;
            this.gb_pos.Text = "位置";
            // 
            // cb_3d2
            // 
            this.cb_3d2.FormattingEnabled = true;
            this.cb_3d2.Location = new System.Drawing.Point(111, 75);
            this.cb_3d2.Name = "cb_3d2";
            this.cb_3d2.Size = new System.Drawing.Size(121, 20);
            this.cb_3d2.TabIndex = 7;
            this.cb_3d2.Visible = false;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(8, 22);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(53, 12);
            this.label43.TabIndex = 2;
            this.label43.Text = "2D拍照位";
            // 
            // cb_2d
            // 
            this.cb_2d.FormattingEnabled = true;
            this.cb_2d.Location = new System.Drawing.Point(111, 19);
            this.cb_2d.Name = "cb_2d";
            this.cb_2d.Size = new System.Drawing.Size(121, 20);
            this.cb_2d.TabIndex = 3;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(8, 55);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(83, 12);
            this.label44.TabIndex = 4;
            this.label44.Text = "3D1扫描起始位";
            this.label44.Visible = false;
            // 
            // cb_3d1
            // 
            this.cb_3d1.FormattingEnabled = true;
            this.cb_3d1.Location = new System.Drawing.Point(111, 52);
            this.cb_3d1.Name = "cb_3d1";
            this.cb_3d1.Size = new System.Drawing.Size(121, 20);
            this.cb_3d1.TabIndex = 5;
            this.cb_3d1.Visible = false;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(8, 78);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(83, 12);
            this.label45.TabIndex = 6;
            this.label45.Text = "3D2扫描起始位";
            this.label45.Visible = false;
            // 
            // ckb_mark
            // 
            this.ckb_mark.AutoSize = true;
            this.ckb_mark.Location = new System.Drawing.Point(309, 21);
            this.ckb_mark.Name = "ckb_mark";
            this.ckb_mark.Size = new System.Drawing.Size(72, 16);
            this.ckb_mark.TabIndex = 26;
            this.ckb_mark.Text = "启用Mark";
            this.ckb_mark.UseVisualStyleBackColor = true;
            this.ckb_mark.CheckedChanged += new System.EventHandler(this.ckb_mark_CheckedChanged);
            // 
            // ckb_ip
            // 
            this.ckb_ip.AutoSize = true;
            this.ckb_ip.Location = new System.Drawing.Point(25, 475);
            this.ckb_ip.Name = "ckb_ip";
            this.ckb_ip.Size = new System.Drawing.Size(96, 16);
            this.ckb_ip.TabIndex = 25;
            this.ckb_ip.Text = "扫码IP：端口";
            this.ckb_ip.UseVisualStyleBackColor = true;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(271, 370);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(17, 12);
            this.label46.TabIndex = 24;
            this.label46.Text = "mm";
            // 
            // txt_length
            // 
            this.txt_length.Location = new System.Drawing.Point(135, 367);
            this.txt_length.Name = "txt_length";
            this.txt_length.Size = new System.Drawing.Size(121, 21);
            this.txt_length.TabIndex = 23;
            this.txt_length.Text = "90";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(23, 370);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(65, 12);
            this.label47.TabIndex = 22;
            this.label47.Text = "3D扫描长度";
            // 
            // txt_ip
            // 
            this.txt_ip.Location = new System.Drawing.Point(135, 473);
            this.txt_ip.Name = "txt_ip";
            this.txt_ip.Size = new System.Drawing.Size(121, 21);
            this.txt_ip.TabIndex = 21;
            this.txt_ip.Text = "127.0.0.1:8000";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(318, 108);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(17, 12);
            this.label48.TabIndex = 19;
            this.label48.Text = "ms";
            // 
            // txt_dely_out
            // 
            this.txt_dely_out.Location = new System.Drawing.Point(262, 105);
            this.txt_dely_out.Name = "txt_dely_out";
            this.txt_dely_out.Size = new System.Drawing.Size(41, 21);
            this.txt_dely_out.TabIndex = 18;
            this.txt_dely_out.Text = "0";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(318, 82);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(17, 12);
            this.label49.TabIndex = 17;
            this.label49.Text = "ms";
            // 
            // txt_dely_put
            // 
            this.txt_dely_put.Location = new System.Drawing.Point(262, 79);
            this.txt_dely_put.Name = "txt_dely_put";
            this.txt_dely_put.Size = new System.Drawing.Size(41, 21);
            this.txt_dely_put.TabIndex = 16;
            this.txt_dely_put.Text = "0";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(318, 58);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(17, 12);
            this.label50.TabIndex = 15;
            this.label50.Text = "ms";
            // 
            // txt_dely_in
            // 
            this.txt_dely_in.Location = new System.Drawing.Point(262, 55);
            this.txt_dely_in.Name = "txt_dely_in";
            this.txt_dely_in.Size = new System.Drawing.Size(41, 21);
            this.txt_dely_in.TabIndex = 14;
            this.txt_dely_in.Text = "0";
            // 
            // cb_out
            // 
            this.cb_out.FormattingEnabled = true;
            this.cb_out.Location = new System.Drawing.Point(135, 105);
            this.cb_out.Name = "cb_out";
            this.cb_out.Size = new System.Drawing.Size(121, 20);
            this.cb_out.TabIndex = 13;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(32, 108);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(101, 12);
            this.label51.TabIndex = 12;
            this.label51.Text = "延时出料触发信号";
            // 
            // cb_put
            // 
            this.cb_put.FormattingEnabled = true;
            this.cb_put.Location = new System.Drawing.Point(135, 80);
            this.cb_put.Name = "cb_put";
            this.cb_put.Size = new System.Drawing.Size(121, 20);
            this.cb_put.TabIndex = 11;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(32, 83);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(101, 12);
            this.label52.TabIndex = 10;
            this.label52.Text = "延时到位触发信号";
            // 
            // cb_in
            // 
            this.cb_in.FormattingEnabled = true;
            this.cb_in.Location = new System.Drawing.Point(135, 55);
            this.cb_in.Name = "cb_in";
            this.cb_in.Size = new System.Drawing.Size(121, 20);
            this.cb_in.TabIndex = 9;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(32, 58);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(101, 12);
            this.label53.TabIndex = 8;
            this.label53.Text = "延时入料触发信号";
            // 
            // txt_name
            // 
            this.txt_name.Location = new System.Drawing.Point(135, 26);
            this.txt_name.Name = "txt_name";
            this.txt_name.Size = new System.Drawing.Size(121, 21);
            this.txt_name.TabIndex = 1;
            this.txt_name.Text = "test1";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(30, 29);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(29, 12);
            this.label54.TabIndex = 0;
            this.label54.Text = "名称";
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.Gray;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.ForeColor = System.Drawing.Color.White;
            this.button7.Location = new System.Drawing.Point(649, 446);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(75, 23);
            this.button7.TabIndex = 7;
            this.button7.Text = "删除";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.Gray;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.ForeColor = System.Drawing.Color.White;
            this.button6.Location = new System.Drawing.Point(550, 446);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 23);
            this.button6.TabIndex = 6;
            this.button6.Text = "更新";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(445, 92);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(53, 12);
            this.label39.TabIndex = 5;
            this.label39.Text = "当前方案";
            // 
            // cb_project
            // 
            this.cb_project.FormattingEnabled = true;
            this.cb_project.Location = new System.Drawing.Point(534, 89);
            this.cb_project.Name = "cb_project";
            this.cb_project.Size = new System.Drawing.Size(121, 20);
            this.cb_project.TabIndex = 4;
            this.cb_project.SelectedIndexChanged += new System.EventHandler(this.cb_project_SelectedIndexChanged);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Gray;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.ForeColor = System.Drawing.Color.White;
            this.button5.Location = new System.Drawing.Point(457, 446);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 3;
            this.button5.Text = "添加";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click_1);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Gray;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(692, 578);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 2;
            this.button1.Text = "保存";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // chk_smt
            // 
            this.chk_smt.AutoSize = true;
            this.chk_smt.Location = new System.Drawing.Point(112, 263);
            this.chk_smt.Name = "chk_smt";
            this.chk_smt.Size = new System.Drawing.Size(72, 16);
            this.chk_smt.TabIndex = 17;
            this.chk_smt.Text = "加载图像";
            this.chk_smt.UseVisualStyleBackColor = true;
            // 
            // ParamForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(776, 603);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.tabControl1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximizeBox = false;
            this.Name = "ParamForm";
            this.Text = "参数设置界面";
            this.Load += new System.EventHandler(this.ParamForm_Load);
            this.panel1.ResumeLayout(false);
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.ZhouParam.ResumeLayout(false);
            this.OtherParam.ResumeLayout(false);
            this.OtherParam.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.gb_mark.ResumeLayout(false);
            this.gb_mark.PerformLayout();
            this.gb_pos.ResumeLayout(false);
            this.gb_pos.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txt_pvmm1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_rightLimt1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_leftLimt1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_dec1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_val1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_acc1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox txt_pvmm4;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txt_rightLimt4;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txt_leftLimt4;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txt_dec4;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txt_val4;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txt_acc4;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txt_pvmm3;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txt_rightLimt3;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txt_leftLimt3;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txt_dec3;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txt_val3;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txt_acc3;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txt_pvmm2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txt_rightLimt2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txt_leftLimt2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txt_dec2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txt_val2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txt_acc2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txt_time4;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox txt_time3;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox txt_time2;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox txt_time1;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage ZhouParam;
        private System.Windows.Forms.TabPage OtherParam;
        private System.Windows.Forms.Button btn_look;
        private System.Windows.Forms.TextBox txt_smt;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox txt_log;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.ListView lst_poss;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.TextBox txt_3DVal;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TextBox txt_bdpos;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Button btn_bd;
        private System.Windows.Forms.TextBox txt_bdnum;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox txt_bdbc;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox txt_3Ddis;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.TextBox txt_delyTime;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.CheckBox chk_sip;
        private System.Windows.Forms.TextBox txt_runnum;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.ComboBox cb_project;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.TextBox txt_speed;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.GroupBox gb_mark;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.ComboBox cb_mark2;
        private System.Windows.Forms.ComboBox cb_mark1;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.GroupBox gb_pos;
        private System.Windows.Forms.ComboBox cb_3d2;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.ComboBox cb_2d;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.ComboBox cb_3d1;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.CheckBox ckb_mark;
        private System.Windows.Forms.CheckBox ckb_ip;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.TextBox txt_length;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.TextBox txt_ip;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.TextBox txt_dely_out;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.TextBox txt_dely_put;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.TextBox txt_dely_in;
        private System.Windows.Forms.ComboBox cb_out;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.ComboBox cb_put;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.ComboBox cb_in;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.TextBox txt_name;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.TextBox txt_3d2y;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.TextBox txt_3d2x;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.TextBox txt_3d1y;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.TextBox txt_3d1x;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.ComboBox cb_after;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.ComboBox cb_befor;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.TextBox txt_gpu;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.TextBox txt_time5;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.TextBox txt_pvmm5;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.TextBox txt_rightLimt5;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.TextBox txt_leftLimt5;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.TextBox txt_dec5;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.TextBox txt_val5;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.TextBox txt_acc5;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.ComboBox cb_jackAir;
        private System.Windows.Forms.ComboBox cb_blockAir;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.ComboBox cb_jackAir2;
        private System.Windows.Forms.CheckBox ckb_g;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.TextBox txt_buz2;
        private System.Windows.Forms.TextBox txt_buz1;
        private System.Windows.Forms.CheckBox chk_buz;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.TextBox txt_g_dis;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.CheckBox chk_smt;
    }
}