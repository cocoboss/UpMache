﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace BenchMark
{
    public partial class FormUserManage : Form
    {

        User current_user=new User ();
        Auth current_Auth = new Auth ();
        public FormUserManage()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            CheckTxt();
            UserMode um = new UserMode(current_user);
            um.Add(current_user);
            Task.Delay(200);
            if(um.SelectOne(current_user.name) ==null)
            {
                MessageBox.Show(Global.isZh?"增加用户失败": "Failed to add users");
            }else
            {
                
                dglst.DataSource= um.SelectAll();
                SetSecondColumnToStars(dglst);
            }

        }
        private void AddRoot()
        {
            root_auth.Nodes.Clear ();
            TreeNode roots= new TreeNode ();
             TreeNode root = new TreeNode("设置");
            root.Tag = new CheckBox { Text = "设置" };
            TreeNode root2 = new TreeNode("用户设置");
            root2.Tag = new CheckBox { Text = "用户设置" };
            TreeNode[] treeNode =
               {
                        new TreeNode("IO"),
                        new TreeNode("参数设置"),
                        new TreeNode("轴控")
                };
            TreeNode[] treeNode2 =
              {
                        new TreeNode("用户登录"),
                        new TreeNode("用户退出"),
                        new TreeNode("用户管理")
                };
            root.Nodes.AddRange(treeNode);
            root2.Nodes.AddRange(treeNode2);
            roots.Nodes.Add(root);
            roots.Nodes.Add(root2);
            root_auth.Nodes.Add(roots);
            root_auth.ExpandAll();
        }
        private void CheckTxt()
        {
            string name=txt_name.Text.Trim();
            string pwd=txt_pwd.Text.Trim();
            string pwd2=txt_pwd2.Text.Trim();
            int auth = txt_auth.SelectedIndex;
            if (string.IsNullOrEmpty(name))
            {
                MessageBox.Show(Global.isZh ? "用户名不能为空": "The username cannot be empty");
            }
            if (string.IsNullOrEmpty(pwd))
            {
                MessageBox.Show(Global.isZh ? "密码不能为空" : "The password cannot be empty");
            }
            if (string.IsNullOrEmpty(pwd2))
            {
                MessageBox.Show(Global.isZh ? "密码不能为空" : "The password cannot be empty");
            }
            if(pwd!=pwd2)
            {
                MessageBox.Show(Global.isZh ? "密码输入不一致，请重新输入密码确认": "The password input is inconsistent. Please re-enter the password to confirm");
                txt_pwd.Text = "";
                txt_pwd2.Text = "";
            }
            current_user.pwd = pwd;
            current_user.name = name;
            current_user.auth = auth;

        }
        

        private void FormUserManage_Load(object sender, EventArgs e)
        {
            txt_auth.SelectedIndex = 0;
            com_auth.SelectedIndex = 0;
            
            UserMode um = new UserMode(current_user);
            dglst.DataSource = um.SelectAll();
            SetSecondColumnToStars(dglst);

            current_Auth = SelectAuth(com_auth.SelectedIndex);
            
            UpdateAuth(current_Auth);
            Show(Global.isZh);
        }
        public Auth SelectAuth(int id)
        {
            AuthMode mode = new AuthMode();
            return mode.Select(id);
        }

        private void UpdateAuth(Auth item)
        {
            if (item != null)
            {
                int temp = 0;
                temp = item.mark & (1 << 0);
                chk_io.Checked = temp != 0;
                temp = item.mark & (1 << 1);
                chk_pram.Checked = temp != 0;
                temp = item.mark & (1 << 2);
                chk_userManage.Checked = temp != 0;
            }else
            {
                item=new Auth();
                UpdateAuth(item);
            }
        
        }
        private void SetSecondColumnToStars(DataGridView dataGridView)
        {
            foreach (DataGridViewRow row in dataGridView.Rows)
            {
                // 检查行是否不是新行（即不是用于添加新行的那一行，通常它是空的）
                if (!row.IsNewRow)
                {
                    // 设置第二列（索引为1，因为索引是从0开始的）的值为***
                    row.Cells[2].Value = "***";
                }
            }
        }

        private void dglst_MouseClick(object sender, MouseEventArgs e)
        {
        }

        private void dglst_SelectionChanged(object sender, EventArgs e)
        {
            if(dglst.SelectedRows.Count==1)
            {
                foreach (DataGridViewRow row in dglst.SelectedRows)
                {
                    // 处理被选中的行
                    //Console.WriteLine("Selected Row Index: " + row.Index);
                    // 你可以通过row.Cells[columnIndex].Value来获取特定单元格的值
                    txt_name.Text= row.Cells[1].Value.ToString();
                    txt_auth.SelectedIndex = int.Parse(row.Cells[3].Value.ToString());
                }
            }
        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            CheckTxt();
            UserMode um = new UserMode(current_user);
            User us = um.SelectOne(current_user.name);
            if(us.pwd!=current_user.pwd)
            {
                MessageBox.Show(Global.isZh?"密码错误，不能修改": "Password error, cannot be modified");
            }else
            {
                um.Update(current_user);
                Task.Delay(20);
                dglst.DataSource = um.SelectAll();
                SetSecondColumnToStars(dglst);
            }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            CheckTxt();
            if(MessageBox.Show(Global.isZh ? "确认是否删除该用户": "Confirm whether to delete the user", Global.isZh ? "警告": "warn", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                UserMode um = new UserMode(current_user);
                um.Delete(current_user);
                current_user=new User();
                Task.Delay(20);
                dglst.DataSource = um.SelectAll();
                SetSecondColumnToStars(dglst);
            }
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Auth temp= new Auth();
            temp.mark = (temp.mark | ((chk_io.Checked ? 1 : 0) << 0));
            temp.mark = (temp.mark | ((chk_pram.Checked ? 1 : 0) << 1));
            temp.mark = (temp.mark | ((chk_userManage.Checked ? 1 : 0) << 2));
            temp.id = com_auth.SelectedIndex;
            AuthMode am= new AuthMode();
            current_Auth= am.Select(temp.id);
            if(current_Auth!=null)
            {
                am.Update(temp);
            }else
            {
                am.Add(temp);
            }
            current_Auth = temp;
            UpdateAuth(current_Auth);

        }

        private void com_auth_SelectedIndexChanged(object sender, EventArgs e)
        {
            current_Auth = SelectAuth(com_auth.SelectedIndex);
                UpdateAuth(current_Auth);
        }

        private void Show(bool isZh)
        {
            if (!isZh)
            {
                Thread.CurrentThread.CurrentUICulture = new CultureInfo("en-US");
                Global.LoadLanguage(this, typeof(FormUserManage));
            }
            else
            {
                Thread.CurrentThread.CurrentUICulture = new CultureInfo("zh-CN");
                Global.LoadLanguage(this, typeof(FormUserManage));
            }
        }
    }
}
