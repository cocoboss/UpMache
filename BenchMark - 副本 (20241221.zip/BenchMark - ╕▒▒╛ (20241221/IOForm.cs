﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BenchMark
{
    public partial class IOForm : Form
    {

        
        public IOForm()
        {
            InitializeComponent();
        }
        public void Show(string path,string name, bool[] temp,ref Dictionary<int, string> tempio)
        {
            //string path =Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location)+"\\di.ini";
            if (File.Exists(path))
            {
                var datas = File.ReadAllLines(path);
                foreach (var item in datas)
                {
                    var line = item.Trim();
                    if (!string.IsNullOrEmpty(line) && line.Contains("="))
                    {
                        var fir = line.Split('=');
                        if (int.TryParse(fir[0], out int no))
                        {
                            CheckBox checkBox = new CheckBox();
                            checkBox.Text = fir[1];
                            if (name.Equals("di"))
                                checkBox.Enabled = false;
                            else
                            {
                                checkBox.Click += DoChange;
                                checkBox.Enabled = true;
                            }
                            checkBox.Name = name+no.ToString();
                            checkBox.Checked = temp[no];
                            if (temp.Length < no)
                            {
                                MessageBox.Show(Global.isZh?"请检查配置是否正确": "Please check if the configuration is correct");
                            }
                            if (name.Equals("di"))
                                tp_in.Controls.Add(checkBox, 0, no);
                            else if(name.Equals("do"))
                                tp_out.Controls.Add(checkBox, 0, no);
                            if (!tempio.ContainsKey(no))
                                tempio.Add(no, fir[1]);
                        } 
                    }
                }
            }
        }
        public void ShowDO()
        {
            for (int i = 0; i < 16; i++)
            {
                CheckBox checkBox = new CheckBox();
                checkBox.Text = "di" + i;
                checkBox.Name = "di"+i.ToString();
                tp_out.Controls.Add(checkBox, 0, i);
            }
        }

    //public delegate void EventHandler(object sender, EventArgs e);
        public void DoChange(object sender, EventArgs e)
        {
            CheckBox box=(CheckBox)sender;
            short num=Convert.ToInt16(box.Name.Replace("do", "").Trim());
            num += 1;
            int temp = (box.Checked ? 1 : 0);
            Axis.SetDoSignl(num,(short)temp);
            RefreshIO();
        }

        private void IOForm_Load(object sender, EventArgs e)
        {
            LoadConfig();
            Show(Global.isZh);
        }
        public void LoadConfig()
        {
            Axis.GetDi();
            Axis.GetDo();
            Show(Global.DiPath, "di", Axis.axis_di, ref Global.Dicdi);
            Show(Global.DoPath, "do", Axis.axis_do, ref Global.Dicdo);
        }
        public void RefreshIO()
        {
            Axis.GetDi();
            Axis.GetDo();
            Update(this);
        }
        public void Update(Control control)
        {
            foreach(Control item in control.Controls)
            {
                if(item is CheckBox)
                {
                    CheckBox box = (CheckBox)item;
                    Global.ControlInvocke(box, () =>
                    {
                        string temp = box.Name;
                        if (box.Name.Contains("di"))
                        {
                            temp = temp.Replace("di", "").Trim();
                            if (int.TryParse(temp, out int no))
                                box.Checked = Axis.axis_di[no];
                        }
                        else if (box.Name.Contains("do"))
                        {
                            temp = temp.Replace("do", "").Trim();
                            if (int.TryParse(temp, out int no))
                                box.Checked = Axis.axis_do[no];
                        }
                    });
                    
                }
                Update(item);
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            RefreshIO();
        }

        private void Show(bool isZh)
        {
            if (!isZh)
            {
                Thread.CurrentThread.CurrentUICulture = new CultureInfo("en-US");
                Global.LoadLanguage(this, typeof(IOForm));
            }
            else
            {
                Thread.CurrentThread.CurrentUICulture = new CultureInfo("zh-CN");
                Global.LoadLanguage(this, typeof(IOForm));
            }
        }
    }
}
