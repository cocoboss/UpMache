﻿
namespace BenchMark
{
    partial class MainForm
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Timer timer1;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.logs = new System.Windows.Forms.GroupBox();
            this.loglst = new System.Windows.Forms.ListBox();
            this.alarms = new System.Windows.Forms.GroupBox();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.alarmLst = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btn_stop = new System.Windows.Forms.Button();
            this.btn_run = new System.Windows.Forms.Button();
            this.menu_set = new System.Windows.Forms.MenuStrip();
            this.Setting = new System.Windows.Forms.ToolStripMenuItem();
            this.IO = new System.Windows.Forms.ToolStripMenuItem();
            this.ParamSetting = new System.Windows.Forms.ToolStripMenuItem();
            this.AxisControl = new System.Windows.Forms.ToolStripMenuItem();
            this.OldTest = new System.Windows.Forms.ToolStripMenuItem();
            this.UserSetting = new System.Windows.Forms.ToolStripMenuItem();
            this.UserLogin = new System.Windows.Forms.ToolStripMenuItem();
            this.UserLogout = new System.Windows.Forms.ToolStripMenuItem();
            this.UserManages = new System.Windows.Forms.ToolStripMenuItem();
            this.btn_zero = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btn_name = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.btn_axisSts = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_eqSts = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.panel3 = new System.Windows.Forms.Panel();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            timer1 = new System.Windows.Forms.Timer(this.components);
            this.logs.SuspendLayout();
            this.alarms.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.alarmLst)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.menu_set.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // timer1
            // 
            timer1.Enabled = true;
            timer1.Interval = 1000;
            timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // logs
            // 
            this.logs.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.logs.Controls.Add(this.loglst);
            this.logs.Location = new System.Drawing.Point(8, 415);
            this.logs.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.logs.Name = "logs";
            this.logs.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.logs.Size = new System.Drawing.Size(241, 286);
            this.logs.TabIndex = 3;
            this.logs.TabStop = false;
            this.logs.Text = "日志记录";
            // 
            // loglst
            // 
            this.loglst.Dock = System.Windows.Forms.DockStyle.Fill;
            this.loglst.FormattingEnabled = true;
            this.loglst.HorizontalScrollbar = true;
            this.loglst.ItemHeight = 15;
            this.loglst.Location = new System.Drawing.Point(3, 20);
            this.loglst.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.loglst.Name = "loglst";
            this.loglst.ScrollAlwaysVisible = true;
            this.loglst.Size = new System.Drawing.Size(235, 264);
            this.loglst.TabIndex = 0;
            // 
            // alarms
            // 
            this.alarms.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.alarms.Controls.Add(this.button4);
            this.alarms.Controls.Add(this.button3);
            this.alarms.Controls.Add(this.alarmLst);
            this.alarms.Location = new System.Drawing.Point(8, 706);
            this.alarms.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.alarms.Name = "alarms";
            this.alarms.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.alarms.Size = new System.Drawing.Size(244, 270);
            this.alarms.TabIndex = 4;
            this.alarms.TabStop = false;
            this.alarms.Text = "报警信息";
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Linen;
            this.button4.Location = new System.Drawing.Point(140, 221);
            this.button4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(104, 40);
            this.button4.TabIndex = 2;
            this.button4.Text = "清警";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Linen;
            this.button3.Location = new System.Drawing.Point(7, 220);
            this.button3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(112, 44);
            this.button3.TabIndex = 1;
            this.button3.Text = "关闭蜂鸣";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // alarmLst
            // 
            this.alarmLst.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.alarmLst.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column2});
            this.alarmLst.Location = new System.Drawing.Point(8, 25);
            this.alarmLst.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.alarmLst.Name = "alarmLst";
            this.alarmLst.RowHeadersWidth = 51;
            this.alarmLst.RowTemplate.Height = 23;
            this.alarmLst.Size = new System.Drawing.Size(236, 188);
            this.alarmLst.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.btn_stop);
            this.groupBox1.Controls.Add(this.btn_run);
            this.groupBox1.Controls.Add(this.menu_set);
            this.groupBox1.Controls.Add(this.btn_zero);
            this.groupBox1.Location = new System.Drawing.Point(3, 151);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Size = new System.Drawing.Size(251, 129);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "操作区";
            // 
            // btn_stop
            // 
            this.btn_stop.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btn_stop.BackColor = System.Drawing.Color.Gray;
            this.btn_stop.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_stop.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_stop.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_stop.ForeColor = System.Drawing.Color.White;
            this.btn_stop.Image = global::BenchMark.Properties.Resources.stop_circle_line;
            this.btn_stop.Location = new System.Drawing.Point(163, 61);
            this.btn_stop.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_stop.Name = "btn_stop";
            this.btn_stop.Size = new System.Drawing.Size(80, 62);
            this.btn_stop.TabIndex = 11;
            this.btn_stop.Tag = "停止";
            this.btn_stop.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_stop.UseVisualStyleBackColor = false;
            this.btn_stop.Click += new System.EventHandler(this.btn_stop_Click);
            this.btn_stop.MouseLeave += new System.EventHandler(this.btn_zero_MouseLeave);
            this.btn_stop.MouseHover += new System.EventHandler(this.btn_zero_MouseHover);
            // 
            // btn_run
            // 
            this.btn_run.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btn_run.BackColor = System.Drawing.Color.Gray;
            this.btn_run.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_run.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_run.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_run.ForeColor = System.Drawing.Color.White;
            this.btn_run.Image = global::BenchMark.Properties.Resources.play_circle_line;
            this.btn_run.Location = new System.Drawing.Point(81, 61);
            this.btn_run.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_run.Name = "btn_run";
            this.btn_run.Size = new System.Drawing.Size(80, 62);
            this.btn_run.TabIndex = 10;
            this.btn_run.Tag = "运行";
            this.btn_run.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_run.UseVisualStyleBackColor = false;
            this.btn_run.Click += new System.EventHandler(this.btn_run_Click);
            this.btn_run.MouseEnter += new System.EventHandler(this.btn_zero_MouseHover);
            this.btn_run.MouseLeave += new System.EventHandler(this.btn_zero_MouseLeave);
            // 
            // menu_set
            // 
            this.menu_set.Dock = System.Windows.Forms.DockStyle.None;
            this.menu_set.Font = new System.Drawing.Font("Microsoft YaHei UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.menu_set.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menu_set.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Setting,
            this.UserSetting});
            this.menu_set.Location = new System.Drawing.Point(7, 15);
            this.menu_set.Name = "menu_set";
            this.menu_set.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.menu_set.Size = new System.Drawing.Size(207, 39);
            this.menu_set.TabIndex = 1;
            this.menu_set.Text = "menuStrip1";
            // 
            // Setting
            // 
            this.Setting.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.IO,
            this.ParamSetting,
            this.AxisControl,
            this.OldTest});
            this.Setting.Font = new System.Drawing.Font("Microsoft YaHei UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Setting.Name = "Setting";
            this.Setting.Size = new System.Drawing.Size(76, 35);
            this.Setting.Text = "设置";
            // 
            // IO
            // 
            this.IO.Name = "IO";
            this.IO.Size = new System.Drawing.Size(224, 36);
            this.IO.Text = "IO";
            this.IO.Click += new System.EventHandler(this.iOToolStripMenuItem_Click);
            // 
            // ParamSetting
            // 
            this.ParamSetting.Name = "ParamSetting";
            this.ParamSetting.Size = new System.Drawing.Size(224, 36);
            this.ParamSetting.Text = "参数设置";
            this.ParamSetting.Click += new System.EventHandler(this.参数设置ToolStripMenuItem_Click);
            // 
            // AxisControl
            // 
            this.AxisControl.Name = "AxisControl";
            this.AxisControl.Size = new System.Drawing.Size(224, 36);
            this.AxisControl.Text = "轴控";
            this.AxisControl.Click += new System.EventHandler(this.轴控ToolStripMenuItem_Click);
            // 
            // OldTest
            // 
            this.OldTest.Name = "OldTest";
            this.OldTest.Size = new System.Drawing.Size(224, 36);
            this.OldTest.Text = "老化测试";
            this.OldTest.Click += new System.EventHandler(this.老化测试ToolStripMenuItem_Click);
            // 
            // UserSetting
            // 
            this.UserSetting.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.UserLogin,
            this.UserLogout,
            this.UserManages});
            this.UserSetting.Name = "UserSetting";
            this.UserSetting.Size = new System.Drawing.Size(124, 35);
            this.UserSetting.Text = "用户设置";
            // 
            // UserLogin
            // 
            this.UserLogin.Name = "UserLogin";
            this.UserLogin.Size = new System.Drawing.Size(198, 36);
            this.UserLogin.Text = "用户登录";
            this.UserLogin.Click += new System.EventHandler(this.用户登录ToolStripMenuItem_Click);
            // 
            // UserLogout
            // 
            this.UserLogout.Name = "UserLogout";
            this.UserLogout.Size = new System.Drawing.Size(198, 36);
            this.UserLogout.Text = "用户注销";
            this.UserLogout.Click += new System.EventHandler(this.用户注销ToolStripMenuItem_Click);
            // 
            // UserManages
            // 
            this.UserManages.Name = "UserManages";
            this.UserManages.Size = new System.Drawing.Size(198, 36);
            this.UserManages.Text = "用户管理";
            this.UserManages.Click += new System.EventHandler(this.用户设置ToolStripMenuItem_Click);
            // 
            // btn_zero
            // 
            this.btn_zero.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btn_zero.BackColor = System.Drawing.Color.Gray;
            this.btn_zero.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_zero.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_zero.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_zero.ForeColor = System.Drawing.Color.White;
            this.btn_zero.Image = global::BenchMark.Properties.Resources.iconmonstr_restore_lined_24;
            this.btn_zero.Location = new System.Drawing.Point(0, 61);
            this.btn_zero.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_zero.Name = "btn_zero";
            this.btn_zero.Size = new System.Drawing.Size(80, 62);
            this.btn_zero.TabIndex = 9;
            this.btn_zero.Tag = "复位";
            this.btn_zero.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_zero.UseVisualStyleBackColor = false;
            this.btn_zero.Click += new System.EventHandler(this.btn_zero_Click);
            this.btn_zero.MouseLeave += new System.EventHandler(this.btn_zero_MouseLeave);
            this.btn_zero.MouseHover += new System.EventHandler(this.btn_zero_MouseHover);
            this.btn_zero.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btn_zero_MouseUp);
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.tabControl1);
            this.groupBox2.Location = new System.Drawing.Point(275, 5);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox2.Size = new System.Drawing.Size(1777, 972);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "显示区";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(3, 20);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1771, 950);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.panel1);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage1.Size = new System.Drawing.Size(1763, 921);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "图像";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(4, 4);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1755, 913);
            this.panel1.TabIndex = 0;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.btn_name);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.btn_axisSts);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.btn_eqSts);
            this.groupBox3.Location = new System.Drawing.Point(4, 285);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox3.Size = new System.Drawing.Size(260, 125);
            this.groupBox3.TabIndex = 7;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "状态";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(0, 96);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 24);
            this.label3.TabIndex = 5;
            this.label3.Text = "用户名";
            // 
            // btn_name
            // 
            this.btn_name.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.btn_name.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_name.Enabled = false;
            this.btn_name.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_name.Location = new System.Drawing.Point(120, 90);
            this.btn_name.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_name.Name = "btn_name";
            this.btn_name.Size = new System.Drawing.Size(135, 29);
            this.btn_name.TabIndex = 4;
            this.btn_name.UseVisualStyleBackColor = false;
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(0, 64);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 24);
            this.label2.TabIndex = 3;
            this.label2.Text = "轴状态";
            // 
            // btn_axisSts
            // 
            this.btn_axisSts.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.btn_axisSts.BackColor = System.Drawing.Color.Green;
            this.btn_axisSts.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_axisSts.Location = new System.Drawing.Point(121, 58);
            this.btn_axisSts.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_axisSts.Name = "btn_axisSts";
            this.btn_axisSts.Size = new System.Drawing.Size(135, 29);
            this.btn_axisSts.TabIndex = 2;
            this.btn_axisSts.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(0, 30);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(106, 24);
            this.label1.TabIndex = 1;
            this.label1.Text = "设备状态";
            // 
            // btn_eqSts
            // 
            this.btn_eqSts.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.btn_eqSts.BackColor = System.Drawing.Color.Green;
            this.btn_eqSts.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_eqSts.Location = new System.Drawing.Point(120, 24);
            this.btn_eqSts.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_eqSts.Name = "btn_eqSts";
            this.btn_eqSts.Size = new System.Drawing.Size(135, 29);
            this.btn_eqSts.TabIndex = 0;
            this.btn_eqSts.UseVisualStyleBackColor = false;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.button1);
            this.panel2.Location = new System.Drawing.Point(1, 5);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(252, 92);
            this.panel2.TabIndex = 9;
            // 
            // button1
            // 
            this.button1.BackgroundImage = global::BenchMark.Properties.Resources.lcd;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button1.Location = new System.Drawing.Point(0, 0);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(252, 92);
            this.button1.TabIndex = 12;
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("宋体", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button2.Location = new System.Drawing.Point(0, 98);
            this.button2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(253, 55);
            this.button2.TabIndex = 10;
            this.button2.Text = "胶量检测";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // backgroundWorker1
            // 
            this.backgroundWorker1.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundWorker1_DoWork);
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.panel3.Controls.Add(this.logs);
            this.panel3.Controls.Add(this.button2);
            this.panel3.Controls.Add(this.groupBox1);
            this.panel3.Controls.Add(this.panel2);
            this.panel3.Controls.Add(this.groupBox3);
            this.panel3.Controls.Add(this.alarms);
            this.panel3.Location = new System.Drawing.Point(4, 1);
            this.panel3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(264, 979);
            this.panel3.TabIndex = 11;
            // 
            // Column2
            // 
            this.Column2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Column2.HeaderText = "messages";
            this.Column2.MinimumWidth = 6;
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(2052, 979);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.groupBox2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menu_set;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "MainForm";
            this.Text = "胶量检测";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MainForm_FormClosed);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.logs.ResumeLayout(false);
            this.alarms.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.alarmLst)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.menu_set.ResumeLayout(false);
            this.menu_set.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.GroupBox logs;
        private System.Windows.Forms.GroupBox alarms;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.MenuStrip menu_set;
        private System.Windows.Forms.ToolStripMenuItem Setting;
        private System.Windows.Forms.ToolStripMenuItem IO;
        private System.Windows.Forms.ToolStripMenuItem ParamSetting;
        private System.Windows.Forms.ToolStripMenuItem AxisControl;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.ListBox loglst;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_eqSts;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_axisSts;
        private System.Windows.Forms.Button btn_stop;
        private System.Windows.Forms.Button btn_run;
        private System.Windows.Forms.Button btn_zero;
        private System.Windows.Forms.ToolStripMenuItem UserSetting;
        private System.Windows.Forms.ToolStripMenuItem UserLogin;
        private System.Windows.Forms.ToolStripMenuItem UserLogout;
        private System.Windows.Forms.ToolStripMenuItem UserManages;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.DataGridView alarmLst;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btn_name;
        private System.Windows.Forms.ToolStripMenuItem OldTest;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
    }
}

