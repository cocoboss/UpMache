﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static gts.mc;

namespace BenchMark
{
    public partial class SettingForm : Form
    {

        short axis;//当前轴号
        int search_home;//Home搜索距离
        int home_offset;//Home偏移量
        int search_index;//Index搜索距离
        int index_offset;//Index偏移量
        bool[] en = new bool[8];//各轴的伺服使能状态
        uint clk;//时钟参数
        short capture;
        gts.mc.TTrapPrm trapPrm;
        gts.mc.THomePrm pHomePrm;
        int status,pvalue;
        int pos;
        double vel, prfvel, encvel,prfpos, encpos;//运动状态参数
        gts.mc.TJogPrm jog;
        //string runmode;
        short stage;//阶段标志，1表示处于Home搜索阶段，2表示处于Home回零阶段，3表示处于Index搜索阶段，4表示处于Index回零阶段
        int ret;
        public SettingForm()
        {
            InitializeComponent();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            //gts.mc.GT_Open(0, 1);
            gts.mc.GT_Reset();
        }
        public short GetCardId()
        {
           return Convert.ToInt16(cardId.SelectedIndex+1);
        }

        private void button15_Click(object sender, EventArgs e)
        {
            gts.mc.GT_LoadConfig("GTS800.cfg");//下载配置文件
            gts.mc.GT_ClrSts(1, 8);//清除各轴报警和限位
        }

        private void button16_MouseDown(object sender, MouseEventArgs e)
        {

            ///读取参数
            vel = Convert.ToDouble(this.txt_setval.Text);
            jog.acc = Convert.ToDouble(this.txt_setaval.Text);
            jog.dec = Convert.ToDouble(this.txt_setdval.Text);



            gts.mc.GT_SetJogPrm(axis, ref jog);//设置jog运动参数

            gts.mc.GT_SetVel(axis, vel);//设置目标速度

            gts.mc.GT_Update(1 << (axis - 1));//更新轴运动
        }

        private void button16_MouseUp(object sender, MouseEventArgs e)
        {
            gts.mc.GT_Stop(1 << (axis - 1), 0);
        }

        private void button12_Click_1(object sender, EventArgs e)
        {
            axis = GetCardId();
            vel = Convert.ToDouble(this.txt_setval.Text);
            pos += Convert.ToInt32(this.txt_setpos.Text);
            trapPrm.acc = Convert.ToDouble(this.textBox3.Text);
            trapPrm.dec = Convert.ToDouble(this.txt_setdval.Text);
            trapPrm.smoothTime = Convert.ToInt16(this.txt_settime.Text);
            trapPrm.velStart = 0;

            gts.mc.GT_SetTrapPrm(axis, ref trapPrm);//设置点位运动参数
            gts.mc.GT_SetVel(axis, vel);//设置目标速度
            gts.mc.GT_SetPos(axis, pos);//设置目标位置
            gts.mc.GT_Update(1 << (axis - 1));//更新轴运动
        }
        /// <summary>
        /// Home搜索
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button7_Click(object sender, EventArgs e)
        {
            //Home搜索距离
            search_home = Convert.ToInt32(home_jl.Text);

            short sRtn;
            // 启动Home捕获
            sRtn = gts.mc.GT_SetCaptureMode(axis, gts.mc.CAPTURE_HOME);
            // 切换到点位运动模式
            sRtn = gts.mc.GT_PrfTrap(axis);
            // 读取点位模式运动参数
            sRtn = gts.mc.GT_GetTrapPrm(axis, out trapPrm);
            trapPrm.acc = 0.25;
            trapPrm.dec = 0.25;
            // 设置点位模式运动参数
            sRtn = gts.mc.GT_SetTrapPrm(axis, ref trapPrm);
            // 设置点位模式目标速度，即回原点速度
            sRtn = gts.mc.GT_SetVel(axis, 10);
            // 设置点位模式目标位置，即原点搜索距离
            sRtn = gts.mc.GT_SetPos(axis, search_home);
            // 启动运动
            sRtn = gts.mc.GT_Update(1 << (axis - 1));

            //阶段标志
            stage = 1;
        }

        /// <summary>
        /// Home回零
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button8_Click(object sender, EventArgs e)
        {
            //Home偏移量
            home_offset = Convert.ToInt32(home_pyl.Text);

            short sRtn;
            //捕获到Home才可以执行Home回零
            if (capture == 1)
            {
                // 运动到"捕获位置+偏移量"
                sRtn = gts.mc.GT_SetPos(axis, pos + home_offset);
                // 在运动状态下更新目标位置
                sRtn = gts.mc.GT_Update(1 << (axis - 1));

                //阶段标志
                stage = 2;
            }
        }
        /// <summary>
        /// Index搜索
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button10_Click(object sender, EventArgs e)
        {
            //重置捕获状态
            capture = 0;
            //Index搜索距离
            search_index = Convert.ToInt32(index_jl.Text);

            short sRtn;
            //  启动index捕获
            sRtn = gts.mc.GT_SetCaptureMode(axis, gts.mc.CAPTURE_INDEX);
            //  设置当前位置+index 搜索距离为目标位置
            sRtn = gts.mc.GT_SetPos(axis, (int)(prfpos + search_index));
            //  启动运动
            sRtn = gts.mc.GT_Update(1 << (axis - 1));

            //阶段标志
            stage = 3;
        }
        /// <summary>
        /// Index回零
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button9_Click(object sender, EventArgs e)
        {
            //Index偏移量
            index_offset = Convert.ToInt32(index_pyl.Text);

            short sRtn;
            //捕获到Index才可以执行Index回零
            if (capture == 1)
            {
                //  设置捕获位置+index偏移量为目标位置
                sRtn = gts.mc.GT_SetPos(axis, pos + index_offset);
                //  启动运动
                sRtn = gts.mc.GT_Update(1 << (axis - 1));

                //阶段标志
                stage = 4;
            }
        }

        private void cardId_SelectedIndexChanged(object sender, EventArgs e)
        {
            axis = GetCardId();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            pHomePrm.mode = gts.mc.HOME_MODE_LIMIT_HOME;
            pHomePrm.moveDir = -1; //-1-负方向，1-正方向
            pHomePrm.indexDir = 1;  //-1-负方向， 1 - 正方向，在限位 + Index 回原点模式下 moveDir 与indexDir 应该相异
            pHomePrm.edge = 1;
            pHomePrm.pad1_1 = 0;
            pHomePrm.pad1_2 = 0;
            pHomePrm.pad1_3 = 0;
            pHomePrm.velHigh = 10;
            pHomePrm.velLow = 5;
            pHomePrm.acc = 0.1;
            pHomePrm.dec = 0.1;
            pHomePrm.smoothTime = 3;
            pHomePrm.pad2_1 = 1;
            pHomePrm.pad2_2 = 1;
            pHomePrm.pad2_3 = 1;
            pHomePrm.homeOffset= 10;
            pHomePrm.searchHomeDistance = 0;
            pHomePrm.searchIndexDistance = 0;
            pHomePrm.escapeStep = 10;
            gts.mc.GT_GoHome(axis, ref pHomePrm);
        }

        private void button19_MouseDown(object sender, MouseEventArgs e)
        {
            Dowork(true);
        }
        public void Dowork(bool isZheng)
        {
            vel = Convert.ToDouble(this.txt_setval.Text);
            jog.acc = Convert.ToDouble(this.txt_setaval.Text);
            jog.dec = Convert.ToDouble(this.txt_setdval.Text);



            gts.mc.GT_SetJogPrm(axis, ref jog);//设置jog运动参数

            gts.mc.GT_SetVel(axis, isZheng?vel:-vel);//设置目标速度

            gts.mc.GT_Update(1 << (axis - 1));//更新轴运动
        }

        private void button19_MouseUp(object sender, MouseEventArgs e)
        {
            gts.mc.GT_Stop(1 << (axis - 1), 0);
        }

        private void button17_MouseDown(object sender, MouseEventArgs e)
        {
            Dowork(false);
        }

        private void button17_MouseUp(object sender, MouseEventArgs e)
        {
            gts.mc.GT_Stop(1 << (axis - 1), 0);
        }

        private void button11_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button19_Click(object sender, EventArgs e)
        {

        }

        private void button17_Click(object sender, EventArgs e)
        {

        }

        private void SettingForm_Load(object sender, EventArgs e)
        {
            ret=gts.mc.GT_Open(0, 1);
            cardId.SelectedIndex = 0;
        }

        private void button13_Click(object sender, EventArgs e)
        {
            gts.mc.GT_ZeroPos(1, 8);
        }
        //平滑停止
        private void button18_Click(object sender, EventArgs e)
        {
            gts.mc.GT_Stop(1 << (axis - 1), 0);
            pos = 0;
        }
        //刷新状态
        private void timer1_Tick(object sender, EventArgs e)
        {
            axis = GetCardId();
            if (!en[axis - 1])
            {
                this.btn_power.Text = "伺服使能";
            }
            if (en[axis - 1])
            {
                this.btn_power.Text = "伺服关闭";
            }
            gts.mc.GT_GetPrfPos(axis, out prfpos, 1, out clk);
            this.txt_prfpos.Text = Math.Round(prfpos, 1).ToString();
            gts.mc.GT_GetPrfVel(axis, out prfvel, 1, out clk);
            this.txt_prfval.Text = Math.Round(prfvel, 1).ToString();
            gts.mc.GT_GetEncPos(axis, out encpos, 1, out clk);
            this.txt_enpos.Text = Math.Round(encpos, 1).ToString();
            gts.mc.GT_GetEncVel(axis, out encvel, 1, out clk);
            this.txt_enval.Text = Math.Round(encvel, 1).ToString();
            gts.mc.GT_GetSts(axis, out status, 1, out clk);
            this.txt_sta.Text = (status).ToString();
            gts.mc.GT_GetPrfMode(axis, out pvalue, 1, out clk);
            this.txt_mode.Text = (pvalue).ToString();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            axis = GetCardId();
            if (!en[axis - 1])
            {
                gts.mc.GT_AxisOn(axis);//上伺服
                this.btn_power.Text = "伺服关闭";
            }
            if (en[axis - 1])
            {
                gts.mc.GT_AxisOff(axis);//下伺服
                this.btn_power.Text = "伺服使能";
            }
            en[axis - 1] = !en[axis - 1];
        }
    }
}
