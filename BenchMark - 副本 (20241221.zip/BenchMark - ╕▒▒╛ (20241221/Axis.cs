﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using static gts.mc;
using static gts.mc_la;

namespace BenchMark
{
    public class Axis
    {
        public static gts.mc.THomePrm pHomePrm;
        public static gts.mc.TJogPrm jogPrm;
        public static gts.mc.TTrapPrm trapPrm;
        public static short[] axis = new short[3]{ 1, 2, 3 };
        public static int[] pos = new int[3] { 0, 0, 0 };
        public static int[] enpos = new int[3] { 0, 0, 0 };
        public static int[] axisSts = new int[3] { 0, 0, 0 };
        public static bool[] en = new bool[8];//各轴的伺服使能状态
        public static bool[] axis_di = new bool[16];
        public static bool[] axisExt_di = new bool[16];
        public static bool[] axis_do = new bool[16];
        public static bool[] baseposs = new bool[3];
        public static short ret = 0;
        public static ushort lGpiValueExt ;
        public static int lGpiValue, lGpoValue;
        public static uint clk;
        public static double encpos, prfpos;
        public static bool isPrfjog;
        public static bool basepos;
        //public static string Action<string, short> log;
        public static gts.mc.THomePrm GetGoHomeParam()
        {
            pHomePrm.mode = gts.mc.HOME_MODE_LIMIT_HOME;
            pHomePrm.moveDir = -1; //-1-负方向，1-正方向
            pHomePrm.indexDir = 1;  //-1-负方向， 1 - 正方向，在限位 + Index 回原点模式下 moveDir 与indexDir 应该相异
            pHomePrm.edge = 1;
            pHomePrm.pad1_1 = 0;
            pHomePrm.pad1_2 = 0;
            pHomePrm.pad1_3 = 0;
            pHomePrm.velHigh = 20;
            pHomePrm.velLow = 10;
            pHomePrm.acc = 0.1;
            pHomePrm.dec = 0.1;
            pHomePrm.smoothTime = 3;
            pHomePrm.pad2_1 = 1;
            pHomePrm.pad2_2 = 1;
            pHomePrm.pad2_3 = 1;
            pHomePrm.homeOffset = 5;
            pHomePrm.searchHomeDistance = 0;
            pHomePrm.searchIndexDistance = 0;
            pHomePrm.escapeStep = 10;
            return pHomePrm;
        }

        public static gts.mc.TTrapPrm GetTrapPrm(double acc=0.5,double dec = 0.5,short time=0,double velstar=0)
        {
            trapPrm.acc = acc;
            trapPrm.dec = dec;
            trapPrm.smoothTime = time;
            trapPrm.velStart = velstar;
            return trapPrm;
        }
        public static gts.mc.TJogPrm GetJogPrm(double acc = 0.5, double dec = 0.5, double smooth = 0)
        {
            jogPrm.acc = acc;
            jogPrm.dec = dec;
            //jogPrm.smooth = smooth;
            //jogPrm.velStart = 0;
            return jogPrm;
        }
        public static short GoHome(short no)
        {
            GetGoHomeParam();
            ret = gts.mc.GT_GoHome(no, ref pHomePrm);
            //pos[no - 1] = 0;
            //enpos[no - 1] = 0;
            baseposs[no - 1] = false;
            return ret;
        }

        public static void GetenPos(short no,bool isprf=false)
        {
            gts.mc.GT_GetEncPos(no, out encpos, 1, out clk);
            gts.mc.GT_GetPrfPos(no, out prfpos, 1, out clk);
            if (!isprf)
                pos[no - 1] = Convert.ToInt32(encpos);
            else
                pos[no - 1] = Convert.ToInt32(prfpos);
            if (encpos!=prfpos)
            {
                gts.mc.GT_SetPrfPos(no, pos[no - 1]);
            }
            
        }
        public static bool DoPower(short id,bool isOn)
        {
            if (isOn)
            {
                ret=gts.mc.GT_AxisOn(id);//上伺服
                en[id - 1] = isOn;
            }
            else
            {
                ret = gts.mc.GT_AxisOff(id);
                en[id - 1] = isOn;
            }
            return en[id - 1];
        }
        public static void DoPowerAll()
        {
            ret = gts.mc.GT_AxisOn(1);//上伺服
            //Thread.Sleep(1000);
            ret = gts.mc.GT_AxisOn(2);
            ret = gts.mc.GT_AxisOn(3);
            //if (Global.IsOpenFrist < 1)
            //{
            //    Thread.Sleep(3000);
            //    Global.IsOpenFrist++;
            //}
        }
        public static void GoHomeAll()
        {
            for(int i=axis.Length-1;i>=0;i--)
            {
                GoHome(axis[i]);
                //Thread.Sleep(10000*i);
            }
            //ClearPosAll();
        }
        public static short OpenCard()
        {
            ret = gts.mc.GT_Open(0, 1);
            ret |= gts.mc.GT_Reset();
            string path = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + "\\cfg\\GT800_test.cfg";
            //string path = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + "\\GTS800.cfg";
            ret |= gts.mc.GT_LoadConfig(path);
            ret |= OpenExtCard();
            return ret;
        }
        public static short OpenExtCard()
        {
            ret = gts.mc.GT_OpenExtMdl("gts.dll");
            //ret |= gts.mc.GT_Reset();
            string path = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + "\\cfg\\ExtModule.cfg";
            //string path = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + "\\GTS800.cfg";
            ret |= gts.mc.GT_LoadConfig(path);
            return ret;
        }
        public static void GetExtIO()
        {
            gts.mc.GT_GetExtIoValue(0, out lGpiValueExt);
            int temp = 0;
            for (int i = 0; i < axisExt_di.Length; i++)
            {
                temp = lGpiValueExt & (1 << i);
                axisExt_di[i] = temp == 0 ? false : true;
            }
        }
        public static void Open() 
        {
            try
            {
                //打开运动卡控制
                //if (Global.IsOpenFrist == 0)
                {
                    //OpenCard();
                    //先复位运动卡，在重新导入配置，在清警、复原DO
                    //ret = gts.mc.GT_Reset();
                    //string path = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + "\\cfg\\GT800_test.cfg";
                    ////string path = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + "\\GTS800.cfg";
                    //ret = gts.mc.GT_LoadConfig(path);
                    //Global.IsOpenFrist++;
                }
                SetDoAll(0);
                ClearAlarmAll();
                Thread.Sleep(500);
                SetDoAll(0);
                ClearPosAll();
            }
            catch(Exception e)
            {
                SetDoAll(0);
                ClearAlarmAll();
                Thread.Sleep(10);
                SetDoAll(0);
                ClearPosAll();
            }

            //SetDoAll(0);
            //ret = gts.mc.GT_SetDo(gts.mc.MC_GPO, 0);
        }
        public static void Close()
        {
            ret = gts.mc.GT_Close();
        }
        public static void ClearAlarmAll()
        {
            ret = gts.mc.GT_ClrSts(1, 8);//清除各轴报警和限位
        }

        /// <summary>
        /// ret返回指令含义
        /// </summary>
        /// <param name="no"></param>
        /// <returns></returns>
        public static string RetValDefine(short no)
        {
            string status = "";
            switch(no)
            {
                case 0:
                    status = "执行成功";
                    break; 
                case 1:
                    status = "指令执行错误";
                    break;
                case 2:
                    status = "license不支持";
                    break;
                case 7:
                    status = "指令参数错误";
                    break;
                case 8:
                    status = "不支持该指令";
                    break;
                case -6:
                    status = "打开控制器失败";
                    break;
                case -7:
                    status = "运动控制器没有响应";
                    break;
                case -8:
                    status = "多线程资源忙";
                    break;
                default:
                    status = "主机和运动控制器通讯失败";
                    break;
            }
            return status;
        }
        /// <summary>
        /// 轴状态定义
        /// </summary>
        /// <param name="no"></param>
        /// <returns></returns>
        public static string AxisStatusDefine(short no)
        {
            string status = "";
            switch (no)
            {
                case 0:
                    //status = "执行成功";
                    break;
                case 1:
                    status = "驱动器报警";
                    break;
                case 2:
                    //status = "license不支持";
                    break;
                case 3:
                    break;
                case 4:
                    status = "跟随误差越限标志";
                    break;
                case 5:
                    status = "正限位触发标志";
                    break;
                case 6:
                    status = "负限位触发标志";
                    break;
                case 7:
                    status = "IO平滑停止触发标志";
                    break;
                case 8:
                    status = "IO急停触发标志";
                    break;
                case 9:
                    status = "电机使能标志";
                    break;
                case 10:
                    status = "规划运动标志";
                    break;
                case 11:
                    status = "电机到位标志";
                    break;
                default:
                    //status = "主机和运动控制器通讯失败";
                    break;
            }
            return status;
        }

        public static void GetEnposAll()
        {
            for (int i = axis.Length - 1; i >= 0; i--)
            {
                ret = gts.mc.GT_GetEncPos(axis[i], out encpos, 1, out clk);
                ret = gts.mc.GT_GetPrfPos(axis[i], out prfpos, 1, out clk);
                enpos[i] = (int)(encpos);
                pos[i] = (int)(prfpos);
            }
        }
        public static double GetEnpos(short no)
        {

            ret = gts.mc.GT_GetEncPos(no, out encpos, 1, out clk);
            ret = gts.mc.GT_GetPrfPos(no, out prfpos, 1, out clk);
            return encpos;
        }
        public static void Stop(short no)
        {
            ret = gts.mc.GT_Stop(1 << (no - 1), 0);
        }
        public static void StopAll()
        {
            for (int i = 0; i < axis.Length; i++)
            {
                Stop(axis[i]);
            }
            Stop(4);
            Stop(5);
        }

        public static void DoJog(short no,double val, TJogPrm jog, bool fx)
        {
            isPrfjog = true;
            if(no<=3)
            baseposs[no - 1] = false;
            ret = gts.mc.GT_PrfJog(no);
            ret = gts.mc.GT_SetJogPrm(no, ref jog);//设置jog运动参数

            ret = gts.mc.GT_SetVel(no, fx ? val : -val);//设置目标速度

            ret = gts.mc.GT_Update(1 << (no - 1));//更新轴运动
        }
        public static void DoTrap(short no,  TTrapPrm trapPrm,int distenses, double val = 5,bool isclearpos=false)
        {
            isPrfjog = false;
            //if (isclearpos)
            //    ClearPos(no);
            if(no <= 3)
            baseposs[no - 1] = false;
            ret = gts.mc.GT_PrfTrap(no);
            ret = gts.mc.GT_SetTrapPrm(no, ref trapPrm);//设置点位运动参数
            ret = gts.mc.GT_SetVel(no, val);//设置目标速度
            ret = gts.mc.GT_SetPos(no, distenses);//设置目标位置
            ret = gts.mc.GT_Update(1 << (no - 1));//更新轴运动
        }
        public static void ClearPos(short no)
        {
            ret = gts.mc.GT_ZeroPos(no, 1);
            Task.Delay(20);
            ret = gts.mc.GT_GetEncPos(no, out encpos, 1, out clk);
            ret = gts.mc.GT_GetPrfPos(no, out prfpos, 1, out clk);
            enpos[no-1] = (int)(encpos);
            pos[no-1] = (int)(prfpos);
            //pos[no - 1] = 0;
            //enpos[no - 1] = 0;
            baseposs[no - 1] = true;
        }
        public static void ClearPosAll()
        {
            ret = gts.mc.GT_ZeroPos(1, 8);
            Task.Delay(20);
            GetEnposAll();
            for (int i = 0; i < pos.Length; i++)
            {
                //pos[i] = 0;
                //enpos[i] = 0;
                baseposs[i] = true;
            }
        }

        public static void GetAxisStas()
        {
            for (int i = 0; i < axis.Length; i++) 
            {
                ret = gts.mc.GT_GetSts(axis[i], out axisSts[i], 1, out clk);
            }
            
        }
        public static int GetAxisSts(short i)
        {
            ret=gts.mc.GT_GetSts(i, out int temp, 1, out clk);
            return temp;
        }
        public static bool GetBasePos(short no)
        {
            gts.mc.GT_GetDiRaw(MC_HOME, out int temp);
            temp = temp & (1 << no - 1);
            basepos = temp == 0 ? false : true;
            return basepos;
        }

        public static void GetDi()
        {
            gts.mc.GT_GetDi(gts.mc.MC_GPI, out lGpiValue);
            int temp = 0;
            for (int i=0; i<axis_di.Length; i++)
            {
                temp=lGpiValue & (1<< i);
                axis_di[i]=temp==0 ? false : true;
            }
        }
        
        public static void GetDo()
        {
            gts.mc.GT_GetDo(gts.mc.MC_GPO, out lGpoValue);
            int temp = 0;
            for (int i = 0; i < axis_do.Length; i++)
            {
                temp = lGpoValue & (1 << i);
                axis_do[i] = temp == 0 ? false : true;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="doTemp">1-16</param>
        /// <param name="val">0,1</param>
        public static void SetDoSignl(short doTemp,short val)
        {
            gts.mc.GT_SetDoBit(MC_GPO, doTemp, val);
        }
        public static void SetDoAll(short val)
        {
            gts.mc.GT_SetDo(gts.mc.MC_GPO, val);
        }
    }
}
