﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Timers;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;

namespace BenchMark
{
    public partial class MainForm : Form
    {

        //SciEngine m_engine;
        //MainThread mainThread;
        bool isSmt = false;
        int startnum = 1;
        List<string> alarmLists = new List<string>();
        User c_user = new User();
        IOForm m_form;
        ParamForm m_paramForm;
        //SingleContrlForm m_contrlForm;
        //SettingForm settingForm;
        ZControlForm m_zControlForm;
        FormLogin login;
        FormUserManage userManage;
        Thread sci;
        Enm_Axis axisSts=Enm_Axis.stop;
        EquipStatus eqSts=EquipStatus.free;
        //static object logobj=new object();
        int header = 0;
        ImageForm imageForm = null;

        private ToolTip toolTip;
        public MainForm()
        {
            InitializeComponent();
            toolTip = new ToolTip();
            //toolTip.AutoPopDelay = 500;
            //toolTip.InitialDelay = 500;
            //toolTip.ReshowDelay = 500;
            toolTip.ShowAlways = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void iOToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            if (MainThread.Instance().CheckAuth(2, c_user.auth) || true)
            {
                if (m_form == null || m_form.IsDisposed)
                    m_form = new IOForm();
                m_form.Show();
            }
            else
            {
                m_zControlForm?.Close();
                MessageBox.Show(Global.isZh?"权限不够": "insufficient privilege");
            };
        }

        private void 参数设置ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            if (MainThread.Instance().CheckAuth(2, c_user.auth) || true)
            {
                if (m_paramForm == null || m_paramForm.IsDisposed)
                    m_paramForm = new ParamForm();
                m_paramForm.Show();
            }
            else
            {
                m_zControlForm?.Close();
                MessageBox.Show(Global.isZh ? "权限不够" : "insufficient privilege");
            }
        }

        private void 轴参数设置ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (m_paramForm == null || m_paramForm.IsDisposed)
                m_paramForm = new ParamForm();
            m_paramForm.Show();



            //ParamForm param = new ParamForm();
            //param.Show();
        }

        private void 轴控ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (m_zControlForm == null || m_zControlForm.IsDisposed)
            {
                m_zControlForm = new ZControlForm();
            }
            m_zControlForm.TopMost = true;
            m_zControlForm.Show();
            //if (m_contrlForm==null || m_contrlForm.IsDisposed)
            //{
            //    m_contrlForm=new SingleContrlForm();
            //}
            //m_contrlForm.TopMost = true;
            //m_contrlForm.Show();
        }
        public void WriteLog(string msg)
        {
            Task.Run(() => { MainThread.Instance().RecordLog(msg); });
            Global.ControlInvocke(loglst, () =>
            {
                string msgs = "["+DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") +"]: "+ msg;
               
                if(loglst.Items.Count > 500)
                {
                    loglst.Items.Remove(loglst.Items[0]);
                } 
                loglst.Items.Add(msgs);
                loglst.TopIndex= loglst.Items.Count-1;
            });
        }
        private async void MainForm_Load(object sender, EventArgs e)
        {

            string msg=MainThread.Instance().Init();
            MainThread.Instance().logHelper = WriteLog;
            MainThread.Instance().alarmsUpdate = AddAramLst;
            MainThread.Instance().mainStsUpdate= UpdateSts;
            MainThread.Instance().axisStsUpdate = UpdateAxisSts;
            MainThread.Instance().Userlogin = UpdateUser;
            Show(Global.isZh);
            //sci = new Thread(new ThreadStart(DoWorkSci));
            //sci.Start();
            if (string.IsNullOrEmpty(msg))
                msg += Global.isZh ? "打开软件" : "open soft";
            WriteLog(msg);
        }
        public void UpdateUser(User user)
        {
            if (user != null)
            {


                if (string.IsNullOrEmpty(user.name))
                {
                    btn_name.Text =Global.isZh? "未登录":"Not_Login";
                    btn_name.BackColor = Color.Red;
                    c_user = new User();
                }
                else
                {
                    btn_name.Text = user.name;
                    btn_name.BackColor = Color.Green;
                    c_user = user;
                }
            }
            Show(Global.isZh);
        }

        public void UpdateAxisSts(Enm_Axis item)
        {
            if (axisSts != item)
            {
                axisSts = item;
                Global.ControlInvocke(btn_axisSts, () =>
                {
                    if (item == Enm_Axis.alnormal)
                    {
                        btn_axisSts.Text = Global.isZh ? "异常" : "Alnormal";
                        btn_axisSts.BackColor = Color.Red;
                    }
                    if (item == Enm_Axis.nopower)
                    {
                        btn_axisSts.Text = Global.isZh ? "未使能" : "NoPower";
                        btn_axisSts.BackColor = Color.Red;
                    }
                    else if(item == Enm_Axis.stop)
                    {
                        btn_axisSts.Text = Global.isZh ? "待机" : "Free";
                        btn_axisSts.BackColor = Color.Yellow;
                    }
                    else if (item == Enm_Axis.run)
                    {
                        btn_axisSts.Text = Global.isZh ? "运行" : "Run";
                        btn_axisSts.BackColor = Color.Green;
                    }
                });
            }
        }
        public void UpdateSts(EquipStatus item)
        {
            if(eqSts!=item)
            {
                eqSts=item;
                Global.ControlInvocke(btn_eqSts, () =>
                {
                    if (item == EquipStatus.alarm)
                    {
                        btn_eqSts.Text = Global.isZh ? "报警" : "alarming";
                        btn_eqSts.BackColor = Color.Red;
                    }else
                    {
                        btn_eqSts.Text = Global.isZh ? "正常":"normal";
                        btn_eqSts.BackColor = Color.Green;
                    }      
                });
            }
            switch (item)
            {
                case EquipStatus.init:
                case EquipStatus.reset:
                case EquipStatus.stop:
                    Global.ControlInvocke(this, () =>
                    {
                        Btn_Enabled(true);
                    });
                    break;
                case EquipStatus.pause:
                    break;
                    case EquipStatus.run: 
                    break;
                    case EquipStatus.alarm:
                     break;
                default: break;
            }
        }

        public void DoWorkSci()
        {
            #region 嵌入OPT界面

            Global.ControlInvocke(this, () =>
            {
                //m_engine = new SciEngine();
                //m_engine.InitEngine();
                //m_engine.SetMsgWindow((long)this.Handle);
                //m_engine.RunMode();
                //m_engine.ConnectRunWnd(0, (long)pictureBox1.Handle);
                //////The height of the title is approximately 30 pixels.
                //m_engine.MoveRunWindow(0, 0, 30, pictureBox1.Right - pictureBox1.Left, pictureBox1.Bottom - pictureBox1.Top);
                //string strPath = MainThread.Instance().datas.dataConfig.other.smtPath;
                //if (string.IsNullOrEmpty(strPath))
                //{
                //    openFileDialog1.Filter = "SMT文件|*.smt";
                //    openFileDialog1.Multiselect = false;
                //    strPath = openFileDialog1.FileName;
                //    MainThread.Instance().datas.dataConfig.other.smtPath = strPath;
                //    FileDeal.SaveFile(MainThread.Instance().datas.dataConfig);
                //}
                //m_engine.OpenProject(strPath);
                //this.Resize += MainForm_Resize;
            });


            #endregion
        }

        private void MainForm_Resize(object sender, EventArgs e)
        {

            //m_engine.RunMode();

            //m_engine.ConnectRunWnd(0, (long)pictureBox1.Handle);

            //m_engine.MoveRunWindow(0, 0, 30, pictureBox1.Right - pictureBox1.Left, pictureBox1.Bottom - pictureBox1.Top);
        }


        private void timer1_Tick(object sender, EventArgs e)
        {
            if(!isSmt)
            {
                //this.timer1.Enabled = false;
                if(MainThread.Instance().datas.dataConfig.isSmt)
                TaskAsync();

            }
            RefreshIO();
        }
        public void RefreshIO()
        {
            //Axis.GetDi();
            //Axis.GetDo();
        }
        private void TaskAsync()
        {
            imageForm = null;
            isSmt = true;
            Task.Run(() =>
            {
                Global.ControlInvocke(this, () =>
                {
                    imageForm = new ImageForm();
                    imageForm.TopLevel = false;
                    this.panel1.Controls.Add(imageForm);
                    imageForm.Dock = DockStyle.Fill;
                    imageForm.Show();
                });
            });
        }
      
        public void BtnTxtChange(int num)
        {
            //Global.ControlInvocke()
        }

        private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            MainThread.Instance().EndThread();
            sci?.Abort();
            this.Dispose(true);
            this.Close();

            //m_engine.Stop();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            WriteLog(Global.isZh?"手动点击初始化": "hand click Init");
            MainThread.Instance().InitEq();
            bool temp = false;
            btn_run.Enabled = temp;
            btn_stop.Enabled = !temp;
            btn_zero.Enabled = temp;
            menu_set.Enabled = temp;
        }
        public void Btn_Enabled(bool temp=true)
        {
            btn_run.Enabled = temp;
            btn_stop.Enabled = temp;
            btn_zero.Enabled = temp;
            menu_set.Enabled = temp;
        }

        private void btn_zero_Click(object sender, EventArgs e)
        {
            WriteLog(Global.isZh ? "手动点击复位" : "hand click Reset");
            MainThread.Instance().Reset();
            bool temp = false;
            btn_run.Enabled = temp;
            btn_stop.Enabled = !temp;
            btn_zero.Enabled = temp;
            menu_set.Enabled = temp;
        }

        private void btn_run_Click(object sender, EventArgs e)
        {
            WriteLog(Global.isZh?"手动点击运行": "hand click Run");
            if(!MainThread.Instance().IsCreatePro())
            {
                string tempstr = Global.isZh ? "未检测到流程，请先创建流程，" : "It is not project,please create project in frist";
                WriteLog(tempstr);
                MessageBox.Show(tempstr);
                return;
            }
            MainThread.Instance().Start();
            startnum = 0;
            btn_stop.Text =Global.isZh? "暂停": "Pause";
            bool temp = false;
            btn_run.Enabled = temp;
            btn_stop.Enabled = !temp;
            btn_zero.Enabled = temp;
            menu_set.Enabled = temp;
        }

        private void btn_stop_Click(object sender, EventArgs e)
        {
            if (startnum == 0)
            {
                WriteLog(Global.isZh ? "手动点击暂停" : "hand click Pause");
                MainThread.Instance().Pause();
                startnum++;
                //Global.ControlInvocke(btn_stop, () =>
                //{
                    btn_stop.Text = Global.isZh ? "停止":"Stop";
                btn_run.Enabled = true;
                menu_set.Enabled = true;
                //});

            }
            else
            {
                WriteLog(Global.isZh?"手动点击停止": "hand click Stop");
                MainThread.Instance().Stop();
                Btn_Enabled(true);
            }
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            MainThread.Instance().ChangeBuzzer(0);
        }
        public void AddAramLst(string msg)
        {
            if(!alarmLists.Contains(msg))
            {
                int temp = 0;
                Global.ControlInvocke(alarmLst, () =>
                {
                    alarmLst.Rows.Insert(0, msg);
                    alarmLst.Rows[temp].HeaderCell.Value = string.Format("{0}", ++header);
                    alarmLst.FirstDisplayedScrollingRowIndex = temp;
                });
                alarmLists.Add(msg);
            }

        }
        private void button4_Click(object sender, EventArgs e)
        {
            alarmLists.Clear();
            alarmLst.Rows.Clear();
            header = 0;
        }

        private void 用户登录ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (login == null || login.IsDisposed)
                login = new FormLogin();
            login.Show();
        }

        private void 用户设置ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(MainThread.Instance().CheckAuth(2,c_user.auth))
            {
                if (userManage == null || userManage.IsDisposed)
                    userManage = new FormUserManage();
                userManage.Show();
            }else
            {
                m_zControlForm?.Close();
                MessageBox.Show(Global.isZh ? "权限不够" : "insufficient privilege");
            }
           
        }

        private void 用户注销ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MainThread.Instance().Logout();
        }

        private void 老化测试ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(Global.isZh ? "确认是否老化测试": "Confirm if there is an Old_test", Global.isZh ? "提示":"Tip", MessageBoxButtons.YesNo) == DialogResult.No)
            {
                return;
            }
            WriteLog(Global.isZh?"手动点击老化测试": "hand click Old_test");
            MainThread.Instance().Start(99);
            //startnum = 0;
            //btn_stop.Text = "暂停";
            bool temp = false;
            btn_run.Enabled = temp;
            btn_stop.Enabled = !temp;
            btn_zero.Enabled = temp;
            menu_set.Enabled = temp;
        }
        private void Show(bool isZh)
        {
            if (!isZh)
            {
                Thread.CurrentThread.CurrentUICulture = new CultureInfo("en-US");
                Global.LoadLanguage(this, typeof(MainForm));
            }
            else
            {
                Thread.CurrentThread.CurrentUICulture = new CultureInfo("zh-CN");
                Global.LoadLanguage(this, typeof(MainForm));
            }
            ChangeMuin(isZh);
        }
        private void ChangeMuin(bool iszh=true)
        {
            Global.ControlInvocke(menu_set, () =>
            {
                void TraverseMenuItems(ToolStripItemCollection items)
                {
                    foreach (ToolStripMenuItem item in items)
                    {
                        switch(item.Name)
                        {
                            case "Setting":
                                item.Text = iszh? "设置":"Setting";
                                break;
                            case "UserSetting":
                                item.Text = iszh ? "用户设置":"UserSetting";
                                break;
                            case "ParamSetting":
                                item.Text = iszh ? "参数设置" : "ParamSetting";
                                break;
                            case "AxisControl":
                                item.Text = iszh ? "轴控" : "AxisControl";
                                break;
                            case "OldTest":
                                item.Text = iszh ? "老化测试" : "OldTest";
                                break;
                            case "UserLogin":
                                item.Text = iszh ? "用户登录" : "UserLogin";
                                break;
                            case "UserLogout":
                                item.Text = iszh ? "用户注销" : "UserLogout";
                                break;
                            case "UserManages":
                                item.Text = iszh ? "用户管理" : "UserManages";
                                break;
                            default:break;
                        }
                        TraverseMenuItems(item.DropDownItems);
                    }
                }
                TraverseMenuItems(menu_set.Items);
            });
            
        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            //Task.Run(() =>
            //{
            //    Global.ControlInvocke(this, () =>
            //    {
            //        imageForm = new ImageForm();
            //        imageForm.TopLevel = false;
            //        this.panel1.Controls.Add(imageForm);
            //        imageForm.Dock = DockStyle.Fill;
            //        imageForm.Show();
            //    });
            //});
        }

        private void btn_zero_MouseUp(object sender, MouseEventArgs e)
        {
            Button bt=sender as Button;
            if (bt!=null)
            {
                toolTip.SetToolTip(bt, bt.Tag.ToString());
            }
        }

        private void btn_zero_MouseLeave(object sender, EventArgs e)
        {
            toolTip.SetToolTip((Control)sender, string.Empty);
        }

        private void btn_zero_MouseHover(object sender, EventArgs e)
        {
            Button bt = sender as Button;
            if (bt != null)
            {
                toolTip.SetToolTip(bt, bt.Tag.ToString());
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //if (m_contrlForm == null || m_contrlForm.IsDisposed)
            //    m_contrlForm = new SingleContrlForm();
            //m_contrlForm.Show();

            //if (settingForm == null || settingForm.IsDisposed)
            //    settingForm = new SettingForm();
            //settingForm.Show();


        }
    }
}
