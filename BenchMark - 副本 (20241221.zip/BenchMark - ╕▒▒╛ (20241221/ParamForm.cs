﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static gts.mc;
using static gts.mc_la;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace BenchMark
{
    public partial class ParamForm : Form
    {
        int index=999;
        int num = 99;
        public static ManualResetEvent btn_bd_event = new ManualResetEvent(false);

        public ParamForm()
        {
            InitializeComponent();
        }
        DataConfig dataConfigs;
        ProjectData proData;
        //FileDeal fileDeal = new FileDeal();
        private void btn_look_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "SMT文件|*.smt";
            openFileDialog1.Multiselect = false;
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                txt_smt.Text = openFileDialog1.FileName;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //folderBrowserDialog1.Filter = "All files (*.*)|*.*";
            //folderBrowserDialog1.Multiselect = false;
            if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
            {
                txt_log.Text = folderBrowserDialog1.SelectedPath;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (lst_poss.SelectedItems.Count <= 0)
            {
                string tempMsg = Global.isZh ? "请先选择一个位置选项" : "Please select a location option first";
                MessageBox.Show(tempMsg);
                return;
            }
            Axis.GetEnposAll();
            lst_poss.Items[lst_poss.SelectedIndices[0]].SubItems[1].Text = Axis.enpos[0].ToString();
            lst_poss.Items[lst_poss.SelectedIndices[0]].SubItems[2].Text = Axis.enpos[1].ToString();
            lst_poss.Items[lst_poss.SelectedIndices[0]].SubItems[3].Text = Axis.enpos[2].ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (lst_poss.SelectedItems.Count <= 0)
            {
                string tempMsg = Global.isZh ? "请先选择一个位置选项" : "Please select a location option first";
                MessageBox.Show(tempMsg);
                return;
            }
            int pos=int.TryParse(lst_poss.Items[lst_poss.SelectedIndices[0]].SubItems[1].Text, out int ivv1) ? ivv1 : 0;
            Axis.DoTrap(1, Axis.GetTrapPrm(), pos, dataConfigs.alexParams.x_axle.val);
            pos = int.TryParse(lst_poss.Items[lst_poss.SelectedIndices[0]].SubItems[2].Text, out int ivv2) ? ivv2 : 0;
            Axis.DoTrap(2, Axis.GetTrapPrm(), pos, dataConfigs.alexParams.y_axle.val);
             pos = int.TryParse(lst_poss.Items[lst_poss.SelectedIndices[0]].SubItems[3].Text, out int ivv3) ? ivv3 : 0;
            Axis.DoTrap(3, Axis.GetTrapPrm(), pos, dataConfigs.alexParams.z_axle.val);
        }
        public void SetPos(Postion item,int num)
        {
            lst_poss.Items[num].SubItems[1].Text = item.X.ToString();
            lst_poss.Items[num].SubItems[2].Text = item.Y.ToString();
            lst_poss.Items[num].SubItems[3].Text = item.Z.ToString();
        }

        public Postion GetPos(int num)
        {
            Postion item=new Postion();
            int pos = int.TryParse(lst_poss.Items[num].SubItems[1].Text, out int ivv11) ? ivv11 : 0;
            item.X = Convert.ToDouble(pos);
            pos = int.TryParse(lst_poss.Items[num].SubItems[2].Text, out int ivv12) ? ivv12 : 0;
            item.Y = Convert.ToDouble(pos);
            pos = int.TryParse(lst_poss.Items[num].SubItems[3].Text, out int ivv13) ? ivv13 : 0;
            item.Z = Convert.ToDouble(pos);
            return item;
        }
        public DataConfig SaveTxt()
        {
            try
            {
                ParaamSigle axle_x = new ParaamSigle(1);
                ParaamSigle axle_y = new ParaamSigle(2);
                ParaamSigle axle_z = new ParaamSigle(3);
                ParaamSigle axle_k = new ParaamSigle(4);
                ParaamSigle axle_g = new ParaamSigle(5);
                #region x,y,z,k,g获取数据
                axle_x.val = Convert.ToDouble(txt_val1.Text.Trim());
                axle_x.dcc = Convert.ToDouble(txt_dec1.Text.Trim());
                axle_x.acc = Convert.ToDouble(txt_acc1.Text.Trim());
                axle_x.leftLimitpos = Convert.ToDouble(txt_leftLimt1.Text.Trim());
                axle_x.rightLimitpos = Convert.ToDouble(txt_rightLimt1.Text.Trim());
                axle_x.plse_mm = Convert.ToDouble(txt_pvmm1.Text.Trim());
                axle_x.smoothTime = Convert.ToInt32(txt_time1.Text.Trim());
                axle_y.val = Convert.ToDouble(txt_val2.Text.Trim());
                axle_y.dcc = Convert.ToDouble(txt_dec2.Text.Trim());
                axle_y.acc = Convert.ToDouble(txt_acc2.Text.Trim());
                axle_y.leftLimitpos = Convert.ToDouble(txt_leftLimt2.Text.Trim());
                axle_y.rightLimitpos = Convert.ToDouble(txt_rightLimt2.Text.Trim());
                axle_y.plse_mm = Convert.ToDouble(txt_pvmm2.Text.Trim());
                axle_y.smoothTime = Convert.ToInt32(txt_time2.Text.Trim());
                axle_z.val = Convert.ToDouble(txt_val3.Text.Trim());
                axle_z.dcc = Convert.ToDouble(txt_dec3.Text.Trim());
                axle_z.acc = Convert.ToDouble(txt_acc3.Text.Trim());
                axle_z.leftLimitpos = Convert.ToDouble(txt_leftLimt3.Text.Trim());
                axle_z.rightLimitpos = Convert.ToDouble(txt_rightLimt3.Text.Trim());
                axle_z.plse_mm = Convert.ToDouble(txt_pvmm3.Text.Trim());
                axle_z.smoothTime = Convert.ToInt32(txt_time3.Text.Trim());
                axle_k.val = Convert.ToDouble(txt_val4.Text.Trim());
                axle_k.dcc = Convert.ToDouble(txt_dec4.Text.Trim());
                axle_k.acc = Convert.ToDouble(txt_acc4.Text.Trim());
                axle_k.leftLimitpos = Convert.ToDouble(txt_leftLimt4.Text.Trim());
                axle_k.rightLimitpos = Convert.ToDouble(txt_rightLimt4.Text.Trim());
                axle_k.plse_mm = Convert.ToDouble(txt_pvmm4.Text.Trim());
                axle_k.smoothTime = Convert.ToInt32(txt_time4.Text.Trim());
                axle_g.val = Convert.ToDouble(txt_val5.Text.Trim());
                axle_g.dcc = Convert.ToDouble(txt_dec5.Text.Trim());
                axle_g.acc = Convert.ToDouble(txt_acc5.Text.Trim());
                axle_g.leftLimitpos = Convert.ToDouble(txt_leftLimt5.Text.Trim());
                axle_g.rightLimitpos = Convert.ToDouble(txt_rightLimt5.Text.Trim());
                axle_g.plse_mm = Convert.ToDouble(txt_pvmm5.Text.Trim());
                axle_g.smoothTime = Convert.ToInt32(txt_time5.Text.Trim());
                #endregion
                AxleParams alexParams = new AxleParams(axle_x, axle_y, axle_z, axle_k,axle_g);
                Data data = new Data();
                for (int i = 0; i < lst_poss.Items.Count; i++)
                {
                    data.posLists.Add(GetPos(i));
                }
                //Postion d2PosStart = new Postion();
                //Postion d2PosEnd = new Postion();
                //Postion d3PosStart1 = new Postion();
                //Postion d3PosEnd1 = new Postion();
                //Postion d3PosStart2 = new Postion();
                //Postion d3PosEnd2 = new Postion();
                #region 获取位置数据
                //d2PosStart = GetPos(d2PosStart, 0);
                //d2PosEnd = GetPos(d2PosEnd, 1);
                //d3PosStart1 = GetPos(d3PosStart1, 2);
                //d3PosEnd1 = GetPos(d3PosEnd1, 3);
                //d3PosStart2 = GetPos(d3PosStart2, 4);
                //d3PosEnd2 = GetPos(d3PosEnd2, 5);
                //Data data = new Data();
                //data.d2PosStart = d2PosStart;
                //data.d2PosEnd = d2PosEnd;
                //data.d3Pos1Start = d3PosStart1;
                //data.d3Pos1End = d3PosEnd1;
                //data.d3Pos2End = d3PosEnd2;
                //data.d3Pos2Start = d3PosStart2;
                #endregion
                OtherParam otherParam = new OtherParam();
                otherParam.logPath = txt_log.Text.Trim();
                otherParam.smtPath = txt_smt.Text.Trim();
                DataConfig dataConfig = new DataConfig();
                dataConfig.isSip = chk_sip.Checked;
                dataConfig.isSmt = chk_smt.Checked;
                dataConfig.isBuzing = chk_buz.Checked;
                dataConfig.d3_val = Convert.ToDouble(txt_3DVal.Text.Trim());
                dataConfig.buz_delyTime1 = Convert.ToInt32(txt_buz1.Text.Trim());
                dataConfig.buz_delyTime2 = Convert.ToInt32(txt_buz2.Text.Trim());
                dataConfig.run_num = Convert.ToInt32(txt_runnum.Text.Trim());
                dataConfig.d3_distence = Convert.ToDouble(txt_3Ddis.Text.Trim());
                dataConfig.office_3d1_x = Convert.ToDouble(txt_3d1x.Text.Trim());
                dataConfig.office_3d1_y = Convert.ToDouble(txt_3d1y.Text.Trim());
                dataConfig.office_3d2_x = Convert.ToDouble(txt_3d2x.Text.Trim());
                dataConfig.office_3d2_y = Convert.ToDouble(txt_3d2y.Text.Trim());
                dataConfig.delyTime = Convert.ToInt32(txt_delyTime.Text.Trim());
                dataConfig.alexParams = alexParams;
                dataConfig.other = otherParam;
                dataConfig.paramPostion = data;
                //fileDeal.dataConfig = dataConfig;
                proData.index = cb_project.SelectedIndex;
                dataConfig.pro = proData;
                dataConfigs = dataConfig;
                MainThread.Instance().datas.dataConfig = dataConfigs;
                string tempStr = Global.isZh ? "数据保存" : " config data is saved";
                MainThread.Instance().logHelper?.Invoke(tempStr);

                return dataConfig;
            }catch(Exception ex)
            {
                string tempStr = Global.isZh ? "数据保存出错" : " config data is saved fail";
                MainThread.Instance().logHelper?.Invoke(tempStr);
                return null;
            }
        }
        public void SaveData()
        {

            FileDeal.SaveFile(SaveTxt());
        }
        public void Loadxyzk(AxleParams axle) 
        {
            #region x,y,z,k获取数据
            txt_val1.Text=axle.x_axle.val.ToString();
            txt_dec1.Text = axle.x_axle.dcc.ToString();
            txt_acc1.Text = axle.x_axle.acc.ToString();
            txt_leftLimt1.Text = axle.x_axle.leftLimitpos.ToString();
            txt_rightLimt1.Text = axle.x_axle.rightLimitpos.ToString();
            txt_pvmm1.Text = axle.x_axle.plse_mm.ToString();
            txt_time1.Text = axle.x_axle.smoothTime.ToString();

            txt_val2.Text=axle.y_axle.val.ToString();
            txt_dec2.Text = axle.y_axle.dcc.ToString();
            txt_acc2.Text = axle.y_axle.acc.ToString();
            txt_leftLimt2.Text = axle.y_axle.leftLimitpos.ToString();
            txt_rightLimt2.Text = axle.y_axle.rightLimitpos.ToString();
            txt_pvmm2.Text = axle.y_axle.plse_mm.ToString();
            txt_time2.Text = axle.y_axle.smoothTime.ToString();

            txt_val3.Text = axle.z_axle.val.ToString();
            txt_dec3.Text = axle.z_axle.dcc.ToString();
            txt_acc3.Text = axle.z_axle.acc.ToString();
            txt_leftLimt3.Text = axle.z_axle.leftLimitpos.ToString();
            txt_rightLimt3.Text = axle.z_axle.rightLimitpos.ToString();
            txt_pvmm3.Text = axle.z_axle.plse_mm.ToString();
            txt_time3.Text = axle.z_axle.smoothTime.ToString();

            txt_val4.Text = axle.k_axle.val.ToString();
            txt_dec4.Text = axle.k_axle.dcc.ToString();
            txt_acc4.Text = axle.k_axle.acc.ToString();
            txt_leftLimt4.Text = axle.k_axle.leftLimitpos.ToString();
            txt_rightLimt4.Text = axle.k_axle.rightLimitpos.ToString();
            txt_pvmm4.Text = axle.k_axle.plse_mm.ToString();
            txt_time4.Text = axle.k_axle.smoothTime.ToString();

            txt_val5.Text = axle.g_axle.val.ToString();
            txt_dec5.Text = axle.g_axle.dcc.ToString();
            txt_acc5.Text = axle.g_axle.acc.ToString();
            txt_leftLimt5.Text = axle.g_axle.leftLimitpos.ToString();
            txt_rightLimt5.Text = axle.g_axle.rightLimitpos.ToString();
            txt_pvmm5.Text = axle.g_axle.plse_mm.ToString();
            txt_time5.Text = axle.g_axle.smoothTime.ToString();
            #endregion
        }
        public void LoadOther(OtherParam item)
        {
            txt_log.Text = item.logPath;
            txt_smt.Text = item.smtPath;
        }
        private void Changed_Chk()
        {
            gb_mark.Enabled = ckb_mark.Checked;
            //cb_mark1.Enabled = ckb_mark.Checked;
            //cb_mark2.Enabled = ckb_mark.Checked;
            gb_pos.Enabled = !ckb_mark.Checked;
            //cb_2d.Enabled = !ckb_mark.Checked;
            //cb_3d1.Enabled = !ckb_mark.Checked;
            //cb_3d2.Enabled = !ckb_mark.Checked;
        }
        public void LoadData()
        {
           
            //FileDeal.dataConfig= FileDeal.LoadFile();
            dataConfigs = MainThread.Instance().datas.dataConfig;
            proData = dataConfigs.pro;
            if (dataConfigs != null)
            {
                Loadxyzk(dataConfigs.alexParams);
                for(int i=0;i< dataConfigs.paramPostion.posLists.Count;i++)
                {
                    if (i >= Global.Dicpos.Count)
                        continue;
                    SetPos(dataConfigs.paramPostion.posLists[i], i);
                }
                //SetPos(fileDeal.dataConfig.paramPostion.d2PosStart,0);
                //SetPos(fileDeal.dataConfig.paramPostion.d2PosEnd, 1);
                //SetPos(fileDeal.dataConfig.paramPostion.d3Pos1Start, 2);
                //SetPos(fileDeal.dataConfig.paramPostion.d3Pos1End, 3);
                //SetPos(fileDeal.dataConfig.paramPostion.d3Pos2Start, 4);
                //SetPos(fileDeal.dataConfig.paramPostion.d3Pos2End, 5);
                LoadOther(dataConfigs.other);
                txt_3DVal.Text = dataConfigs.d3_val.ToString();
                txt_3Ddis.Text=dataConfigs.d3_distence.ToString();
                txt_3d1x.Text=dataConfigs.office_3d1_x.ToString();
                txt_3d1y.Text=dataConfigs.office_3d1_y.ToString();
                txt_3d2x.Text=dataConfigs.office_3d2_x.ToString();
                txt_3d2y.Text=dataConfigs.office_3d2_y.ToString();
                txt_delyTime.Text = dataConfigs.delyTime.ToString();
                txt_buz1.Text = dataConfigs.buz_delyTime1.ToString();
                txt_buz2.Text = dataConfigs.buz_delyTime2.ToString();
                chk_sip.Checked = dataConfigs.isSip;
                chk_smt.Checked = dataConfigs.isSmt;
                chk_buz.Checked = dataConfigs.isBuzing;
                txt_runnum.Text=dataConfigs.run_num.ToString();
                //dataConfigs = FileDeal.dataConfig;
                
            }
            else
            {
                string tempStr = Global.isZh ? "数据导入失败" : "load config data is fail";
                MainThread.Instance().logHelper?.Invoke(tempStr);
            }
            if(proData != null)
            {
                Rush();
                if (proData.projectBases.Count>0 && proData.index < proData.projectBases.Count)
                    WriteData(proData.projectBases[proData.index].item);
            }
            else
            {
                string tempStr = Global.isZh ? "数据导入失败" : "load config data is fail";
                MainThread.Instance().logHelper?.Invoke(tempStr);
            }

        }
        private void button1_Click(object sender, EventArgs e)
        {
            SaveData();
        }

        private void ParamForm_Load(object sender, EventArgs e)
        {
            Changed_Chk();
            Global.Dicpos = Global.LodPosIni(Global.PosPath);
            Global.Dicdi = Global.LodPosIni(Global.DiPath);
            Global.Dicdo = Global.LodPosIni(Global.DoPath);
            Show(Global.isZh);
            LoadProData(Global.ToList(Global.Dicdi), Global.ToList(Global.Dicpos),Global.ToList(Global.Dicdo));
            AddPosList();
            LoadData();
        }
        public void AddPosList()
        {
            lst_poss.Items.Clear();
            //var item= Global.isZh? Enm_PosLists_zh:Enm_PosLists_en;
            for (int i = 0;i< Global.Dicpos.Count;i++)
            {
                lst_poss.Items.Add(new System.Windows.Forms.ListViewItem(new string[] {
            Global.Dicpos[i],
            "0",
                    "0",
            "0"}, -1));
            }
        }


        public enum Enm_PosLists_en
        {
            d2PosStart ,
            d2PosEnd ,
            d3PosStart1 ,
            d3PosEnd1 ,
            d3PosStart2 ,
            d3PosEnd2 ,
            bak1,
            bak2,
            bak3,
            bak4,
            bak5,
            bak6,
            bak7,
            bak8,
            bak9,
            bak10,
            bak11,
            bak12,
            Count
        }
        public enum Enm_PosLists_zh
        {
            初始位置2D=0,
            结束位置2D=1,
            初始位置3D1=2,
            结束位置3D1=3,
            初始位置3D2=4,
            结束位置3D2=5,
            备用1,
            备用2,
            备用3,
            备用4,
            备用5,
            备用6,
            备用7,
            备用8,
            备用9,
            备用10,
            备用11,
            备用12,
            Count
        }

        private void lst_poss_MouseClick(object sender, MouseEventArgs e)
        {
            if (lst_poss.SelectedItems.Count == 1)
            {
                txt_bdpos.Text = lst_poss.Items[lst_poss.SelectedIndices[0]].SubItems[0].Text;
                index = lst_poss.SelectedIndices[0];
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                if (index == 999)
                {
                    string tempMsg = Global.isZh ? "请先在上面选择一个位置选项" : "Please select a location option above first";
                    MessageBox.Show(tempMsg);
                    return;
                }
                Postion itembd = GetPos(index);
                txt_bdnum.Text = "0";
                if (num >0) 
                {
                    num=0;
                    btn_bd.Text = Global.isZh ? "停止标定": "stop_mark";
                    double dis_bd = Convert.ToDouble(txt_bdbc.Text);
                    List<Postion> tempposs = new List<Postion>();
                    for (int i = 0; i < 3; i++)
                    {
                        for (int j = 0; j < 3; j++)
                        {
                            //if ()
                            Postion item = new Postion();
                            item.Y = itembd.Y;
                            item.X = itembd.X;
                            item.Z = itembd.Z;
                            if (i < 1)
                            {
                                item.Y += dis_bd;
                            }
                            else if (i > 1)
                            {
                                item.Y -= dis_bd;
                            }
                            if (j < 1)
                            {
                                item.X -=dis_bd;
                            }
                            else if (j > 1)
                            {
                                item.X += dis_bd;
                            }
                            tempposs.Add(item);
                        }
                    }
                    Task.Run(() => {
                        DoD2orD3ConnAction(tempposs);
                    });
                }
                else
                {
                    btn_bd.Text = Global.isZh ? "开始标定测试": "mark_startTest";
                    btn_bd_event.Set();
                    num++;
                }  
            }
            catch (Exception ex)
            {
                btn_bd.Text = Global.isZh ? "开始标定测试" : "mark_startTest";
                btn_bd_event.Set();
                num++;
                MainThread.Instance().logHelper?.Invoke(Global.isZh ? "标定测试失败，":"mark_test fail，" +ex.StackTrace+ex.Message);
            }
        }
        public void DoD2orD3ConnAction(List<Postion> pos)
        {
            ClientConn client = null;
            MainThread.Instance().ConnectClient(ref MainThread.Instance().client1, 8001);
            
            if (MainThread.Instance().client1 != null && MainThread.Instance().client1._isRunning)
                client = MainThread.Instance().client1;
            else
            {
                string msg = Global.isZh ? "标定测试失败，tcp连接失败！" : "mark test failed, TCP connection failed!";
                MainThread.Instance().logHelper?.Invoke(msg);
                return;
            }
            //client.receivedAction = DealServesMsg;
            Thread.Sleep(500);
            if (client._isRunning)
            {
                int numtemp = 0;
                foreach (Postion item in pos)
                {
                    string msg = "2D,A,SN,";
                    if (numtemp > 0)
                    {
                        if (!Global.tcpConnRet[(int)Enm_Run.D2])
                        {
                            btn_bd_event.Reset();
                            btn_bd_event.WaitOne();
                        }
                        Task.Delay(500);
                    }
                    if (num > 0)
                        break;
                    double x = item.X * 0.001;
                    double y = item.Y * 0.001;
                    msg += $"{numtemp + 1},{x},{y}";
                    //Task.Delay(50);
                    MainThread.Instance().MoveTrap(item);
                    Task.Delay(5000);
                    if(GetRet(item))
                    {
                        if (num > 0)
                            break;
                        MainThread.Instance().logHelper?.Invoke($"第{numtemp + 1}次发送消息，{msg}");
                        Global.tcpConnRet[(int)Enm_Run.D2] = false;
                        client.SendMessageAsync(msg);
                        numtemp++;
                        Global.ControlInvocke(txt_bdnum, () =>
                        {
                            txt_bdnum.Text = numtemp.ToString();
                        }); 
                    }
                }

                Global.ControlInvocke(btn_bd, () =>
                {
                    btn_bd.Text = Global.isZh ? "开始标定测试" : "mark_startTest";
                    btn_bd_event.Set();
                    txt_bdnum.Text = "0";
                    num++;
                });
            }
            else
            {
                Global.ControlInvocke(btn_bd, () =>
                {
                    btn_bd.Text = Global.isZh ? "开始标定测试" : "mark_startTest";
                    btn_bd_event.Set();
                    num++;
                });
                string strmsg = Global.isZh ? "tcp连接8001端口超时,请检查端口是否被占用或者tcp服务是否开启" : "TCP connection 8001 port timeout, please check if the port is occupied or if TCP service is enabled";
                MainThread.Instance().logHelper?.Invoke(strmsg);
            }
        }

        public bool GetRet(Postion pos)
        {
            uint time=Global.timeGetTime();
            while (true)
            {
                if (MainThread.Instance().PosTrapEquals(MainThread.Instance().GetPos(), pos))
                {
                    break;
                }
                else if(Global.timeGetTime() - time >30000)
                {
                    MainThread.Instance().logHelper?.Invoke(Global.isZh ? "请检测轴是否异常": "Please check if the axis is abnormal");
                    break;
                }
                Thread.Sleep(500);
            }
            Thread.Sleep(500);
            return true;
        }
        private void Show(bool isZh)
        {
            if (!isZh)
            {
                Thread.CurrentThread.CurrentUICulture = new CultureInfo("en-US");
                Global.LoadLanguage(this, typeof(ParamForm));
            }
            else
            {
                Thread.CurrentThread.CurrentUICulture = new CultureInfo("zh-CN");
                Global.LoadLanguage(this, typeof(ParamForm));
            }
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            Projecter item=ReadData();
            bool ret = false;
            foreach(var temp in proData.projectBases)
            {
                if (temp.item.Name.Equals(item.Name))
                {
                    ret = true;
                    string tempStrs = Global.isZh ? "已经有相同工程名称" : "It haved same project name";
                    MainThread.Instance().logHelper?.Invoke(tempStrs);
                    MessageBox.Show(tempStrs);
                    break;
                }
            }
            if (ret)
                return;
            ProjectBase projectBase=new ProjectBase();
            projectBase.pos_mark1 = GetPos(item.Pos_mark1);
            projectBase.pos_mark2 = GetPos(item.Pos_mark2);
            projectBase.pos_2d = GetPos(item.Pos_2d);

            //double temp_3d1_x = (dataConfigs.office_3d1_x - item.Length_3d / 2) * dataConfigs.alexParams.x_axle.plse_mm;
            //double temp_3d2_x = (dataConfigs.office_3d2_x - item.Length_3d / 2) * dataConfigs.alexParams.x_axle.plse_mm;
            double temp_3d1_y = (dataConfigs.office_3d1_y - item.Length_3d / 2) * dataConfigs.alexParams.y_axle.plse_mm;
            double temp_3d2_y = (dataConfigs.office_3d2_y + item.Length_3d / 2) * dataConfigs.alexParams.y_axle.plse_mm;
            //double temp_3d1_y = (Global.office_3d1_y) * dataConfigs.alexParams.y_axle.plse_mm;

            projectBase.pos_3d1 = MainThread.Instance().AddPos(projectBase.pos_2d,  dataConfigs.office_3d1_x * dataConfigs.alexParams.x_axle.plse_mm, temp_3d1_y);
            projectBase.pos_3d2 = MainThread.Instance().AddPos(projectBase.pos_2d,  dataConfigs.office_3d2_x * dataConfigs.alexParams.x_axle.plse_mm, temp_3d2_y);

            //projectBase.pos_3d1 = MainThread.Instance().AddPos(projectBase.pos_2d, temp_3d1_x, dataConfigs.office_3d1_y * dataConfigs.alexParams.y_axle.plse_mm);
            //projectBase.pos_3d2 = MainThread.Instance().AddPos(projectBase.pos_2d, temp_3d2_x, dataConfigs.office_3d2_y * dataConfigs.alexParams.y_axle.plse_mm); 
            projectBase.item = item;
            proData.projectBases.Add(projectBase);
            Rush();
            string tempStr = Global.isZh ? $"添加工程:{item.Name}" : $" add Project:{item.Name}";
            MainThread.Instance().logHelper?.Invoke(tempStr);
        }
        public void Rush()
        {
            cb_project.Items.Clear();
            if (proData.projectBases.Count > 0)
            {
                foreach (var item in proData.projectBases)
                {
                    cb_project.Items.Add(item.item.Name);
                }
                if (proData.index < proData.projectBases.Count)
                    cb_project.SelectedIndex = proData.index;
                else
                    cb_project.SelectedIndex = -1;
            }

        }
        private void ckb_mark_CheckedChanged(object sender, EventArgs e)
        {
             Changed_Chk();
        }

        public void LoadProData(List<string> data1, List<string> data2, List<string> data3)
        {
            cb_in.Items.Clear();
            cb_out.Items.Clear();
            cb_put.Items.Clear();
            cb_2d.Items.Clear();
            cb_3d1.Items.Clear();
            cb_3d2.Items.Clear();
            cb_mark1.Items.Clear();
            cb_mark2.Items.Clear();

            cb_in.Items.AddRange(data1.ToArray());
            cb_put.Items.AddRange(data1.ToArray());
            cb_out.Items.AddRange(data1.ToArray());
            cb_blockAir.Items.AddRange(data3.ToArray());
            cb_jackAir.Items.AddRange(data3.ToArray());
            cb_jackAir2.Items.AddRange(data3.ToArray());
            cb_befor.Items.AddRange(data1.ToArray());
            cb_after.Items.AddRange(data1.ToArray());
            cb_2d.Items.AddRange(data2.ToArray());
            cb_3d1.Items.AddRange(data2.ToArray());
            cb_3d2.Items.AddRange(data2.ToArray());
            cb_mark1.Items.AddRange(data2.ToArray());
            cb_mark2.Items.AddRange(data2.ToArray());

            cb_in.SelectedIndex = 0;
            cb_out.SelectedIndex = 0;
            cb_put.SelectedIndex = 0;
            cb_2d.SelectedIndex = 0;
            cb_3d1.SelectedIndex = 0;
            cb_3d2.SelectedIndex = 0;
            cb_mark1.SelectedIndex = 0;
            cb_mark2.SelectedIndex = 0;
        }

        public void WriteData(Projecter item)
        {
            txt_name.Text = item.Name;
            txt_ip.Text = item.Bard_ip;
            txt_dely_in.Text = item.Signal_in_delyTime.ToString();
            txt_dely_put.Text = item.Signal_put_delyTime.ToString();
            txt_dely_out.Text = item.Signal_out_delyTime.ToString();
            ckb_mark.Checked = item.IsMarked;
            ckb_g.Checked = item.IsRight_g;
            ckb_ip.Checked = item.IsReadBard;
            cb_in.SelectedIndex = item.Signal_in;
            cb_put.SelectedIndex = item.Signal_put;
            cb_out.SelectedIndex = item.Signal_out;
            cb_after.SelectedIndex = item.After_get;
            cb_befor.SelectedIndex = item.Befor_get;
            cb_blockAir.SelectedIndex = item.Block_Air;
            cb_jackAir.SelectedIndex = item.Jack_Air;
            cb_jackAir2.SelectedIndex = item.Jack_Air2;
            cb_2d.SelectedIndex = item.Pos_2d;
            cb_3d1.SelectedIndex = item.Pos_3d1;
            cb_3d2.SelectedIndex = item.Pos_3d2;
            cb_mark1.SelectedIndex = item.Pos_mark1;
            cb_mark2.SelectedIndex = item.Pos_mark2;
            txt_length.Text = item.Length_3d.ToString();
            txt_g_dis.Text = item.Dis_g.ToString();
            txt_speed.Text = item.Speed_3d.ToString();
            txt_gpu.Text = item.Gpu_type.ToString();
        }
        public Projecter ReadData()
        {
            Projecter item = new Projecter();
            item.Name = txt_name.Text.Trim().ToString();
            item.Bard_ip = txt_ip.Text.Trim().ToString();
            item.IsMarked = ckb_mark.Checked;
            item.IsRight_g = ckb_g.Checked;
            item.IsReadBard = ckb_ip.Checked;
            item.Signal_in = cb_in.SelectedIndex;
            item.Signal_put = cb_put.SelectedIndex;
            item.Signal_out = cb_out.SelectedIndex;
            item.Block_Air = cb_blockAir.SelectedIndex;
            item.Jack_Air = cb_jackAir.SelectedIndex;
            item.Jack_Air2 = cb_jackAir2.SelectedIndex;
            item.Befor_get = cb_befor.SelectedIndex;
            item.After_get = cb_after.SelectedIndex;
            item.Pos_2d = cb_2d.SelectedIndex;
            item.Pos_3d1 = cb_3d1.SelectedIndex;
            item.Pos_3d2 = cb_3d2.SelectedIndex;
            item.Pos_mark1 = cb_mark1.SelectedIndex;
            item.Pos_mark2 = cb_mark2.SelectedIndex;
            item.Signal_in_delyTime = int.Parse(txt_dely_in.Text.Trim().ToString());
            item.Signal_put_delyTime = int.Parse(txt_dely_put.Text.Trim().ToString());
            item.Signal_out_delyTime = int.Parse(txt_dely_out.Text.Trim().ToString());
            item.Gpu_type = int.Parse(txt_gpu.Text.Trim().ToString());
            item.Length_3d = double.Parse(txt_length.Text.Trim().ToString());
            item.Dis_g = double.Parse(txt_g_dis.Text.Trim().ToString());
            item.Speed_3d = double.Parse(txt_speed.Text.Trim().ToString());
            return item;
        }

        private void cb_project_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (proData.projectBases.Count > 0 && cb_project.SelectedIndex < proData.projectBases.Count)
                WriteData(proData.projectBases[cb_project.SelectedIndex].item);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (proData.projectBases.Count > 0 && cb_project.SelectedIndex < proData.projectBases.Count)
                proData.projectBases.RemoveAt(cb_project.SelectedIndex);
            Rush();
            string tempStr = Global.isZh ? $"删除工程:{proData.projectBases[cb_project.SelectedIndex].item.Name}" : $" delete Project:{proData.projectBases[cb_project.SelectedIndex].item.Name}";
            MainThread.Instance().logHelper?.Invoke(tempStr);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Projecter item = ReadData();
            ProjectBase projectBase = new ProjectBase();
            projectBase.pos_mark1 = GetPos(item.Pos_mark1);
            projectBase.pos_mark2 = GetPos(item.Pos_mark2);
            projectBase.pos_2d = GetPos(item.Pos_2d);
            //projectBase.pos_3d1 = GetPos(item.Pos_3d1);
            //projectBase.pos_3d2 = GetPos(item.Pos_3d2);
            //double temp_3d1_x = (dataConfigs.office_3d1_x - item.Length_3d / 2) * dataConfigs.alexParams.x_axle.plse_mm;
            //double temp_3d2_x = (dataConfigs.office_3d2_x - item.Length_3d / 2) * dataConfigs.alexParams.x_axle.plse_mm;
            ////double temp_3d1_y = (Global.office_3d1_y) * dataConfigs.alexParams.y_axle.plse_mm;

            //projectBase.pos_3d1 = MainThread.Instance().AddPos(projectBase.pos_2d, temp_3d1_x, dataConfigs.office_3d1_y * dataConfigs.alexParams.y_axle.plse_mm);
            //projectBase.pos_3d2 = MainThread.Instance().AddPos(projectBase.pos_2d, temp_3d2_x, dataConfigs.office_3d2_y * dataConfigs.alexParams.y_axle.plse_mm);

            double temp_3d1_y = (dataConfigs.office_3d1_y - item.Length_3d / 2) * dataConfigs.alexParams.y_axle.plse_mm;
            double temp_3d2_y = (dataConfigs.office_3d2_y + item.Length_3d / 2) * dataConfigs.alexParams.y_axle.plse_mm;
            //double temp_3d1_y = (Global.office_3d1_y) * dataConfigs.alexParams.y_axle.plse_mm;

            projectBase.pos_3d1 = MainThread.Instance().AddPos(projectBase.pos_2d, dataConfigs.office_3d1_x * dataConfigs.alexParams.x_axle.plse_mm, temp_3d1_y);
            projectBase.pos_3d2 = MainThread.Instance().AddPos(projectBase.pos_2d, dataConfigs.office_3d2_x * dataConfigs.alexParams.x_axle.plse_mm, temp_3d2_y);
            projectBase.item = item;
            if (proData.projectBases.Count > 0 && cb_project.SelectedIndex < proData.projectBases.Count)
                proData.projectBases[cb_project.SelectedIndex]= projectBase;
            Rush();
            string tempStr = Global.isZh ? $"更新工程:{proData.projectBases[cb_project.SelectedIndex].item.Name}" : $" update Project:{proData.projectBases[cb_project.SelectedIndex].item.Name}";
            MainThread.Instance().logHelper?.Invoke(tempStr);
        }
    }
}
