﻿namespace BenchMark
{
    partial class FormUserManage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btn_delete = new System.Windows.Forms.Button();
            this.txt_pwd2 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btn_update = new System.Windows.Forms.Button();
            this.txt_auth = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_pwd = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_name = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.dglst = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.chk_userManage = new System.Windows.Forms.CheckBox();
            this.chk_pram = new System.Windows.Forms.CheckBox();
            this.label5 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.com_auth = new System.Windows.Forms.ComboBox();
            this.chk_io = new System.Windows.Forms.CheckBox();
            this.root_auth = new System.Windows.Forms.TreeView();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dglst)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(13, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(690, 479);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.btn_delete);
            this.tabPage1.Controls.Add(this.txt_pwd2);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.btn_update);
            this.tabPage1.Controls.Add(this.txt_auth);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.txt_pwd);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.txt_name);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Controls.Add(this.dglst);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(682, 453);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "用户管理";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // btn_delete
            // 
            this.btn_delete.BackColor = System.Drawing.Color.Gray;
            this.btn_delete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_delete.ForeColor = System.Drawing.Color.White;
            this.btn_delete.Location = new System.Drawing.Point(580, 277);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(75, 23);
            this.btn_delete.TabIndex = 11;
            this.btn_delete.Text = "删除";
            this.btn_delete.UseVisualStyleBackColor = false;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // txt_pwd2
            // 
            this.txt_pwd2.Location = new System.Drawing.Point(465, 143);
            this.txt_pwd2.Name = "txt_pwd2";
            this.txt_pwd2.PasswordChar = '*';
            this.txt_pwd2.Size = new System.Drawing.Size(121, 21);
            this.txt_pwd2.TabIndex = 10;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(373, 146);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 12);
            this.label4.TabIndex = 9;
            this.label4.Text = "确认密码";
            // 
            // btn_update
            // 
            this.btn_update.BackColor = System.Drawing.Color.Gray;
            this.btn_update.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_update.ForeColor = System.Drawing.Color.White;
            this.btn_update.Location = new System.Drawing.Point(477, 277);
            this.btn_update.Name = "btn_update";
            this.btn_update.Size = new System.Drawing.Size(75, 23);
            this.btn_update.TabIndex = 8;
            this.btn_update.Text = "修改";
            this.btn_update.UseVisualStyleBackColor = false;
            this.btn_update.Click += new System.EventHandler(this.btn_update_Click);
            // 
            // txt_auth
            // 
            this.txt_auth.FormattingEnabled = true;
            this.txt_auth.Items.AddRange(new object[] {
            "staff",
            "projecter",
            "adminiterator"});
            this.txt_auth.Location = new System.Drawing.Point(465, 190);
            this.txt_auth.Name = "txt_auth";
            this.txt_auth.Size = new System.Drawing.Size(121, 20);
            this.txt_auth.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(375, 193);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 12);
            this.label3.TabIndex = 6;
            this.label3.Text = "权限";
            // 
            // txt_pwd
            // 
            this.txt_pwd.Location = new System.Drawing.Point(465, 94);
            this.txt_pwd.Name = "txt_pwd";
            this.txt_pwd.PasswordChar = '*';
            this.txt_pwd.Size = new System.Drawing.Size(121, 21);
            this.txt_pwd.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(373, 97);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 12);
            this.label2.TabIndex = 4;
            this.label2.Text = "密码";
            // 
            // txt_name
            // 
            this.txt_name.Location = new System.Drawing.Point(465, 47);
            this.txt_name.Name = "txt_name";
            this.txt_name.Size = new System.Drawing.Size(121, 21);
            this.txt_name.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(373, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 12);
            this.label1.TabIndex = 2;
            this.label1.Text = "用户名";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Gray;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(377, 277);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "增加";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // dglst
            // 
            this.dglst.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dglst.Location = new System.Drawing.Point(7, 7);
            this.dglst.Name = "dglst";
            this.dglst.RowTemplate.Height = 23;
            this.dglst.Size = new System.Drawing.Size(308, 410);
            this.dglst.TabIndex = 0;
            this.dglst.SelectionChanged += new System.EventHandler(this.dglst_SelectionChanged);
            this.dglst.MouseClick += new System.Windows.Forms.MouseEventHandler(this.dglst_MouseClick);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.chk_userManage);
            this.tabPage2.Controls.Add(this.chk_pram);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.button2);
            this.tabPage2.Controls.Add(this.com_auth);
            this.tabPage2.Controls.Add(this.chk_io);
            this.tabPage2.Controls.Add(this.root_auth);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(682, 453);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "权限管理";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // chk_userManage
            // 
            this.chk_userManage.AutoSize = true;
            this.chk_userManage.Location = new System.Drawing.Point(79, 126);
            this.chk_userManage.Name = "chk_userManage";
            this.chk_userManage.Size = new System.Drawing.Size(72, 16);
            this.chk_userManage.TabIndex = 6;
            this.chk_userManage.Text = "用户管理";
            this.chk_userManage.UseVisualStyleBackColor = true;
            // 
            // chk_pram
            // 
            this.chk_pram.AutoSize = true;
            this.chk_pram.Location = new System.Drawing.Point(79, 87);
            this.chk_pram.Name = "chk_pram";
            this.chk_pram.Size = new System.Drawing.Size(72, 16);
            this.chk_pram.TabIndex = 5;
            this.chk_pram.Text = "参数设置";
            this.chk_pram.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(319, 86);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(29, 12);
            this.label5.TabIndex = 4;
            this.label5.Text = "权限";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Gray;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(562, 80);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 3;
            this.button2.Text = "保存";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // com_auth
            // 
            this.com_auth.FormattingEnabled = true;
            this.com_auth.Items.AddRange(new object[] {
            "staff",
            "projecter",
            "administrator"});
            this.com_auth.Location = new System.Drawing.Point(391, 83);
            this.com_auth.Name = "com_auth";
            this.com_auth.Size = new System.Drawing.Size(121, 20);
            this.com_auth.TabIndex = 2;
            this.com_auth.SelectedIndexChanged += new System.EventHandler(this.com_auth_SelectedIndexChanged);
            // 
            // chk_io
            // 
            this.chk_io.AutoSize = true;
            this.chk_io.Location = new System.Drawing.Point(79, 50);
            this.chk_io.Name = "chk_io";
            this.chk_io.Size = new System.Drawing.Size(36, 16);
            this.chk_io.TabIndex = 1;
            this.chk_io.Text = "IO";
            this.chk_io.UseVisualStyleBackColor = true;
            // 
            // root_auth
            // 
            this.root_auth.Location = new System.Drawing.Point(6, 6);
            this.root_auth.Name = "root_auth";
            this.root_auth.Size = new System.Drawing.Size(261, 428);
            this.root_auth.TabIndex = 0;
            // 
            // FormUserManage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(769, 503);
            this.Controls.Add(this.tabControl1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormUserManage";
            this.Text = "FormUserManage";
            this.Load += new System.EventHandler(this.FormUserManage_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dglst)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.DataGridView dglst;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.ComboBox txt_auth;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_pwd;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_name;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txt_pwd2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btn_update;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.TreeView root_auth;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ComboBox com_auth;
        private System.Windows.Forms.CheckBox chk_io;
        private System.Windows.Forms.CheckBox chk_userManage;
        private System.Windows.Forms.CheckBox chk_pram;
    }
}