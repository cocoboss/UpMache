﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SQLite;
using System.Data;
using System.Collections;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
using System.Xml.Linq;

namespace BenchMark
{
    public class DBhelper
    {

        //public static string connString= Global.ConnectionString;
        public static void DoNonQuery(string sql, params SQLiteParameter[] parameters)
        {
            using (SQLiteConnection conn = new SQLiteConnection(Global.ConnectionString))
            {
                using (var command = new SQLiteCommand(sql, conn))
                {
                    if (parameters != null)
                    {
                        command.Parameters.AddRange(parameters);
                    }
                    conn.Open();
                    command.ExecuteNonQuery();
                }  
            }
        }
        public static DataTable DoQuery(string sql, params SQLiteParameter[] parameters)
        {
            DataTable dataTable = new DataTable();
            using (SQLiteConnection conn = new SQLiteConnection(Global.ConnectionString))
            {
                using (var command = new SQLiteCommand(sql, conn))
                {
                    if (parameters != null)
                    {
                        command.Parameters.AddRange(parameters);
                    }
                    using (SQLiteDataAdapter adapter = new SQLiteDataAdapter(command))
                    {
                        conn.Open();
                        adapter.Fill(dataTable);
                    }
                }
            }
            return dataTable;
        }
        public static object DoScalar(string query, params SQLiteParameter[] parameters)
        {
            object result = null;
            using (SQLiteConnection conn = new SQLiteConnection(Global.ConnectionString))
            {
                using (var command = new SQLiteCommand(query, conn))
                {
                    if (parameters != null)
                    {
                        command.Parameters.AddRange(parameters);
                    }
                    conn.Open();
                    result = command.ExecuteScalar();
                }
            }
            return result;
        }

    }
    public class ProductionMode
    {
        public ProductionMode()
        {

        }

    }
    public class AuthMode
    {
        public Auth auth { get; set; }

        public AuthMode()
        {
            auth = new Auth();
        }
        public void Add(Auth auth)
        {
            string sql = "insert into Auth Values(@id,@num)";
            SQLiteParameter[] sQLiteParameter =
            {
                new SQLiteParameter("@id",DbType.Int32),
                new SQLiteParameter("@num",DbType.Int32),
            };
            sQLiteParameter[0].Value = auth.id;
            sQLiteParameter[1].Value = auth.mark;
            DBhelper.DoScalar(sql, sQLiteParameter);
        }
        public Auth Select(int id)
        {
            Auth user = new Auth();
            string sql = $"select * from Auth where id={id}  ";
            DataTable dt = DBhelper.DoQuery(sql, null);
            if (dt != null && dt.Rows.Count>0)
            {
                DataRow dr = dt.Rows[0];
                user.id = int.Parse(dr["id"].ToString());
                user.mark =int.Parse( dr["mark"].ToString());
            }else
            {
                user = null;
            }
            return user;
        }

        public DataTable SelectAll()
        {
            string sql = $"select * from Auth";
            DataTable dt = DBhelper.DoQuery(sql, null);
            return dt;
        }
        public void Update(Auth auth)
        {
            string sql = "update Auth set mark=@auth where id=@id";
            SQLiteParameter[] sQLiteParameter =
            {
                new SQLiteParameter("@id",DbType.Int32),
                //new SQLiteParameter("@pwd",DbType.String),
                new SQLiteParameter("@auth",DbType.Int32)
            };
            sQLiteParameter[0].Value = auth.id;
            //sQLiteParameter[1].Value = user.pwd;
            sQLiteParameter[1].Value = auth.mark;
            DBhelper.DoScalar(sql, sQLiteParameter);
        }
    }


    public class UserMode
    {
        public User user { get;set; }
        public UserMode(User item) 
        {
            user=item;
        }
       public void Add(User user)
        {
            string sql = "insert into User Values(null,@name,@pwd,@auth)";
            SQLiteParameter[] sQLiteParameter =
            {
                new SQLiteParameter("@name",DbType.String),
                new SQLiteParameter("@pwd",DbType.String),
                new SQLiteParameter("@auth",DbType.Int32)
            };
            sQLiteParameter[0].Value = user.name;
            sQLiteParameter[1].Value = user.pwd;
            sQLiteParameter[2].Value = user.auth;
            DBhelper.DoScalar(sql,sQLiteParameter);
        }
        public User SelectOne(string name) 
        {
            User user = new User();
            string sql = $"select * from User where name='{name}'";
            DataTable dt=DBhelper.DoQuery(sql,null);
            if(dt != null)
            {
                DataRow dr = dt.Rows[0];
                user.name = dr["name"].ToString();
                user.pwd = dr["pwd"].ToString();
                user.auth = int.Parse(dr["auth"].ToString());
            }else
            {
                user = null;
            }
            return user;
        }
        public DataTable SelectAll()
        {
            string sql = $"select * from User";
            DataTable dt = DBhelper.DoQuery(sql, null);
            return dt;
        }

        public void Update(User user)
        {
            string sql = "update User set auth=@auth where name=@name";
            SQLiteParameter[] sQLiteParameter =
            {
                new SQLiteParameter("@name",DbType.String),
                //new SQLiteParameter("@pwd",DbType.String),
                new SQLiteParameter("@auth",DbType.Int32)
            };
            sQLiteParameter[0].Value = user.name;
            //sQLiteParameter[1].Value = user.pwd;
            sQLiteParameter[1].Value = user.auth;
            DBhelper.DoScalar(sql, sQLiteParameter);
        }

        public void Delete(User user) 
        {
            string sql = "delete from User where name=@name";
            SQLiteParameter[] sQLiteParameter =
            {
                new SQLiteParameter("@name",DbType.String),
                //new SQLiteParameter("@pwd",DbType.String),
                //new SQLiteParameter("@auth",DbType.Int32)
            };
            sQLiteParameter[0].Value = user.name;
            DBhelper.DoScalar(sql, sQLiteParameter);
        }

    }
}
