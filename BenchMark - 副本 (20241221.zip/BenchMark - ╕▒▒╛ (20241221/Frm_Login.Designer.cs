﻿namespace AutoPressBrakeMachine
{
    partial class Frm_Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            AnimatorNS.Animation animation1 = new AnimatorNS.Animation();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm_Login));
            this.Animator = new AnimatorNS.Animator(this.components);
            this.XR_Container = new XRails.Controls.XRails_Container();
            this.XR_RightPanel = new XRails.Controls.XRails_Panel();
            this.xRails_Button1 = new XRails.Controls.XRails_Button();
            this.XR_Button_Login = new XRails.Controls.XRails_Button();
            this.xRails_TitleLabel1 = new XRails.Controls.XRails_TitleLabel();
            this.XR_TitleLabel_Welcome = new XRails.Controls.XRails_TitleLabel();
            this.XR_Label_LoggingIn = new XRails.Controls.XRails_Label();
            this.text_pass = new XRails.Controls.XRails_TextBox();
            this.text_user = new XRails.Controls.XRails_TextBox();
            this.XR_LinkLabel_Email = new XRails.Controls.XRails_LinkLabel();
            this.XR_Label_Contact = new XRails.Controls.XRails_Label();
            this.XR_Label_Support = new XRails.Controls.XRails_Label();
            this.XR_LeftPanel = new XRails.Controls.XRails_Panel();
            this.PB_Logo = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.XR_Container.SuspendLayout();
            this.XR_RightPanel.SuspendLayout();
            this.XR_LeftPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PB_Logo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // Animator
            // 
            this.Animator.AnimationType = AnimatorNS.AnimationType.Custom;
            this.Animator.Cursor = null;
            animation1.AnimateOnlyDifferences = true;
            animation1.BlindCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.BlindCoeff")));
            animation1.LeafCoeff = 0F;
            animation1.MaxTime = 1F;
            animation1.MinTime = 0F;
            animation1.MosaicCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.MosaicCoeff")));
            animation1.MosaicShift = ((System.Drawing.PointF)(resources.GetObject("animation1.MosaicShift")));
            animation1.MosaicSize = 0;
            animation1.Padding = new System.Windows.Forms.Padding(0);
            animation1.RotateCoeff = 0F;
            animation1.RotateLimit = 0F;
            animation1.ScaleCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.ScaleCoeff")));
            animation1.SlideCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.SlideCoeff")));
            animation1.TimeCoeff = 0F;
            animation1.TransparencyCoeff = 0F;
            this.Animator.DefaultAnimation = animation1;
            // 
            // XR_Container
            // 
            this.XR_Container.Controls.Add(this.XR_RightPanel);
            this.XR_Container.Controls.Add(this.XR_LeftPanel);
            this.XR_Container.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.Animator.SetDecoration(this.XR_Container, AnimatorNS.DecorationType.None);
            this.XR_Container.Dock = System.Windows.Forms.DockStyle.Fill;
            this.XR_Container.DrawIcon = false;
            this.XR_Container.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.XR_Container.Location = new System.Drawing.Point(0, 0);
            this.XR_Container.MinimumSize = new System.Drawing.Size(100, 39);
            this.XR_Container.Name = "XR_Container";
            this.XR_Container.Padding = new System.Windows.Forms.Padding(0, 29, 0, 0);
            this.XR_Container.Size = new System.Drawing.Size(705, 475);
            this.XR_Container.TabIndex = 0;
            this.XR_Container.Text = "登录";
            this.XR_Container.TextAlignment = XRails.Controls.XRails_Container.Alignment.Left;
            this.XR_Container.TitleBarTextColor = System.Drawing.Color.Gainsboro;
            // 
            // XR_RightPanel
            // 
            this.XR_RightPanel.Controls.Add(this.xRails_Button1);
            this.XR_RightPanel.Controls.Add(this.XR_Button_Login);
            this.XR_RightPanel.Controls.Add(this.xRails_TitleLabel1);
            this.XR_RightPanel.Controls.Add(this.XR_TitleLabel_Welcome);
            this.XR_RightPanel.Controls.Add(this.XR_Label_LoggingIn);
            this.XR_RightPanel.Controls.Add(this.text_pass);
            this.XR_RightPanel.Controls.Add(this.text_user);
            this.XR_RightPanel.Controls.Add(this.XR_LinkLabel_Email);
            this.XR_RightPanel.Controls.Add(this.XR_Label_Contact);
            this.XR_RightPanel.Controls.Add(this.XR_Label_Support);
            this.XR_RightPanel.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.Animator.SetDecoration(this.XR_RightPanel, AnimatorNS.DecorationType.None);
            this.XR_RightPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.XR_RightPanel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.XR_RightPanel.LeftSideColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(93)))), ((int)(((byte)(89)))));
            this.XR_RightPanel.Location = new System.Drawing.Point(350, 29);
            this.XR_RightPanel.Name = "XR_RightPanel";
            this.XR_RightPanel.RightSideColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(44)))), ((int)(((byte)(61)))));
            this.XR_RightPanel.Side = XRails.Controls.XRails_Panel.PanelSide.Right;
            this.XR_RightPanel.Size = new System.Drawing.Size(355, 446);
            this.XR_RightPanel.TabIndex = 2;
            // 
            // xRails_Button1
            // 
            this.xRails_Button1.BackColor = System.Drawing.Color.Transparent;
            this.Animator.SetDecoration(this.xRails_Button1, AnimatorNS.DecorationType.None);
            this.xRails_Button1.DialogResult = System.Windows.Forms.DialogResult.No;
            this.xRails_Button1.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.xRails_Button1.Location = new System.Drawing.Point(255, 324);
            this.xRails_Button1.MinimumSize = new System.Drawing.Size(60, 43);
            this.xRails_Button1.Name = "xRails_Button1";
            this.xRails_Button1.Radius = 20;
            this.xRails_Button1.Size = new System.Drawing.Size(77, 43);
            this.xRails_Button1.TabIndex = 4;
            this.xRails_Button1.Text = "关闭";
            this.xRails_Button1.Click += new System.EventHandler(this.xRails_Button1_Click);
            // 
            // XR_Button_Login
            // 
            this.XR_Button_Login.BackColor = System.Drawing.Color.Transparent;
            this.Animator.SetDecoration(this.XR_Button_Login, AnimatorNS.DecorationType.None);
            this.XR_Button_Login.DialogResult = System.Windows.Forms.DialogResult.None;
            this.XR_Button_Login.Enabled = false;
            this.XR_Button_Login.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.XR_Button_Login.Location = new System.Drawing.Point(3, 284);
            this.XR_Button_Login.MinimumSize = new System.Drawing.Size(144, 43);
            this.XR_Button_Login.Name = "XR_Button_Login";
            this.XR_Button_Login.Radius = 20;
            this.XR_Button_Login.Size = new System.Drawing.Size(144, 43);
            this.XR_Button_Login.TabIndex = 3;
            this.XR_Button_Login.Text = "登录";
            this.XR_Button_Login.Click += new System.EventHandler(this.XR_Button_Login_Click);
            // 
            // xRails_TitleLabel1
            // 
            this.xRails_TitleLabel1.AutoSize = true;
            this.xRails_TitleLabel1.BackColor = System.Drawing.Color.Transparent;
            this.xRails_TitleLabel1.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.Animator.SetDecoration(this.xRails_TitleLabel1, AnimatorNS.DecorationType.None);
            this.xRails_TitleLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F);
            this.xRails_TitleLabel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.xRails_TitleLabel1.Location = new System.Drawing.Point(237, 100);
            this.xRails_TitleLabel1.Name = "xRails_TitleLabel1";
            this.xRails_TitleLabel1.Side = XRails.Controls.XRails_TitleLabel.PanelSide.RightPanel;
            this.xRails_TitleLabel1.Size = new System.Drawing.Size(110, 40);
            this.xRails_TitleLabel1.TabIndex = 7;
            this.xRails_TitleLabel1.Text = "欢迎您";
            this.xRails_TitleLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.xRails_TitleLabel1.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.xRails_TitleLabel1.UseCompatibleTextRendering = true;
            // 
            // XR_TitleLabel_Welcome
            // 
            this.XR_TitleLabel_Welcome.AutoSize = true;
            this.XR_TitleLabel_Welcome.BackColor = System.Drawing.Color.Transparent;
            this.XR_TitleLabel_Welcome.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.Animator.SetDecoration(this.XR_TitleLabel_Welcome, AnimatorNS.DecorationType.None);
            this.XR_TitleLabel_Welcome.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F);
            this.XR_TitleLabel_Welcome.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(171)))), ((int)(((byte)(176)))));
            this.XR_TitleLabel_Welcome.Location = new System.Drawing.Point(3, 10);
            this.XR_TitleLabel_Welcome.Name = "XR_TitleLabel_Welcome";
            this.XR_TitleLabel_Welcome.Side = XRails.Controls.XRails_TitleLabel.PanelSide.RightPanel;
            this.XR_TitleLabel_Welcome.Size = new System.Drawing.Size(326, 74);
            this.XR_TitleLabel_Welcome.TabIndex = 7;
            this.XR_TitleLabel_Welcome.Text = "深圳市立创达自动化\r\n设备有限公司";
            this.XR_TitleLabel_Welcome.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.XR_TitleLabel_Welcome.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.XR_TitleLabel_Welcome.UseCompatibleTextRendering = true;
            // 
            // XR_Label_LoggingIn
            // 
            this.XR_Label_LoggingIn.BackColor = System.Drawing.Color.Transparent;
            this.XR_Label_LoggingIn.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.Animator.SetDecoration(this.XR_Label_LoggingIn, AnimatorNS.DecorationType.None);
            this.XR_Label_LoggingIn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.XR_Label_LoggingIn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(114)))), ((int)(((byte)(118)))), ((int)(((byte)(127)))));
            this.XR_Label_LoggingIn.Image = ((System.Drawing.Image)(resources.GetObject("XR_Label_LoggingIn.Image")));
            this.XR_Label_LoggingIn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.XR_Label_LoggingIn.Location = new System.Drawing.Point(17, 304);
            this.XR_Label_LoggingIn.Name = "XR_Label_LoggingIn";
            this.XR_Label_LoggingIn.Size = new System.Drawing.Size(96, 20);
            this.XR_Label_LoggingIn.TabIndex = 8;
            this.XR_Label_LoggingIn.Text = "Logging in...";
            this.XR_Label_LoggingIn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.XR_Label_LoggingIn.Visible = false;
            // 
            // text_pass
            // 
            this.text_pass.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(48)))), ((int)(((byte)(67)))));
            this.text_pass.ColorBordersOnEnter = true;
            this.Animator.SetDecoration(this.text_pass, AnimatorNS.DecorationType.None);
            this.text_pass.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.text_pass.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(131)))), ((int)(((byte)(140)))));
            this.text_pass.Image = ((System.Drawing.Image)(resources.GetObject("text_pass.Image")));
            this.text_pass.Location = new System.Drawing.Point(0, 228);
            this.text_pass.MaxLength = 30;
            this.text_pass.Multiline = false;
            this.text_pass.Name = "text_pass";
            this.text_pass.ReadOnly = false;
            this.text_pass.ShortcutsEnabled = true;
            this.text_pass.ShowBottomBorder = true;
            this.text_pass.ShowTopBorder = false;
            this.text_pass.Size = new System.Drawing.Size(350, 50);
            this.text_pass.TabIndex = 2;
            this.text_pass.TextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.text_pass.UseSystemPasswordChar = true;
            this.text_pass.Watermark = "密码";
            this.text_pass.WatermarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(120)))), ((int)(((byte)(129)))));
            this.text_pass.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.text_user_KeyPress);
            // 
            // text_user
            // 
            this.text_user.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(48)))), ((int)(((byte)(67)))));
            this.text_user.ColorBordersOnEnter = true;
            this.Animator.SetDecoration(this.text_user, AnimatorNS.DecorationType.None);
            this.text_user.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.text_user.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(131)))), ((int)(((byte)(140)))));
            this.text_user.Image = ((System.Drawing.Image)(resources.GetObject("text_user.Image")));
            this.text_user.Location = new System.Drawing.Point(0, 182);
            this.text_user.MaxLength = 64;
            this.text_user.Multiline = false;
            this.text_user.Name = "text_user";
            this.text_user.ReadOnly = false;
            this.text_user.ShortcutsEnabled = true;
            this.text_user.ShowBottomBorder = false;
            this.text_user.ShowTopBorder = true;
            this.text_user.Size = new System.Drawing.Size(350, 50);
            this.text_user.TabIndex = 1;
            this.text_user.TextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.text_user.UseSystemPasswordChar = false;
            this.text_user.Watermark = "用户名";
            this.text_user.WatermarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(120)))), ((int)(((byte)(129)))));
            this.text_user.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.text_user_KeyPress);
            // 
            // XR_LinkLabel_Email
            // 
            this.XR_LinkLabel_Email.ActiveLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(89)))), ((int)(((byte)(84)))));
            this.XR_LinkLabel_Email.AutoSize = true;
            this.XR_LinkLabel_Email.BackColor = System.Drawing.Color.Transparent;
            this.XR_LinkLabel_Email.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.Animator.SetDecoration(this.XR_LinkLabel_Email, AnimatorNS.DecorationType.None);
            this.XR_LinkLabel_Email.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.XR_LinkLabel_Email.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.XR_LinkLabel_Email.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(93)))), ((int)(((byte)(89)))));
            this.XR_LinkLabel_Email.Location = new System.Drawing.Point(239, 422);
            this.XR_LinkLabel_Email.Name = "XR_LinkLabel_Email";
            this.XR_LinkLabel_Email.Size = new System.Drawing.Size(108, 15);
            this.XR_LinkLabel_Email.TabIndex = 4;
            this.XR_LinkLabel_Email.TabStop = true;
            this.XR_LinkLabel_Email.Text = "david@smtgd.com";
            this.XR_LinkLabel_Email.Visible = false;
            this.XR_LinkLabel_Email.VisitedLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(89)))), ((int)(((byte)(84)))));
            // 
            // XR_Label_Contact
            // 
            this.XR_Label_Contact.AutoSize = true;
            this.XR_Label_Contact.BackColor = System.Drawing.Color.Transparent;
            this.XR_Label_Contact.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.Animator.SetDecoration(this.XR_Label_Contact, AnimatorNS.DecorationType.None);
            this.XR_Label_Contact.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.XR_Label_Contact.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(114)))), ((int)(((byte)(118)))), ((int)(((byte)(127)))));
            this.XR_Label_Contact.Location = new System.Drawing.Point(42, 393);
            this.XR_Label_Contact.Name = "XR_Label_Contact";
            this.XR_Label_Contact.Size = new System.Drawing.Size(314, 15);
            this.XR_Label_Contact.TabIndex = 3;
            this.XR_Label_Contact.Text = "COPYRIGHT 2018 © 深圳市立创达自动化设备有限公司 \r\n";
            this.XR_Label_Contact.Visible = false;
            // 
            // XR_Label_Support
            // 
            this.XR_Label_Support.AutoSize = true;
            this.XR_Label_Support.BackColor = System.Drawing.Color.Transparent;
            this.XR_Label_Support.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.Animator.SetDecoration(this.XR_Label_Support, AnimatorNS.DecorationType.None);
            this.XR_Label_Support.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.XR_Label_Support.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(114)))), ((int)(((byte)(118)))), ((int)(((byte)(127)))));
            this.XR_Label_Support.Location = new System.Drawing.Point(42, 375);
            this.XR_Label_Support.Name = "XR_Label_Support";
            this.XR_Label_Support.Size = new System.Drawing.Size(50, 15);
            this.XR_Label_Support.TabIndex = 2;
            this.XR_Label_Support.Text = "Support";
            this.XR_Label_Support.Visible = false;
            // 
            // XR_LeftPanel
            // 
            this.XR_LeftPanel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("XR_LeftPanel.BackgroundImage")));
            this.XR_LeftPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.XR_LeftPanel.Controls.Add(this.PB_Logo);
            this.XR_LeftPanel.Controls.Add(this.pictureBox1);
            this.XR_LeftPanel.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.Animator.SetDecoration(this.XR_LeftPanel, AnimatorNS.DecorationType.None);
            this.XR_LeftPanel.Dock = System.Windows.Forms.DockStyle.Left;
            this.XR_LeftPanel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.XR_LeftPanel.LeftSideColor = System.Drawing.Color.Gainsboro;
            this.XR_LeftPanel.Location = new System.Drawing.Point(0, 29);
            this.XR_LeftPanel.Name = "XR_LeftPanel";
            this.XR_LeftPanel.RightSideColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(44)))), ((int)(((byte)(61)))));
            this.XR_LeftPanel.Side = XRails.Controls.XRails_Panel.PanelSide.Left;
            this.XR_LeftPanel.Size = new System.Drawing.Size(350, 446);
            this.XR_LeftPanel.TabIndex = 1;
            // 
            // PB_Logo
            // 
            this.PB_Logo.BackColor = System.Drawing.Color.White;
            this.Animator.SetDecoration(this.PB_Logo, AnimatorNS.DecorationType.None);
            this.PB_Logo.Dock = System.Windows.Forms.DockStyle.Top;
            this.PB_Logo.Image = ((System.Drawing.Image)(resources.GetObject("PB_Logo.Image")));
            this.PB_Logo.Location = new System.Drawing.Point(0, 0);
            this.PB_Logo.Name = "PB_Logo";
            this.PB_Logo.Size = new System.Drawing.Size(350, 99);
            this.PB_Logo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.PB_Logo.TabIndex = 0;
            this.PB_Logo.TabStop = false;
            // 
            // pictureBox1
            // 
            this.Animator.SetDecoration(this.pictureBox1, AnimatorNS.DecorationType.None);
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 293);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(344, 142);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // Frm_Login
            // 
            this.AcceptButton = this.XR_Button_Login;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(705, 475);
            this.Controls.Add(this.XR_Container);
            this.Animator.SetDecoration(this, AnimatorNS.DecorationType.None);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.MaximumSize = new System.Drawing.Size(1920, 1040);
            this.Name = "Frm_Login";
            this.Opacity = 0.1D;
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "XRails Login";
            this.TransparencyKey = System.Drawing.Color.Fuchsia;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Frm_Login_FormClosing);
            this.Shown += new System.EventHandler(this.Frm_Login_Shown);
            this.Enter += new System.EventHandler(this.XR_Button_Login_Click);
            this.XR_Container.ResumeLayout(false);
            this.XR_RightPanel.ResumeLayout(false);
            this.XR_RightPanel.PerformLayout();
            this.XR_LeftPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.PB_Logo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private XRails.Controls.XRails_Container XR_Container;
        private XRails.Controls.XRails_Panel XR_LeftPanel;
        private XRails.Controls.XRails_Panel XR_RightPanel;
        private System.Windows.Forms.PictureBox PB_Logo;
        private XRails.Controls.XRails_Button XR_Button_Login;
        private XRails.Controls.XRails_Label XR_Label_Support;
        private XRails.Controls.XRails_LinkLabel XR_LinkLabel_Email;
        private XRails.Controls.XRails_Label XR_Label_Contact;
        private XRails.Controls.XRails_TextBox text_user;
        private XRails.Controls.XRails_TextBox text_pass;
        private XRails.Controls.XRails_TitleLabel XR_TitleLabel_Welcome;
        private XRails.Controls.XRails_Label XR_Label_LoggingIn;
        private AnimatorNS.Animator Animator;
        private System.Windows.Forms.PictureBox pictureBox1;
        private XRails.Controls.XRails_Button xRails_Button1;
        private XRails.Controls.XRails_TitleLabel xRails_TitleLabel1;
    }
}

