﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.IO;
using System.Configuration;
using System.Runtime.InteropServices;
using System.Xml;
using Newtonsoft.Json;

namespace BenchMark
{
    public class ParamsManage
    {
        public DataConfig dataConfig;
        public PostionParam posParamReal;
        public string data;
       
    }
    public class PostionParam
    {
        public Postion realPos;
        public Postion prevPos;
    }
    public class ProjectData
    {
        public int index = 0;
        public List<ProjectBase> projectBases ;
        public ProjectData()
        {
            projectBases = new List<ProjectBase>();
        }

    }
    public class ProjectBase
    {
        public Projecter item;
        public Postion pos_2d;
        public Postion pos_3d1;
        public Postion pos_3d2;
        public Postion pos_mark1;
        public Postion pos_mark2;

    }
    public class Role
    {
        public string name;
        public Enm_Auth auth;
    }
    public class Productdatas
    {
        //public int id;
        public string sn;
        public string result;
        public double length;
        public double width;
        public double height;
        public double total_s;
        public double dj_cc;
        public double all_cc;
        public int dj_num;
        public string mark;
    }
    public class DataConfig
    {
        public bool isSip=false;
        public bool isSmt=false;
        public bool isBuzing=false;
        public int buz_delyTime1 = 0;
        public int buz_delyTime2 = 0;
        public int run_num = 0;
        public double d3_val = 5;
        public double d3_distence = 90000;
        public  double office_3d1_x = -47.294;
        public  double office_3d1_y = -46.715;
        //public static double office_3d1_z = 0;
        public  double office_3d2_x = 57.917;
        public  double office_3d2_y = 56.476;
        //public static double office_3d2_z = 0;
        public int delyTime = 2000;
        public AxleParams alexParams;
        public Data paramPostion = new Data();
        public OtherParam other = new OtherParam();
        public ProjectData pro=new ProjectData();
        public DataConfig()
        {
        }
    }

    public class Projecter
    {
        public string Name { get; set; }
        public bool IsMarked { get; set; }=false;
        public bool IsRight_g { get; set; } = true;
        public bool IsReadBard { get; set; }=false;
        public int Signal_in { get; set; } = 0;
        public int Signal_in_delyTime { get; set; }
        public int Signal_put { get; set; }
        public int Signal_put_delyTime { get; set; }
        public int Signal_out { get; set; }
        public int Signal_out_delyTime { get; set; }
        public int Gpu_type { get; set; }
        public int Block_Air { get; set; }
        public int Jack_Air { get; set; }
        public int Jack_Air2 { get; set; }

        public int Befor_get { get; set; }
        public int After_get { get; set; }
        public int Pos_2d { get; set; }
        public int Pos_3d1 { get; set; }
        public int Pos_3d2 { get; set; }
        public int Pos_mark1 { get; set; }
        public int Pos_mark2 { get; set; }
        public double Length_3d { get; set; } = 90;
        public double Dis_g { get; set; } = 10;
        public double Speed_3d { get; set; } = 10;

        public string Bard_ip { get; set; }
    }
    public  class FileDeal
    {
        public static DataConfig dataConfig=new DataConfig();
        public static string inipath= Global.exePath + "\\cfg\\" + ConfigurationManager.AppSettings["inipath"];
        //public FileDeal()
        //{
        //    inipath = Global.exePath+"\\" + ConfigurationManager.AppSettings["inipath"];
        //    //inipath = dataConfig.other.exePath+inipath;
        //}
        [DllImport("kernel32", CharSet = CharSet.Unicode)]
        public static extern long WritePrivateProfileString(string section, string key, string val, string filePath);
        [DllImport("kernel32", CharSet = CharSet.Unicode)]
        public static extern int GetPrivateProfileString(string section, string key, string def, StringBuilder retVal, int size, string filePath);

        public static void FileWrite(DataConfig dataConfig,string path)
        {
            try
            {
                if (!Directory.Exists(Path.GetDirectoryName(path)))
                {
                    Directory.CreateDirectory(Path.GetDirectoryName(path));
                }
                if (Directory.Exists(Path.GetDirectoryName(path)) && dataConfig!=null)
                {
                    string json = JsonConvert.SerializeObject(dataConfig, Newtonsoft.Json.Formatting.Indented);
                    File.WriteAllText(path, json);
                } 
            }catch(Exception e)
            {

            }
            
        }
        public static DataConfig FileRead(string filePath) 
        {
            DataConfig dataConfig=null;
            try
            {
                if (Directory.Exists(Path.GetDirectoryName(filePath)))
                {
                    string jsonContent = File.ReadAllText(filePath);
                    dataConfig = JsonConvert.DeserializeObject<DataConfig>(jsonContent);
                }
                
            }catch(Exception ex)
            {
                dataConfig=null;
            }
            return dataConfig;
        }
        public static DataConfig LoadFile()
        {
            dataConfig=FileRead(inipath);
            return dataConfig;
        }
        public static void SaveFile(DataConfig dataConfigs)
        {
            FileWrite(dataConfigs, inipath);
        }
    }
}
