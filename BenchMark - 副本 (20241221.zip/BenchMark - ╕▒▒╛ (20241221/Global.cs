﻿using BenchMark.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BenchMark
{
    public class Global
    {
        public static int IsOpenFrist = 0;
        public static Dictionary<int, int> DicAuth = new Dictionary<int, int>();
        public static Dictionary<int, string> Dicdi = new Dictionary<int, string>();
        public static Dictionary<int, string> Dicdo = new Dictionary<int, string>();
        public static Dictionary<int, string> Dicpos = new Dictionary<int, string>();
        public static Dictionary<int, string> DicAlarms = new Dictionary<int, string>();
        //public static string MainPath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
        public static string exePath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);


        public static string bardStr = "";
        public static EquipStatus eqStatus = EquipStatus.stop;
        public static int Currentnum = -1;
        public static int Currentnumold = 0;
        public static int ledchange = 0;
        public static Enm_LED ledsta;
        public static EquipStatus axisSts;
        public static bool isZh = true;
        public static bool isBuzzering = false;
        public static bool isShipMark = false;
        public static bool[] isrun = new bool[3] {true,true,true};
        public static bool[] tcpConnRet = new bool[3] { false, false, false };
        public static string[] tcpConnRetmsg = new string[3];
        public static double officepos = 50;
        public static int sts_axisstopSts = 512;//轴返回状态,使能后正常为512
        public static int sts_axisrunSts1 = 1536;//轴返回状态,使能后正常为512
        public static int sts_axisrunSts2 = 1600;//轴返回状态,使能后正常为512
        public static int sts_axisrunStsNoPower = 0;//轴返回状态,使能后正常为512


        //public static double office_3d1_x = -47.294;
        //public static double office_3d1_y = -46.715;
        //public static double office_3d1_z = 0;
        //public static double office_3d2_x = 57.917;
        //public static double office_3d2_y = 56.476;
        //public static double office_3d2_z = 0;


        [DllImport("winmm")]
        public static extern uint timeGetTime();
        [DllImport("winmm")]
        public static extern void timeBeginPeriod(int t);
        [DllImport("winmm")]
        public static extern void timeEndPeriod(int t);

        public static Dictionary<int, string> LodPosIni(string path)
        {
            Dictionary<int, string> Dicpos=new Dictionary<int, string>();
            if (File.Exists(path))
            {
                var datas = File.ReadAllLines(path);
                foreach (var item in datas)
                {
                    var line = item.Trim();
                    if (!string.IsNullOrEmpty(line) && line.Contains("="))
                    {
                        var fir = line.Split('=');
                        if (int.TryParse(fir[0], out int no))
                        {
                            if (!Dicpos.ContainsKey(no))
                                Dicpos.Add(no, fir[1]);
                        }
                    }
                }
            }
            return Dicpos;
        }
        public static List<string> ToList(Dictionary<int, string> item)
        {
            var list = new List<string>();
            foreach (var item2 in item)
            {
                list.Add(item2.Value);
            }
            return list;
        }

        public static Dictionary<int ,int> LodAuth()
        {
            Dictionary<int, int> dic= new Dictionary<int ,int>();   
            AuthMode mode=new AuthMode();
            DataTable dt= mode.SelectAll();
            if(dt!=null && dt.Rows.Count>0 )
            {
                foreach (DataRow dr in dt.Rows)
                {
                   dic.Add(int.Parse(dr["id"].ToString()),int.Parse(dr["mark"].ToString()));
                }
            }
            return dic;
        }
        public static void ControlInvocke(Control contrl, Action act)
        {
            // DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            if (contrl.InvokeRequired)
            {
                contrl.Invoke(act);
            }
            else
            {
                act();
            }
        }
        //public static string DiPath = exePath + "\\cfg\\di.ini";
        //public static string DoPath = exePath + "\\cfg\\do.ini";
        //public static string PosPath = exePath + "\\cfg\\pos.ini";
        //public static string TimeDelyPath = exePath + "\\cfg\\delyTime.ini";
        public static string DiPath
        {
            get
            {
                string temp = isZh ? "" : "-en-US";
                return exePath + $"\\cfg\\di{temp}.ini";
            }
        }
        public static string DoPath
        {
            get
            {
                string temp = isZh ? "" : "-en-US";
                return exePath + $"\\cfg\\do{temp}.ini";
            }
        }
        public static string PosPath
        {
            get
            {
                string temp = isZh ? "" : "-en-US";
                return exePath + $"\\cfg\\pos{temp}.ini";
            }
        }
        public static string AlarmPath {
            get {
                string temp = isZh ? "" : "-en-US";
                return exePath + $"\\cfg\\alarm{temp}.ini"; 
            }
        }
        public static string TimeDelyPath
        {
            get
            {
                string temp = isZh ? "" : "-en-US";
                return exePath + $"\\cfg\\delyTime{temp}.ini";
            }
        }
        public static string ConnectionString
        { 
            get
            {
                return $"Data Source ={exePath}\\cfg\\"+ ConfigurationManager.AppSettings["dbfile"];
            }
        }
        public static void LoadLanguage(Form form, Type formType)
        {
            if (form != null)
            {
                ComponentResourceManager resources = new ComponentResourceManager(formType);
                resources.ApplyResources(form, "$this");
                Loading(form, resources);
            }
        }
        private static void Loading(Control control, ComponentResourceManager resources)
        {
            if (control is MenuStrip)
            {
                MenuStrip ts = (MenuStrip)control;
                //if (ts.Items.Count > 0 && ts.Items.Count==2)
                {
                        //List<ToolStripMenuItem> ls= ts.Items.Cast<ToolStripItem>().Any(item => item is ToolStripMenuItem);
                        //resources.ApplyResources(ts.Items[0].Text, "Setting");
                        ////if (ts.Items[0].)
                        //    resources.ApplyResources(ts.Items[1].Text, "UserSetting"); 
                }
            }
            foreach (Control c in control.Controls)
            {
                resources.ApplyResources(c, c.Name);
                if (c.Controls != null)
                {
                    Loading(c, resources);
                }
            }
        }
        public static void Changed()
        {
            if (Global.isZh)
            {
                Global.isZh = false;
                Global.SaveConfig("lanuage", "EN");
            }
            else
            {
                Global.isZh = true;
                Global.SaveConfig("lanuage", "ZH");
            }
        }
        public static void SaveConfig(string key ,string val)
        {
            string configPath = AppDomain.CurrentDomain.SetupInformation.ConfigurationFile;

            // 加载配置文件
            ExeConfigurationFileMap fileMap = new ExeConfigurationFileMap { ExeConfigFilename = configPath };
            Configuration config = ConfigurationManager.OpenMappedExeConfiguration(fileMap, ConfigurationUserLevel.None);

            // 检查该配置项是否存在，如果存在则修改它，否则添加它
            if (config.AppSettings.Settings[key] != null)
            {
                config.AppSettings.Settings[key].Value = val;
            }
            else
            {
                config.AppSettings.Settings.Add(key, val);
            }

            // 保存修改后的配置文件
            config.Save(ConfigurationSaveMode.Modified);

            // 强制重新加载配置节以反映更改（可选）
            ConfigurationManager.RefreshSection("appSettings");
        }
    }
    public enum EquipStatus
    {
        reset = 0,
        run = 1,
        init = 2,
        free=3,
        pause=4,
        stop= 5,
         alarm=6
    }
    public enum Enm_Auth
    {
        staff = 0,
        projecter=1,
        administerator=2
    }
    public enum Enm_Axis
    {
        run=0,
        stop=1,
        alnormal=2,
        nopower=3
    }
    public enum Enm_Run
    {
        D2 = 0,
        D31 = 1,
        D32 = 2
    }
    public enum Enm_LED
    {
        red = 0,
        yellow = 1,
        green = 2
    }
    public enum Enm_TimeSet
    {
        jackbefordelyTime=0,
    }

    /// <summary>
    /// 样机di信号
    /// </summary>
    //public enum Enm_Di
    //{
    //    start = 0,
    //    stop = 1,
    //    reset = 2,
    //    forceStop = 3,//急停
    //    door = 4,
    //    dibak1 = 5,
    //    Input = 6,
    //    runpos = 7,
    //    output = 8,
    //    blockHomePos = 9,
    //    blockRunPos = 10,
    //    jackHomePos = 11,
    //    jackRunPos = 12,
    //    beforInput = 13,
    //    beforInputNg = 14,
    //    afterOutput = 15
    //}

    //发货机di信号
    public enum Enm_Di
    {
        //start = 0,
        //stop = 1,
        //reset = 2,
        forceStop = 0,//急停
        bakDi0 = 1,
        bakDi1 = 2,
        bakDi2 = 3,
        light = 4,
        door = 5,
        left = 6,
        leftBlockLeft = 7,
        leftBlockRightSignal = 8,
        rightBlockLeftSignal = 9,
        rightBlockRight = 10,
        right = 11,
        bakDi3 = 12,
        beforInput = 13,
        beforInputNg = 14,
        afterOutput = 15
    }
    public enum Enm_Do
    {
        dobak = 0,
        dobak1 = 1,
        leftBlockAir = 2,     //阻挡气缸
        jackAirDown = 3,      //顶升气缸
        jackAirTop = 4,      //顶升气缸
        rightBlockAir = 5,
        dobak3 = 6,
        dobak4 = 7,
        lighting = 8,
        beforquest = 9,
        ownHaved = 10,
        ownHavedNg = 11,
        redLight = 12,
        yellowLight = 13,
        greenLight = 14,
        buzzer = 15 //蜂鸣器
    }
    //public enum Enm_Do
    //{
    //    transport = 0,
    //    transportDirection = 1,
    //    blockAir = 2,     //阻挡气缸
    //    jackAir = 3,      //顶升气缸
    //    d3Control = 4,
    //    dobak2 = 5,
    //    dobak3 = 6,
    //    dobak4 = 7,
    //    lighting = 8,
    //    beforquest = 9,
    //    ownHaved = 10,
    //    ownHavedNg = 11,
    //    redLight = 12,
    //    yellowLight = 13,
    //    greenLight = 14,
    //    buzzer = 15 //蜂鸣器
    //}
}
