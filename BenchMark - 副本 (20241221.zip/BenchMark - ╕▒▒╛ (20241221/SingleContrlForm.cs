﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static gts.mc;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace BenchMark
{
    public partial class SingleContrlForm : Form
    {
        short axis;
        TJogPrm jog;
        TTrapPrm trapPrm;
        
        double val;
        int pos,tempos;
        uint clk;//时钟参数
        int status, pvalue;
        double vel, prfvel, encvel, prfpos, encpos;//运动状态参数
        public SingleContrlForm()
        {
            InitializeComponent();
        }
        public short GetCardId()
        {
            return Convert.ToInt16(cardId.SelectedIndex + 1);
        }
        private void SingleContrlForm_Load(object sender, EventArgs e)
        {
            gts.mc.GT_Open(0, 1);
            cardId.SelectedIndex = 0;
            jog.acc = 0.1;
            jog.dec = 0.1;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            bool ret=Axis.DoPower(axis, !Axis.en[axis - 1]);
            if (!ret)
            {
                //gts.mc.GT_AxisOn(axis);//上伺服
                this.btn_power.Text = "伺服关闭";
            }else
            {
                //gts.mc.GT_AxisOff(axis);//下伺服
                this.btn_power.Text = "伺服使能";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Axis.GoHome(axis);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Axis.Stop(axis);
        }

        private void cardId_SelectedIndexChanged(object sender, EventArgs e)
        {
            axis = GetCardId();
        }

        private void button4_MouseDown(object sender, MouseEventArgs e)
        {
            val=Convert.ToDouble(txt_val.Text);
            Axis.DoJog(axis, val, jog, false);
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void button7_MouseDown(object sender, MouseEventArgs e)
        {
            val = Convert.ToDouble(txt_val.Text);
            Axis.DoJog(4, val, jog, false);
        }

        private void button8_MouseDown(object sender, MouseEventArgs e)
        {
            val = Convert.ToDouble(txt_val.Text);
            Axis.DoJog(4, val, jog, true);
        }

        private void button8_MouseUp(object sender, MouseEventArgs e)
        {
            Axis.Stop(4);
        }

        private void button7_MouseUp(object sender, MouseEventArgs e)
        {
            Axis.Stop(4);
        }

        private void button9_Click(object sender, EventArgs e)
        {
            trapPrm.acc = 0.5;
            trapPrm.dec = 0.5;
            trapPrm.smoothTime = 0;
            trapPrm.velStart = 0;
            tempos = Convert.ToInt32(txt_posxyz.Text);
            val = Convert.ToDouble(txt_val.Text);
            Axis.DoTrap(axis, trapPrm, tempos, val, true);
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Axis.Open();
        }

        private void button5_MouseDown(object sender, MouseEventArgs e)
        {
            val = Convert.ToDouble(txt_val.Text);
            Axis.DoJog(axis, val, jog, true);
        }

        private void button5_MouseUp(object sender, MouseEventArgs e)
        {
            Axis.Stop(axis);
        }

        private void button4_MouseUp(object sender, MouseEventArgs e)
        {
            Axis.Stop(axis);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Axis.ClearAlarmAll();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            axis = GetCardId();
            if (!Axis.en[axis - 1])
            {
                //gts.mc.GT_AxisOn(axis);//上伺服
                this.btn_power.Text = "伺服关闭";
            }
            else
            {
                //gts.mc.GT_AxisOff(axis);//下伺服
                this.btn_power.Text = "伺服使能";
            }
            //if (Axis.GetBasePos(axis))
            //    Axis.ClearPos(axis);
            gts.mc.GT_GetPrfPos(axis, out prfpos, 1, out clk);
            this.txt_prfpos.Text = Math.Round(prfpos, 1).ToString();
            gts.mc.GT_GetPrfVel(axis, out prfvel, 1, out clk);
            this.txt_prfval.Text = Math.Round(prfvel, 1).ToString();
            gts.mc.GT_GetEncPos(axis, out encpos, 1, out clk);
            this.txt_enpos.Text = Math.Round(encpos, 1).ToString();
            //gts.mc.GT_GetEncVel(axis, out encvel, 1, out clk);
            //this.txt_enval.Text = Math.Round(encvel, 1).ToString();
            gts.mc.GT_GetSts(axis, out status, 1, out clk);
            this.txt_sta.Text = (status).ToString();
            //gts.mc.GT_GetPrfMode(axis, out pvalue, 1, out clk);
            //this.txt_mode.Text = (pvalue).ToString();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            trapPrm.acc = 0.5;
            trapPrm.dec = 0.5;
            trapPrm.smoothTime = 0;
            trapPrm.velStart = 0;
            tempos=Convert.ToInt32(txt_pos.Text);
            Axis.DoTrap(4, trapPrm, tempos, 10,true);
        }
    }
}
