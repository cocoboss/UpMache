﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
//using System.Security.Claims;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Windows.Forms;
using static BenchMark.ParamForm;
using static gts.mc_la;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;

namespace BenchMark
{
    public class MainThread
    {
        public TaskManager taskManager = new TaskManager();
        public ParamsManage datas= new ParamsManage();
        public User curUser = new User();
        public ClientConn client1;
        public ClientConn client2;
        public ClientConn client3;
        public ClientConn clientBard;
        public string bardStr = "";
        public uint timeinit;
        public uint time1;
        public uint time2;
        public uint time3;
        //public uint time4;
        private Thread mThread;
        private static MainThread instance=new MainThread();
        private static object objlock=new object();
        private static object logobjlock = new object();
        public int index=0;
        public int gpu_num=0;
        public int error_num=0;
        public Enm_Axis _Axis = Enm_Axis.nopower;
        Postion officePos,pos3D1officestart, pos3D1officeend, pos3D2officestart, pos3D2officeend;
        public Action<string> logHelper;
        public Action<Enm_Axis> axisStsUpdate;
        //public Action<EquipStatus> equipmentStsUpdate;
        public Action<Productdatas> dateFormUpdate;
        public Action<string> alarmsUpdate;
        public Action<EquipStatus> mainStsUpdate;
        public Action<User> Userlogin;

        public static ManualResetEvent btn_pro_event = new ManualResetEvent(false);

        private MainThread() 
        {
            
            taskManager.taskAction = DoworkIn;
            taskManager.taskAction1 = D2orD3BeforCheck;
            taskManager.taskAction2 = DoD2ConnAction1;
            taskManager.taskAction3 = DoD2MoveMarkPos1;
            taskManager.taskAction4 = DoD2MovePaiComplted1;
            taskManager.taskAction5 = DoD2ConnAction2;
            taskManager.taskAction6 = DoD2MoveMarkPos2;
            taskManager.taskAction7 = DoD2MovePaiComplted2;
            taskManager.taskAction8 = DoD2ConnAction;
            taskManager.taskAction9 = DoD2MoveMarkPos;
            taskManager.taskAction10 = DoD2MovePaiComplted;
            taskManager.taskAction11 = DoD31ConnAction;
            taskManager.taskAction12 = DoD31MoveMarkPos;
            taskManager.taskAction13 = DoD31MovePaiComplted;
            taskManager.taskAction14 = DoD32ConnAction;
            taskManager.taskAction15 = DoD32MoveMarkPos;
            taskManager.taskAction16 = DoD32MovePaiComplted;
            taskManager.taskAction17 = DoD3AndD2MovePaiComplted;
            taskManager.taskAction18 = DoworkcheckOutput;
            taskManager.taskAction19 = DoworkOutput;
            taskManager.taskAction20 = DoworkCompleted;
            taskManager.taskAction21 = DoworkQuested;
            taskManager.taskAction99 = OldTest;
            taskManager.stopAction = PauseAxisAndTask;

        }

        public static MainThread Instance()
        {
            if(instance==null)
            {
                lock(objlock)
                {
                    if(instance==null)
                        instance=new MainThread();
                }
            }
            return instance;
        }
        public Postion AddPos(Postion pos,double x,double y=0,double z=0)
        {
            Postion item = new Postion();
            item.X = pos.X + x;
            item.Y = pos.Y + y;
            item.Z = pos.Z + z;
            return item;
        }
        public void EndThread()
        {
            mThread?.Abort();
        }
        public void LoadData()
        {
            logHelper?.Invoke(Global.isZh?"导入Config参数。。。":"load config params...");
            datas.dataConfig = FileDeal.LoadFile();
            Global.Dicdi = Global.LodPosIni(Global.DiPath);
            Global.Dicdo = Global.LodPosIni(Global.DoPath);
            Global.Dicpos = Global.LodPosIni(Global.PosPath);
            Global.DicAlarms = Global.LodPosIni(Global.AlarmPath);
            Global.DicAuth = Global.LodAuth();
            time1=Global.timeGetTime();
            time2 = Global.timeGetTime();
            time3 = Global.timeGetTime();
            if(ConfigurationManager.AppSettings["lanuage"].ToUpper().Equals("ZH"))
                Global.isZh=true;
            else
                Global.isZh=false;
            //ClientConn();
            //client1 = new ClientConn("127.0.0.1", 8001);
            //client1.receivedAction = DealServesMsg;
            //client2 = new ClientConn("127.0.0.1", 8002);
            //client2.receivedAction = DealServesMsg;
            //client3 = new ClientConn("127.0.0.1", 8003);
            //client3.receivedAction = DealServesMsg;

        }

        public void ClientConn()
        {
            Task.Run(() =>
            {
                CheckClientConn(ref client1, 8001, time1);
                CheckClientConn(ref client2, 8002, time2);
                CheckClientConn(ref client3, 8003, time3);
            });
        }
        public void CheckClientConn(ref ClientConn client,int port,uint time)
        {
            try
            {
                if(Global.timeGetTime()- time>60000) 
                {
                    if (client == null || !client._isRunning)
                    {
                        client = new ClientConn("127.0.0.1", port);
                        client.receivedAction = DealServesMsg;
                        //Task.Delay(1000);
                    }
                }

            }catch(Exception ex)
            {
                string msg1 = $"服务端口{port}连接失败,{ex.Message}+{ex.StackTrace}";
                string msg2 = $"Server Port{port} connect fail,{ex.Message}+{ex.StackTrace}";
                logHelper?.Invoke(Global.isZh?msg1:msg2);
            }

        }

        public void CheckClientBardConn(ref ClientConn client, string conStr)
        {
            try
            {
                var ipStr= conStr.Split(new char[] {':'});
                if(ipStr.Length>=2)
                {
                    if (client == null || !client._isRunning)
                    {
                        client = new ClientConn(IPAddress.Parse(ipStr[0]).ToString(), int.Parse(ipStr[1]));
                        client.receivedAction = DealBardMsg;
                        //Task.Delay(1000);
                        Thread.Sleep(1000);
                    }
                }

            }
            catch (Exception ex)
            {
                string msg1 = $"服务端{conStr}连接失败,{ex.Message}+{ex.StackTrace}";
                string msg2 = $"Server Ip {conStr} connect fail,{ex.Message}+{ex.StackTrace}";
                logHelper?.Invoke(Global.isZh ? msg1 : msg2);
            }

        }
        public string TurnOnAndOffBard()
        {
            Projecter pa = datas.dataConfig.pro.projectBases[datas.dataConfig.pro.index].item;
            if (!pa.IsReadBard)
                return "";
            string msg ="";
            string strOn = "16540D";
            string strOff = "16550D";
            try
            {
                if (clientBard == null || !clientBard._isRunning)
                {

                    CheckClientBardConn(ref clientBard, pa.Bard_ip);
                }
                clientBard.SendMessageAsync((strOn), false);
                timeinit = Global.timeGetTime();
                Thread.Sleep(150);
                while (Global.timeGetTime() - timeinit < 500)
                {
                    if (!string.IsNullOrEmpty(Global.bardStr))
                    {
                        msg = Global.bardStr;
                        Global.bardStr = "";
                        break;
                    }
                    Thread.Sleep(10);
                }
                clientBard.SendMessageAsync((strOff), false);
            }
            catch (Exception e)
            {
                clientBard.SendMessageAsync((strOff), false);
            }
            return msg;
        }
        public bool CheckAuth(int in_num,int authnum)
        {
            int temp = 0;
            temp = Global.DicAuth[authnum] & (1 << in_num);
            if (temp == 0)
                return false;
            else
                return true;
        }

        public void DealServesMsg(string msg)
        {
            logHelper?.Invoke(msg);
            if (msg.Contains("Sent") && msg.Contains("Received"))
            {
                var item = msg.Split(':');
                if (item.Length >= 4 &&  item[0].Contains("Sent") && item[2].Contains("Received"))
                {
                    if (item[1].Contains("2D"))
                    {
                        Global.tcpConnRet[(int)Enm_Run.D2] = true;
                        Global.tcpConnRetmsg[(int)Enm_Run.D2] = item[3];
                    }
                    else if(item[1].Contains("3D1") || item[1].Contains("3D2"))
                    {
                        Global.tcpConnRet[(int)Enm_Run.D31] = true;
                        Global.tcpConnRetmsg[(int)Enm_Run.D31] = item[3];
                    }
                    //else if(item[1].Contains("3D2"))
                    //{
                    //    Global.tcpConnRet[(int)Enm_Run.D32] = true;
                    //    Global.tcpConnRetmsg[(int)Enm_Run.D32] = item[3];
                    //}
                    
                }
            }else if(msg.Contains("Received"))
            {
                var item = msg.Split(':');
                Global.tcpConnRet[(int)Enm_Run.D32] = true;
                Global.tcpConnRetmsg[(int)Enm_Run.D32] = item[2];
            }
            btn_pro_event.Set();
            ParamForm.btn_bd_event.Set();
        }
        public void DealBardMsg(string msg)
        {
            logHelper?.Invoke(msg);
            if (msg.Contains("Sent") && msg.Contains("Received"))
            {
                var item = msg.Split(':');
                if (item.Length >= 4)
                {
                    Global.bardStr = item[3];
                }

            }
            else if (msg.Contains("Received"))
            {
                var item = msg.Split(':');
                if (item.Length > 2)
                {
                    Global.bardStr = item[2];
                }
            }
        }
            #region 运动流程方法
            public async void DoworkIn(CancellationToken token)
        {
            CancelToken(token);
            Axis.GetDi();
            BeforQuestPanel(1);
            Projecter pa = datas.dataConfig.pro.projectBases[datas.dataConfig.pro.index].item;
            int signal = pa.Signal_in;
            //if (Axis.axis_di[(int)Enm_Di.Input] && CheckDoInput())
            if (Axis.axis_di[signal] && CheckDoInput())
            {
                bardStr = "";
                BeforQuestPanel(0);
                //Thread.Sleep(pa.Signal_in_delyTime);
                logHelper?.Invoke(Global.isZh ? "入料信号触发": "Input signal triggered");
                TranspotRunorStop(1, pa.IsRight_g);
                if (Axis.axis_do[(int)Enm_Do.ownHavedNg])
                {
                    HavedNgPanel(1);
                    blockAirUporDown(1);
                    taskManager.currentStep = 18;
                }
                else
                {
                    HavedPanel(1);
                    blockAirUporDown(0);
                    Global.Currentnum = 1;
                    taskManager.currentStep = 1;
                }
                
            }
            if (Global.Currentnum>0)
                Global.eqStatus = EquipStatus.run;
        }
        public async void D2orD3BeforCheck(CancellationToken token)
        {
            CancelToken(token);
            Axis.GetDi();

            Projecter pa = datas.dataConfig.pro.projectBases[datas.dataConfig.pro.index].item;
            int signal = pa.Signal_put;
            //if (Axis.axis_di[(int)Enm_Di.runpos])
            if (Axis.axis_di[signal])
            {
               
                if(Global.isShipMark || datas.dataConfig.isSip)
                {
                    blockAirUporDown(1);
                    JackAirUporDown(0);
                    TranspotRunorStop(1, pa.IsRight_g);
                    taskManager.currentStep = 18;
                }else
                {
                    //Thread.Sleep(datas.dataConfig.delyTime);
                    Thread.Sleep(pa.Signal_put_delyTime);
                    TranspotRunorStop(0, pa.IsRight_g);
                    TransportMoveDis(pa.Dis_g);
                    //Thread.Sleep(pa.Signal_put_delyTime);
                    bardStr=TurnOnAndOffBard();
                    JackAirUporDown(1);
                    if(string.IsNullOrEmpty(bardStr) || bardStr=="NG")
                        bardStr = TurnOnAndOffBard();
                    if (datas.dataConfig.pro.projectBases[datas.dataConfig.pro.index].item.IsMarked)
                    {
                        ResetProject();
                        taskManager.currentStep = 2;
                    }
                    else
                    {
                        SetProject(datas.dataConfig.pro.projectBases[datas.dataConfig.pro.index]);
                        taskManager.currentStep = 8;
                    }
                    
                }
                
            }
            if (Global.Currentnum > 0)
                Global.eqStatus = EquipStatus.run;
        }
        public void ResetProject()
        {
            index = 0;
            gpu_num = datas.dataConfig.pro.projectBases[datas.dataConfig.pro.index].item.Gpu_type;
            officePos = null;
            pos3D1officestart = null;
            pos3D1officeend = null; 
            pos3D2officestart = null;
            pos3D2officeend = null;
        }
        public void SetProject(ProjectBase item)
        {
            index = 0;
            gpu_num = item.item.Gpu_type;
            officePos = item.pos_2d;
            pos3D1officestart = item.pos_3d1;
            pos3D1officeend = AddPos(pos3D1officestart,0, item.item.Length_3d*datas.dataConfig.alexParams.y_axle.plse_mm);
            //pos3D1officeend = new Postion();
            //pos3D1officeend.X = pos3D1officestart.X + item.item.Length_3d;
            //pos3D1officeend.Y = pos3D1officestart.Y;
            //pos3D1officeend.Z = pos3D1officestart.Z;

            pos3D2officestart = item.pos_3d2;
            pos3D2officeend = AddPos(pos3D2officestart,0, -(item.item.Length_3d * datas.dataConfig.alexParams.y_axle.plse_mm));
            //pos3D2officeend = new Postion();
            //pos3D2officeend.Z = pos3D2officestart.Z;
            //pos3D2officeend.Y = pos3D2officestart.Y;
            //pos3D2officeend.X = pos3D2officestart.X + item.item.Length_3d;
        }
        public bool CheckPosIsnull(Postion postion,string msg="")
        {
            bool ret = false;
            if (postion == null && error_num==0)
            {
                error_num++;
                logHelper?.Invoke(msg+(Global.isZh ? "位置为空" : " pos is null"));
                ret = true;
                Global.eqStatus = EquipStatus.run;
            }
            return ret;
        }
        public async void DoD2ConnAction1(CancellationToken token)
        {
            //client1= new ClientConn("127.0.0.1", 8001);

            //Postion postion = datas.dataConfig.paramPostion.posLists[(int)Enm_PosLists_zh.初始位置2D];
            Postion postion = datas.dataConfig.pro.projectBases[datas.dataConfig.pro.index].pos_mark1;
            DoD2orD3ConnAction(ref client1,ref time1, 8001, postion, token);
        }
        public async void DoD2ConnAction2(CancellationToken token)
        {
            //Postion postion = datas.dataConfig.paramPostion.posLists[(int)Enm_PosLists_zh.结束位置2D];
            Postion postion = datas.dataConfig.pro.projectBases[datas.dataConfig.pro.index].pos_mark2;
            DoD2orD3ConnAction(ref client1, ref time1, 8001, postion, token);
        }
        public async void DoD2ConnAction(CancellationToken token)
        {
            if (CheckPosIsnull(officePos,"2d"))
            {
                return;
            }else
            {
                error_num = 0;
            }
            DoD2orD3ConnAction(ref client1, ref time1, 8001, officePos, token);
        }
        public async void DoD31ConnAction(CancellationToken token)
        {
            //client1= new ClientConn("127.0.0.1", 8001);
            //DoD2orD3ConnAction(ref client2, ref time2, 8002, datas.dataConfig.paramPostion.posLists[(int)Enm_PosLists_zh.初始位置3D1], token);
            if(CheckPosIsnull(pos3D1officestart,"3d1"))
            {
                return;
            }
            else
            {
                error_num = 0;
            }
            DoD2orD3ConnAction(ref client2, ref time2, 8002, pos3D1officestart, token);
        }
        public async void DoD32ConnAction(CancellationToken token)
        {
            //client1= new ClientConn("127.0.0.1", 8001);
            Global.tcpConnRet[(int)Enm_Run.D32]=false;
            if(CheckPosIsnull(pos3D2officestart,"3d2"))
            {
                return;
            }
            else
            {
                error_num = 0;
            }
            DoD2orD3ConnAction(ref client2, ref time3, 8002, pos3D2officestart, token);
        }
        public void DoD2orD3ConnAction(ref ClientConn client, ref uint time, int port,Postion pos,CancellationToken token)
        {
            CancelToken(token);
            //if (!Global.isrun[(int)Enm_Run.D2])
            //{
            //    taskManager.currentStep = 7;
            //    //return;
            //}else
            //if (!Global.isrun[(int)Enm_Run.D31])
            //{
            //    taskManager.currentStep = 10;
            //    //return;
            //}else
            //if (!Global.isrun[(int)Enm_Run.D32])
            //{
            //    JackAirUporDown(0);
            //    blockAirUporDown(1);
            //    TranspotRunorStop(1, false);
            //    taskManager.currentStep = 14;
            //    //return;
            //}else
            {
                if (client == null)
                {
                    client = new ClientConn("127.0.0.1", port);
                    client.receivedAction = DealServesMsg;
                    time = Global.timeGetTime();
                }
                Thread.Sleep(200);
                if (client._isRunning)
                {

                    //await MoveJog(datas.dataConfig.paramPostion.posLists[(int)Enm_PosLists_zh.结束位置2D], token);
                    //await MoveTrap(datas.dataConfig.paramPostion.posLists[(int)Enm_PosLists_zh.初始位置2D]);
                    MoveTrap(pos);
                    taskManager.currentStep += 1;
                }
                else
                {

                    uint now = Global.timeGetTime();
                    if ((now - time) > 10000)
                    {
                        client = null;
                    }
                    Thread.Sleep(30);
                }
            }
            if (Global.Currentnum > 0)
                Global.eqStatus = EquipStatus.run;
        }

        public void ConnectClient(ref ClientConn client,int port)
        {
            
                client = new ClientConn("127.0.0.1", port);
                client.receivedAction = DealServesMsg;
            Thread.Sleep(800);
        }

        public void OldTest(CancellationToken token)
        {
            //Postion pos=new Postion();
            //Random random = new Random();
            //pos.X = random.Next((int)datas.dataConfig.alexParams.x_axle.leftLimitpos, (int)datas.dataConfig.alexParams.x_axle.rightLimitpos);
            //pos.Y = random.Next((int)datas.dataConfig.alexParams.y_axle.leftLimitpos, (int)datas.dataConfig.alexParams.y_axle.rightLimitpos);
            //pos.Z = random.Next((int)datas.dataConfig.alexParams.z_axle.leftLimitpos, (int)datas.dataConfig.alexParams.z_axle.rightLimitpos);

            CancelToken(token);
            uint time=Global.timeGetTime();
            foreach (Postion pos in datas.dataConfig.paramPostion.posLists)
            {
                if (Global.Currentnum <= 0)
                    break;

                if (pos.X == 0 && pos.Y == 0)
                    continue;
                MoveTrap(pos);
                Thread.Sleep(2000);
                time = Global.timeGetTime();
                while (true)
                {
                    if (GetEqStopSts() && PosTrapEquals(GetPos(), pos))
                    {
                        break;
                    }
                    else if (Global.timeGetTime() - time > 2000)
                        break;
                    Thread.Sleep(2000);
                }
                
            }

            taskManager.currentStep = 99;
            if (Global.Currentnum > 0)
                Global.eqStatus = EquipStatus.run;
            
            
        }



        public void AuotOldRun(Postion pos, CancellationToken token)
        {
            CancelToken(token);
            MoveTrap(pos);
            taskManager.currentStep = 99;
            if (Global.Currentnum > 0)
                Global.eqStatus = EquipStatus.run;
        }
        public async void DoD2MoveMarkPos1(CancellationToken token)
        {
            //Postion pos1= datas.dataConfig.paramPostion.posLists[(int)Enm_PosLists_zh.初始位置2D];
            //Postion pos2 = datas.dataConfig.paramPostion.posLists[(int)Enm_PosLists_zh.结束位置2D];
            Postion pos1 = datas.dataConfig.pro.projectBases[datas.dataConfig.pro.index].pos_mark1; 
            Postion pos2 = datas.dataConfig.pro.projectBases[datas.dataConfig.pro.index].pos_mark2; 
            //string tempMsg = $"2D,C1,SN,{index+1}";
            string tempMsg = $"2D,C1,{bardStr},{gpu_num}";
            DoD2orD3MoveMarkPos(pos1, pos1, client1,0, (int)Enm_Run.D32, tempMsg, token);
        }
        public async void DoD2MoveMarkPos2(CancellationToken token)
        {
            //Postion pos1 = datas.dataConfig.paramPostion.posLists[(int)Enm_PosLists_zh.初始位置2D];
            //Postion pos2 = datas.dataConfig.paramPostion.posLists[(int)Enm_PosLists_zh.结束位置2D];
            Postion pos1 = datas.dataConfig.pro.projectBases[datas.dataConfig.pro.index].pos_mark1;
            Postion pos2 = datas.dataConfig.pro.projectBases[datas.dataConfig.pro.index].pos_mark2;
            //DoD2orD3MoveMarkPos(pos2, pos2, client1, 0, (int)Enm_Run.D32, "2D,C2,", token);
            //string tempMsg = $"2D,C2,SN,{index + 1}";
            string tempMsg = $"2D,C2,{bardStr},{gpu_num}";
            DoD2orD3MoveMarkPos(pos2, pos2, client1, 0, (int)Enm_Run.D32, tempMsg, token);
        }
        public async void DoD2MoveMarkPos(CancellationToken token)
        {
            //Postion pos1 = datas.dataConfig.paramPostion.posLists[(int)Enm_PosLists_zh.初始位置2D];
            //Postion pos2 = datas.dataConfig.paramPostion.posLists[(int)Enm_PosLists_zh.结束位置2D];
            //DoD2orD3MoveMarkPos(pos2, pos2, client1, 0, (int)Enm_Run.D32, "2D,C2,", token);
            //string tempMsg = $"2D,D1,SN,{index + 1}";
            string tempMsg = $"2D,D1,{bardStr},{gpu_num}";
            //CheckPosIsnull(officePos);
            if (CheckPosIsnull(officePos,"2d"))
            {
                return;
            }
            else
            {
                error_num = 0;
            }
            DoD2orD3MoveMarkPos(officePos, officePos, client1, 0, (int)Enm_Run.D32, tempMsg, token);
        }
        public async void DoD31MoveMarkPos(CancellationToken token)
        {
            //Postion pos1 = datas.dataConfig.paramPostion.posLists[(int)Enm_PosLists_zh.初始位置3D1];
            //Postion pos2 = datas.dataConfig.paramPostion.posLists[(int)Enm_PosLists_zh.结束位置3D1];
            double val = datas.dataConfig.pro.projectBases[datas.dataConfig.pro.index].item.Speed_3d;
            //string tempMsg = $"3D1,C1,SN,{index + 1}";
            string tempMsg = $"3D1,C1,{bardStr},{gpu_num}";
            //CheckPosIsnull(pos3D1officestart);
            //CheckPosIsnull(pos3D1officeend);
            if (CheckPosIsnull(pos3D1officestart,"3d1"))
            {
                return;
            }
            else
            {
                error_num = 0;
            }
            //if (CheckPosIsnull(pos3D1officeend,"3d2"))
            //{
            //    return;
            //}
            //else
            //{
            //    error_num = 0;
            //}
            DoD2orD3MoveMarkPos(pos3D1officestart, pos3D1officeend, client2, val, (int)Enm_Run.D31, tempMsg, token);
        }
        public async void DoD32MoveMarkPos(CancellationToken token)
        {
            double val = datas.dataConfig.pro.projectBases[datas.dataConfig.pro.index].item.Speed_3d;
            //string tempMsg = $"3D2,C1,SN,{index + 1}";
            string tempMsg = $"3D2,C1,{bardStr},{gpu_num}";
            //CheckPosIsnull(pos3D2officestart);
            //CheckPosIsnull(pos3D2officeend);
            if (CheckPosIsnull(pos3D2officestart, "3d2"))
            {
                
                return;
            }
            if (CheckPosIsnull(pos3D2officeend, "3d2"))
            {
                return;
            }
            DoD2orD3MoveMarkPos(pos3D2officestart, pos3D2officeend, client2, val,(int)Enm_Run.D32, tempMsg, token);
        }
        public async void DoD2orD3MoveMarkPos(Postion pos1,Postion pos2,ClientConn client, double val, int num,string msg, CancellationToken token)
        {
            CancelToken(token);
            if(GetEqStopSts() )
            {
                if (PosTrapEquals(GetPos(), pos1))
                {
                    double x = Axis.enpos[0] * 0.001;
                    double y = Axis.enpos[1] * 0.001;
                    msg += $",{x},{y}";
                    Task.Delay(30);
                    if (client._isRunning)
                    {
                        string msg1 = $"第{index + 1}次发送消息，{msg}";
                        string msg2 = $"Send message for the {index + 1} th time，{msg}";
                        logHelper?.Invoke(Global.isZh ? msg1 : msg2);
                        Global.tcpConnRet[num] = false;
                        await client.SendMessageAsync(msg);
                        if (msg.Contains("3D"))
                            await MoveTrap(pos2, val);
                        else
                            await MoveTrap(pos2);
                        //await MoveTrap(pos2, val);
                        taskManager.currentStep += 1;
                    }
                    else
                    {
                        taskManager.currentStep -= 1;
                    }
                    //await MoveJog(datas.dataConfig.paramPostion.posLists[(int)Enm_PosLists_zh.结束位置2D], token);
                    //MoveTrap(datas.dataConfig.paramPostion.posLists[(int)Enm_PosLists_zh.结束位置2D]);
                }else
                {
                    await MoveTrap(pos1);
                }
            }
            if (Global.Currentnum > 0)
                Global.eqStatus = EquipStatus.run;
        }
        public async void DoD2MoveOffice(CancellationToken token)
        {
            CancelToken(token);
            //
            if (client1 == null)
            {
                client1 = new ClientConn("127.0.0.1", 8001);
                client1.receivedAction = DealServesMsg;
            }
                
            Thread.Sleep(10);
            if (Global.tcpConnRet[(int)Enm_Run.D2])
            {
                if (Global.tcpConnRetmsg[(int)Enm_Run.D2].Contains("OK"))
                {
                    if(Global.isShipMark)
                    {
                        taskManager.currentStep = 7;
                    }
                    else
                    {
                        //var msg = client1.receivedMessage.Split(',');
                        //Postion retPos = new Postion();
                        //retPos.X = int.Parse(msg[1]);
                        //retPos.Y = int.Parse(msg[2]);
                        //retPos.Z = 0;
                        //await MoveDistences(retPos);
                        //officePos = GetPos();
                        //officePos.X += retPos.X;
                        //officePos.Y += retPos.Y;
                        //officePos.Z += retPos.Z;
                        taskManager.currentStep += 1;
                    }
                        //client1.receivedMessage = "";
                    
                }   
                else if(Global.tcpConnRetmsg[(int)Enm_Run.D2].Contains("NG"))
                {
                    //client1.receivedMessage = "";
                    taskManager.currentStep -= 2;
                }
                    

            }
            if (Global.Currentnum > 0)
                Global.eqStatus = EquipStatus.run;
        }
        public async void DoD2MovePaiPos(CancellationToken token)
        {
            CancelToken(token);
            Task.Delay(20);
            if (GetEqStopSts())
            {
                if (PosTrapEquals(GetPos(), officePos))
                {
                    double x = Axis.enpos[0] * 0.001;
                    double y = Axis.enpos[1] * 0.001;
                    string msg = $"2D,c2,{x},{y}";
                    if (client1._isRunning)
                    {
                        await client1.SendMessageAsync(msg);
                        taskManager.currentStep += 1;
                    }
                    else
                    {
                        //MessageBox.Show("图像采集连接断掉，请检查网线是否松动！");
                        //client = new ClientConn("127.0.0.1", 8001);
                        //Thread.Sleep(1000);
                        //taskManager.currentStep -= 1;
                    }
                }else
                {
                   await MoveTrap(officePos);
                }
            }
            if (Global.Currentnum > 0)
                Global.eqStatus = EquipStatus.run;
        }

        public async void DoD2MovePaiComplted1(CancellationToken token)
        {
            //Postion pos1 = datas.dataConfig.paramPostion.posLists[(int)Enm_PosLists_zh.初始位置2D];
            Postion pos1 = datas.dataConfig.pro.projectBases[datas.dataConfig.pro.index].pos_mark1;
          
            DoD2OrD3MovePaiComplted(client1, pos1, (int)Enm_Run.D2, token);
        }
        public async void DoD2MovePaiComplted2(CancellationToken token)
        {
            //Postion pos1 = datas.dataConfig.paramPostion.posLists[(int)Enm_PosLists_zh.结束位置2D];
            //Postion pos1 = datas.dataConfig.pro.projectBases[datas.dataConfig.pro.index].pos_mark1;
            Postion pos1 = datas.dataConfig.pro.projectBases[datas.dataConfig.pro.index].pos_mark2;
            DoD2OrD3MovePaiComplted(client1, pos1, (int)Enm_Run.D2, token);
        }
        public async void DoD2MovePaiComplted(CancellationToken token)
        {
            DoD2OrD3MovePaiComplted(client1, officePos, (int)Enm_Run.D2, token);
        }
        public async void DoD31MovePaiComplted(CancellationToken token)
        {
            //Postion pos1 = datas.dataConfig.paramPostion.posLists[(int)Enm_PosLists_zh.初始位置3D1];
            DoD2OrD3MovePaiComplted(client2, pos3D1officestart, (int)Enm_Run.D31, token);
        }
        public async void DoD32MovePaiComplted(CancellationToken token)
        {
            //Postion pos1 = datas.dataConfig.paramPostion.posLists[(int)Enm_PosLists_zh.初始位置3D2];
            DoD2OrD3MovePaiComplted(client2, pos3D2officestart, (int)Enm_Run.D31, token);
        }
        public async void DoD2OrD3MovePaiComplted(ClientConn client,Postion pos,int num, CancellationToken token)
        {
            CancelToken(token);
            Projecter pa = datas.dataConfig.pro.projectBases[datas.dataConfig.pro.index].item;
            //if (client == null || !client._isRunning)
            //{
            //    //MessageBox.Show("图像未采集完，连接断掉，请检查网线是否松动！");
            //}
            if (Global.tcpConnRet[num])
            {
                if (Global.tcpConnRetmsg[num].Contains("OK"))
                {
                    //Received: OK,SN,1,179.538,105.346,86.172,62.167,191.984,161.157,
                    var msg = Global.tcpConnRetmsg[num].Split(',');
                    if (num==(int)Enm_Run.D2)
                    {
                        if (pa.IsMarked)
                        {
                            if (msg.Length >= 9)
                            {
                                Postion temp = GetPos();
                                officePos = new Postion();
                                officePos.X = double.Parse(msg[3]) * 1000;
                                officePos.Y = double.Parse(msg[4]) * 1000;
                                officePos.Z = temp.Z;

                                pos3D1officestart = new Postion();
                                pos3D1officestart.X = double.Parse(msg[5]) * 1000;
                                pos3D1officestart.Y = double.Parse(msg[6]) * 1000;
                                pos3D1officestart.Z = temp.Z;

                                pos3D1officeend = AddPos(pos3D1officestart,0, datas.dataConfig.d3_distence);

                                pos3D2officestart = new Postion();
                                pos3D2officestart.X = double.Parse(msg[7]) * 1000;
                                pos3D2officestart.Y = double.Parse(msg[8]) * 1000;
                                pos3D2officestart.Z = temp.Z;

                                pos3D2officeend = AddPos(pos3D2officestart,0, -datas.dataConfig.d3_distence);

                                //x轴作为扫描方向
                                //double temp_3d1_x = (datas.dataConfig.office_3d1_x - datas.dataConfig.pro.projectBases[datas.dataConfig.pro.index].item.Length_3d / 2) * datas.dataConfig.alexParams.x_axle.plse_mm;
                                //double temp_3d2_x = (datas.dataConfig.office_3d2_x - datas.dataConfig.pro.projectBases[datas.dataConfig.pro.index].item.Length_3d / 2) * datas.dataConfig.alexParams.x_axle.plse_mm;
                                //pos3D1officestart = AddPos(officePos, temp_3d1_x, datas.dataConfig.office_3d1_y * datas.dataConfig.alexParams.y_axle.plse_mm);
                                //pos3D2officestart = AddPos(officePos, temp_3d2_x, datas.dataConfig.office_3d1_y * datas.dataConfig.alexParams.y_axle.plse_mm);
                                //y轴作为扫描方向
                                //double temp_3d1_y = (datas.dataConfig.office_3d1_y - pa.Length_3d / 2) * datas.dataConfig.alexParams.y_axle.plse_mm;
                                //double temp_3d2_y = (datas.dataConfig.office_3d2_y - pa.Length_3d / 2) * datas.dataConfig.alexParams.y_axle.plse_mm;
                                //pos3D1officestart = AddPos(officePos,  datas.dataConfig.office_3d1_x * datas.dataConfig.alexParams.x_axle.plse_mm, temp_3d1_y);
                                //pos3D2officestart = AddPos(officePos,  datas.dataConfig.office_3d1_x * datas.dataConfig.alexParams.x_axle.plse_mm, temp_3d2_y);

                                //pos3D1officeend = AddPos(pos3D1officestart,0, datas.dataConfig.pro.projectBases[datas.dataConfig.pro.index].item.Length_3d * datas.dataConfig.alexParams.x_axle.plse_mm);

                                //pos3D2officeend = AddPos(pos3D2officestart,0, datas.dataConfig.pro.projectBases[datas.dataConfig.pro.index].item.Length_3d * datas.dataConfig.alexParams.x_axle.plse_mm);

                                Global.tcpConnRetmsg[num] = "";
                            }
                        }
                        else
                        {
                            Global.tcpConnRetmsg[num] = "";
                        }      
                    }
                    taskManager.currentStep += 1;
                    //client.receivedMessage = "";
                }
                else if (Global.tcpConnRetmsg[num].Contains("NG"))
                {
                    //client.receivedMessage = "";
                    //await MoveDistences(pos);
                    if (num == (int)Enm_Run.D2)
                    {
                        
                        if (index>datas.dataConfig.run_num)
                        {
                            HavedNgPanel(1);
                            JackAirUporDown(0);
                            blockAirUporDown(1);
                            TranspotRunorStop(1, pa.IsRight_g);
                            taskManager.currentStep = 18;
                            index = 0;
                        }
                        else
                        {
                            if (datas.dataConfig.pro.projectBases[datas.dataConfig.pro.index].item.IsMarked)
                                taskManager.currentStep = 2;
                            else
                                taskManager.currentStep = 8;
                            //index += 1;
                        }
                        index++;
                    } 
                    else
                    {
                        taskManager.currentStep += 1;
                    }
                }else if(Global.tcpConnRetmsg[num].Contains("1"))
                {
                    //client.receivedMessage = "";
                    taskManager.currentStep += 1;
                    //index = 0;
                }
                else if (Global.tcpConnRetmsg[num].Contains("2"))
                {
                    //client.receivedMessage = "";
                    await MoveTrap(pos);
                    taskManager.currentStep -= 1;
                    //index += 1;
                }

                Global.tcpConnRet[num] = false;
            }else
            {
                btn_pro_event.Reset();
                btn_pro_event.WaitOne();
            }
            if (Global.Currentnum > 0)
                Global.eqStatus = EquipStatus.run;
        }
        public async void DoD3AndD2MovePaiComplted(CancellationToken token)
        {
            CancelToken(token);
            Projecter pa = datas.dataConfig.pro.projectBases[datas.dataConfig.pro.index].item;
            if (client3 == null || !client3._isRunning)
            {
                client3 = new ClientConn("127.0.0.1", 8003);
                client3.receivedAction = DealServesMsg;
                //MessageBox.Show("图像未采集完，连接断掉，请检查网线是否松动！");
                Task.Delay(20);
            }
            if (Global.tcpConnRet[(int)Enm_Run.D32])
            {
                if (Global.tcpConnRetmsg[(int)Enm_Run.D32].Contains(","))
                {
                    //var msg = client3.receivedMessage.Split(',');
                    //Postion retPos = new Postion();
                    //retPos.X = int.Parse(msg[1]);
                    //retPos.Y = int.Parse(msg[2]);
                    //retPos.Z = 0;
                    //await MoveDistences(retPos);
                    //officePos = GetPos();
                    //officePos.X += retPos.X;
                    //officePos.Y += retPos.Y;
                    //officePos.Z += retPos.Z;
                    JackAirUporDown(0);
                    blockAirUporDown(1);
                    TranspotRunorStop(1, pa.IsRight_g);
                    Postion pos1 = null;
                    if (datas.dataConfig.pro.projectBases[datas.dataConfig.pro.index].item.IsMarked)
                        pos1 = datas.dataConfig.pro.projectBases[datas.dataConfig.pro.index].pos_mark1;
                    else
                        pos1 = datas.dataConfig.pro.projectBases[datas.dataConfig.pro.index].pos_2d;
                    await MoveTrap(pos1);   
                    taskManager.currentStep += 1;
                    //client3.receivedMessage = "";
                }
                else
                {
                    if (datas.dataConfig.pro.projectBases[datas.dataConfig.pro.index].item.IsMarked)
                        taskManager.currentStep = 2;
                    else
                        taskManager.currentStep = 8;
                }
            }
            if (Global.Currentnum > 0)
                Global.eqStatus = EquipStatus.run;
        }

        public async void DoworkcheckOutput(CancellationToken token)
        {
            CancelToken(token);
            Axis.GetDi();

            Projecter pa = datas.dataConfig.pro.projectBases[datas.dataConfig.pro.index].item;
            int signal = pa.Signal_out;

            //if (Axis.axis_di[(int)Enm_Di.output])
            if (Axis.axis_di[signal])
            {
                Thread.Sleep(pa.Signal_out_delyTime);
                logHelper?.Invoke(Global.isZh?"出料信号触发": "output signal triggered");
                
                TranspotRunorStop(0, pa.IsRight_g);
                //JackAirUporDown(1);
                taskManager.currentStep += 1;
            }
            if (Global.Currentnum > 0)
                Global.eqStatus = EquipStatus.run;
        }
        public async void DoworkOutput(CancellationToken token)
        {
            CancelToken(token);
            Axis.GetDi();
            Projecter pa = datas.dataConfig.pro.projectBases[datas.dataConfig.pro.index].item;
            int signal = pa.After_get;
            //if (Axis.axis_di[(int)Enm_Di.afterOutput])
            if (Axis.axis_di[signal])
            {
                Thread.Sleep(10);
                TranspotRunorStop(1, pa.IsRight_g);
                //JackAirUporDown(1);
                taskManager.currentStep += 1;
            }
            if (Global.Currentnum > 0)
                Global.eqStatus = EquipStatus.run;
        }
        public async void DoworkCompleted(CancellationToken token)
        {
            CancelToken(token);
            Axis.GetDi();

            Projecter pa = datas.dataConfig.pro.projectBases[datas.dataConfig.pro.index].item;
            int signal = pa.Signal_out;

            //if (!Axis.axis_di[(int)Enm_Di.output])
            if (!Axis.axis_di[signal])
            {
                Thread.Sleep(pa.Signal_out_delyTime);
                TranspotRunorStop(0, pa.IsRight_g);
                blockAirUporDown(0);
                HavedPanel(0);
                HavedNgPanel(0);
                BeforQuestPanel(1);
                //JackAirUporDown(1);
                taskManager.currentStep += 1;
            }
            if (Global.Currentnum > 0)
                Global.eqStatus = EquipStatus.run;
        }
        public async void DoworkQuested(CancellationToken token)
        {
            CancelToken(token);
            Axis.GetDi();
            Projecter pa = datas.dataConfig.pro.projectBases[datas.dataConfig.pro.index].item;
            int signal = pa.Befor_get;
            //if (Axis.axis_di[(int)Enm_Di.beforInput])
            if (Axis.axis_di[signal])
            {
                Thread.Sleep(10);
                //TranspotRunorStop(1, false);
                //blockAirUporDown(0);
                taskManager.currentStep = 0;
            }
            else if (Axis.axis_di[(int)Enm_Di.beforInputNg])
            {
                Thread.Sleep(10);
                TranspotRunorStop(1, pa.IsRight_g);
                blockAirUporDown(1);
                HavedNgPanel(1);
                taskManager.currentStep = 14;
            }
            if (Global.Currentnum > 0)
                Global.eqStatus = EquipStatus.run;
        }
        public async void DoworkFindPanel(CancellationToken token)
        {
            CancelToken(token);
            Axis.GetDi();
            //if (Axis.axis_di[(int)Enm_Di.Input])
            //{
            //    Thread.Sleep(100);
            //    TranspotRunorStop(0, false);
            //    blockAirUporDown(0);
            //    HavedPanel(0);
            //    BeforQuestPanel(1);
            //    taskManager.currentStep += 1;
            //}
            if (Global.Currentnum > 0)
                Global.eqStatus = EquipStatus.run;
        }
        //public async void DoD31MovePaiStartPos(CancellationToken token)
        //{
        //    CancelToken(token);
        //    //await MoveTrap(datas.dataConfig.paramPostion.posLists[(int)Enm_PosLists_zh.初始位置3D1]);
        //    //taskManager.currentStep += 1;
        //    Global.eqStatus = EquipStatus.run;
        //}
        //public async void DoD31ConnActionAndMove(ClientConn client,CancellationToken token)
        //{
        //    CancelToken(token);
        //    //
        //    taskManager.currentStep += 1;
        //    Global.eqStatus = EquipStatus.run;
        //}
        //public async void ClearPos(CancellationToken token)
        //{
        //    CancelToken(token);
        //}
        #endregion

        public Postion GetPos()
        {
            Postion pos =new Postion();
            Axis.GetEnposAll();
            pos.X = Axis.enpos[0];
            pos.Y = Axis.enpos[1];
            pos.Z = Axis.enpos[2];
            return pos;
        }

        public bool IsCreatePro()
        {
            if (datas.dataConfig.pro.projectBases.Count > 0 && datas.dataConfig.pro.index < datas.dataConfig.pro.projectBases.Count)
                return true;
            else return false;
        }
        public bool PosTrapEquals(Postion pos1 ,Postion pos2)
        {
            double temp = Global.officepos;
            if(Math.Abs(pos1.X-pos2.X)<= temp && Math.Abs(pos1.Y- pos2.Y) <= temp /*&& Math.Abs(pos1.Z - pos2.Z) <= temp*/)
                    return true;
            else
                return false;
        }
        public bool PosJogEquals(Postion pos1, Postion pos2)
        {
            double temp = 0;
            if (Math.Abs(pos1.X - pos2.X) <= temp && Math.Abs(pos1.Y - pos2.Y) <= temp /*&& Math.Abs(pos1.Z - pos2.Z) <= temp*/)
                return true;
            else
                return false;
        }
        public void TransportMoveDis(double dis,double val=10)
        {
            if(dis==0) return;
            double enpos= Axis.GetEnpos(datas.dataConfig.alexParams.g_axle.axis);
            int sts = Axis.GetAxisSts(datas.dataConfig.alexParams.g_axle.axis);
            MoveTrapBase(datas.dataConfig.alexParams.g_axle.axis, datas.dataConfig.alexParams.g_axle, (int)(enpos + dis* datas.dataConfig.alexParams.g_axle.plse_mm), val);
            while(sts!= Axis.GetAxisSts(datas.dataConfig.alexParams.g_axle.axis))
            {
                Thread.Sleep(50);
            }
        }
        public async Task MoveDistences(Postion pos)
        {
            Postion tempPos=GetPos();
            //if(axis==0)
            {
                MoveTrapBase(datas.dataConfig.alexParams.x_axle.axis, datas.dataConfig.alexParams.x_axle, (int)(pos.X + tempPos.X));
                MoveTrapBase(datas.dataConfig.alexParams.y_axle.axis, datas.dataConfig.alexParams.y_axle, (int)(pos.Y + tempPos.Y));
                MoveTrapBase(datas.dataConfig.alexParams.z_axle.axis, datas.dataConfig.alexParams.z_axle, (int)(pos.Z + tempPos.Z));
            }
            //else
            //{
            //    switch(axis)
            //    {
            //        case 1:
            //            MoveTrapBase(1, datas.dataConfig.alexParams.x_axle, (int)(pos.X + tempPos.X), 5);
            //            break;
            //            case 2:
            //            MoveTrapBase(2, datas.dataConfig.alexParams.y_axle, (int)(pos.Y + tempPos.Y), 5);
            //            break;
            //            case 3:
            //            MoveTrapBase(3, datas.dataConfig.alexParams.z_axle, (int)(pos.Z + tempPos.Z), 5);
            //            break;
            //        case 4:
            //            //MoveTrapBase(4, datas.dataConfig.alexParams.k_axle, (int)(pos.K + tempPos.Z), 5);
            //            break;
            //        default:break;
            //    }
            //}
        }
        public async Task MoveTrap(Postion pos, double val = 0)
        {
            MoveTrapBase(datas.dataConfig.alexParams.x_axle.axis, datas.dataConfig.alexParams.x_axle, (int)(pos.X ),val);
            MoveTrapBase(datas.dataConfig.alexParams.y_axle.axis, datas.dataConfig.alexParams.y_axle, (int)(pos.Y ),val);
            MoveTrapBase(datas.dataConfig.alexParams.z_axle.axis, datas.dataConfig.alexParams.z_axle, (int)(pos.Z), val);
        }
        public void MoveTrapBase( short no, ParaamSigle axis,int dis,double val=0)
        {
            if (no < 4)
                CheckLimitPosAlarm(axis, dis);
            GetEuipsts(EquipStatus.run);
            //Axis.GetTrapPrm(axis.acc,axis.dcc,(short)axis.smoothTime);
            Axis.GetTrapPrm(val == 0 ? axis.acc : 0.1, val == 0 ? axis.dcc : 0.1, (short)axis.smoothTime);
            switch (no)
                {
                    case 1:
                    Axis.DoTrap(1, Axis.trapPrm, dis, val == 0 ? axis.val : val);
                        break;
                    case 2:
                        Axis.DoTrap(2, Axis.trapPrm, dis, val == 0 ? axis.val : val);
                    break;
                    case 3:
                        Axis.DoTrap(3, Axis.trapPrm, dis, val == 0 ? axis.val : val);
                    break;
                    case 4:
                        Axis.DoTrap(4, Axis.trapPrm, dis, val == 0 ? axis.val : val);
                    break;
                case 5:
                    Axis.DoTrap(5, Axis.trapPrm, dis, val == 0 ? axis.val : val);
                    break;
                default: break;
                }
            GetAxisSts();
        }

        
        public void CheckLimitPosAlarm(ParaamSigle axis,int dis)
        {
           
            if (dis > axis.rightLimitpos * axis.plse_mm)
            {
                string tempMsg = Global.isZh ? "即将移动的位置超软正限位，请确认后再跑" : "The position that is about to be moved has a super soft right limit. Please confirm before running";
                //string msgAlarm = ;
                Alarming(tempMsg);
                return;
            }
            
            if (dis < axis.leftLimitpos * axis.plse_mm)
            {
                string tempMsg = Global.isZh ? "即将移动的位置超软负限位，请确认后再跑" : "The position that is about to be moved has a super soft left limit. Please confirm before running";
                //msgAlarm = dis < axis.leftLimitpos * axis.plse_mm ? tempMsg : "";
                Alarming(tempMsg);
            }
                
        }
        public void MoveJogBase(short no, ParaamSigle axis, bool fx,double val=0)
        {
            if(no<4)
            {
                Axis.GetEnposAll();
                CheckLimitPosAlarm(axis, Axis.enpos[no - 1]);
            }
            Axis.GetJogPrm(val==0?axis.acc:0.1, val==0?axis.dcc:0.1, (double)axis.smoothTime);
            switch (no)
            {
                case 1:
                    Axis.DoJog(1, val == 0 ? axis.val : val, Axis.jogPrm, fx);
                    break;
                case 2:
                    Axis.DoJog(2, val == 0 ? axis.val : val, Axis.jogPrm, fx);
                    break;
                case 3:
                    Axis.DoJog(3, val == 0 ? axis.val : val, Axis.jogPrm, fx);
                    break;
                case 4:
                    Axis.DoJog(4, val == 0 ? axis.val : val, Axis.jogPrm, fx);
                    break;
                case 5:
                    Axis.DoJog(5, val == 0 ? axis.val : val, Axis.jogPrm, fx);
                    break;
                default: break;
            }
            //GetAxisSts();
        }

        //public async Task MoveJog(Postion pos, CancellationToken token)
        //{

        //    bool ret1 = false;
        //    bool ret2 = false;
        //    bool ret3 = false;
        //    Postion enposs = GetPos();
        //    //Axis.DoJog(axis, val, jog, true);
        //    //Axis.GetJogPrm();
        //    MoveJogBase(datas.dataConfig.alexParams.x_axle.axis, datas.dataConfig.alexParams.x_axle,  pos.X- enposs.X > 0 ? false : true);
        //    MoveJogBase(datas.dataConfig.alexParams.y_axle.axis, datas.dataConfig.alexParams.y_axle, pos.Y - enposs.Y > 0 ? false : true);
        //    MoveJogBase(datas.dataConfig.alexParams.z_axle.axis, datas.dataConfig.alexParams.z_axle, pos.Z - enposs.Z > 0 ? false : true);
        //    //Axis.DoJog(1, datas.dataConfig.alexParams.x_axle.val, Axis.jogPrm, enposs.X - pos.X > 0 ? false : true);
        //    //Axis.DoJog(2, datas.dataConfig.alexParams.y_axle.val, Axis.jogPrm, enposs.Y - pos.Y > 0 ? false : true);
        //    //Axis.DoJog(3, datas.dataConfig.alexParams.z_axle.val, Axis.jogPrm, enposs.Z - pos.Z > 0 ? false : true);
        //    while (!ret1 && !ret2 && !ret3)
        //    {
        //        CancelToken(token);
        //        enposs = GetPos();
        //        if (Math.Abs(enposs.X - pos.X) >= 0)
        //        {
        //            ret1=false;
        //        }  
        //        else
        //        { 
        //            ret1 = true;
        //            Axis.Stop(datas.dataConfig.alexParams.x_axle.axis);
        //        }
        //        if (Math.Abs(enposs.Y - pos.Y) != 0)
        //        { 
        //            ret2 = false;
        //        }
        //        else
        //        { 
        //            ret2 = true;
        //            Axis.Stop(datas.dataConfig.alexParams.y_axle.axis);
        //        }
        //        if (Math.Abs(enposs.Z - pos.Z) != 0)
        //        { 
        //            ret3 = false;
        //        }
        //        else
        //        { 
        //            ret3 = true;
        //            Axis.Stop(datas.dataConfig.alexParams.z_axle.axis);
        //        }
        //        Thread.Sleep(3);
        //    }
        //}


        public void CancelToken(CancellationToken token)
        {
            if (token.IsCancellationRequested)
            {
                throw new ArgumentOutOfRangeException("cancellationToken");
            }
        }

        public void AxisStop()
        {
            GetEuipsts(EquipStatus.stop);
            Axis.StopAll();
        }

        #region 执行Do输出
        public bool CheckDoInput()
        {
            if(Global.Currentnum == 1)
            {
                return true;
            }else
            {
                return false;
            }
        }
        /// <summary>
        /// 运输待跑料
        /// </summary>
        /// <param name="val">1 run,0 stop</param>
        /// <param name="isleft">是否方向向左</param>
        public void TranspotRunorStop(short val,bool isright=true)
        {
            ParaamSigle axiss = datas.dataConfig.alexParams.g_axle;
            if (val == 0)
            {
                Axis.Stop(axiss.axis);
            }else
            {
                MoveJogBase(axiss.axis, axiss, isright, axiss.val);
            }
            
            

            //if (isright)
            //{
            //    logHelper?.Invoke(Global.isZh ? "执行传输转动向右" : "Perform transmission rotation to the right");
            //    //Axis.SetDoSignl((short)Enm_Do.transport+1, val);
            //    DoWrite(Enm_Do.transport, val);
            //}
            //else
            //{
            //    //Axis.SetDoSignl((short)Enm_Do.transportDirection+1, val);
            //    //Axis.SetDoSignl((short)Enm_Do.transport + 1, val);
            //    DoWrite(Enm_Do.transportDirection, val);
            //    DoWrite(Enm_Do.transport, val);
            //}
        }
        public void JackAirUporDown(short val)
        {
            //WriteLog("顶升气缸", val);
            //Axis.SetDoSignl((short)Enm_Do.jackAir + 1, val);
            Projecter pa = datas.dataConfig.pro.projectBases[datas.dataConfig.pro.index].item;
            //DoWrite(Enm_Do.jackAir, val);
            DoWrite((Enm_Do)pa.Jack_Air, 0);
            DoWrite((Enm_Do)pa.Jack_Air2, 0);
            Thread.Sleep(100);
            DoWrite((Enm_Do)pa.Jack_Air, val);
            DoWrite((Enm_Do)pa.Jack_Air2, (short)(val == 0?1:0));
            //Task.Run(() => {
            //    Task.Delay(2000);
            //    CheckjackPos(val);
            //});

        }
        public void blockAirUporDown(short val)
        {
            //WriteLog("阻挡气缸", val);
            //Axis.SetDoSignl((short)Enm_Do.blockAir + 1, val);
            Projecter pa = datas.dataConfig.pro.projectBases[datas.dataConfig.pro.index].item;
            //DoWrite(Enm_Do.blockAir, val);
            DoWrite((Enm_Do)pa.Block_Air, val);
            //Task.Run(() => {
            //    Task.Delay(2000);
            //    CheckblockPos(val);
            //});
            
        }
        public void HavedPanel(short val)
        {
            //WriteLog("机台有料", val);
            //Axis.SetDoSignl((short)Enm_Do.ownHaved + 1, val);
            DoWrite(Enm_Do.ownHaved, val);
        }
        public void HavedNgPanel(short val)
        {
            DoWrite(Enm_Do.ownHavedNg, val);
            //WriteLog("机台有NG料", val);
            //Axis.SetDoSignl((short)Enm_Do.ownHavedNg + 1, val);
        }
        public void BeforQuestPanel(short val)
        {

            if (Axis.axis_do[(int)Enm_Do.beforquest] != (val==1?true:false))
                DoWrite(Enm_Do.beforquest, val);
            //WriteLog("请求来料",val) ;
            //Axis.SetDoSignl((short)Enm_Do.beforquest + 1, val);
        }
        public void DoWrite(Enm_Do item,short val)
        {
            if(Global.Dicdo.Count>0 && Global.Dicdo.Count >= (int)item)
            {
                WriteLog(Global.Dicdo[(int)item], val);
                Axis.SetDoSignl((short)((int)item + 1), val);
            }
    
        }
        public void WriteLog(string msg ,short val)
        {
            string msg1 = Global.isZh ? "打开" : "open";
            string msg2 = Global.isZh ? "关闭" : "close";
            msg += (val == 1 ? msg1 : msg2);
            logHelper?.Invoke(msg);
        }

        public void LedandBuzz(Enm_LED led)
        {

            switch(led)
            {
                case Enm_LED.green:
                    Axis.SetDoSignl((short)Enm_Do.yellowLight + 1, 0);
                    Axis.SetDoSignl((short)Enm_Do.greenLight + 1, 1);
                    Axis.SetDoSignl((short)Enm_Do.redLight + 1, 0);
                    //Axis.SetDoSignl((short)Enm_Do.buzzer + 1, 0);
                    Global.isBuzzering = false;
                    //logHelper?.Invoke("显示绿灯");
                    break;
                case Enm_LED.red:
                    Axis.SetDoSignl((short)Enm_Do.yellowLight + 1, 0);
                    Axis.SetDoSignl((short)Enm_Do.greenLight + 1, 0);
                    Axis.SetDoSignl((short)Enm_Do.redLight + 1, 1);
                    Global.isBuzzering = true;
                    //logHelper?.Invoke("显示红灯");
                    break;
                case Enm_LED.yellow:
                    Axis.SetDoSignl((short)Enm_Do.yellowLight + 1, 1);
                    Axis.SetDoSignl((short)Enm_Do.greenLight + 1, 0);
                    Axis.SetDoSignl((short)Enm_Do.redLight + 1, 0);
                    Global.isBuzzering = false;
                    //logHelper?.Invoke("显示黄灯");
                    break;
                 default: break;
            }
            Buzzering(datas.dataConfig.isBuzing);
            Global.ledchange = 0;
        }

        public void Buzzering(bool isContinue=true)
        {
            if(!isContinue)
            {
                if (Global.isBuzzering)
                    Axis.SetDoSignl((short)Enm_Do.buzzer + 1, 1);
                else
                    Axis.SetDoSignl((short)Enm_Do.buzzer + 1, 0);
            }
            else
            {
                Task.Run(() =>
                {
                    while (true)
                    {
                        if (!Global.isBuzzering)
                        {
                            Axis.SetDoSignl((short)Enm_Do.buzzer + 1, 0);
                            break;
                        }
                        else
                        {
                            Axis.SetDoSignl((short)Enm_Do.buzzer + 1, 1);
                            Thread.Sleep(datas.dataConfig.buz_delyTime1);
                            Axis.SetDoSignl((short)Enm_Do.buzzer + 1, 0);
                            Thread.Sleep(datas.dataConfig.buz_delyTime2);
                        }
                    }
                });
            }

            
        }


        public void ChangeBuzzer(short val)
        {
            Global.isBuzzering = false;
            Axis.SetDoSignl((short)Enm_Do.buzzer + 1, val);
        }
        #endregion
        public string Init()
        {
            string strmsg = "";
            if (Axis.OpenCard() != 0)
            {
                string msg = Global.isZh ? "打开运动控制卡失败，请确认与其他软件不冲突后在重新打开。" : "Open RunControl is Fail,please sure other soft is not use it,then restart ";
                //logHelper?.Invoke(msg);
                strmsg = msg;
            }

            LoadData();
            mThread = new Thread(new ThreadStart(Do_Thread_Work));
            mThread.Priority = ThreadPriority.AboveNormal;
            mThread.Start();

            Thread.Sleep(300);
            Axis.ClearAlarmAll();
            Thread.Sleep(500);
            Axis.DoPowerAll();
            return strmsg;
        }
        public void InitEq()
        {
            Global.Currentnum = 3;
            Global.eqStatus = EquipStatus.init;
        }
        public void Pause()
        {
            Global.Currentnum = 0;
            Global.eqStatus = EquipStatus.pause;
        }
        public void Reset()
        {
            Global.Currentnum = 3;
            Global.eqStatus = EquipStatus.reset;
        }

        public void RecordLog(string msg)
        {
            try
            {
                lock(logobjlock)
                {
                    string dateTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                    string dateTimefile = DateTime.Now.ToString("yyyy-MM-dd");
                    msg = "["+dateTime+"]: "+msg;
                    string path = datas.dataConfig.other.logPath;
                    if(string.IsNullOrEmpty(path))
                    {
                        path = "D:\\log";
                    }
                    path = path + "\\" + DateTime.Now.ToString("yyyy-MM");
                    if (!Directory.Exists(path))
                    {
                        Directory.CreateDirectory(path);
                    }
                    path = path + "\\"  + dateTimefile+ "log.txt";
                    using (StreamWriter sw = new StreamWriter(path, true))
                    {
                        sw.WriteLine(msg);
                        sw.Flush();
                        sw.Close();
                    }   
                }
            }
            catch(Exception ex) 
            { 
                Console.WriteLine("write log is fail: "+ex.ToString());
            }
        }
        public bool Login(string username, string password)
        {
            bool ret=false;
            curUser.name = username;
            curUser.pwd = password;
            UserMode um = new UserMode(curUser);
            curUser=um.SelectOne(username);
            if (curUser == null)
            {
                ret = false;
                curUser = new User();
            }
            else
            {
                if(curUser.pwd==password)
                ret = true;
                else
                {
                    ret = false;
                    curUser = new User();
                }           
            }
            if (ret)
                logHelper?.Invoke(Global.isZh ? "用户登录成功":"user is login success");
            else
                logHelper?.Invoke(Global.isZh ? "用户登录失败":"user is login fail");
            Userlogin?.Invoke(curUser);
            return ret;
        }

        public void Logout()
        {
            curUser=new User();
            Userlogin?.Invoke(curUser);
            logHelper?.Invoke(Global.isZh?"用户注销":"user logout");
        }
        public void Do_Thread_Work() 
        {
            Global.eqStatus = EquipStatus.free;
            while (true)
            {
                //taskManager.StartProcess(null, null);
                CheckDiAll();
                //if (Global.timeGetTime() - time1 > 60000)
                //{
                //    ClientConn();
                //}
                switch (Global.eqStatus)
                {
                    case EquipStatus.run:
                        //Global.Currentnum = 1;
                        GetEuipsts(EquipStatus.run);
                        Global.eqStatus = EquipStatus.free;
                        taskManager.StartProcess(null, null);
                        //mainStsUpdate?.Invoke(EquipStatus.run);
                        break;
                    case EquipStatus.stop:
                        taskManager.currentStep = 0;
                        StopAxisAndTask();
                        Global.eqStatus = EquipStatus.free;
                        taskManager.PauseProcess(null, null);
                     
                        //mainStsUpdate?.Invoke(EquipStatus.stop);
                        break;
                    case EquipStatus.pause:
                        Global.eqStatus = EquipStatus.free;
                        taskManager.PauseProcess(null, null);
                        
                        //mainStsUpdate?.Invoke(EquipStatus.pause);
                        break;
                    case EquipStatus.reset:
                        AllInitOrReset();
                        break;
                    case EquipStatus.init:
                        AllInitOrReset();
                        break;
                    default:
                        //if (client1==null && client2 == null && client3 == null && Global.timeGetTime() - time1 > 60000)
                        //{
                        //    ClientConn();
                        //}
                        //CheckCurrentSts();
                        //CheckForceStop();
                        break;
                }
                Thread.Sleep(20);
            }
        }

        public void AllReset()
        {
            if (Global.Currentnum == 3)
            {
                client1 = null;
                client2 = null;
                client3 = null;
                timeinit = Global.timeGetTime();
                Axis.GoHomeAll();
                GetEuipsts(EquipStatus.run);
                Global.Currentnum -= 1;
            }
            Thread.Sleep(800);
            if (Global.Currentnum > 0 && GetEqStopSts())
            {
                Thread.Sleep(2000);
                //Axis.ClearPosAll();
                //Thread.Sleep(1000);
                Axis.GetEnposAll();
                Thread.Sleep(20);
                if (Axis.enpos[0] == 0 && Axis.enpos[1] == 0 && Axis.enpos[2] == 0)
                {
                    Global.eqStatus = EquipStatus.free;
                    GetEuipsts(EquipStatus.stop);
                    Global.Currentnum = 0;
                    mainStsUpdate?.Invoke(EquipStatus.reset);
                    //CheckjackPos(0);
                    //CheckblockPos(0);
                }
                else
                {
                    Global.Currentnum = 2;
                    Global.eqStatus = EquipStatus.reset;
                }
               
            }
            else if (Global.timeGetTime() - timeinit > 60000)
            {

                logHelper?.Invoke(Global.isZh ? "轴异常，回原失败，请检查轴" : "Axis exception, GoHome failed, please check the axis");
            }
            taskManager.currentStep = 0;
        }
        public void PowerAll()
        {
            bool ret = Axis.en[0] & Axis.en[1] & Axis.en[2];
            for (int i = 0; i < 3; i++)
            {
                  Axis.DoPower((short)(i + 1), !ret);
            }
            
        }
        public void AllInitOrReset()
        {
            if (Global.Currentnum == 3)
            {
                timeinit = Global.timeGetTime();
                Axis.Open();
                Axis.DoPowerAll();
                
                GetEuipsts(EquipStatus.run);
                //AllReset();
                Axis.GoHomeAll();
                Global.Currentnum -= 1;
            }
            Thread.Sleep(1000);
            if (Global.Currentnum > 0 && GetEqStopSts())
            {
                Thread.Sleep(2000);
                Axis.ClearPosAll();
                Thread.Sleep(100);
                Axis.GetEnposAll();
                Thread.Sleep(20);
                if (Axis.enpos[0] == 0 && Axis.enpos[1] == 0 && Axis.enpos[2] == 0)
                {
                    Global.eqStatus = EquipStatus.free;
                    GetEuipsts(EquipStatus.stop);
                    Global.Currentnum = 0;
                    mainStsUpdate?.Invoke(EquipStatus.reset);
                    //CheckjackPos(0);
                    //CheckblockPos(0);
                }
                else
                {
                    Global.Currentnum = 2;
                    Global.eqStatus = EquipStatus.reset;
                }
                
            }
            else if (Global.timeGetTime() - timeinit > 60000)
            {

                logHelper?.Invoke(Global.isZh ? "轴异常，初始化失败，请检查轴" : "Axis exception, initialization failed, please check the axis");
            }
            taskManager.currentStep = 0;
        }
        public void Start(int num=0)
        {
            Global.Currentnum = 1;
            taskManager.currentStep = num;
            //taskManager.StartProcess(null,null);
            Global.eqStatus = EquipStatus.run;

        }

        public void CheckjackPos(short num)
        {
            if(!IsCreatePro())
            {
                return;
            }
            Projecter pa = datas.dataConfig.pro.projectBases[datas.dataConfig.pro.index].item;
            Axis.GetDi();
            if(num==0)
            {
                if (!Axis.axis_di[pa.Jack_Air])
                {
                    Alarming(Global.isZh ? "顶升气缸未在原位，请检查气阀是否打开": "The jack cylinder is not in the initial position. Please check if the air valve is open");
                }
            }else if (num==1)
            {
                if (!Axis.axis_di[pa.Jack_Air])
                {
                    Alarming(Global.isZh ? "顶升气缸未在动位，请检查气阀是否打开": "The jack cylinder is not in the moving position. Please check if the air valve is open");
                }
            }  
        }
        public void CheckblockPos(short num)
        {
            if (!IsCreatePro())
            {
                return;
            }
            Projecter pa = datas.dataConfig.pro.projectBases[datas.dataConfig.pro.index].item;
            Axis.GetDi();
            if (num == 0)
            {
                //if (!Axis.axis_di[(int)Enm_Di.blockHomePos])
                if (!Axis.axis_di[pa.Block_Air])
                {
                    Alarming(Global.isZh ? "阻挡气缸未在原位，请检查气阀是否打开" : "The blocking cylinder is not in the initial position. Please check if the air valve is open");
                }
            }
            else if (num == 1)
            {
                if (!Axis.axis_di[pa.Block_Air])
                {
                    Alarming(Global.isZh?"阻挡气缸未在动位，请检查气阀是否打开": "The blocking cylinder is not in the moving position. Please check if the air valve is open");
                }
            }
        }
        public void DoZeroPos()
        {
            Postion zero = new Postion();
            zero.X = 0;
            zero.Y = 0;
            zero.Z = 0;
            MoveTrap(zero,5);
        }
        public bool GetEqStopSts()
        {
            bool eqSts = false;
            Axis.GetAxisStas();
            if(Axis.axisSts[0] == Global.sts_axisstopSts && Axis.axisSts[1] == Global.sts_axisstopSts && Axis.axisSts[2] == Global.sts_axisstopSts)
                eqSts = true;
            return eqSts;
        }
        public bool GetEqRunSts()
        {
            bool eqSts = false;
            Axis.GetAxisStas();
            bool ret1 = Axis.axisSts[0] == Global.sts_axisrunSts1 || Axis.axisSts[0] == Global.sts_axisrunSts2;
            bool ret2 = Axis.axisSts[1] == Global.sts_axisrunSts1 || Axis.axisSts[1] == Global.sts_axisrunSts2;
            bool ret3 = Axis.axisSts[2] == Global.sts_axisrunSts1 || Axis.axisSts[2] == Global.sts_axisrunSts2;
            if (ret1 || ret2 || ret3)
                eqSts = true;
            return eqSts;
        }

        public Enm_Axis GetAxisSts()
        {
            Enm_Axis enm_Axis = Enm_Axis.alnormal;
            Axis.GetAxisStas();
            bool ret1 = Axis.axisSts[0] == Global.sts_axisrunSts1 || Axis.axisSts[0] == Global.sts_axisrunSts2;
            bool ret2 = Axis.axisSts[1] == Global.sts_axisrunSts1 || Axis.axisSts[1] == Global.sts_axisrunSts2;
            bool ret3 = Axis.axisSts[2] == Global.sts_axisrunSts1 || Axis.axisSts[2] == Global.sts_axisrunSts2;
            bool ret5 = Axis.axisSts[0] == Global.sts_axisstopSts || ret1;
            bool ret6 = Axis.axisSts[1] == Global.sts_axisstopSts || ret2;
            bool ret7 = Axis.axisSts[2] == Global.sts_axisstopSts || ret3;
            //logHelper?.Invoke(string.Format("轴1：{0}，轴2：{1}，轴3：{2}", Axis.axisSts[0], Axis.axisSts[1], Axis.axisSts[2]));

            if (!ret6 || !ret6 || !ret7)
            {
                bool ret8 = Axis.axisSts[0] == Global.sts_axisrunStsNoPower;
                bool ret9 = Axis.axisSts[1] == Global.sts_axisrunStsNoPower;
                bool ret10 = Axis.axisSts[2] == Global.sts_axisrunStsNoPower;
                
                if(ret8 && ret9 && ret10)
                {
                    enm_Axis = Enm_Axis.nopower;
                }
                else
                {
                    enm_Axis = Enm_Axis.alnormal;
                    GetEuipsts(EquipStatus.alarm);
                }
            }
            else if (ret1 || ret2 || ret3)
            {
                enm_Axis = Enm_Axis.run;
            }
            else if (Axis.axisSts[0] == Global.sts_axisstopSts && Axis.axisSts[1] == Global.sts_axisstopSts && Axis.axisSts[2] == Global.sts_axisstopSts)
            {
                enm_Axis = Enm_Axis.stop;
            }
            else
            {
                Console.WriteLine(Global.isZh?"轴状态获取异常":"axis status get alnormal");
                GetEuipsts(EquipStatus.alarm);
            }
            axisStsUpdate?.Invoke(enm_Axis);
            _Axis=enm_Axis;
            return enm_Axis;
        }
        public void CheckDiAll()
        {
            Axis.GetDi();
            Axis.GetDo();
            CheckForceStop();
            CheckLight();
            GetAxisSts();
        }
        public void CheckLedCurrentSts()
        {
            //if (Global.axisSts== EquipStatus.alarm)
            //{
            //    Global.axisSts = EquipStatus.alarm;
            //}
            //else
            if (Global.ledchange==0 )
            {
                return;
            }
            //Global.Currentnumold = Global.Currentnum;
            switch (Global.axisSts)
            {
                case EquipStatus.init:
                case EquipStatus.reset:
                case EquipStatus.run:
                    LedandBuzz(Enm_LED.green);
                    break;
                case EquipStatus.pause:
                case EquipStatus.stop:
                    LedandBuzz(Enm_LED.yellow);
                    break;

                case EquipStatus.alarm:
                    LedandBuzz(Enm_LED.red);
                    //Alarming();
                    break;
                
                default :
                    break;
                    
            }
        }
        public void Alarming(string msg,bool isstop=true)
        {
            logHelper?.Invoke(Global.isZh?"触发报警：" + msg : "triggered alarm: " + msg);
            Global.Currentnum = 0;
            alarmsUpdate?.Invoke(msg);
            if (isstop)
                AxisStop();
            Task.Delay(300);
            GetEuipsts(EquipStatus.alarm);
        }
        public void ClearAlarming()
        {
            Axis.ClearAlarmAll();
            Task.Delay(1000);
            CheckDiAll();
        }
        public void CheckLight()
        {
            if (Axis.axis_di[(int)Enm_Di.light])
            {
                if (!Axis.axis_do[(int)Enm_Do.lighting])
                {
                    logHelper?.Invoke(Global.isZh ? "手动触发照明打开信号" : "tigger light on signal");
                    DoWrite((Enm_Do.lighting), 1);
                }
                    
            }else
            {
                if (Axis.axis_do[(int)Enm_Do.lighting])
                {
                    logHelper?.Invoke(Global.isZh ? "手动触发照明关闭信号" : "tigger light off signal");
                    DoWrite((Enm_Do.lighting), 0);
                }
                    
            }
        }
        public void CheckForceStop()
        {
            if (Axis.axis_di[(int)Enm_Di.forceStop] && Global.Currentnum != -1)
            {
                taskManager.PauseProcess(null, null);
                Alarming(Global.isZh?"急停触发": "Force stop signal triggered");
                StopAxisAndTask();
                Task.Delay(300);
                GetEuipsts(EquipStatus.alarm);
                Global.Currentnum = -1;
                mainStsUpdate?.Invoke(EquipStatus.alarm);
            }

        }

        public void PauseAxisAndTask()
        {
            TranspotRunorStop(0, false);
            
            GetEuipsts(EquipStatus.stop);
            //Global.Currentnum = 0;
        }
        public void StopAxisAndTask()
        {
            AxisStop();
            JackAirUporDown(0);
            PauseAxisAndTask();
            
            //GetEuipsts(EquipStatus.stop);
            //Global.Currentnum = 0;
        }
        public void GetEuipsts(EquipStatus item)
        {
            if (Global.axisSts !=item)
            {
                Global.ledchange = 1;
                Global.axisSts = item;
            }
            CheckLedCurrentSts();
        }
        public void Stop()
        {
            Global.Currentnum = 0;
            Global.eqStatus = EquipStatus.stop;
            //Axis.StopAll();
           
        }

       

    }
}
