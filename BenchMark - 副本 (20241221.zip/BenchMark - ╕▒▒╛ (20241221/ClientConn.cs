﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace BenchMark
{
    public class ClientConn:IDisposable
    {
        private TcpClient _client;
        private NetworkStream _stream;
        public bool _isRunning;
        private Thread _receiveThread;
        public string receivedMessage;
        public string sendMsg;
        public Action<string> receivedAction;

        public ClientConn(string serverIp, int serverPort)
        {
            _client = new TcpClient();
            Task.Run(async () => await ConnectAsync(serverIp, serverPort));
        }

        private async Task ConnectAsync(string serverIp, int serverPort)
        {
            try
            {
                await _client.ConnectAsync(serverIp, serverPort);
                _stream = _client.GetStream();
                _isRunning = true;
                StartReceiving();
                Console.WriteLine("Connected to server.");
            }
            catch (Exception ex)
            {
                _client = null;
                Console.WriteLine($"Failed to connect: {ex.Message}");
            }
        }
        private byte[] HexToByteArry(string hex)
        {
            int num = hex.Length;
            byte[] bytes = new byte[num / 2];
            for (int i = 0; i < num; i += 2)
            {
                bytes[i / 2] = Convert.ToByte(hex.Substring(i, 2), 16);
            }
            return bytes;
        }
        public async Task SendMessageAsync(string message,bool isStr=true)
        {
            try
            {
                if (!_isRunning)
                    throw new InvalidOperationException("Client is not connected.");

                byte[] data = Encoding.UTF8.GetBytes(message);
                if(isStr)
                    data = Encoding.UTF8.GetBytes(message);
                else
                    data = HexToByteArry(message);
                await _stream.WriteAsync(data, 0, data.Length);
                sendMsg = $"Sent: {message}";
                Console.WriteLine($"Sent: {message}");
            }
            catch (Exception ex)
            {
                _client=null;
            }
           
        }

        private void StartReceiving()
        {
            _receiveThread = new Thread(ReceiveData);
            _receiveThread.IsBackground = true;
            _receiveThread.Start();
        }

        private void ReceiveData()
        {
            byte[] buffer = new byte[1024];
            int bytesRead;

            while (_isRunning)
            {
                try
                {
                    if (_stream.DataAvailable)
                    {
                        bytesRead = _stream.Read(buffer, 0, buffer.Length);
                        receivedMessage = Encoding.UTF8.GetString(buffer, 0, bytesRead);
                        string msgtemp = sendMsg + ":" + $"Received: {receivedMessage}";
                        Task.Run(() => { receivedAction?.Invoke(msgtemp); });
                        Console.WriteLine($"Received: {receivedMessage}");
                        sendMsg = "";
                        receivedMessage = "";
                        // Here you can process the received message as needed  
                    }
                    Thread.Sleep(1); // Prevent tight loop  
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error receiving data: {ex.Message}");
                    Stop();
                }
            }
        }

        public void Stop()
        {
            _isRunning = false;
            _receiveThread?.Join();
            _client?.Close();
            _stream?.Dispose();
            Console.WriteLine("Client stopped.");
        }

        public void Dispose()
        {
            Stop();
        }
    }
}
