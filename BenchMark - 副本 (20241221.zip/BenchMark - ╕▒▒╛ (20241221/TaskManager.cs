﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace BenchMark
{
    public class TaskManager
    {
        public CancellationTokenSource cts = new CancellationTokenSource();
        public Task executionTask;
        public int currentStep = 0;
        public Action<CancellationToken> taskAction;
        public Action<CancellationToken> taskAction1;
        public Action<CancellationToken> taskAction2;
        public Action<CancellationToken> taskAction3;
        public Action<CancellationToken> taskAction4;
        public Action<CancellationToken> taskAction5;
        public Action<CancellationToken> taskAction6; 
        public Action<CancellationToken> taskAction7;
        public Action<CancellationToken> taskAction8;
        public Action<CancellationToken> taskAction9;
        public Action<CancellationToken> taskAction10;
        public Action<CancellationToken> taskAction11;
        public Action<CancellationToken> taskAction12;
        public Action<CancellationToken> taskAction13;
        public Action<CancellationToken> taskAction14;
        public Action<CancellationToken> taskAction15;
        public Action<CancellationToken> taskAction16;
        public Action<CancellationToken> taskAction17;
        public Action<CancellationToken> taskAction18;
        public Action<CancellationToken> taskAction19;
        public Action<CancellationToken> taskAction20;
        public Action<CancellationToken> taskAction21;
        public Action<CancellationToken> taskAction22;
        public Action<CancellationToken> taskAction99;
        public Action stopAction;
        public Action<string> logger;
        public bool isStop = false;
        public async void StartProcess(object sender, EventArgs e)
        {
            // 重置CancellationTokenSource  
            cts = new CancellationTokenSource();

            // 开始执行流程  
            executionTask = Task.Run(() => ExecuteProcess(cts.Token), cts.Token);
            //Global.eqStatus = EquipStatus.run;
            // 注意：如果需要在UI中更新状态，请使用Invoke或BeginInvoke来确保线程安全  
        }
        public async Task ExecuteProcess(CancellationToken token)
        {
            try
            {
                //if (currentStep >= 5)
                //    currentStep = 0;
                // 检查是否已请求取消  
                token.ThrowIfCancellationRequested();
                // 模拟一个耗时的操作  
                //await Task.Delay(1000, token); // 等待1秒 
                //for (int i = currentStep; i < 5; i++)
                switch (currentStep)
                {
                    case 0:
                    taskAction?.Invoke(token);
                    // 更新当前步骤（这里只是打印到控制台，实际中可能需要更新UI）  
                    //Console.WriteLine($"Executing step {i + 1}");
                    // 如果需要更新UI，请使用Invoke或BeginInvoke  
                    //logger?.Invoke($"Executing step {currentStep+1}");
                        // 假设currentStep用于跟踪流程进度，但在这个简单示例中不需要  
                        //currentStep = i + 1;
                        break;
                    case 1:
                        taskAction1?.Invoke(token);
                        break; 
                    case 2:
                        taskAction2?.Invoke(token);
                        break; 
                    case 3:
                        taskAction3?.Invoke(token);
                        break;
                    case 4:
                        taskAction4?.Invoke(token);
                        break;
                    case 5:
                        taskAction5?.Invoke(token);
                        break;
                    case 6:
                        taskAction6?.Invoke(token);
                        break;
                    case 7:
                        taskAction7?.Invoke(token);
                        break;
                    case 8:
                        taskAction8?.Invoke(token);
                        break;
                    case 9:
                        taskAction9?.Invoke(token);
                        break;
                        case 10:
                            taskAction10?.Invoke(token);
                        break;
                        case 11:    
                            taskAction11?.Invoke(token);
                        break;
                        case 12:
                            taskAction12?.Invoke(token);
                        break;
                        case 13:
                            taskAction13?.Invoke(token);
                        break;
                        case 14:
                            taskAction14?.Invoke(token);
                        break;
                        case 15:
                            taskAction15?.Invoke(token);
                        break;
                        case 16:
                            taskAction16?.Invoke(token);
                        break;

                        case 17:
                            taskAction17?.Invoke(token);
                        break;
                        case 18:
                            taskAction18?.Invoke(token);
                        break;
                        case 19:
                        taskAction19?.Invoke(token);
                        break;
                    case 20:
                        taskAction20?.Invoke(token);
                        break;
                    case 21:
                        taskAction21.Invoke(token);
                        break;
                    case 22:
                        taskAction22?.Invoke(token);
                        break;
                    case 99:
                        taskAction99?.Invoke(token);
                        break;
                    default:break;
                }

                //Console.WriteLine("Process completed.");
            }
            catch (OperationCanceledException)
            {
                //stopAction?.Invoke();
                //Global.eqStatus = EquipStatus.stop;
                //Console.WriteLine("Process cancelled.");
            }
            catch (Exception ex)
            {
                //stopAction?.Invoke();
                //Global.eqStatus = EquipStatus.stop;
                // 处理其他异常  
                //Console.WriteLine($"An error occurred: {ex.Message}");
            }
        }
        public void PauseProcess(object sender, EventArgs e)
        {
            // 请求取消当前任务  
            if (cts != null && !cts.IsCancellationRequested)
            {
                cts.Cancel();
                stopAction?.Invoke();
                //Global.eqStatus = EquipStatus.stop;
            }
        }
    }


}
