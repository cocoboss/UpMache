﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace BenchMark
{
    public class Data
    {
        public List<Postion> posLists =new List<Postion>();
        //public List<DelyTime> delyTimeLists = new List<DelyTime>();
        //public Postion d2PosStart=new Postion ();
        //public Postion d2PosEnd=new Postion ();
        //public Postion d3Pos1Start = new Postion();
        //public Postion d3Pos1End = new Postion();
        //public Postion d3Pos2Start = new Postion();
        //public Postion d3Pos2End = new Postion();
    }
    public class DelyTime
    {
        public int id;
        public string name;
        public string val;
    }
    public class AxleParams
    {
        public ParaamSigle x_axle ;
        public ParaamSigle y_axle;
        public ParaamSigle z_axle;
        public ParaamSigle k_axle;
        public ParaamSigle g_axle;

        public AxleParams(ParaamSigle paraam1, ParaamSigle paraam2, ParaamSigle paraam3, ParaamSigle paraam4, ParaamSigle paraam5) {
            x_axle = paraam1;
            y_axle = paraam2;   
            z_axle = paraam3;
            k_axle= paraam4;
            g_axle= paraam5;
        }
    }
    public class OtherParam
    {
        public string smtPath;
        public string logPath="D:\\log";
        public string cfgPath = "\\cfg\\GT800_test.cfg";
    }
    public class Postion
    {
        public double X;
        public double Y;
        public double Z;
        public Postion()
        {
            X = 0;
            Y = 0;
            Z = 0;
        }
    }
    public class ParaamSigle:BaseParam
    {
        public short axis;
        public ParaamSigle(short id)
        {
            axis = id;
        }
    }
    public class BaseParam
    {
        public double val=5;
        public double acc = 0.1;
        public double dcc = 0.1;
        public double rightLimitpos = 5000;
        public double leftLimitpos = -5;
        public double plse_mm = 5;
        public int smoothTime = 3;
    }
    
}
