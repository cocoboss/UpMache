﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace BenchMark
{
    public partial class FormLogin : Form
    {
        public FormLogin()
        {
            InitializeComponent();
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string name=txt_name.Text.Trim();
            string pwd = txt_pwd.Text.Trim();
            if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(pwd))
            {
                MessageBox.Show(Global.isZh?"用户名或密码不能为空": "Username or password cannot be empty");
            }
            else
            {
                if (MainThread.Instance().Login(name, pwd))
                {
                    this.Close();
                }
                else
                {
                    MessageBox.Show(Global.isZh ? "用户名或密码错误": "Incorrect username or password");
                }
            }
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MainThread.Instance().Userlogin?.Invoke(null);
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            
            Global.Changed();
            Show(Global.isZh);
            string msg = Global.isZh ? "切换为中文" : "Switch to English";
            MainThread.Instance().logHelper?.Invoke(msg);
        }
        private void Show(bool isZh)
        {
            if (!isZh)
            {
                Thread.CurrentThread.CurrentUICulture = new CultureInfo("en-US");
                Global.LoadLanguage(this, typeof(FormLogin));
            }
            else
            {
                Thread.CurrentThread.CurrentUICulture = new CultureInfo("zh-CN");
                Global.LoadLanguage(this, typeof(FormLogin));
            }
        }

        private void FormLogin_Load(object sender, EventArgs e)
        {
            Show(Global.isZh);
        }
    }
}
