﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BenchMark
{
    public partial class DataForm : Form
    {
        Productdatas data;
        int header=0;
        public DataForm()
        {
            InitializeComponent();
        }
        public void UpdateDatas()
        {
            int temp = 0;
            Global.ControlInvocke(datalst, () =>
            {
                datalst.Rows.Insert(temp,
                    //data.id,
                    data.sn,
                    data.result,
                    data.length,
                    data.width,
                    data.height,
                    data.total_s,
                    data.dj_cc,
                    data.all_cc,
                    data.dj_num,
                    data.mark
                    );
                datalst.Rows[temp].HeaderCell.Value=string.Format("{0}",++header);
                datalst.FirstDisplayedScrollingRowIndex = temp;
                if(datalst.Rows.Count > 1000 )
                {
                    datalst.Rows.RemoveAt(datalst.Rows.Count - 1 - 1);
                }
            });
        }
    }
}
