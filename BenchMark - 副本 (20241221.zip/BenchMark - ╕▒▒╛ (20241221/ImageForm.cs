﻿//using SciSmtCamLib;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BenchMark
{
    public partial class ImageForm : Form
    {

        //SciEngine m_engine;
        //Thread sci;
        public ImageForm()
        {
            InitializeComponent();
        }

        private void ImageForm_Load(object sender, EventArgs e)
        {
            //sci = new Thread(new ThreadStart(DoWorkSci));
            //sci.Start();
        }
        //public void DoWorkSci()
        //{
        //    #region 嵌入OPT界面
        //    try
        //    {
        //        Global.ControlInvocke(this, () =>
        //        {
        //            m_engine = new SciEngine();
        //            m_engine.InitEngine();
        //            m_engine.SetMsgWindow((long)this.Handle);
        //            m_engine.RunMode();
        //            m_engine.ConnectRunWnd(0, (long)pictureBox1.Handle);
        //            ////The height of the title is approximately 30 pixels.
        //            m_engine.MoveRunWindow(0, 0, 30, pictureBox1.Right - pictureBox1.Left, pictureBox1.Bottom - pictureBox1.Top);
        //            string strPath = MainThread.Instance().datas.dataConfig.other.smtPath;
        //            if (string.IsNullOrEmpty(strPath))
        //            {
        //                openFileDialog1.Filter = "SMT文件|*.smt";
        //                openFileDialog1.Multiselect = false;
        //                strPath = openFileDialog1.FileName;
        //                MainThread.Instance().datas.dataConfig.other.smtPath = strPath;
        //                FileDeal.SaveFile(MainThread.Instance().datas.dataConfig);
        //            }
        //            m_engine.OpenProject(strPath);
        //            this.Resize += MainForm_Resize;
        //        });
        //    }catch (Exception ex)
        //    {
        //        string msg = ex.Message+ (Global.isZh?"图像加载失败":"Images load is fail ");
        //        MainThread.Instance().logHelper?.Invoke(msg);
        //    }

        //    #endregion
        //}

        //private void MainForm_Resize(object sender, EventArgs e)
        //{

        //    m_engine.RunMode();

        //    m_engine.ConnectRunWnd(0, (long)pictureBox1.Handle);

        //    m_engine.MoveRunWindow(0, 0, 30, pictureBox1.Right - pictureBox1.Left, pictureBox1.Bottom - pictureBox1.Top);
        //}
    }
}
