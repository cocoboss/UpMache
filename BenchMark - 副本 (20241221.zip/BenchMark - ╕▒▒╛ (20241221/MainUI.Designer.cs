﻿

namespace BenchMark
{
    partial class MainUI
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Timer Timer;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainUI));
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.文件ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiNew = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiNew2 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiOpen = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiSave = new System.Windows.Forms.ToolStripMenuItem();
            this.语言ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiEnglish = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiChinese = new System.Windows.Forms.ToolStripMenuItem();
            this.帮助ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiLog = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tsmiAboutUs = new System.Windows.Forms.ToolStripMenuItem();
            this.工具ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiQuickSetting = new System.Windows.Forms.ToolStripMenuItem();
            this.数据报表ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lblCOMPANY = new System.Windows.Forms.Label();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.labpos = new System.Windows.Forms.Label();
            this.labinformation = new System.Windows.Forms.Label();
            this.labmessage = new System.Windows.Forms.Label();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btn_feeding_off = new System.Windows.Forms.Button();
            this.btn_feeding_on = new System.Windows.Forms.Button();
            this.ckbSaveData = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.checkBox_AI = new System.Windows.Forms.CheckBox();
            this.btnReset = new System.Windows.Forms.Button();
            this.label_user = new System.Windows.Forms.Label();
            this.btnUser = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnDataClear = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btnPerformance = new System.Windows.Forms.Button();
            this.btnDischarge = new System.Windows.Forms.Button();
            this.btnStop = new System.Windows.Forms.Button();
            this.btnStart = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            Timer = new System.Windows.Forms.Timer(this.components);
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // Timer
            // 
            Timer.Enabled = true;
            Timer.Interval = 300;
            Timer.Tick += new System.EventHandler(this.Timer_Tick);
            // 
            // folderBrowserDialog1
            // 
            resources.ApplyResources(this.folderBrowserDialog1, "folderBrowserDialog1");
            // 
            // saveFileDialog1
            // 
            resources.ApplyResources(this.saveFileDialog1, "saveFileDialog1");
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            resources.ApplyResources(this.openFileDialog1, "openFileDialog1");
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 500;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // tableLayoutPanel1
            // 
            resources.ApplyResources(this.tableLayoutPanel1, "tableLayoutPanel1");
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel3, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel4, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.panel3, 0, 1);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            // 
            // tableLayoutPanel2
            // 
            resources.ApplyResources(this.tableLayoutPanel2, "tableLayoutPanel2");
            this.tableLayoutPanel2.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel2.Controls.Add(this.menuStrip1, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.lblCOMPANY, 0, 0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            // 
            // menuStrip1
            // 
            resources.ApplyResources(this.menuStrip1, "menuStrip1");
            this.menuStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(86)))), ((int)(((byte)(140)))));
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.文件ToolStripMenuItem,
            this.语言ToolStripMenuItem,
            this.帮助ToolStripMenuItem,
            this.工具ToolStripMenuItem});
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            this.menuStrip1.DoubleClick += new System.EventHandler(this.menuStrip1_DoubleClick);
            // 
            // 文件ToolStripMenuItem
            // 
            resources.ApplyResources(this.文件ToolStripMenuItem, "文件ToolStripMenuItem");
            this.文件ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiNew,
            this.tsmiNew2,
            this.tsmiOpen,
            this.tsmiSave});
            this.文件ToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(69)))), ((int)(((byte)(191)))), ((int)(((byte)(235)))));
            this.文件ToolStripMenuItem.Name = "文件ToolStripMenuItem";
            // 
            // tsmiNew
            // 
            resources.ApplyResources(this.tsmiNew, "tsmiNew");
            this.tsmiNew.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(69)))), ((int)(((byte)(191)))), ((int)(((byte)(235)))));
            this.tsmiNew.Name = "tsmiNew";
            this.tsmiNew.Click += new System.EventHandler(this.tsmiNew_Click);
            // 
            // tsmiNew2
            // 
            resources.ApplyResources(this.tsmiNew2, "tsmiNew2");
            this.tsmiNew2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(69)))), ((int)(((byte)(191)))), ((int)(((byte)(235)))));
            this.tsmiNew2.Name = "tsmiNew2";
            this.tsmiNew2.Click += new System.EventHandler(this.tsmiNew2_Click);
            // 
            // tsmiOpen
            // 
            resources.ApplyResources(this.tsmiOpen, "tsmiOpen");
            this.tsmiOpen.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(69)))), ((int)(((byte)(191)))), ((int)(((byte)(235)))));
            this.tsmiOpen.Name = "tsmiOpen";
            this.tsmiOpen.Click += new System.EventHandler(this.tsmiOpen_Click);
            // 
            // tsmiSave
            // 
            resources.ApplyResources(this.tsmiSave, "tsmiSave");
            this.tsmiSave.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(69)))), ((int)(((byte)(191)))), ((int)(((byte)(235)))));
            this.tsmiSave.Name = "tsmiSave";
            this.tsmiSave.Click += new System.EventHandler(this.tsmiSave_Click);
            // 
            // 语言ToolStripMenuItem
            // 
            resources.ApplyResources(this.语言ToolStripMenuItem, "语言ToolStripMenuItem");
            this.语言ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiEnglish,
            this.tsmiChinese});
            this.语言ToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(69)))), ((int)(((byte)(191)))), ((int)(((byte)(235)))));
            this.语言ToolStripMenuItem.Name = "语言ToolStripMenuItem";
            // 
            // tsmiEnglish
            // 
            resources.ApplyResources(this.tsmiEnglish, "tsmiEnglish");
            this.tsmiEnglish.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(69)))), ((int)(((byte)(191)))), ((int)(((byte)(235)))));
            this.tsmiEnglish.Name = "tsmiEnglish";
            // 
            // tsmiChinese
            // 
            resources.ApplyResources(this.tsmiChinese, "tsmiChinese");
            this.tsmiChinese.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(69)))), ((int)(((byte)(191)))), ((int)(((byte)(235)))));
            this.tsmiChinese.Name = "tsmiChinese";
            // 
            // 帮助ToolStripMenuItem
            // 
            resources.ApplyResources(this.帮助ToolStripMenuItem, "帮助ToolStripMenuItem");
            this.帮助ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiLog,
            this.toolStripSeparator1,
            this.tsmiAboutUs});
            this.帮助ToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(69)))), ((int)(((byte)(191)))), ((int)(((byte)(235)))));
            this.帮助ToolStripMenuItem.Name = "帮助ToolStripMenuItem";
            // 
            // tsmiLog
            // 
            resources.ApplyResources(this.tsmiLog, "tsmiLog");
            this.tsmiLog.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(69)))), ((int)(((byte)(191)))), ((int)(((byte)(235)))));
            this.tsmiLog.Name = "tsmiLog";
            // 
            // toolStripSeparator1
            // 
            resources.ApplyResources(this.toolStripSeparator1, "toolStripSeparator1");
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            // 
            // tsmiAboutUs
            // 
            resources.ApplyResources(this.tsmiAboutUs, "tsmiAboutUs");
            this.tsmiAboutUs.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(69)))), ((int)(((byte)(191)))), ((int)(((byte)(235)))));
            this.tsmiAboutUs.Name = "tsmiAboutUs";
            this.tsmiAboutUs.Click += new System.EventHandler(this.tsmiAboutUs_Click);
            // 
            // 工具ToolStripMenuItem
            // 
            resources.ApplyResources(this.工具ToolStripMenuItem, "工具ToolStripMenuItem");
            this.工具ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiQuickSetting,
            this.数据报表ToolStripMenuItem});
            this.工具ToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(69)))), ((int)(((byte)(191)))), ((int)(((byte)(235)))));
            this.工具ToolStripMenuItem.Name = "工具ToolStripMenuItem";
            // 
            // tsmiQuickSetting
            // 
            resources.ApplyResources(this.tsmiQuickSetting, "tsmiQuickSetting");
            this.tsmiQuickSetting.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(69)))), ((int)(((byte)(191)))), ((int)(((byte)(235)))));
            this.tsmiQuickSetting.Name = "tsmiQuickSetting";
            this.tsmiQuickSetting.Click += new System.EventHandler(this.tsmiQuickSetting_Click);
            // 
            // 数据报表ToolStripMenuItem
            // 
            resources.ApplyResources(this.数据报表ToolStripMenuItem, "数据报表ToolStripMenuItem");
            this.数据报表ToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(69)))), ((int)(((byte)(191)))), ((int)(((byte)(235)))));
            this.数据报表ToolStripMenuItem.Name = "数据报表ToolStripMenuItem";
            this.数据报表ToolStripMenuItem.Click += new System.EventHandler(this.数据报表ToolStripMenuItem_Click);
            // 
            // lblCOMPANY
            // 
            resources.ApplyResources(this.lblCOMPANY, "lblCOMPANY");
            this.lblCOMPANY.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(7)))), ((int)(((byte)(62)))), ((int)(((byte)(104)))));
            this.lblCOMPANY.ForeColor = System.Drawing.Color.Yellow;
            this.lblCOMPANY.Name = "lblCOMPANY";
            this.lblCOMPANY.DoubleClick += new System.EventHandler(this.menuStrip1_DoubleClick);
            // 
            // tableLayoutPanel3
            // 
            resources.ApplyResources(this.tableLayoutPanel3, "tableLayoutPanel3");
            this.tableLayoutPanel3.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel3.Controls.Add(this.labpos, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.labinformation, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.labmessage, 0, 0);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            // 
            // labpos
            // 
            resources.ApplyResources(this.labpos, "labpos");
            this.labpos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(86)))), ((int)(((byte)(140)))));
            this.labpos.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.labpos.ForeColor = System.Drawing.Color.Black;
            this.labpos.Name = "labpos";
            // 
            // labinformation
            // 
            resources.ApplyResources(this.labinformation, "labinformation");
            this.labinformation.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(86)))), ((int)(((byte)(140)))));
            this.labinformation.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.labinformation.ForeColor = System.Drawing.Color.Green;
            this.labinformation.Name = "labinformation";
            // 
            // labmessage
            // 
            resources.ApplyResources(this.labmessage, "labmessage");
            this.labmessage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(86)))), ((int)(((byte)(140)))));
            this.labmessage.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.labmessage.ForeColor = System.Drawing.Color.Red;
            this.labmessage.Name = "labmessage";
            // 
            // tableLayoutPanel4
            // 
            resources.ApplyResources(this.tableLayoutPanel4, "tableLayoutPanel4");
            this.tableLayoutPanel4.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel4.Controls.Add(this.tableLayoutPanel5, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.panel2, 0, 0);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            // 
            // tableLayoutPanel5
            // 
            resources.ApplyResources(this.tableLayoutPanel5, "tableLayoutPanel5");
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            // 
            // panel2
            // 
            resources.ApplyResources(this.panel2, "panel2");
            this.panel2.BackColor = System.Drawing.Color.Transparent;
            this.panel2.Name = "panel2";
            // 
            // panel3
            // 
            resources.ApplyResources(this.panel3, "panel3");
            this.panel3.BackColor = System.Drawing.Color.Transparent;
            this.panel3.Controls.Add(this.btn_feeding_off);
            this.panel3.Controls.Add(this.btn_feeding_on);
            this.panel3.Controls.Add(this.ckbSaveData);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.checkBox_AI);
            this.panel3.Controls.Add(this.btnReset);
            this.panel3.Controls.Add(this.label_user);
            this.panel3.Controls.Add(this.btnUser);
            this.panel3.Controls.Add(this.btnClose);
            this.panel3.Controls.Add(this.btnDataClear);
            this.panel3.Controls.Add(this.button1);
            this.panel3.Controls.Add(this.btnPerformance);
            this.panel3.Controls.Add(this.btnDischarge);
            this.panel3.Controls.Add(this.btnStop);
            this.panel3.Controls.Add(this.btnStart);
            this.panel3.Name = "panel3";
            // 
            // btn_feeding_off
            // 
            resources.ApplyResources(this.btn_feeding_off, "btn_feeding_off");
            this.btn_feeding_off.BackColor = System.Drawing.Color.Transparent;
            this.btn_feeding_off.FlatAppearance.BorderSize = 0;
            this.btn_feeding_off.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btn_feeding_off.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btn_feeding_off.ForeColor = System.Drawing.SystemColors.Control;
            this.btn_feeding_off.Name = "btn_feeding_off";
            this.btn_feeding_off.UseVisualStyleBackColor = false;
            // 
            // btn_feeding_on
            // 
            resources.ApplyResources(this.btn_feeding_on, "btn_feeding_on");
            this.btn_feeding_on.BackColor = System.Drawing.Color.Transparent;
            this.btn_feeding_on.FlatAppearance.BorderSize = 0;
            this.btn_feeding_on.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btn_feeding_on.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btn_feeding_on.ForeColor = System.Drawing.SystemColors.Control;
            this.btn_feeding_on.Name = "btn_feeding_on";
            this.btn_feeding_on.UseVisualStyleBackColor = false;
            // 
            // ckbSaveData
            // 
            resources.ApplyResources(this.ckbSaveData, "ckbSaveData");
            this.ckbSaveData.Name = "ckbSaveData";
            this.ckbSaveData.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.ForeColor = System.Drawing.Color.Yellow;
            this.label1.Name = "label1";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // checkBox_AI
            // 
            resources.ApplyResources(this.checkBox_AI, "checkBox_AI");
            this.checkBox_AI.Name = "checkBox_AI";
            this.checkBox_AI.UseVisualStyleBackColor = true;
            this.checkBox_AI.CheckedChanged += new System.EventHandler(this.checkBox_AI_CheckedChanged);
            // 
            // btnReset
            // 
            resources.ApplyResources(this.btnReset, "btnReset");
            this.btnReset.BackColor = System.Drawing.Color.Transparent;
            this.btnReset.FlatAppearance.BorderSize = 0;
            this.btnReset.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(86)))), ((int)(((byte)(140)))));
            this.btnReset.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(86)))), ((int)(((byte)(140)))));
            this.btnReset.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(86)))), ((int)(((byte)(140)))));
            this.btnReset.ForeColor = System.Drawing.Color.White;
            this.btnReset.Name = "btnReset";
            this.btnReset.UseVisualStyleBackColor = false;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // label_user
            // 
            resources.ApplyResources(this.label_user, "label_user");
            this.label_user.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label_user.Name = "label_user";
            this.label_user.Click += new System.EventHandler(this.label_user_Click);
            // 
            // btnUser
            // 
            resources.ApplyResources(this.btnUser, "btnUser");
            this.btnUser.BackColor = System.Drawing.Color.Transparent;
            this.btnUser.FlatAppearance.BorderSize = 0;
            this.btnUser.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(86)))), ((int)(((byte)(140)))));
            this.btnUser.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(86)))), ((int)(((byte)(140)))));
            this.btnUser.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(86)))), ((int)(((byte)(140)))));
            this.btnUser.ForeColor = System.Drawing.Color.White;
            this.btnUser.Name = "btnUser";
            this.btnUser.UseVisualStyleBackColor = false;
            this.btnUser.Click += new System.EventHandler(this.btnUser_Click);
            // 
            // btnClose
            // 
            resources.ApplyResources(this.btnClose, "btnClose");
            this.btnClose.BackColor = System.Drawing.Color.Transparent;
            this.btnClose.FlatAppearance.BorderSize = 0;
            this.btnClose.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(86)))), ((int)(((byte)(140)))));
            this.btnClose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(86)))), ((int)(((byte)(140)))));
            this.btnClose.ForeColor = System.Drawing.Color.Black;
            this.btnClose.Name = "btnClose";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnDataClear
            // 
            resources.ApplyResources(this.btnDataClear, "btnDataClear");
            this.btnDataClear.BackColor = System.Drawing.Color.Transparent;
            this.btnDataClear.FlatAppearance.BorderSize = 0;
            this.btnDataClear.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(86)))), ((int)(((byte)(140)))));
            this.btnDataClear.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(86)))), ((int)(((byte)(140)))));
            this.btnDataClear.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(86)))), ((int)(((byte)(140)))));
            this.btnDataClear.ForeColor = System.Drawing.Color.White;
            this.btnDataClear.Name = "btnDataClear";
            this.btnDataClear.UseVisualStyleBackColor = false;
            this.btnDataClear.Click += new System.EventHandler(this.btnDataClear_Click);
            // 
            // button1
            // 
            resources.ApplyResources(this.button1, "button1");
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.BackgroundImage = global::BenchMark.Properties.Resources.lcd;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(86)))), ((int)(((byte)(140)))));
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(86)))), ((int)(((byte)(140)))));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Name = "button1";
            this.button1.TabStop = false;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnPerformance
            // 
            resources.ApplyResources(this.btnPerformance, "btnPerformance");
            this.btnPerformance.BackColor = System.Drawing.Color.Transparent;
            this.btnPerformance.FlatAppearance.BorderSize = 0;
            this.btnPerformance.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(86)))), ((int)(((byte)(140)))));
            this.btnPerformance.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(86)))), ((int)(((byte)(140)))));
            this.btnPerformance.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(86)))), ((int)(((byte)(140)))));
            this.btnPerformance.ForeColor = System.Drawing.Color.White;
            this.btnPerformance.Name = "btnPerformance";
            this.btnPerformance.UseVisualStyleBackColor = false;
            this.btnPerformance.Click += new System.EventHandler(this.btnPerformance_Click);
            // 
            // btnDischarge
            // 
            resources.ApplyResources(this.btnDischarge, "btnDischarge");
            this.btnDischarge.BackColor = System.Drawing.Color.Transparent;
            this.btnDischarge.FlatAppearance.BorderSize = 0;
            this.btnDischarge.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(86)))), ((int)(((byte)(140)))));
            this.btnDischarge.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(86)))), ((int)(((byte)(140)))));
            this.btnDischarge.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(86)))), ((int)(((byte)(140)))));
            this.btnDischarge.ForeColor = System.Drawing.Color.White;
            this.btnDischarge.Name = "btnDischarge";
            this.btnDischarge.UseVisualStyleBackColor = false;
            this.btnDischarge.Click += new System.EventHandler(this.btnDischarge_Click);
            // 
            // btnStop
            // 
            resources.ApplyResources(this.btnStop, "btnStop");
            this.btnStop.BackColor = System.Drawing.Color.Transparent;
            this.btnStop.FlatAppearance.BorderSize = 0;
            this.btnStop.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(86)))), ((int)(((byte)(140)))));
            this.btnStop.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(86)))), ((int)(((byte)(140)))));
            this.btnStop.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(86)))), ((int)(((byte)(140)))));
            this.btnStop.ForeColor = System.Drawing.Color.White;
            this.btnStop.Name = "btnStop";
            this.btnStop.UseVisualStyleBackColor = false;
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
            // 
            // btnStart
            // 
            resources.ApplyResources(this.btnStart, "btnStart");
            this.btnStart.BackColor = System.Drawing.Color.Transparent;
            this.btnStart.FlatAppearance.BorderSize = 0;
            this.btnStart.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(86)))), ((int)(((byte)(140)))));
            this.btnStart.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(86)))), ((int)(((byte)(140)))));
            this.btnStart.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(86)))), ((int)(((byte)(140)))));
            this.btnStart.ForeColor = System.Drawing.Color.White;
            this.btnStart.Name = "btnStart";
            this.btnStart.UseVisualStyleBackColor = false;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // panel4
            // 
            resources.ApplyResources(this.panel4, "panel4");
            this.panel4.BackColor = System.Drawing.Color.Transparent;
            this.panel4.Name = "panel4";
            // 
            // MainUI
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tableLayoutPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MainUI";
            this.Load += new System.EventHandler(this.MainUI_Load);
            this.Shown += new System.EventHandler(this.MainUI_Shown);
            this.Resize += new System.EventHandler(this.MainUI_Resize);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lblCOMPANY;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnDataClear;
        private System.Windows.Forms.Button btnPerformance;
        private System.Windows.Forms.Button btnDischarge;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 文件ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tsmiNew;
        private System.Windows.Forms.ToolStripMenuItem tsmiOpen;
        private System.Windows.Forms.ToolStripMenuItem tsmiSave;
        private System.Windows.Forms.ToolStripMenuItem 工具ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 帮助ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 语言ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tsmiEnglish;
        private System.Windows.Forms.ToolStripMenuItem tsmiChinese;
        private System.Windows.Forms.ToolStripMenuItem tsmiLog;
        private System.Windows.Forms.Button btnUser;
        private System.Windows.Forms.ToolStripMenuItem tsmiAboutUs;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Label labpos;
        private System.Windows.Forms.Label labinformation;
        private System.Windows.Forms.Label labmessage;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        //private DXT_VisionToolBase.Frm.frmDataResultShow frmDataResultShow;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ToolStripMenuItem tsmiQuickSetting;
        public System.Windows.Forms.Label label_user;
        private System.Windows.Forms.ToolStripMenuItem tsmiNew2;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.CheckBox checkBox_AI;
        public System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripMenuItem 数据报表ToolStripMenuItem;
        private System.Windows.Forms.CheckBox ckbSaveData;
        private System.Windows.Forms.Button btn_feeding_off;
        private System.Windows.Forms.Button btn_feeding_on;
        private System.Windows.Forms.Button button1;
    }
}

