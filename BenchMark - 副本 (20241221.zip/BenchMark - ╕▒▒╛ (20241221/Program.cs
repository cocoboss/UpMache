﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BenchMark
{
    static class Program
    {
        /// <summary>
        /// 应用程序的主入口点。
        /// </summary>
        [STAThread]
        static void Main()
        {
            bool isOwn;
            using (Mutex mut = new Mutex(true, "e06cb5ff-ffbb-4a0b-bec9-3282895ab75b",out isOwn))
            {
                if (isOwn)
                {
                    Application.EnableVisualStyles();
                    Application.SetCompatibleTextRenderingDefault(false);
                    Application.Run(new MainForm());
                }
                else
                {
                    MessageBox.Show("一款软件不能同时打开两个");
                }
            }
            
        }
    }
}
