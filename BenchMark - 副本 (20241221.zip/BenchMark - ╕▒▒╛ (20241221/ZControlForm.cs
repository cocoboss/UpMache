﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using static gts.mc_la;

namespace BenchMark
{
    public partial class ZControlForm : Form
    {
        MainThread mainThread = null;
        Enm_Axis axisSts = Enm_Axis.stop;
        Postion postion;
        short axis;
        double val = 0;
        public ZControlForm()
        {
            InitializeComponent();
            mainThread = MainThread.Instance();
        }
        public short GetCardId()
        {
            return Convert.ToInt16(cardId.SelectedIndex + 1);
        }
        public double GetVal()
        {
            return Convert.ToDouble(txt_val.Text.Trim().ToString());
        }
        private void ZControlForm_Load(object sender, EventArgs e)
        {
            cardId.SelectedIndex = 0;
            Show(Global.isZh);
            val=GetVal();
            axis=GetCardId();
            //MainThread.Instance().axisStsUpdate += UpdateAxisSts;
        }
        public void UpdateAxisSts(Enm_Axis item)
        {
            //if (axisSts != item)
            {
                axisSts = item;
                Global.ControlInvocke(txt_axisSts, () =>
                {
                    if (item == Enm_Axis.alnormal)
                    {
                        txt_axisSts.Text = Global.isZh?"异常":"alnormal";
                        txt_axisSts.BackColor = Color.Red;
                    }
                    if (item == Enm_Axis.nopower)
                    {
                        txt_axisSts.Text = Global.isZh ? "未上使能":"noPower";
                        txt_axisSts.BackColor = Color.Red;
                    }
                    else if (item == Enm_Axis.stop)
                    {
                        txt_axisSts.Text = Global.isZh ? "待机":"free";
                        txt_axisSts.BackColor = Color.Yellow;
                    }
                    else if (item == Enm_Axis.run)
                    {
                        txt_axisSts.Text = Global.isZh ? "运行" : "run";
                        txt_axisSts.BackColor = Color.Green;
                    }
                });
            }


        }
        private void button8_Click(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
           
        }

        private void button3_Click(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //复位
            //Global.Currentnum = 3;
            mainThread.InitEq();
            UpdateAxisSts(Enm_Axis.run);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //使能
            mainThread.PowerAll();
            UpdateAxisSts(Enm_Axis.stop);
        }

        private void button6_Click(object sender, EventArgs e)
        {
           
        }

        private void button5_Click(object sender, EventArgs e)
        {
           
        }

        private void button7_Click(object sender, EventArgs e)
        {
            
        }

        private void button2_MouseDown(object sender, MouseEventArgs e)
        {
            //前移
            ParaamSigle axiss = mainThread.datas.dataConfig.alexParams.y_axle;
            mainThread.MoveJogBase(axiss.axis, axiss, false,val);
            UpdateAxisSts(Enm_Axis.run);
        }

        private void button3_MouseDown(object sender, MouseEventArgs e)
        {
            //后移
            ParaamSigle axiss = mainThread.datas.dataConfig.alexParams.y_axle;
            mainThread.MoveJogBase(axiss.axis, axiss, true,val);
            UpdateAxisSts(Enm_Axis.run);
        }

        private void button6_MouseDown(object sender, MouseEventArgs e)
        {
            ParaamSigle axiss = mainThread.datas.dataConfig.alexParams.x_axle;
            mainThread.MoveJogBase(axiss.axis, axiss, true, val);
            UpdateAxisSts(Enm_Axis.run);
        }

        private void button5_MouseDown(object sender, MouseEventArgs e)
        {
            ParaamSigle axiss = mainThread.datas.dataConfig.alexParams.x_axle;
            mainThread.MoveJogBase(axiss.axis, axiss, false, val);
            UpdateAxisSts(Enm_Axis.run);
        }

        private void button7_MouseDown(object sender, MouseEventArgs e)
        {
            ParaamSigle axiss = mainThread.datas.dataConfig.alexParams.z_axle;

            mainThread.MoveJogBase(axiss.axis, axiss, false, val);
            UpdateAxisSts(Enm_Axis.run);
        }

        private void button8_MouseDown(object sender, MouseEventArgs e)
        {
            ParaamSigle axiss = mainThread.datas.dataConfig.alexParams.z_axle;
            mainThread.MoveJogBase(axiss.axis, axiss, true, val);
            UpdateAxisSts(Enm_Axis.run);
        }
        private void Stop_Mouse(object sender, MouseEventArgs e)
        {
            mainThread.AxisStop();
            UpdateAxisSts(Enm_Axis.stop);
        }

        private void button12_Click(object sender, EventArgs e)
        {
            mainThread.AxisStop();
            UpdateAxisSts(Enm_Axis.stop);
        }

        private void button11_Click(object sender, EventArgs e)
        {
            mainThread.ClearAlarming();
        }

        private void button9_Click(object sender, EventArgs e)
        {

        }

        private void button9_MouseDown(object sender, MouseEventArgs e)
        {
            ParaamSigle axiss = mainThread.datas.dataConfig.alexParams.k_axle;
            //axiss.val=val;
            mainThread.MoveJogBase(axiss.axis, axiss, false, val);
            UpdateAxisSts(Enm_Axis.run);
        }

        private void button10_MouseDown(object sender, MouseEventArgs e)
        {
            ParaamSigle axiss = mainThread.datas.dataConfig.alexParams.k_axle;
            //axiss.val = val;
            mainThread.MoveJogBase(axiss.axis, axiss, true, val);
            UpdateAxisSts(Enm_Axis.run);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //UpdateAxisSts(MainThread.Instance()._Axis);
            Postion itempos = mainThread.GetPos();
            if (itempos != null && itempos!= postion)
            {
                postion = itempos;
                //Global.ControlInvocke(txt_pos1, () =>
                //{
                txt_pos1.Text = itempos.X.ToString();
                txt_pos2.Text = itempos.Y.ToString();
                txt_pos3.Text = itempos.Z.ToString();
                //});
            }
            UpdateAxisSts(MainThread.Instance()._Axis);
        }

        private void cardId_SelectedIndexChanged(object sender, EventArgs e)
        {
            axis = GetCardId();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            Postion postiontemp=new Postion();
           int tempos = Convert.ToInt32(txt_posxyz.Text);
            ParaamSigle axiss = null;
            if (axis == 1)
                axiss = mainThread.datas.dataConfig.alexParams.x_axle;
            else if (axis == 2)
                axiss = mainThread.datas.dataConfig.alexParams.y_axle;
            else if (axis == 3)
                axiss = mainThread.datas.dataConfig.alexParams.z_axle;
            else if (axis == 4)
            {
                axiss = mainThread.datas.dataConfig.alexParams.k_axle;
            }
            if (axiss != null)
                mainThread.MoveTrapBase(axis, axiss, tempos, val);

            UpdateAxisSts(Enm_Axis.run);
        }

        private void button14_Click(object sender, EventArgs e)
        {

        }

        private void ZControlForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            //MainThread.Instance().axisStsUpdate -= UpdateAxisSts;
        }

        private void button14_Click_1(object sender, EventArgs e)
        {
            Axis.ClearPosAll();
        }

        private void button6_Click_1(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {

        }

        private void button7_Click_1(object sender, EventArgs e)
        {

        }

        private void button8_Click_1(object sender, EventArgs e)
        {

        }

        private void button3_Click_1(object sender, EventArgs e)
        {

        }

        private void button9_Click_1(object sender, EventArgs e)
        {

        }

        private void button10_Click(object sender, EventArgs e)
        {

        }

        private void Show(bool isZh)
        {
            if (!isZh)
            {
                Thread.CurrentThread.CurrentUICulture = new CultureInfo("en-US");
                Global.LoadLanguage(this, typeof(ZControlForm));
            }
            else
            {
                Thread.CurrentThread.CurrentUICulture = new CultureInfo("zh-CN");
                Global.LoadLanguage(this, typeof(ZControlForm));
            }
        }

        private void txt_val_TextChanged(object sender, EventArgs e)
        {
            val=GetVal();
            if(val==0)
            {
                string msg = Global.isZh ? "注意：速度设置为0，则将按设置的流程速度执行" : "Note: If the speed is set to 0, it will be executed according to the set process speed";
                MessageBox.Show(msg);
            }
        }

        private void button15_MouseDown(object sender, MouseEventArgs e)
        {
            ParaamSigle axiss = mainThread.datas.dataConfig.alexParams.g_axle;
            mainThread.MoveJogBase(axiss.axis, axiss, true, val);
            UpdateAxisSts(Enm_Axis.run);
        }

        private void button16_MouseDown(object sender, MouseEventArgs e)
        {
            ParaamSigle axiss = mainThread.datas.dataConfig.alexParams.g_axle;
            mainThread.MoveJogBase(axiss.axis, axiss, false, val);
            UpdateAxisSts(Enm_Axis.run);
        }

        private void button16_MouseUp(object sender, MouseEventArgs e)
        {
            ParaamSigle axiss = mainThread.datas.dataConfig.alexParams.g_axle;
            Axis.Stop(axiss.axis);
        }

        private void button15_MouseUp(object sender, MouseEventArgs e)
        {
            ParaamSigle axiss = mainThread.datas.dataConfig.alexParams.g_axle;
            Axis.Stop(axiss.axis);
        }

        private void button17_Click(object sender, EventArgs e)
        {
            double dis=double.Parse(txt_dis.Text.Trim().ToString()); 
            val = GetVal();
            mainThread.TransportMoveDis(dis,val);
        }

        private void button18_Click(object sender, EventArgs e)
        {
            this.button18.Enabled = false;
            txt_bard.Text=mainThread.TurnOnAndOffBard();
            this.button18.Enabled = true;
        }
    }
}
