﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BenchMark
{
    public class User
    {
        public int id;
        public string name="";
        public string pwd="";
        public int auth=0;
    }
    public class Auth
    {
        public int id=0;
        public int mark=0;
    }



}
