﻿using ProModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pro
{
    public partial class LoginForm : Form
    {
        List<string> userRight = new List<string>();
        DevManage uf = DevManage.Instance();
        public LoginForm()
        {
            InitializeComponent();
        }

        private void LoginForm_Load(object sender, EventArgs e)
        {
            //if(DevManage.Instance().mainForm!=null)
            //{
            //    Login login = new Pro.Login(DevManage.Instance().mainForm);
            //    //this.Hide();
            //    login.Show();
            //}
            userRight.Clear();
            foreach (var val in uf.userMgn.groupRole)
            {
                com_group.Items.Add(val.Value.remark);
                userRight.Add(val.Key);
            }

        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            if (!userRight[com_group.SelectedIndex].Contains(Em_UserRight.administrator.ToString()))
            {
                string right = uf.userMgn.groupRole[userRight[com_group.SelectedIndex]].remark;
                string mesage = "";
                string name = txt_user.Text.Trim();
                string pwd = txt_pwd.Text.Trim();
                //bool ret = DevManage.Instance().SendACUSERINFO(Em_MES.ACUSERINFO, txt_user.Text.Trim(), txt_pwd.Text.Trim(), right, out mesage);
                bool ret = DevManage.Instance().SendACUSERINFO(Em_MES.ACUSERINFO, name, pwd, right, out mesage);
                if (ret)
                {
                    uf.userMgn.UpdatePerCurrent(uf.userMgn.groupRole[userRight[com_group.SelectedIndex]].groupID);
                    uf.userMgn.currentUser.userName = txt_user.Text.Trim();
                    uf.userMgn.currentUser.remark = right;
                    uf.userMgn.role.name = uf.userMgn.groupRole[userRight[com_group.SelectedIndex]].name;
                    //mains.Show();
                    //this.Close();
                    uf.mainForm.UserChange(ret, e);
                }
                else
                {
                    MessageBox.Show(mesage);
                }
            }else
            {
                bool temp = uf.userMgn.Login(txt_user.Text, txt_pwd.Text);
                if (temp)
                {
                    if (!com_group.SelectedItem.ToString().Contains(uf.userMgn.role.remark))
                    {
                        MessageBox.Show($"该用户只有{uf.userMgn.role.name}权限，权限选择出错");
                    }
                    //mains.Show();
                    //this.Close();
                    uf.mainForm.UserChange(temp, e);
                }
                else
                {
                    MessageBox.Show($"请检查用户或者密码是否正确！");
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            txt_user.Text = "";
            txt_pwd.Text = "";
        }
    }
}
