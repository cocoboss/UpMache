﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ProModel;

namespace Pro
{
    public partial class RoleForm : Form
    {

        public Roles role = new Roles();
        public List<Permissions> bands = new List<Permissions>();
        public List<Permissions> barItem = new List<Permissions>();
        public string groupName;

        public RoleForm(string title,string name)
        {
            InitializeComponent();
            groupName = name;
            role = DevManage.Instance().userMgn.groupRole[name];
            bands = DevManage.Instance().userMgn.perCurrent.pa.GetBand();
            barItem = DevManage.Instance().userMgn.perCurrent.pa.GetBarItem();
            if (title.Contains("查看"))
            {
                //rightTree.Enabled = false;
                button1.Enabled = false;

            }
            this.Text = title;
            roleName.Text = role.remark;
        }
        public bool IsHaveRight(string name)
        {
            bool ret = false;
            string[] rightArr = role.rights.Split(';');
            for (int i= 0;i< rightArr.Length;i++)
            {
                if(rightArr[i].Contains(name) && rightArr[i].Contains(':'))
                {
                    ret=(int.Parse(rightArr[i].Split(':')[1]) < 2 )? false : true;
                }
            }
            return ret;
        }

        private void RoleForm_Load(object sender, EventArgs e)
        {
            rightTree.CheckBoxes = true;
            for (int i=0;i<bands.Count;i++)
            {
                TreeNode node1 = new TreeNode(bands[i].description);
                node1.Name = bands[i].description;
                //node1.Tag = bands[i].name;
                rightTree.Nodes.Add(node1);
                for(int j=0;j<barItem.Count;j++)
                {
                    if (barItem[j].parentID == bands[i].id)
                    {
                        rightTree.Nodes[i].Nodes.Add(barItem[j].description);
                        rightTree.Nodes[i].Nodes[j].Tag = barItem[j].name;
                        if (role.rights.Length > 0)
                        {
                            rightTree.Nodes[i].Nodes[j].Checked = IsHaveRight(barItem[j].name);
                        }
                    }
                }
            }
            for(int i=0;i<rightTree.Nodes.Count;i++)
            {
                bool allEnable = true;
                TreeNode node = rightTree.Nodes[i];
                if(node.Nodes.Count!=0)
                {
                    for(int j=0;j<node.Nodes.Count;j++)
                    {
                        if(!node.Nodes[j].Checked)
                        {
                            allEnable = false;
                            break;
                        }
                        rightTree.Nodes[i].Checked = allEnable;
                        rightTree.Nodes[i].ExpandAll();
                    }
                }
            }


        }

        private void button1_Click(object sender, EventArgs e)
        {
            string str = "";
            if (rightTree.Nodes.Count == 0)
                return;
            for(int i=0;i< rightTree.Nodes.Count;i++)
            {
                TreeNode node = rightTree.Nodes[i];
                if(node.Nodes.Count>0)
                {
                    for(int j=0;j<node.Nodes.Count;j++)
                    {
                        if(!string.IsNullOrEmpty(node.Nodes[j].Tag.ToString().Trim()))
                        {
                            str += node.Nodes[j].Tag.ToString().Trim() + ":" + (node.Nodes[j].Checked ? "2" : "1");
                            if (j != node.Nodes.Count - 1)
                                str += ";";
                        }
                        
                    }
                }
            }
            role.rights = str;
            if(DevManage.Instance().userMgn.UpdateRoleRight(role)>0)
            {
                this.Close();
            }else
            {
                Task.Run(() => { MessageBox.Show("数据库保存权限失败"); });
            }
        }

        private void rightTree_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            //TreeNode node = e.Node;
            //if(node!=null)
            //{
            //    if(node.Nodes.Count>0)
            //    {
            //        if(e.Node.Level==0)
            //        {
            //            for(int i=0;i<node.Nodes.Count;i++)
            //            {
            //                node.Nodes[i].Checked = node.Checked;
            //            }
            //        }
            //    }else
            //    {
            //        TreeNode parentNode = node.Parent;
            //        if(parentNode!=null)
            //        {
            //            if(parentNode.Checked!=node.Checked)
            //            {
            //                bool bSel = true;
            //                for (int i = 0; i < parentNode.Nodes.Count; i++)
            //                {
            //                    if (!parentNode.Nodes[i].Checked)
            //                    {
            //                        bSel = false;
            //                        break;
            //                    }
            //                }
            //                parentNode.Checked = bSel;
            //            }
            //        }
            //    }
            //}
        }
    }
}
