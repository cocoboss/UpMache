﻿using ProModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pro
{
    public partial class DataForm : Form
    {
        Dictionary<string, DataGridViewRow> tempRows = new Dictionary<string, DataGridViewRow>();
        Dictionary<string, DataEventArgs> tempDatas = new Dictionary<string, DataEventArgs>();
        int headerRow = 0;
        public DataForm()
        {
            InitializeComponent();
            DevManage.Instance().userMgn.evenHand.event_MesMessage += MesMessageReceiver;
            DevManage.Instance().userMgn.evenHand.event_DataOut += DataReceiver;
            LoadInfo();
        }

        private void DataForm_Load(object sender, EventArgs e)
        {
 
        }
        public void LoadInfo()
        {
            try
            {
                if (DevManage.Instance().currentParamInit != null)
                {
                    ACEQPTINIT.ACEQPTINITRequestEquipmentInfo info = DevManage.Instance().currentParamInit;
                    txt_gdh.Text = info.WipOrder;
                    txt_gdlx.Text = info.WipOrderType;
                    txt_cpmc.Text = info.ProductDesc;
                    txt_cpbh.Text = info.ProductNo;
                    txt_gylj.Text = info.ProcessID;
                    txt_pfh.Text = info.RecipeID;
                }
                string all = string.IsNullOrEmpty(DevManage.Instance().sysParam.sysParam[Em_DefineVariable.all.ToString()]) ? "0" : DevManage.Instance().sysParam.sysParam[Em_DefineVariable.all.ToString()];
                string ok = string.IsNullOrEmpty(DevManage.Instance().sysParam.sysParam[Em_DefineVariable.OK.ToString()]) ? "0" : DevManage.Instance().sysParam.sysParam[Em_DefineVariable.OK.ToString()];
                txt_all.Text = all;
                txt_ok.Text = ok;
                int ng = int.Parse(all) - int.Parse(ok);
                string rate = "100.00%";
                if (all != "0")
                    rate = (int.Parse(ok) / int.Parse(all)).ToString("0.00%");
                txt_ng.Text = ng.ToString();
                txt_lv.Text = rate;
            }
            catch (Exception ex)
            {
                DevManage.Instance().WriteErrorLog($"数据界面导入数据出错：{ex.Message}");
            }
        }
        public void DataReceiver(object sender, EventArgs e)
        {
            DataEventArgs da = (DataEventArgs)e;
            try
            {
                InveokeCls.DoInvokeRequired(txt_all, () =>
                {
                    txt_all.Text = da.allCount;
                });
                InveokeCls.DoInvokeRequired(txt_ok, () =>
                {
                    txt_ok.Text = da.okCount;
                });
                int ng = int.Parse(da.allCount) - int.Parse(da.okCount);
                string rate = "100.00%";
                if (da.allCount != "0")
                    rate = (double.Parse(da.okCount) / double.Parse(da.allCount)).ToString("0.00%");
                InveokeCls.DoInvokeRequired(txt_ng, () =>
                {
                    txt_ng.Text = ng.ToString();
                });

                InveokeCls.DoInvokeRequired(txt_lv, () =>
                {
                    txt_lv.Text = rate;
                });

                int temp = 0;
                switch (da.type)
                {
                    case Em_Data.dataIn:
                        InveokeCls.DoInvokeRequired(dataGridView1, () =>
                        {
                            //if (tempRows.Keys.Contains(da.val.barCode))
                            //{
                            //    DataGridViewRow row = dataGridView1.Rows[dataGridView1.Rows.IndexOf(tempRows[da.val.barCode])];
                            //    row.Cells[0].Value = da.val.barCode;
                            //    row.Cells[1].Value = da.val.in_time;
                            //    row.Cells[2].Value = da.val.in_result;
                            //    row.Cells[3].Value = da.val.in_message;
                            //}
                            //else
                            //{



                            dataGridView1.Rows.Insert(temp,
                         da.val.barCode,
                          da.val.in_time,
                         da.val.in_result,
                          "",
                          "",
                          "",
                          "",
                          "",
                          "",
                          "",
                          "",
                          "",
                           da.val.in_message,
                          "");
                            dataGridView1.Rows[temp].HeaderCell.Value = string.Format("{0}", ++headerRow);
                            //dataGridView1.Rows[temp].HeaderCell.Value = string.Format("{0}", ++headerRow);
                            if (tempRows.Keys.Contains(da.val.barCode))
                            {
                                tempRows[da.val.barCode] = dataGridView1.Rows[temp];
                                tempDatas[da.val.barCode] = da;
                            }
                            else
                            {
                                tempRows.Add(da.val.barCode, dataGridView1.Rows[temp]);
                                tempDatas.Add(da.val.barCode, da);
                            }

                            dataGridView1.FirstDisplayedScrollingRowIndex = temp;
                            if (dataGridView1.Rows.Count >1000)
                            {
                                dataGridView1.Rows.RemoveAt(dataGridView1.Rows.Count - 1-1);
                            }
                            //}
                        });

                        break;
                    case Em_Data.dataOut:
                        InveokeCls.DoInvokeRequired(dataGridView1, () =>
                        {
                            if (tempRows.Keys.Contains(da.val.barCode) && dataGridView1.Rows.IndexOf(tempRows[da.val.barCode]) != -1)
                            {
                                DataGridViewRow row = dataGridView1.Rows[dataGridView1.Rows.IndexOf(tempRows[da.val.barCode])];
                                row.Cells[3].Value = da.val.out_time;
                                row.Cells[4].Value = da.val.out_result;
                                row.Cells[5].Value = da.val.PoleHeightL;
                                row.Cells[6].Value = da.val.shoulderHeightL;
                                row.Cells[7].Value = da.val.bycellWidth;
                                row.Cells[8].Value = da.val.bycellPlies;
                                row.Cells[9].Value = da.val.PoleHeightR;
                                row.Cells[10].Value = da.val.shoulderHeightR;
                                row.Cells[11].Value = da.val.testPliesPress;
                                row.Cells[13].Value = da.val.out_message;
                                dataGridView1.FirstDisplayedScrollingRowIndex = dataGridView1.Rows.IndexOf(tempRows[da.val.barCode]);
                                tempRows.Remove(da.val.barCode);
                                tempDatas.Remove(da.val.barCode);
                            }
                            else
                            {
                                dataGridView1.Rows.Insert(temp,
                                      da.val.barCode,
                                      //"0",
                                      //"0",
                                      da.val.in_time,
                                      da.val.in_result,
                                      da.val.out_time,
                                      da.val.out_result,
                                      da.val.PoleHeightL,
                                      da.val.shoulderHeightL,
                                      da.val.bycellWidth,
                                      da.val.bycellPlies,
                                      da.val.PoleHeightR,
                                      da.val.shoulderHeightR,
                                      da.val.testPliesPress,
                                       da.val.in_message,
                                        //"0",
                                        da.val.out_message
                                       );
                                dataGridView1.Rows[temp].HeaderCell.Value = string.Format("{0}", ++headerRow);
                                //dataGridView1.Rows.Remove(tempRows[da.val.barCode]);
                                dataGridView1.FirstDisplayedScrollingRowIndex = temp;
                                if (dataGridView1.Rows.Count > 1000)
                                {
                                    dataGridView1.Rows.RemoveAt(dataGridView1.Rows.Count - 1-1);
                                }
                            }
                        });
                        break;
                    default:
                        break;
                }

                string te = DateTime.Now.AddHours(-1).ToString("yyyy-MM-dd HH:mm:ss");
                List<string> lst = new List<string>();
                foreach (var item in tempDatas)
                {
                    if (item.Value.val.in_result.Contains("NG") || te.CompareTo(item.Value.val.in_time) > 0)
                    {
                        lst.Add(item.Value.val.barCode);
                    }
                }
                if (lst.Count > 0)
                {
                    for (int i = 0; i < lst.Count; i++)
                    {
                        tempDatas.Remove(lst[i]);
                        if (tempRows.Keys.Contains(lst[i]))
                        {
                            //dataGridView1.Rows.Remove(tempRows[da.val.barCode]);
                            tempRows.Remove(lst[i]);
                            tempDatas.Remove(lst[i]);
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                DevManage.Instance().WriteErrorLog(ex.Message);
            }
        }
        public void MesMessageReceiver(object sender, EventArgs e)
        {
            MesDataEventArgs ags = (MesDataEventArgs)e;
            switch(ags.type)
            {
                case Em_MesMessage.send:
                    if (ags.type2 == Em_MES.ACLOGONCHECK || ags.type2 == Em_MES.ACLOGOFF)
                    {
                        InveokeCls.DoInvokeRequired(list_send, () =>
                        {
                            list_send.Text = "";
                            list_send.Text = ags.val;
                            txt_send.Text = ags.type2.ToString();
                        });
                    }
                    break;
                case Em_MesMessage.receiver:
                    if (ags.type2 == Em_MES.ACLOGONCHECK || ags.type2 == Em_MES.ACLOGOFF)
                    {
                        InveokeCls.DoInvokeRequired(list_receive, () =>
                        {
                            list_receive.Text = "";
                            list_receive.Text = ags.val;

                            txt_receive.Text = ags.type2.ToString();
                        });
                    }
                    break;

                default:break;

            }

        }

        private void dataGridView1_RowPrePaint(object sender, DataGridViewRowPrePaintEventArgs e)
        {
            //var in_result = this.dataGridView1.Rows[e.RowIndex].Cells["入站结果"].Value.ToString();
            //if (!string.IsNullOrEmpty(in_result) && !in_result.Contains("OK"))
            //{
            //    this.dataGridView1.Rows[e.RowIndex].Cells["入站结果"].Style.ForeColor = Color.Red;
            //}
            //var out_result = this.dataGridView1.Rows[e.RowIndex].Cells["出站结果"].Value.ToString();
            //if (!string.IsNullOrEmpty(out_result) && !out_result.Contains("OK"))
            //{
            //    this.dataGridView1.Rows[e.RowIndex].Cells["出站结果"].Style.ForeColor = Color.Red;
            //}
            //var testPliesPress = this.dataGridView1.Rows[e.RowIndex].Cells["测厚压力"].Value.ToString();
            //string idtestPliesPress= DevManage.Instance().plcpfg.dirDataUint["测厚压力"].bandField;
            //if (!string.IsNullOrEmpty(testPliesPress) && DevManage.Instance().currentInfo.Keys.Contains(idtestPliesPress))
            //{
            //    if (float.Parse(testPliesPress) <float.Parse( DevManage.Instance().currentInfo[idtestPliesPress].LowerControlLimit) || float.Parse(testPliesPress)>float.Parse(DevManage.Instance().currentInfo[idtestPliesPress].UpperControlLimit))
            //    {
            //        this.dataGridView1.Rows[e.RowIndex].Cells["测厚压力"].Style.ForeColor = Color.Red;
            //    }
            //}
            //var PoleHeightL = this.dataGridView1.Rows[e.RowIndex].Cells["电芯左柱高"].Value.ToString();
            //string idPoleHeightL = DevManage.Instance().plcpfg.dirDataUint["电芯左柱高"].bandField;
            //if (!string.IsNullOrEmpty(PoleHeightL) && DevManage.Instance().currentInfo.Keys.Contains(idPoleHeightL))
            //{
            //    if (float.Parse(PoleHeightL) < float.Parse(DevManage.Instance().currentInfo[idPoleHeightL].LowerControlLimit) || float.Parse(PoleHeightL) > float.Parse(DevManage.Instance().currentInfo[idPoleHeightL].UpperControlLimit))
            //    {
            //        this.dataGridView1.Rows[e.RowIndex].Cells["电芯左柱高"].Style.ForeColor = Color.Red;
            //    }
            //}
            //var shoulderHeightL = this.dataGridView1.Rows[e.RowIndex].Cells["电芯左肩高"].Value.ToString();
            //string idshoulderHeightL = DevManage.Instance().plcpfg.dirDataUint["电芯左肩高"].bandField;
            //if (!string.IsNullOrEmpty(shoulderHeightL) && DevManage.Instance().currentInfo.Keys.Contains(idshoulderHeightL))
            //{
            //    if (float.Parse(shoulderHeightL) < float.Parse(DevManage.Instance().currentInfo[idshoulderHeightL].LowerControlLimit) || float.Parse(shoulderHeightL) > float.Parse(DevManage.Instance().currentInfo[idshoulderHeightL].UpperControlLimit))
            //    {
            //        this.dataGridView1.Rows[e.RowIndex].Cells["电芯左肩高"].Style.ForeColor = Color.Red;
            //    }
            //}
            //var bycellWidth = this.dataGridView1.Rows[e.RowIndex].Cells["电芯宽度"].Value.ToString();
            //string idbycellWidth = DevManage.Instance().plcpfg.dirDataUint["电芯宽度"].bandField;
            //if (!string.IsNullOrEmpty(bycellWidth) && DevManage.Instance().currentInfo.Keys.Contains(idbycellWidth))
            //{
            //    if (float.Parse(bycellWidth) < float.Parse(DevManage.Instance().currentInfo[idbycellWidth].LowerControlLimit) || float.Parse(bycellWidth) > float.Parse(DevManage.Instance().currentInfo[idbycellWidth].UpperControlLimit))
            //    {
            //        this.dataGridView1.Rows[e.RowIndex].Cells["电芯宽度"].Style.ForeColor = Color.Red;
            //    }
            //}
            //var bycellPlies = this.dataGridView1.Rows[e.RowIndex].Cells["电芯厚度"].Value.ToString();
            //string idbycellPlies = DevManage.Instance().plcpfg.dirDataUint["电芯厚度"].bandField;
            //if (!string.IsNullOrEmpty(bycellPlies) && DevManage.Instance().currentInfo.Keys.Contains(idbycellPlies))
            //{
            //    if (float.Parse(bycellPlies) < float.Parse(DevManage.Instance().currentInfo[idbycellPlies].LowerControlLimit) || float.Parse(bycellPlies) > float.Parse(DevManage.Instance().currentInfo[idbycellPlies].UpperControlLimit))
            //    {
            //        this.dataGridView1.Rows[e.RowIndex].Cells["电芯厚度"].Style.ForeColor = Color.Red;
            //    }
            //}
            //var PoleHeightR = this.dataGridView1.Rows[e.RowIndex].Cells["电芯右柱高"].Value.ToString();
            //string idPoleHeightR = DevManage.Instance().plcpfg.dirDataUint["电芯右柱高"].bandField;
            //if (!string.IsNullOrEmpty(PoleHeightR) && DevManage.Instance().currentInfo.Keys.Contains(idPoleHeightR))
            //{
            //    if (float.Parse(PoleHeightR) < float.Parse(DevManage.Instance().currentInfo[idPoleHeightR].LowerControlLimit) || float.Parse(PoleHeightR) > float.Parse(DevManage.Instance().currentInfo[idPoleHeightR].UpperControlLimit))
            //    {
            //        this.dataGridView1.Rows[e.RowIndex].Cells["电芯右柱高"].Style.ForeColor = Color.Red;
            //    }
            //}
            //var shoulderHeightR = this.dataGridView1.Rows[e.RowIndex].Cells["电芯右肩高"].Value.ToString();
            //string idshoulderHeightR = DevManage.Instance().plcpfg.dirDataUint["电芯右肩高"].bandField;
            //if (!string.IsNullOrEmpty(shoulderHeightR) && DevManage.Instance().currentInfo.Keys.Contains(idshoulderHeightR))
            //{
            //    if (float.Parse(shoulderHeightR) < float.Parse(DevManage.Instance().currentInfo[idshoulderHeightR].LowerControlLimit) || float.Parse(shoulderHeightR) > float.Parse(DevManage.Instance().currentInfo[idshoulderHeightR].UpperControlLimit))
            //    {
            //        this.dataGridView1.Rows[e.RowIndex].Cells["电芯右肩高"].Style.ForeColor = Color.Red;
            //    }
            //}


        }

        private void dataGridView1_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            //if (this.dataGridView1.Rows.Count < 2)
            //    return;
            if (this.dataGridView1.Rows[e.RowIndex].Cells["入站结果"].Value != null)
            {
                var in_result = this.dataGridView1.Rows[e.RowIndex].Cells["入站结果"].Value.ToString();
                if (!string.IsNullOrEmpty(in_result) && !in_result.Contains("OK"))
                {
                    this.dataGridView1.Rows[e.RowIndex].Cells["入站结果"].Style.ForeColor = Color.Red;
                }
            }
            if (this.dataGridView1.Rows[e.RowIndex].Cells["出站结果"].Value != null)
            {
                var out_result = this.dataGridView1.Rows[e.RowIndex].Cells["出站结果"].Value.ToString();
                if (!string.IsNullOrEmpty(out_result) && !out_result.Contains("OK"))
                {
                    this.dataGridView1.Rows[e.RowIndex].Cells["出站结果"].Style.ForeColor = Color.Red;
                }
            }
            if (this.dataGridView1.Rows[e.RowIndex].Cells["测厚压力"].Value != null)
            {
                var testPliesPress = this.dataGridView1.Rows[e.RowIndex].Cells["测厚压力"].Value.ToString();
                string idtestPliesPress = DevManage.Instance().plcpfg.dirDataUint["测厚压力"].bandField;
                if (!string.IsNullOrEmpty(testPliesPress) && DevManage.Instance().currentInfo.Keys.Contains(idtestPliesPress))
                {
                    if (float.Parse(testPliesPress) < float.Parse(DevManage.Instance().currentInfo[idtestPliesPress].LowerControlLimit) || float.Parse(testPliesPress) > float.Parse(DevManage.Instance().currentInfo[idtestPliesPress].UpperControlLimit))
                    {
                        this.dataGridView1.Rows[e.RowIndex].Cells["测厚压力"].Style.ForeColor = Color.Red;
                    }
                }
            }
            if (this.dataGridView1.Rows[e.RowIndex].Cells["电芯左柱高"].Value != null)
            {
                var PoleHeightL = this.dataGridView1.Rows[e.RowIndex].Cells["电芯左柱高"].Value.ToString();
                string idPoleHeightL = DevManage.Instance().plcpfg.dirDataUint["电芯左柱高"].bandField;
                if (!string.IsNullOrEmpty(PoleHeightL) && DevManage.Instance().currentInfo.Keys.Contains(idPoleHeightL))
                {
                    if (float.Parse(PoleHeightL) < float.Parse(DevManage.Instance().currentInfo[idPoleHeightL].LowerControlLimit) || float.Parse(PoleHeightL) > float.Parse(DevManage.Instance().currentInfo[idPoleHeightL].UpperControlLimit))
                    {
                        this.dataGridView1.Rows[e.RowIndex].Cells["电芯左柱高"].Style.ForeColor = Color.Red;
                    }
                }
            }
            if (this.dataGridView1.Rows[e.RowIndex].Cells["电芯左肩高"].Value != null)
            {
                var shoulderHeightL = this.dataGridView1.Rows[e.RowIndex].Cells["电芯左肩高"].Value.ToString();
                string idshoulderHeightL = DevManage.Instance().plcpfg.dirDataUint["电芯左肩高"].bandField;
                if (!string.IsNullOrEmpty(shoulderHeightL) && DevManage.Instance().currentInfo.Keys.Contains(idshoulderHeightL))
                {
                    if (float.Parse(shoulderHeightL) < float.Parse(DevManage.Instance().currentInfo[idshoulderHeightL].LowerControlLimit) || float.Parse(shoulderHeightL) > float.Parse(DevManage.Instance().currentInfo[idshoulderHeightL].UpperControlLimit))
                    {
                        this.dataGridView1.Rows[e.RowIndex].Cells["电芯左肩高"].Style.ForeColor = Color.Red;
                    }
                }
            }
            if (this.dataGridView1.Rows[e.RowIndex].Cells["电芯宽度"].Value != null)
            {
                var bycellWidth = this.dataGridView1.Rows[e.RowIndex].Cells["电芯宽度"].Value.ToString();
                string idbycellWidth = DevManage.Instance().plcpfg.dirDataUint["电芯宽度"].bandField;
                if (!string.IsNullOrEmpty(bycellWidth) && DevManage.Instance().currentInfo.Keys.Contains(idbycellWidth))
                {
                    if (float.Parse(bycellWidth) < float.Parse(DevManage.Instance().currentInfo[idbycellWidth].LowerControlLimit) || float.Parse(bycellWidth) > float.Parse(DevManage.Instance().currentInfo[idbycellWidth].UpperControlLimit))
                    {
                        this.dataGridView1.Rows[e.RowIndex].Cells["电芯宽度"].Style.ForeColor = Color.Red;
                    }
                }
            }
            if (this.dataGridView1.Rows[e.RowIndex].Cells["电芯厚度"].Value != null)
            {
                var bycellPlies = this.dataGridView1.Rows[e.RowIndex].Cells["电芯厚度"].Value.ToString();
                string idbycellPlies = DevManage.Instance().plcpfg.dirDataUint["电芯厚度"].bandField;
                if (!string.IsNullOrEmpty(bycellPlies) && DevManage.Instance().currentInfo.Keys.Contains(idbycellPlies))
                {
                    if (float.Parse(bycellPlies) < float.Parse(DevManage.Instance().currentInfo[idbycellPlies].LowerControlLimit) || float.Parse(bycellPlies) > float.Parse(DevManage.Instance().currentInfo[idbycellPlies].UpperControlLimit))
                    {
                        this.dataGridView1.Rows[e.RowIndex].Cells["电芯厚度"].Style.ForeColor = Color.Red;
                    }
                }
            }
            if (this.dataGridView1.Rows[e.RowIndex].Cells["电芯右柱高"].Value != null)
            {
                var PoleHeightR = this.dataGridView1.Rows[e.RowIndex].Cells["电芯右柱高"].Value.ToString();
                string idPoleHeightR = DevManage.Instance().plcpfg.dirDataUint["电芯右柱高"].bandField;
                if (!string.IsNullOrEmpty(PoleHeightR) && DevManage.Instance().currentInfo.Keys.Contains(idPoleHeightR))
                {
                    if (float.Parse(PoleHeightR) < float.Parse(DevManage.Instance().currentInfo[idPoleHeightR].LowerControlLimit) || float.Parse(PoleHeightR) > float.Parse(DevManage.Instance().currentInfo[idPoleHeightR].UpperControlLimit))
                    {
                        this.dataGridView1.Rows[e.RowIndex].Cells["电芯右柱高"].Style.ForeColor = Color.Red;
                    }
                }
            }
            if (this.dataGridView1.Rows[e.RowIndex].Cells["电芯右肩高"].Value != null)
            {
                var shoulderHeightR = this.dataGridView1.Rows[e.RowIndex].Cells["电芯右肩高"].Value.ToString();
                string idshoulderHeightR = DevManage.Instance().plcpfg.dirDataUint["电芯右肩高"].bandField;
                if (!string.IsNullOrEmpty(shoulderHeightR) && DevManage.Instance().currentInfo.Keys.Contains(idshoulderHeightR))
                {
                    if (float.Parse(shoulderHeightR) < float.Parse(DevManage.Instance().currentInfo[idshoulderHeightR].LowerControlLimit) || float.Parse(shoulderHeightR) > float.Parse(DevManage.Instance().currentInfo[idshoulderHeightR].UpperControlLimit))
                    {
                        this.dataGridView1.Rows[e.RowIndex].Cells["电芯右肩高"].Style.ForeColor = Color.Red;
                    }
                }
            }
        }

        private void dataGridView1_RowStateChanged(object sender, DataGridViewRowStateChangedEventArgs e)
        {
           
        }
    }
}
