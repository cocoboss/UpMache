﻿using ProBLL;
using ProModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pro
{
    public partial class ManumForm : Form
    {
        public ManumForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try {
                if (MseManager.Instance().isConnect)
                {
                    string message = "";
                    bool ret = DevManage.Instance().SendACEQUPTRUN(out message);
                    if (ret)
                    {
                        DevManage.Instance().RaiseSigStatus(Em_SigName.equipmentIsRun, Em_OtherStatus.OK.ToString());

                        DevManage.Instance().WriteLog($"设备运行请求上传成功");
                        MessageBox.Show("可以开机");
                    }
                    else
                    {
                        DevManage.Instance().RaiseSigStatus(Em_SigName.equipmentIsRun, Em_OtherStatus.NG.ToString());
                        DevManage.Instance().WriteLog($"设备运行请求上传出错;原因：{message}");
                        MessageBox.Show($"不可以开机,原因：{message}");
                    }
                }
                else
                {
                    MessageBox.Show("MES未连接成功，请连接成功后重试！");
                }
            }
            catch(Exception ex)
            {
                DevManage.Instance().WriteErrorLog("设备运行请求上传出错:" + ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DeviceStatusForm df = new Pro.DeviceStatusForm();
            df.StartPosition = FormStartPosition.CenterScreen;

            df.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string message = "";
            bool ret =DevManage.Instance().SendACEQPTPARM(ProcessCode.Text.Trim(),Version.Text.Trim(), out message);
            //ret = true;
            if (ret)
            {
                //DevManage.Instance().Write("上料结果反馈", "2");
                DevManage.Instance().WriteLog($"返回参数：{message}");
                ParamInit pi = new ParamInit();
                pi.processCode = ProcessCode.Text.Trim();
                pi.json = message;



                DevManage.Instance().sysParam.SaveParamInit();
            }
            else
            {
                //DevManage.Instance().Write("上料结果反馈", "1");
                DevManage.Instance().WriteLog($"返回参数失败，原因：{message}");
            }
        }
    }
}
