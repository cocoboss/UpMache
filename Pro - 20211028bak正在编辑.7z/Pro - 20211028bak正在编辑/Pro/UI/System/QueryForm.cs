﻿using ProBLL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Pro
{
    public partial class QueryForm : Form
    {

        string strCondition = "";
        DataTable dataTab=null;


        public QueryForm()
        {
            InitializeComponent();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void QueryForm_Load(object sender, EventArgs e)
        {
            for(int i=0;i<24;i++)
            {
                cmd_startHour.Items.Add(i.ToString());
                cmd_endHour.Items.Add(i.ToString());
            }
            cmd_startHour.SelectedIndex = 9;
            cmd_endHour.SelectedIndex = 21;
            for (int i = 0; i < 60; i++)
            {
                cmd_startMin.Items.Add(i.ToString());
                cmd_endMin.Items.Add(i.ToString());
            }
            cmd_startMin.SelectedIndex = 0;
            cmd_endMin.SelectedIndex = 0;
            for (int i = 0; i < (int)Quy_Result.Count; i++)
            {
                cmd_result.Items.Add(((Quy_Result)i).ToString());
                //cmd_endHour.Items.Add(i.ToString());
            }
            cmd_result.SelectedIndex = 0;
        }

        public string GetFieldString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("barCode as 电芯条码,");
            sb.Append("in_time as 入站时间,");
            sb.Append("in_result as 入站结果,");
            sb.Append("in_message as 入站NG原因,");
            sb.Append("out_time as 出站时间,");
            sb.Append("out_result as 出站结果,");
            sb.Append("out_message as 出站NG原因,");
            sb.Append("PoleHeightL as 电芯左柱高,");
            sb.Append("shoulderHeightL as 电芯左肩高,");
            sb.Append("bycellWidth as 电芯宽度,");
            sb.Append("bycellPlies as 电芯厚度,");
            sb.Append("PoleHeightR as 电芯右柱高,");
            sb.Append("shoulderHeightR as 电芯右肩高,");
            sb.Append("testPliesPress as 测厚压力值,");
            sb.Append("model as 模式");

            return sb.ToString();
        }

        public string GetConddition()
        {
            strCondition = $"where ((in_time>='{cmd_startDate.Value.ToString("yyyy-MM-dd ")}{cmd_startHour.SelectedIndex.ToString()}:{cmd_startMin.SelectedIndex.ToString()}:00'";
            strCondition += $"and in_time<'{cmd_endDate.Value.ToString("yyyy-MM-dd ")}{cmd_endHour.SelectedIndex.ToString()}:{cmd_endMin.SelectedIndex.ToString()}:00')";
            strCondition += $"or (out_time>='{cmd_startDate.Value.ToString("yyyy-MM-dd ")}{cmd_startHour.SelectedIndex.ToString()}:{cmd_startMin.SelectedIndex.ToString()}:00'";
            strCondition += $"and out_time<'{cmd_endDate.Value.ToString("yyyy-MM-dd ")}{cmd_endHour.SelectedIndex.ToString()}:{cmd_endMin.SelectedIndex.ToString()}:00'))";
            switch((Quy_Result)cmd_result.SelectedIndex)
            {
                case Quy_Result.NG:
                    strCondition += $" and (in_result='{cmd_result.Text}' or out_result='{cmd_result.Text}')";
                    break;
                case Quy_Result.OK:
                    strCondition += $" and (in_result='{cmd_result.Text}' or  out_result='{cmd_result.Text}')";
                    break;
                default:
                    break;
            }
            if(cmd_byCell.Text.Trim().Length>0)
            {
                strCondition += $" and barCode like '%{ cmd_byCell.Text.Trim()}%' ";
            }
            return strCondition;
        }
        private void button2_Click(object sender, EventArgs e)
        {
            GetConddition();
            DataBll db = new DataBll();
            dataTab = db.SelectData(GetFieldString(), strCondition);
            dataGrid.DataSource = dataTab;
            dataGrid.Columns["入站时间"].DefaultCellStyle.Format = "yyyy-MM-dd HH:mm:ss";
            dataGrid.Columns["出站时间"].DefaultCellStyle.Format = "yyyy-MM-dd HH:mm:ss";
            this.cmd_byCell.Focus();
            cmd_byCell.SelectAll();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (dataTab == null)
            {
                GetConddition();
                DataBll db = new DataBll();
                dataTab = db.SelectData(GetFieldString(), strCondition);
                //dataGrid.DataSource = dataTab;
                //dataGrid.Columns["入站时间"].DefaultCellStyle.Format = "yyyy-MM-dd HH:mm:ss";
                //dataGrid.Columns["出站时间"].DefaultCellStyle.Format = "yyyy-MM-dd HH:mm:ss";
            }
            SaveFileDialog sf = new SaveFileDialog();
            if (sf.ShowDialog() == DialogResult.OK)
            {
                string filePath = sf.FileName + ".csv";
                using (StreamWriter sw = new StreamWriter(filePath, false, Encoding.UTF8))
                {
                    StringBuilder strBuf = new StringBuilder();
                    foreach(DataColumn col in dataTab.Columns)
                    {
                        strBuf.Append(col.ColumnName + ",");

                    }
                    sw.WriteLine(strBuf.ToString());
                    int colNum = dataTab.Columns.Count;
                    foreach(DataRow row in dataTab.Rows)
                    {
                        strBuf = new StringBuilder();
                        for(int i=0;i<colNum;i++)
                        {
                            strBuf.Append(row[i].ToString() + ",");
                        }
                        sw.WriteLine(strBuf.ToString());
                    }
                    sw.Close();
                }
                MessageBox.Show("导出成功");
            }
            

        }
    }
    public enum Quy_Result
    {
        All,
        OK,
        NG,
        Count
    }
}
