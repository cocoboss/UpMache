﻿namespace Pro
{
    partial class DataForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txt_pfh = new System.Windows.Forms.TextBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.txt_gylj = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.txt_lv = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.txt_cpbh = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.txt_ng = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.txt_cpmc = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.txt_ok = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.txt_gdlx = new System.Windows.Forms.TextBox();
            this.txt_all = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.txt_gdh = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.list_receive = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_receive = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.list_send = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_send = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.电芯条码 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.入站时间 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.入站结果 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.出站时间 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.出站结果 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.电芯左柱高 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.电芯左肩高 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.电芯宽度 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.电芯厚度 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.电芯右柱高 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.电芯右肩高 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.测厚压力 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.入站NG原因 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.出站NG原因 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Location = new System.Drawing.Point(0, 2);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1297, 520);
            this.panel1.TabIndex = 0;
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.电芯条码,
            this.入站时间,
            this.入站结果,
            this.出站时间,
            this.出站结果,
            this.电芯左柱高,
            this.电芯左肩高,
            this.电芯宽度,
            this.电芯厚度,
            this.电芯右柱高,
            this.电芯右肩高,
            this.测厚压力,
            this.入站NG原因,
            this.出站NG原因});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.Size = new System.Drawing.Size(1297, 516);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dataGridView1_RowPostPaint);
            this.dataGridView1.RowPrePaint += new System.Windows.Forms.DataGridViewRowPrePaintEventHandler(this.dataGridView1_RowPrePaint);
            this.dataGridView1.RowStateChanged += new System.Windows.Forms.DataGridViewRowStateChangedEventHandler(this.dataGridView1_RowStateChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.groupBox1.Controls.Add(this.txt_pfh);
            this.groupBox1.Controls.Add(this.textBox24);
            this.groupBox1.Controls.Add(this.txt_gylj);
            this.groupBox1.Controls.Add(this.textBox20);
            this.groupBox1.Controls.Add(this.txt_lv);
            this.groupBox1.Controls.Add(this.textBox14);
            this.groupBox1.Controls.Add(this.txt_cpbh);
            this.groupBox1.Controls.Add(this.textBox16);
            this.groupBox1.Controls.Add(this.txt_ng);
            this.groupBox1.Controls.Add(this.textBox10);
            this.groupBox1.Controls.Add(this.txt_cpmc);
            this.groupBox1.Controls.Add(this.textBox12);
            this.groupBox1.Controls.Add(this.txt_ok);
            this.groupBox1.Controls.Add(this.textBox7);
            this.groupBox1.Controls.Add(this.txt_gdlx);
            this.groupBox1.Controls.Add(this.txt_all);
            this.groupBox1.Controls.Add(this.textBox4);
            this.groupBox1.Controls.Add(this.txt_gdh);
            this.groupBox1.Controls.Add(this.textBox2);
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Location = new System.Drawing.Point(4, 13);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(452, 230);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "产品/设备信息";
            // 
            // txt_pfh
            // 
            this.txt_pfh.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_pfh.Location = new System.Drawing.Point(103, 204);
            this.txt_pfh.Margin = new System.Windows.Forms.Padding(4);
            this.txt_pfh.Name = "txt_pfh";
            this.txt_pfh.ReadOnly = true;
            this.txt_pfh.Size = new System.Drawing.Size(153, 27);
            this.txt_pfh.TabIndex = 21;
            // 
            // textBox24
            // 
            this.textBox24.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox24.Location = new System.Drawing.Point(9, 204);
            this.textBox24.Margin = new System.Windows.Forms.Padding(4);
            this.textBox24.Name = "textBox24";
            this.textBox24.ReadOnly = true;
            this.textBox24.Size = new System.Drawing.Size(88, 27);
            this.textBox24.TabIndex = 20;
            this.textBox24.Text = "配方号:";
            // 
            // txt_gylj
            // 
            this.txt_gylj.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_gylj.Location = new System.Drawing.Point(103, 169);
            this.txt_gylj.Margin = new System.Windows.Forms.Padding(4);
            this.txt_gylj.Name = "txt_gylj";
            this.txt_gylj.ReadOnly = true;
            this.txt_gylj.Size = new System.Drawing.Size(153, 27);
            this.txt_gylj.TabIndex = 17;
            // 
            // textBox20
            // 
            this.textBox20.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox20.Location = new System.Drawing.Point(9, 169);
            this.textBox20.Margin = new System.Windows.Forms.Padding(4);
            this.textBox20.Name = "textBox20";
            this.textBox20.ReadOnly = true;
            this.textBox20.Size = new System.Drawing.Size(88, 27);
            this.textBox20.TabIndex = 16;
            this.textBox20.Text = "工艺路径:";
            // 
            // txt_lv
            // 
            this.txt_lv.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_lv.Location = new System.Drawing.Point(356, 132);
            this.txt_lv.Margin = new System.Windows.Forms.Padding(4);
            this.txt_lv.Name = "txt_lv";
            this.txt_lv.ReadOnly = true;
            this.txt_lv.Size = new System.Drawing.Size(88, 27);
            this.txt_lv.TabIndex = 15;
            // 
            // textBox14
            // 
            this.textBox14.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox14.Location = new System.Drawing.Point(261, 132);
            this.textBox14.Margin = new System.Windows.Forms.Padding(4);
            this.textBox14.Name = "textBox14";
            this.textBox14.ReadOnly = true;
            this.textBox14.Size = new System.Drawing.Size(88, 27);
            this.textBox14.TabIndex = 14;
            this.textBox14.Text = "良率%:";
            // 
            // txt_cpbh
            // 
            this.txt_cpbh.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_cpbh.Location = new System.Drawing.Point(103, 132);
            this.txt_cpbh.Margin = new System.Windows.Forms.Padding(4);
            this.txt_cpbh.Name = "txt_cpbh";
            this.txt_cpbh.ReadOnly = true;
            this.txt_cpbh.Size = new System.Drawing.Size(153, 27);
            this.txt_cpbh.TabIndex = 13;
            // 
            // textBox16
            // 
            this.textBox16.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox16.Location = new System.Drawing.Point(9, 132);
            this.textBox16.Margin = new System.Windows.Forms.Padding(4);
            this.textBox16.Name = "textBox16";
            this.textBox16.ReadOnly = true;
            this.textBox16.Size = new System.Drawing.Size(88, 27);
            this.textBox16.TabIndex = 12;
            this.textBox16.Text = "产品编号:";
            // 
            // txt_ng
            // 
            this.txt_ng.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_ng.Location = new System.Drawing.Point(356, 98);
            this.txt_ng.Margin = new System.Windows.Forms.Padding(4);
            this.txt_ng.Name = "txt_ng";
            this.txt_ng.ReadOnly = true;
            this.txt_ng.Size = new System.Drawing.Size(88, 27);
            this.txt_ng.TabIndex = 11;
            // 
            // textBox10
            // 
            this.textBox10.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox10.Location = new System.Drawing.Point(261, 98);
            this.textBox10.Margin = new System.Windows.Forms.Padding(4);
            this.textBox10.Name = "textBox10";
            this.textBox10.ReadOnly = true;
            this.textBox10.Size = new System.Drawing.Size(88, 27);
            this.textBox10.TabIndex = 10;
            this.textBox10.Text = "NG产量:";
            // 
            // txt_cpmc
            // 
            this.txt_cpmc.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_cpmc.Location = new System.Drawing.Point(103, 98);
            this.txt_cpmc.Margin = new System.Windows.Forms.Padding(4);
            this.txt_cpmc.Name = "txt_cpmc";
            this.txt_cpmc.ReadOnly = true;
            this.txt_cpmc.Size = new System.Drawing.Size(153, 27);
            this.txt_cpmc.TabIndex = 9;
            // 
            // textBox12
            // 
            this.textBox12.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox12.Location = new System.Drawing.Point(9, 98);
            this.textBox12.Margin = new System.Windows.Forms.Padding(4);
            this.textBox12.Name = "textBox12";
            this.textBox12.ReadOnly = true;
            this.textBox12.Size = new System.Drawing.Size(88, 27);
            this.textBox12.TabIndex = 8;
            this.textBox12.Text = "产品名称:";
            // 
            // txt_ok
            // 
            this.txt_ok.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_ok.Location = new System.Drawing.Point(356, 62);
            this.txt_ok.Margin = new System.Windows.Forms.Padding(4);
            this.txt_ok.Name = "txt_ok";
            this.txt_ok.ReadOnly = true;
            this.txt_ok.Size = new System.Drawing.Size(88, 27);
            this.txt_ok.TabIndex = 7;
            // 
            // textBox7
            // 
            this.textBox7.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox7.Location = new System.Drawing.Point(261, 62);
            this.textBox7.Margin = new System.Windows.Forms.Padding(4);
            this.textBox7.Name = "textBox7";
            this.textBox7.ReadOnly = true;
            this.textBox7.Size = new System.Drawing.Size(88, 27);
            this.textBox7.TabIndex = 6;
            this.textBox7.Text = "OK数量:";
            // 
            // txt_gdlx
            // 
            this.txt_gdlx.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_gdlx.Location = new System.Drawing.Point(103, 62);
            this.txt_gdlx.Margin = new System.Windows.Forms.Padding(4);
            this.txt_gdlx.Name = "txt_gdlx";
            this.txt_gdlx.ReadOnly = true;
            this.txt_gdlx.Size = new System.Drawing.Size(153, 27);
            this.txt_gdlx.TabIndex = 5;
            // 
            // txt_all
            // 
            this.txt_all.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_all.Location = new System.Drawing.Point(356, 26);
            this.txt_all.Margin = new System.Windows.Forms.Padding(4);
            this.txt_all.Name = "txt_all";
            this.txt_all.ReadOnly = true;
            this.txt_all.Size = new System.Drawing.Size(88, 27);
            this.txt_all.TabIndex = 4;
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox4.Location = new System.Drawing.Point(261, 26);
            this.textBox4.Margin = new System.Windows.Forms.Padding(4);
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new System.Drawing.Size(88, 27);
            this.textBox4.TabIndex = 3;
            this.textBox4.Text = "当班产量:";
            // 
            // txt_gdh
            // 
            this.txt_gdh.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_gdh.Location = new System.Drawing.Point(103, 26);
            this.txt_gdh.Margin = new System.Windows.Forms.Padding(4);
            this.txt_gdh.Name = "txt_gdh";
            this.txt_gdh.ReadOnly = true;
            this.txt_gdh.Size = new System.Drawing.Size(153, 27);
            this.txt_gdh.TabIndex = 2;
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox2.Location = new System.Drawing.Point(9, 62);
            this.textBox2.Margin = new System.Windows.Forms.Padding(4);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(88, 27);
            this.textBox2.TabIndex = 1;
            this.textBox2.Text = "工单类型:";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox1.Location = new System.Drawing.Point(9, 26);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(88, 27);
            this.textBox1.TabIndex = 0;
            this.textBox1.Text = "工单号:";
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.Controls.Add(this.groupBox3);
            this.panel2.Controls.Add(this.groupBox2);
            this.panel2.Location = new System.Drawing.Point(470, 4);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(818, 239);
            this.panel2.TabIndex = 2;
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox3.Controls.Add(this.list_receive);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.txt_receive);
            this.groupBox3.Location = new System.Drawing.Point(667, 5);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox3.Size = new System.Drawing.Size(147, 230);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "上位机接收";
            // 
            // list_receive
            // 
            this.list_receive.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.list_receive.Location = new System.Drawing.Point(7, 62);
            this.list_receive.Multiline = true;
            this.list_receive.Name = "list_receive";
            this.list_receive.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.list_receive.Size = new System.Drawing.Size(140, 161);
            this.list_receive.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(9, 31);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(98, 18);
            this.label2.TabIndex = 3;
            this.label2.Text = "接收接口：";
            // 
            // txt_receive
            // 
            this.txt_receive.BackColor = System.Drawing.Color.LimeGreen;
            this.txt_receive.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_receive.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_receive.Location = new System.Drawing.Point(116, 31);
            this.txt_receive.Margin = new System.Windows.Forms.Padding(4);
            this.txt_receive.Name = "txt_receive";
            this.txt_receive.Size = new System.Drawing.Size(133, 20);
            this.txt_receive.TabIndex = 2;
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.groupBox2.Controls.Add(this.list_send);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.txt_send);
            this.groupBox2.Location = new System.Drawing.Point(4, 9);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(663, 230);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "上位机发送";
            // 
            // list_send
            // 
            this.list_send.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.list_send.Location = new System.Drawing.Point(8, 62);
            this.list_send.Multiline = true;
            this.list_send.Name = "list_send";
            this.list_send.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.list_send.Size = new System.Drawing.Size(648, 161);
            this.list_send.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(7, 31);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(98, 18);
            this.label1.TabIndex = 1;
            this.label1.Text = "发送接口：";
            // 
            // txt_send
            // 
            this.txt_send.BackColor = System.Drawing.Color.LimeGreen;
            this.txt_send.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_send.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_send.Location = new System.Drawing.Point(119, 30);
            this.txt_send.Margin = new System.Windows.Forms.Padding(4);
            this.txt_send.Name = "txt_send";
            this.txt_send.Size = new System.Drawing.Size(133, 20);
            this.txt_send.TabIndex = 0;
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.Controls.Add(this.panel2);
            this.panel3.Controls.Add(this.groupBox1);
            this.panel3.Location = new System.Drawing.Point(0, 526);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1297, 247);
            this.panel3.TabIndex = 3;
            // 
            // 电芯条码
            // 
            this.电芯条码.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.电芯条码.HeaderText = "电芯条码";
            this.电芯条码.Name = "电芯条码";
            this.电芯条码.Width = 102;
            // 
            // 入站时间
            // 
            this.入站时间.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.入站时间.HeaderText = "入站时间";
            this.入站时间.Name = "入站时间";
            this.入站时间.Width = 102;
            // 
            // 入站结果
            // 
            this.入站结果.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.入站结果.HeaderText = "入站结果";
            this.入站结果.Name = "入站结果";
            this.入站结果.Width = 102;
            // 
            // 出站时间
            // 
            this.出站时间.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.出站时间.HeaderText = "出站时间";
            this.出站时间.Name = "出站时间";
            this.出站时间.Width = 102;
            // 
            // 出站结果
            // 
            this.出站结果.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.出站结果.HeaderText = "出站结果";
            this.出站结果.Name = "出站结果";
            this.出站结果.Width = 102;
            // 
            // 电芯左柱高
            // 
            this.电芯左柱高.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.电芯左柱高.HeaderText = "电芯左柱高(mm)";
            this.电芯左柱高.Name = "电芯左柱高";
            this.电芯左柱高.Width = 145;
            // 
            // 电芯左肩高
            // 
            this.电芯左肩高.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.电芯左肩高.HeaderText = "电芯左肩高(mm)";
            this.电芯左肩高.Name = "电芯左肩高";
            this.电芯左肩高.Width = 145;
            // 
            // 电芯宽度
            // 
            this.电芯宽度.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.电芯宽度.HeaderText = "电芯宽度(mm)";
            this.电芯宽度.Name = "电芯宽度";
            this.电芯宽度.Width = 124;
            // 
            // 电芯厚度
            // 
            this.电芯厚度.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.电芯厚度.HeaderText = "电芯厚度(mm)";
            this.电芯厚度.Name = "电芯厚度";
            this.电芯厚度.Width = 124;
            // 
            // 电芯右柱高
            // 
            this.电芯右柱高.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.电芯右柱高.HeaderText = "电芯右柱高(mm)";
            this.电芯右柱高.Name = "电芯右柱高";
            this.电芯右柱高.Width = 145;
            // 
            // 电芯右肩高
            // 
            this.电芯右肩高.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.电芯右肩高.HeaderText = "电芯右肩高(mm)";
            this.电芯右肩高.Name = "电芯右肩高";
            this.电芯右肩高.Width = 145;
            // 
            // 测厚压力
            // 
            this.测厚压力.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.测厚压力.HeaderText = "测厚压力(kgf)";
            this.测厚压力.Name = "测厚压力";
            this.测厚压力.Width = 124;
            // 
            // 入站NG原因
            // 
            this.入站NG原因.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.入站NG原因.HeaderText = "入站NG原因";
            this.入站NG原因.Name = "入站NG原因";
            this.入站NG原因.Width = 124;
            // 
            // 出站NG原因
            // 
            this.出站NG原因.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.出站NG原因.HeaderText = "出站NG原因";
            this.出站NG原因.Name = "出站NG原因";
            this.出站NG原因.Width = 124;
            // 
            // DataForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1301, 775);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel3);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "DataForm";
            this.Text = "DataForm";
            this.Load += new System.EventHandler(this.DataForm_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txt_pfh;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.TextBox txt_gylj;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TextBox txt_lv;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox txt_cpbh;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox txt_ng;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox txt_cpmc;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox txt_ok;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox txt_gdlx;
        private System.Windows.Forms.TextBox txt_all;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox txt_gdh;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_receive;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_send;
        private System.Windows.Forms.TextBox list_send;
        private System.Windows.Forms.TextBox list_receive;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.DataGridViewTextBoxColumn 电芯条码;
        private System.Windows.Forms.DataGridViewTextBoxColumn 入站时间;
        private System.Windows.Forms.DataGridViewTextBoxColumn 入站结果;
        private System.Windows.Forms.DataGridViewTextBoxColumn 出站时间;
        private System.Windows.Forms.DataGridViewTextBoxColumn 出站结果;
        private System.Windows.Forms.DataGridViewTextBoxColumn 电芯左柱高;
        private System.Windows.Forms.DataGridViewTextBoxColumn 电芯左肩高;
        private System.Windows.Forms.DataGridViewTextBoxColumn 电芯宽度;
        private System.Windows.Forms.DataGridViewTextBoxColumn 电芯厚度;
        private System.Windows.Forms.DataGridViewTextBoxColumn 电芯右柱高;
        private System.Windows.Forms.DataGridViewTextBoxColumn 电芯右肩高;
        private System.Windows.Forms.DataGridViewTextBoxColumn 测厚压力;
        private System.Windows.Forms.DataGridViewTextBoxColumn 入站NG原因;
        private System.Windows.Forms.DataGridViewTextBoxColumn 出站NG原因;
    }
}