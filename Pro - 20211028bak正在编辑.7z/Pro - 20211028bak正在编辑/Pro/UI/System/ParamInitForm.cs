﻿using ProModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ProBLL;
using Apriso.MIPlugins.Communication.Clients.WcfServiceAPI;

namespace Pro
{
    public partial class ParamInitForm : Form
    {
        public bool isParamInit = false;
        public ParamInit pi = null;
        public ParamInitForm()
        {
            InitializeComponent();
            DevManage.Instance().userMgn.evenHand.event_ParamInit += ParamInitReceiver;
        }

        public void ParamInitReceiver(object sender,EventArgs e)
        {
            bool isRet = false;
            Guid guid = Guid.NewGuid();
            InveokeCls.DoInvokeRequired(dataGridView1, () =>
            {
                dataGridView1.Rows.Clear();
            });
            InveokeCls.DoInvokeRequired(dataGridView2, () =>
            {
                dataGridView2.Rows.Clear();
            });
            ACEQPTINIT.ACEQPTINITRequestEquipmentInfo info = null;
            if (e != null)
            {
                ParamInitEventArgs pe = (ParamInitEventArgs)e;
                if (pe.isReturnMes == 0)
                    isRet = true;
                ACEQPTINIT.ACEQPTINITRequest request = Common.FormJson<ACEQPTINIT.ACEQPTINITRequest>(pe.json);
                guid = request.MessageGuid;
                ACEQPTINIT.ACEQPTINITRequestJson json = request.CommandRequestJson;
                if (json.EquipmentInfo.Count > 0)
                    info = json.EquipmentInfo[0];
            }
            else
                info = Common.FormJson<ACEQPTINIT.ACEQPTINITRequestEquipmentInfo>((string)sender);
            InveokeCls.DoInvokeRequired(WipOrder, () =>
            {
                WipOrder.Text = string.IsNullOrEmpty(info.WipOrder)?"": info.WipOrder;
            });
            InveokeCls.DoInvokeRequired(ProductNo, () =>
            {
                ProductNo.Text = string.IsNullOrEmpty(info.ProductNo) ? "" : info.ProductNo;
            });
            InveokeCls.DoInvokeRequired(Customer, () =>
            {
                Customer.Text = string.IsNullOrEmpty(info.Customer) ? "" : info.Customer;
            });
            InveokeCls.DoInvokeRequired(ProductDesc, () =>
            {
                ProductDesc.Text = string.IsNullOrEmpty(info.ProductDesc) ? "" : info.ProductDesc;
            });
            InveokeCls.DoInvokeRequired(WipOrderType, () =>
            {
                WipOrderType.Text = string.IsNullOrEmpty(info.WipOrderType) ? "" : info.WipOrderType;
            });
            InveokeCls.DoInvokeRequired(ProcessID, () =>
            {
                ProcessID.Text = string.IsNullOrEmpty(info.ProcessID) ? "" : info.ProcessID;
            });
            InveokeCls.DoInvokeRequired(Version, () =>
            {
                Version.Text = string.IsNullOrEmpty(info.Version) ? "" : info.Version;
            });
            InveokeCls.DoInvokeRequired(OprSequenceNo, () =>
            {
                OprSequenceNo.Text = string.IsNullOrEmpty(info.OprSequenceNo) ? "" : info.OprSequenceNo;
            });
            InveokeCls.DoInvokeRequired(OperationCode, () =>
            {
                OperationCode.Text = string.IsNullOrEmpty(info.OperationCode) ? "" : info.OperationCode;
            });
            InveokeCls.DoInvokeRequired(OprSequenceDesc, () =>
            {
                OprSequenceDesc.Text = string.IsNullOrEmpty(info.OprSequenceDesc) ? "" : info.OprSequenceDesc;
            });
            InveokeCls.DoInvokeRequired(RecipeID, () =>
            {
                RecipeID.Text = string.IsNullOrEmpty(info.RecipeID) ? "" : info.RecipeID;
            });
            if(info.StepInfo.Count>0)
            {
                foreach (var item in info.StepInfo[0].ParameterInfo)
                {
                    if(item.Description.Contains("设定"))
                    {
                        InveokeCls.DoInvokeRequired(dataGridView1, () =>
                        {
                            dataGridView1.Rows.Insert(0,
                                item.ParameterCode,
                                item.Description,
                                 item.LowerControlLimit,
                                  item.TargetValue,
                                   "",
                                    item.UpperControlLimit,
                                    item.UOMCode
                                );
                        });
                        AddrGroups group = DevManage.Instance().plcpfg.dirGroup[DevManage.Instance().sysParam.sysParam[Em_DefineVariable.ParamInit.ToString()]];
                        for(int i=0;i<group.unitLst.Count;i++)
                        {
                            if (group.unitLst[i].Name.Contains(item.Description))
                            {
                                string temp = group.unitLst[i].Name;
                                switch (temp.Replace(item.Description,""))
                                {
                                    case "":
                                        group.unitLst[i].bandField = item.ParameterCode;
                                        group.unitLst[i].Data = item.TargetValue;
                                        break;
                                    case "上限":
                                        group.unitLst[i].bandField = item.ParameterCode;
                                        group.unitLst[i].Data = item.UpperControlLimit;
                                        break;
                                    case "下限":
                                        group.unitLst[i].bandField = item.ParameterCode;
                                        group.unitLst[i].Data = item.LowerControlLimit;
                                        break;
                                    default:
                                        break;
                                }
                            }
                        }
                        DevManage.Instance().plcpfg.dirGroup[DevManage.Instance().sysParam.sysParam[Em_DefineVariable.ParamInit.ToString()]]=group;

                    }
                    else
                    {
                        InveokeCls.DoInvokeRequired(dataGridView2, () =>
                        {
                            dataGridView2.Rows.Insert(0,
                                                    item.ParameterCode,
                                                    item.Description,
                                                     item.LowerControlLimit,
                                                      //item.TargetValue,
                                                       "",
                                                        item.UpperControlLimit,
                                                        //item.UOMCode
                                                        ""
                                                    );
                        });
                        if(DevManage.Instance().tempInfo.Keys.Contains(item.ParameterCode))
                        {
                            DevManage.Instance().tempInfo[item.ParameterCode] = item;
                        }else
                        {
                            DevManage.Instance().tempInfo.Add(item.ParameterCode, item);
                        }
                        
                    }         
                }
            } 
            
            if(isRet)
            {
                button2_Click(null, null);
                DevManage.Instance().SendRetuenInitParam(guid,isParamInit);
            }
            
            
                
        }

        
        private void button1_Click(object sender, EventArgs e)
        {
            string message = "";
            bool ret = DevManage.Instance().SendACEQPTPARM(txt_code.Text.Trim(), txt_Version.Text.Trim(), out message);
            //ret = true;
            if (ret)
            {
                //DevManage.Instance().Write("上料结果反馈", "2");
                
                DevManage.Instance().WriteLog($"返回参数：{message}");
                pi = new ParamInit();
                pi.processCode = txt_code.Text.Trim();
                pi.json = message;
                pi.isable = 0;
                pi.remark = "";
                pi.employe = "";
                pi.entime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                DevManage.Instance().sysParam.SaveParamInit(pi);
                ParamInitReceiver(message,null);
                DevManage.Instance().tempParamInit = Common.FormJson<ACEQPTINIT.ACEQPTINITRequestEquipmentInfo>(message);
            }
            else
            {
                //DevManage.Instance().Write("上料结果反馈", "1");
                DevManage.Instance().WriteLog($"返回参数失败，原因：{message}");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (DevManage.Instance().tempParamInit != null)
            {
                DevManage.Instance().currentParamInit = null;
                DevManage.Instance().currentParamInit = DevManage.Instance().tempParamInit;
            }
            if (DevManage.Instance().tempInfo != null && DevManage.Instance().tempInfo.Count>0)
            {
                DevManage.Instance().currentInfo.Clear();
                DevManage.Instance().currentInfo = DevManage.Instance().tempInfo;
            }
            //DevManage.Instance().tempParamInit = DevManage.Instance().tempParamInit;
            AddrGroups group = DevManage.Instance().plcpfg.dirGroup[DevManage.Instance().sysParam.sysParam[Em_DefineVariable.ParamInit.ToString()]];
            bool isVal = true;

            for (int i = 0; i < group.unitLst.Count; i++)
            {
                if(dataGridView1.Rows.Count>0)
                {
                    for(int j=0;j< dataGridView1.Rows.Count-1;j++)
                    {
                        if (group.unitLst[i].bandField.Contains(dataGridView1.Rows[j].Cells[0].Value.ToString().Trim()))
                        {
                            if(group.unitLst[i].Name.Contains("上限"))
                            {
                                if (!string.IsNullOrEmpty(dataGridView1.Rows[j].Cells[5].Value.ToString().Trim()))
                                {
                                    DevManage.Instance().Write(group.unitLst[i].Name, dataGridView1.Rows[j].Cells[5].Value.ToString().Trim());
                                    if (!DevManage.Instance().Read(group.unitLst[i].Name).Contains(dataGridView1.Rows[j].Cells[5].Value.ToString().Trim()))
                                        isVal = false;
                                }
                            }
                            else if (group.unitLst[i].Name.Contains("下限"))
                            {
                                if (!string.IsNullOrEmpty(dataGridView1.Rows[j].Cells[2].Value.ToString().Trim()))
                                {
                                    DevManage.Instance().Write(group.unitLst[i].Name, dataGridView1.Rows[j].Cells[2].Value.ToString().Trim());
                                    if (!DevManage.Instance().Read(group.unitLst[i].Name).Contains(dataGridView1.Rows[j].Cells[2].Value.ToString().Trim()))
                                        isVal = false;
                                }
                            }
                            else
                            {
                                if (!string.IsNullOrEmpty(dataGridView1.Rows[j].Cells[3].Value.ToString().Trim()))
                                {
                                    DevManage.Instance().Write(group.unitLst[i].Name, dataGridView1.Rows[j].Cells[3].Value.ToString().Trim());
                                    string temp = DevManage.Instance().Read(group.unitLst[i].Name);
                                    dataGridView1.Rows[j].Cells[4].Value = temp;
                                    if (!temp.Contains(dataGridView1.Rows[j].Cells[3].Value.ToString().Trim()))
                                        isVal = false;
                                }
                            }


                        }
                    }
                }
                
            }
            isParamInit = isVal;
            if (pi != null)
            {
                //ParamInit pi = new ParamInit();
                //pi.processCode = txt_code.Text.Trim();
                //pi.json = message;
                pi.isable = 1;
                //pi.remark = "";
                //pi.employe = "";
                //pi.entime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                DevManage.Instance().sysParam.SaveParamInit(pi);
            }
        }

        private void ParamInitForm_Load(object sender, EventArgs e)
        {
            if (DevManage.Instance().userMgn.perCurrent.rightBarItem.Keys.Contains(this.Name))
            {
                if (DevManage.Instance().userMgn.perCurrent.rightBarItem[this.Name] != Em_Right.Write)
                {
                    DevManage.Instance().ControlEnable(false, this.Controls);
                }
                else
                {
                    DevManage.Instance().ControlEnable(true, this.Controls);
                }
            }
            if (DevManage.Instance().currentParamInit!=null)
            {
                ParamInitReceiver(Common.ToJSON(DevManage.Instance().currentParamInit), null);
            }
            if (DevManage.Instance().isDebug)
                Task.Run(() => { DevManage.Instance().test(); });
        }
    }
}
