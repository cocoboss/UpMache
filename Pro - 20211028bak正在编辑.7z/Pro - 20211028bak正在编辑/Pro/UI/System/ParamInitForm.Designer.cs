﻿namespace Pro
{
    partial class ParamInitForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.OprSequenceNo = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.OprSequenceDesc = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.RecipeID = new System.Windows.Forms.TextBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.ProcessID = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.txt_lv = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.ProductNo = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.OperationCode = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.ProductDesc = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.Version = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.WipOrderType = new System.Windows.Forms.TextBox();
            this.Customer = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.WipOrder = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.结果参数编码 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MES下限值 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PLC下限值 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MES上限值 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PLC上限值 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.设置参数编码 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.参数名称 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.设定下限值 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MES标准值 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PLC实际值 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.设定上限值 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.单位 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txt_Version = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_code = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.textBox9);
            this.groupBox1.Controls.Add(this.textBox11);
            this.groupBox1.Controls.Add(this.textBox13);
            this.groupBox1.Controls.Add(this.textBox15);
            this.groupBox1.Controls.Add(this.textBox17);
            this.groupBox1.Controls.Add(this.textBox18);
            this.groupBox1.Controls.Add(this.OprSequenceNo);
            this.groupBox1.Controls.Add(this.textBox21);
            this.groupBox1.Controls.Add(this.textBox3);
            this.groupBox1.Controls.Add(this.textBox5);
            this.groupBox1.Controls.Add(this.OprSequenceDesc);
            this.groupBox1.Controls.Add(this.textBox8);
            this.groupBox1.Controls.Add(this.RecipeID);
            this.groupBox1.Controls.Add(this.textBox24);
            this.groupBox1.Controls.Add(this.ProcessID);
            this.groupBox1.Controls.Add(this.textBox20);
            this.groupBox1.Controls.Add(this.txt_lv);
            this.groupBox1.Controls.Add(this.textBox14);
            this.groupBox1.Controls.Add(this.ProductNo);
            this.groupBox1.Controls.Add(this.textBox16);
            this.groupBox1.Controls.Add(this.OperationCode);
            this.groupBox1.Controls.Add(this.textBox10);
            this.groupBox1.Controls.Add(this.ProductDesc);
            this.groupBox1.Controls.Add(this.textBox12);
            this.groupBox1.Controls.Add(this.Version);
            this.groupBox1.Controls.Add(this.textBox7);
            this.groupBox1.Controls.Add(this.WipOrderType);
            this.groupBox1.Controls.Add(this.Customer);
            this.groupBox1.Controls.Add(this.textBox4);
            this.groupBox1.Controls.Add(this.WipOrder);
            this.groupBox1.Controls.Add(this.textBox2);
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Location = new System.Drawing.Point(13, 13);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(1047, 170);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "MES下发产品信息";
            // 
            // textBox9
            // 
            this.textBox9.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox9.Location = new System.Drawing.Point(879, 130);
            this.textBox9.Margin = new System.Windows.Forms.Padding(4);
            this.textBox9.Name = "textBox9";
            this.textBox9.ReadOnly = true;
            this.textBox9.Size = new System.Drawing.Size(153, 27);
            this.textBox9.TabIndex = 33;
            // 
            // textBox11
            // 
            this.textBox11.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox11.Location = new System.Drawing.Point(784, 130);
            this.textBox11.Margin = new System.Windows.Forms.Padding(4);
            this.textBox11.Name = "textBox11";
            this.textBox11.ReadOnly = true;
            this.textBox11.Size = new System.Drawing.Size(88, 27);
            this.textBox11.TabIndex = 32;
            // 
            // textBox13
            // 
            this.textBox13.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox13.Location = new System.Drawing.Point(879, 96);
            this.textBox13.Margin = new System.Windows.Forms.Padding(4);
            this.textBox13.Name = "textBox13";
            this.textBox13.ReadOnly = true;
            this.textBox13.Size = new System.Drawing.Size(153, 27);
            this.textBox13.TabIndex = 31;
            // 
            // textBox15
            // 
            this.textBox15.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox15.Location = new System.Drawing.Point(784, 96);
            this.textBox15.Margin = new System.Windows.Forms.Padding(4);
            this.textBox15.Name = "textBox15";
            this.textBox15.ReadOnly = true;
            this.textBox15.Size = new System.Drawing.Size(88, 27);
            this.textBox15.TabIndex = 30;
            // 
            // textBox17
            // 
            this.textBox17.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox17.Location = new System.Drawing.Point(879, 61);
            this.textBox17.Margin = new System.Windows.Forms.Padding(4);
            this.textBox17.Name = "textBox17";
            this.textBox17.ReadOnly = true;
            this.textBox17.Size = new System.Drawing.Size(153, 27);
            this.textBox17.TabIndex = 29;
            // 
            // textBox18
            // 
            this.textBox18.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox18.Location = new System.Drawing.Point(784, 61);
            this.textBox18.Margin = new System.Windows.Forms.Padding(4);
            this.textBox18.Name = "textBox18";
            this.textBox18.ReadOnly = true;
            this.textBox18.Size = new System.Drawing.Size(88, 27);
            this.textBox18.TabIndex = 28;
            // 
            // OprSequenceNo
            // 
            this.OprSequenceNo.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.OprSequenceNo.Location = new System.Drawing.Point(879, 25);
            this.OprSequenceNo.Margin = new System.Windows.Forms.Padding(4);
            this.OprSequenceNo.Name = "OprSequenceNo";
            this.OprSequenceNo.ReadOnly = true;
            this.OprSequenceNo.Size = new System.Drawing.Size(153, 27);
            this.OprSequenceNo.TabIndex = 27;
            // 
            // textBox21
            // 
            this.textBox21.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox21.Location = new System.Drawing.Point(784, 25);
            this.textBox21.Margin = new System.Windows.Forms.Padding(4);
            this.textBox21.Name = "textBox21";
            this.textBox21.ReadOnly = true;
            this.textBox21.Size = new System.Drawing.Size(88, 27);
            this.textBox21.TabIndex = 26;
            this.textBox21.Text = "工序编号:";
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox3.Location = new System.Drawing.Point(623, 130);
            this.textBox3.Margin = new System.Windows.Forms.Padding(4);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(153, 27);
            this.textBox3.TabIndex = 25;
            // 
            // textBox5
            // 
            this.textBox5.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox5.Location = new System.Drawing.Point(528, 130);
            this.textBox5.Margin = new System.Windows.Forms.Padding(4);
            this.textBox5.Name = "textBox5";
            this.textBox5.ReadOnly = true;
            this.textBox5.Size = new System.Drawing.Size(88, 27);
            this.textBox5.TabIndex = 24;
            // 
            // OprSequenceDesc
            // 
            this.OprSequenceDesc.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.OprSequenceDesc.Location = new System.Drawing.Point(623, 96);
            this.OprSequenceDesc.Margin = new System.Windows.Forms.Padding(4);
            this.OprSequenceDesc.Name = "OprSequenceDesc";
            this.OprSequenceDesc.ReadOnly = true;
            this.OprSequenceDesc.Size = new System.Drawing.Size(153, 27);
            this.OprSequenceDesc.TabIndex = 23;
            // 
            // textBox8
            // 
            this.textBox8.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox8.Location = new System.Drawing.Point(528, 96);
            this.textBox8.Margin = new System.Windows.Forms.Padding(4);
            this.textBox8.Name = "textBox8";
            this.textBox8.ReadOnly = true;
            this.textBox8.Size = new System.Drawing.Size(88, 27);
            this.textBox8.TabIndex = 22;
            this.textBox8.Text = "工序名称:";
            // 
            // RecipeID
            // 
            this.RecipeID.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.RecipeID.Location = new System.Drawing.Point(358, 61);
            this.RecipeID.Margin = new System.Windows.Forms.Padding(4);
            this.RecipeID.Name = "RecipeID";
            this.RecipeID.ReadOnly = true;
            this.RecipeID.Size = new System.Drawing.Size(153, 27);
            this.RecipeID.TabIndex = 21;
            // 
            // textBox24
            // 
            this.textBox24.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox24.Location = new System.Drawing.Point(264, 61);
            this.textBox24.Margin = new System.Windows.Forms.Padding(4);
            this.textBox24.Name = "textBox24";
            this.textBox24.ReadOnly = true;
            this.textBox24.Size = new System.Drawing.Size(88, 27);
            this.textBox24.TabIndex = 20;
            this.textBox24.Text = "配方号:";
            // 
            // ProcessID
            // 
            this.ProcessID.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ProcessID.Location = new System.Drawing.Point(358, 25);
            this.ProcessID.Margin = new System.Windows.Forms.Padding(4);
            this.ProcessID.Name = "ProcessID";
            this.ProcessID.ReadOnly = true;
            this.ProcessID.Size = new System.Drawing.Size(153, 27);
            this.ProcessID.TabIndex = 17;
            // 
            // textBox20
            // 
            this.textBox20.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox20.Location = new System.Drawing.Point(264, 26);
            this.textBox20.Margin = new System.Windows.Forms.Padding(4);
            this.textBox20.Name = "textBox20";
            this.textBox20.ReadOnly = true;
            this.textBox20.Size = new System.Drawing.Size(88, 27);
            this.textBox20.TabIndex = 16;
            this.textBox20.Text = "工艺路径:";
            // 
            // txt_lv
            // 
            this.txt_lv.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_lv.Location = new System.Drawing.Point(358, 130);
            this.txt_lv.Margin = new System.Windows.Forms.Padding(4);
            this.txt_lv.Name = "txt_lv";
            this.txt_lv.ReadOnly = true;
            this.txt_lv.Size = new System.Drawing.Size(153, 27);
            this.txt_lv.TabIndex = 15;
            // 
            // textBox14
            // 
            this.textBox14.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox14.Location = new System.Drawing.Point(263, 130);
            this.textBox14.Margin = new System.Windows.Forms.Padding(4);
            this.textBox14.Name = "textBox14";
            this.textBox14.ReadOnly = true;
            this.textBox14.Size = new System.Drawing.Size(88, 27);
            this.textBox14.TabIndex = 14;
            // 
            // ProductNo
            // 
            this.ProductNo.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ProductNo.Location = new System.Drawing.Point(103, 132);
            this.ProductNo.Margin = new System.Windows.Forms.Padding(4);
            this.ProductNo.Name = "ProductNo";
            this.ProductNo.ReadOnly = true;
            this.ProductNo.Size = new System.Drawing.Size(153, 27);
            this.ProductNo.TabIndex = 13;
            // 
            // textBox16
            // 
            this.textBox16.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox16.Location = new System.Drawing.Point(9, 132);
            this.textBox16.Margin = new System.Windows.Forms.Padding(4);
            this.textBox16.Name = "textBox16";
            this.textBox16.ReadOnly = true;
            this.textBox16.Size = new System.Drawing.Size(88, 27);
            this.textBox16.TabIndex = 12;
            this.textBox16.Text = "产品编号:";
            // 
            // OperationCode
            // 
            this.OperationCode.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.OperationCode.Location = new System.Drawing.Point(358, 96);
            this.OperationCode.Margin = new System.Windows.Forms.Padding(4);
            this.OperationCode.Name = "OperationCode";
            this.OperationCode.ReadOnly = true;
            this.OperationCode.Size = new System.Drawing.Size(153, 27);
            this.OperationCode.TabIndex = 11;
            // 
            // textBox10
            // 
            this.textBox10.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox10.Location = new System.Drawing.Point(263, 96);
            this.textBox10.Margin = new System.Windows.Forms.Padding(4);
            this.textBox10.Name = "textBox10";
            this.textBox10.ReadOnly = true;
            this.textBox10.Size = new System.Drawing.Size(88, 27);
            this.textBox10.TabIndex = 10;
            this.textBox10.Text = "工序代码:";
            // 
            // ProductDesc
            // 
            this.ProductDesc.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ProductDesc.Location = new System.Drawing.Point(103, 98);
            this.ProductDesc.Margin = new System.Windows.Forms.Padding(4);
            this.ProductDesc.Name = "ProductDesc";
            this.ProductDesc.ReadOnly = true;
            this.ProductDesc.Size = new System.Drawing.Size(153, 27);
            this.ProductDesc.TabIndex = 9;
            // 
            // textBox12
            // 
            this.textBox12.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox12.Location = new System.Drawing.Point(9, 98);
            this.textBox12.Margin = new System.Windows.Forms.Padding(4);
            this.textBox12.Name = "textBox12";
            this.textBox12.ReadOnly = true;
            this.textBox12.Size = new System.Drawing.Size(88, 27);
            this.textBox12.TabIndex = 8;
            this.textBox12.Text = "产品名称:";
            // 
            // Version
            // 
            this.Version.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Version.Location = new System.Drawing.Point(623, 61);
            this.Version.Margin = new System.Windows.Forms.Padding(4);
            this.Version.Name = "Version";
            this.Version.ReadOnly = true;
            this.Version.Size = new System.Drawing.Size(153, 27);
            this.Version.TabIndex = 7;
            // 
            // textBox7
            // 
            this.textBox7.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox7.Location = new System.Drawing.Point(528, 61);
            this.textBox7.Margin = new System.Windows.Forms.Padding(4);
            this.textBox7.Name = "textBox7";
            this.textBox7.ReadOnly = true;
            this.textBox7.Size = new System.Drawing.Size(88, 27);
            this.textBox7.TabIndex = 6;
            this.textBox7.Text = "版本信息:";
            // 
            // WipOrderType
            // 
            this.WipOrderType.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.WipOrderType.Location = new System.Drawing.Point(103, 62);
            this.WipOrderType.Margin = new System.Windows.Forms.Padding(4);
            this.WipOrderType.Name = "WipOrderType";
            this.WipOrderType.ReadOnly = true;
            this.WipOrderType.Size = new System.Drawing.Size(153, 27);
            this.WipOrderType.TabIndex = 5;
            // 
            // Customer
            // 
            this.Customer.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Customer.Location = new System.Drawing.Point(623, 25);
            this.Customer.Margin = new System.Windows.Forms.Padding(4);
            this.Customer.Name = "Customer";
            this.Customer.ReadOnly = true;
            this.Customer.Size = new System.Drawing.Size(153, 27);
            this.Customer.TabIndex = 4;
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox4.Location = new System.Drawing.Point(528, 25);
            this.textBox4.Margin = new System.Windows.Forms.Padding(4);
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new System.Drawing.Size(88, 27);
            this.textBox4.TabIndex = 3;
            this.textBox4.Text = "客户:";
            // 
            // WipOrder
            // 
            this.WipOrder.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.WipOrder.Location = new System.Drawing.Point(103, 26);
            this.WipOrder.Margin = new System.Windows.Forms.Padding(4);
            this.WipOrder.Name = "WipOrder";
            this.WipOrder.ReadOnly = true;
            this.WipOrder.Size = new System.Drawing.Size(153, 27);
            this.WipOrder.TabIndex = 2;
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox2.Location = new System.Drawing.Point(9, 62);
            this.textBox2.Margin = new System.Windows.Forms.Padding(4);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(88, 27);
            this.textBox2.TabIndex = 1;
            this.textBox2.Text = "工单类型:";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox1.Location = new System.Drawing.Point(9, 26);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(88, 27);
            this.textBox1.TabIndex = 0;
            this.textBox1.Text = "工单号:";
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.dataGridView2);
            this.groupBox2.Controls.Add(this.dataGridView1);
            this.groupBox2.Location = new System.Drawing.Point(13, 190);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1047, 416);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "MES下发参数管理";
            // 
            // dataGridView2
            // 
            this.dataGridView2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView2.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.结果参数编码,
            this.dataGridViewTextBoxColumn1,
            this.MES下限值,
            this.PLC下限值,
            this.MES上限值,
            this.PLC上限值});
            this.dataGridView2.Location = new System.Drawing.Point(340, 25);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowTemplate.Height = 27;
            this.dataGridView2.Size = new System.Drawing.Size(692, 385);
            this.dataGridView2.TabIndex = 1;
            // 
            // 结果参数编码
            // 
            this.结果参数编码.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.结果参数编码.HeaderText = "结果参数编码(PR/AR)";
            this.结果参数编码.Name = "结果参数编码";
            this.结果参数编码.ReadOnly = true;
            this.结果参数编码.Width = 116;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn1.HeaderText = "参数名称";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 75;
            // 
            // MES下限值
            // 
            this.MES下限值.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.MES下限值.HeaderText = "MES下限值";
            this.MES下限值.Name = "MES下限值";
            this.MES下限值.ReadOnly = true;
            this.MES下限值.Width = 83;
            // 
            // PLC下限值
            // 
            this.PLC下限值.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.PLC下限值.HeaderText = "PLC下限值";
            this.PLC下限值.Name = "PLC下限值";
            this.PLC下限值.ReadOnly = true;
            this.PLC下限值.Width = 83;
            // 
            // MES上限值
            // 
            this.MES上限值.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.MES上限值.HeaderText = "MES上限值";
            this.MES上限值.Name = "MES上限值";
            this.MES上限值.ReadOnly = true;
            this.MES上限值.Width = 83;
            // 
            // PLC上限值
            // 
            this.PLC上限值.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.PLC上限值.HeaderText = "PLC上限值";
            this.PLC上限值.Name = "PLC上限值";
            this.PLC上限值.ReadOnly = true;
            this.PLC上限值.Width = 83;
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.设置参数编码,
            this.参数名称,
            this.设定下限值,
            this.MES标准值,
            this.PLC实际值,
            this.设定上限值,
            this.单位});
            this.dataGridView1.Location = new System.Drawing.Point(9, 25);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 27;
            this.dataGridView1.Size = new System.Drawing.Size(325, 385);
            this.dataGridView1.TabIndex = 0;
            // 
            // 设置参数编码
            // 
            this.设置参数编码.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.设置参数编码.HeaderText = "设置参数编码(PS)";
            this.设置参数编码.Name = "设置参数编码";
            this.设置参数编码.Width = 102;
            // 
            // 参数名称
            // 
            this.参数名称.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.参数名称.HeaderText = "参数名称";
            this.参数名称.Name = "参数名称";
            this.参数名称.ReadOnly = true;
            this.参数名称.Width = 75;
            // 
            // 设定下限值
            // 
            this.设定下限值.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.设定下限值.HeaderText = "设定下限值";
            this.设定下限值.Name = "设定下限值";
            this.设定下限值.ReadOnly = true;
            this.设定下限值.Width = 89;
            // 
            // MES标准值
            // 
            this.MES标准值.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.MES标准值.HeaderText = "MES标准值";
            this.MES标准值.Name = "MES标准值";
            this.MES标准值.Width = 83;
            // 
            // PLC实际值
            // 
            this.PLC实际值.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.PLC实际值.HeaderText = "PLC实际值";
            this.PLC实际值.Name = "PLC实际值";
            this.PLC实际值.ReadOnly = true;
            this.PLC实际值.Width = 83;
            // 
            // 设定上限值
            // 
            this.设定上限值.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.设定上限值.HeaderText = "设定上限值";
            this.设定上限值.Name = "设定上限值";
            this.设定上限值.ReadOnly = true;
            this.设定上限值.Width = 89;
            // 
            // 单位
            // 
            this.单位.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.单位.HeaderText = "单位";
            this.单位.Name = "单位";
            this.单位.ReadOnly = true;
            this.单位.Width = 62;
            // 
            // txt_Version
            // 
            this.txt_Version.Location = new System.Drawing.Point(313, 11);
            this.txt_Version.Name = "txt_Version";
            this.txt_Version.Size = new System.Drawing.Size(126, 25);
            this.txt_Version.TabIndex = 10;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(233, 17);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 15);
            this.label2.TabIndex = 9;
            this.label2.Text = "版本信息：";
            // 
            // txt_code
            // 
            this.txt_code.Location = new System.Drawing.Point(87, 11);
            this.txt_code.Name = "txt_code";
            this.txt_code.Size = new System.Drawing.Size(126, 25);
            this.txt_code.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 15);
            this.label1.TabIndex = 7;
            this.label1.Text = "工艺线路：";
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.txt_Version);
            this.panel1.Controls.Add(this.txt_code);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(13, 619);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1047, 50);
            this.panel1.TabIndex = 11;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("宋体", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button1.Location = new System.Drawing.Point(466, 8);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(161, 35);
            this.button1.TabIndex = 14;
            this.button1.Text = "参数主动获取";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("宋体", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button3.Location = new System.Drawing.Point(822, 7);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(138, 35);
            this.button3.TabIndex = 13;
            this.button3.Text = "读取PLC参数";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("宋体", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button2.Location = new System.Drawing.Point(651, 8);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(142, 35);
            this.button2.TabIndex = 12;
            this.button2.Text = "参数写入PLC";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // ParamInitForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1066, 680);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ParamInitForm";
            this.Text = "ParamInit";
            this.Load += new System.EventHandler(this.ParamInitForm_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox OprSequenceNo;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox OprSequenceDesc;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox RecipeID;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.TextBox ProcessID;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TextBox txt_lv;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox ProductNo;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox OperationCode;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox ProductDesc;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox Version;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox WipOrderType;
        private System.Windows.Forms.TextBox Customer;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox WipOrder;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txt_Version;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_code;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridViewTextBoxColumn 结果参数编码;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn MES下限值;
        private System.Windows.Forms.DataGridViewTextBoxColumn PLC下限值;
        private System.Windows.Forms.DataGridViewTextBoxColumn MES上限值;
        private System.Windows.Forms.DataGridViewTextBoxColumn PLC上限值;
        private System.Windows.Forms.DataGridViewTextBoxColumn 设置参数编码;
        private System.Windows.Forms.DataGridViewTextBoxColumn 参数名称;
        private System.Windows.Forms.DataGridViewTextBoxColumn 设定下限值;
        private System.Windows.Forms.DataGridViewTextBoxColumn MES标准值;
        private System.Windows.Forms.DataGridViewTextBoxColumn PLC实际值;
        private System.Windows.Forms.DataGridViewTextBoxColumn 设定上限值;
        private System.Windows.Forms.DataGridViewTextBoxColumn 单位;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
    }
}