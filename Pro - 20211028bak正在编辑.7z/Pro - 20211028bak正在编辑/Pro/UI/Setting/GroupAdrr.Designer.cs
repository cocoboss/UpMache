﻿namespace Pro
{
    partial class GroupAdrr
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGrid = new System.Windows.Forms.DataGridView();
            this.名称 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.地址 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.数据长度 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.数据类型 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.变量名 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.绑定参数ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGrid
            // 
            this.dataGrid.BackgroundColor = System.Drawing.Color.White;
            this.dataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.名称,
            this.地址,
            this.数据长度,
            this.数据类型,
            this.变量名,
            this.绑定参数ID});
            this.dataGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGrid.Location = new System.Drawing.Point(0, 0);
            this.dataGrid.Name = "dataGrid";
            this.dataGrid.RowTemplate.Height = 23;
            this.dataGrid.Size = new System.Drawing.Size(557, 353);
            this.dataGrid.TabIndex = 0;
            // 
            // 名称
            // 
            this.名称.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.名称.HeaderText = "名称";
            this.名称.Name = "名称";
            this.名称.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.名称.Width = 35;
            // 
            // 地址
            // 
            this.地址.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.地址.HeaderText = "地址";
            this.地址.Name = "地址";
            this.地址.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.地址.Width = 35;
            // 
            // 数据长度
            // 
            this.数据长度.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.数据长度.HeaderText = "数据长度";
            this.数据长度.Name = "数据长度";
            this.数据长度.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.数据长度.Width = 59;
            // 
            // 数据类型
            // 
            this.数据类型.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.数据类型.HeaderText = "数据类型";
            this.数据类型.Name = "数据类型";
            this.数据类型.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.数据类型.Width = 59;
            // 
            // 变量名
            // 
            this.变量名.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.变量名.HeaderText = "变量名";
            this.变量名.Name = "变量名";
            this.变量名.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.变量名.Width = 47;
            // 
            // 绑定参数ID
            // 
            this.绑定参数ID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.绑定参数ID.HeaderText = "绑定参数ID";
            this.绑定参数ID.Name = "绑定参数ID";
            this.绑定参数ID.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.绑定参数ID.Width = 71;
            // 
            // GroupAdrr
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(557, 353);
            this.Controls.Add(this.dataGrid);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "GroupAdrr";
            this.Text = "GroupAdrr";
            this.Load += new System.EventHandler(this.GroupAdrr_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGrid;
        private System.Windows.Forms.DataGridViewTextBoxColumn 名称;
        private System.Windows.Forms.DataGridViewTextBoxColumn 地址;
        private System.Windows.Forms.DataGridViewTextBoxColumn 数据长度;
        private System.Windows.Forms.DataGridViewComboBoxColumn 数据类型;
        private System.Windows.Forms.DataGridViewTextBoxColumn 变量名;
        private System.Windows.Forms.DataGridViewTextBoxColumn 绑定参数ID;
    }
}