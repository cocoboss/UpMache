﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ProBLL;
using ProModel;

namespace Pro
{
    public partial class SystemForm : Form
    {

        

        public SystemForm()
        {
            InitializeComponent();
        }
       
        private void button1_Click(object sender, EventArgs e)
        {
            SystemParam param = DevManage.Instance().sysParam;
            param.EquipmentCode = txt_EquipmentCode.Text.Trim();
            param.Software = txt_Software.Text.Trim();
            param.mesDely = txt_mesDely.Text.Trim();
            param.lineCode = txt_lineCode.Text.Trim();
            param.logoutTime = txt_logoutTime.Text.Trim();
            param.mesMainIp = txt_mesMainIp.Text.Trim();
            param.plcIp = txt_PlcIp.Text.Trim();
            param.ftpIp = txt_ftpIp.Text.Trim();
            param.ftpName = txt_ftpName.Text.Trim();
            param.ftpPwd = txt_ftpPwd.Text.Trim();
            param.isLogoutTimer = chk_isLogoutTimer.Checked;
            param.isUploadAlarm = chk_isUploadAlarm.Checked;
            DevManage.Instance().sysParam = param;
            DevManage.Instance().sysParam.Save();
        }

        private void SystemForm_Load(object sender, EventArgs e)
        {
            if (DevManage.Instance().userMgn.perCurrent.rightBarItem.Keys.Contains(this.Name))
            {
                if (DevManage.Instance().userMgn.perCurrent.rightBarItem[this.Name] != Em_Right.Write)
                {
                    DevManage.Instance().ControlEnable(false, this.Controls);
                }
                else
                {
                    DevManage.Instance().ControlEnable(true, this.Controls);
                }
            }
            SystemParam param = DevManage.Instance().sysParam;
            txt_EquipmentCode.Text = param.EquipmentCode;
            txt_Software.Text = param.Software;
            txt_mesDely.Text = param.mesDely;
            txt_lineCode.Text = param.lineCode;
            txt_logoutTime.Text = param.logoutTime;
            txt_mesMainIp.Text = param.mesMainIp;
            txt_PlcIp.Text = param.plcIp;
            txt_ftpIp.Text = param.ftpIp;
            txt_ftpName.Text = param.ftpName;
            txt_ftpPwd.Text = param.ftpPwd;
            chk_isLogoutTimer.Checked = param.isLogoutTimer;
            chk_isUploadAlarm.Checked = param.isUploadAlarm;
        }
    }
}
