﻿using ProBLL;
using ProModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pro
{
    public partial class AddrConfigForm : Form
    {
        public AddrConfigForm()
        {
            InitializeComponent();
        }

        private void AddrConfigForm_Load(object sender, System.EventArgs e)
        {
            tabControl1.TabPages.Clear();
            InitTabPage();
            if (DevManage.Instance().userMgn.perCurrent.rightBarItem.Keys.Contains(this.Name))
            {
                if (DevManage.Instance().userMgn.perCurrent.rightBarItem[this.Name] != Em_Right.Write)
                {
                    DevManage.Instance().ControlEnable(false, this.Controls);
                }
                else
                {
                    DevManage.Instance().ControlEnable(true, this.Controls);
                }
            }
        }

        void InitTabPage()
        {
            PlcConfigs cfg=DevManage.Instance().plcpfg;
            if (cfg.addrGroupLst.Count <= 0)
                return;
            for(int i=0;i<cfg.addrGroupLst.Count;i++)
            {
                AddrGroups group = cfg.addrGroupLst[i];
                TabPage tab = new TabPage();
                tab.Text = group.name;
                tab.Name = group.name;
                GroupAdrr page = new Pro.GroupAdrr(group);
                page.Dock = DockStyle.Fill;
                page.Name = group.name;
                page.TopLevel = false;
                tab.Controls.Add(page);
                tabControl1.TabPages.Add(tab);
                page.Show();
            }
            UpdateAddrCmb(0);
        }
        private void UpdateAddrCmb(int index)
        {
            if (index < 0)
                return;
            cmb_Addr.Items.Clear();
            cmb_Addr.SelectedIndex = -1;
            cmb_Addr.Text = "";
            AddrGroups group = DevManage.Instance().plcpfg.addrGroupLst[index];
            for (int i = 0; i < group.unitLst.Count; i++)
            {
                if (group.unitLst[i].Name.Length > 0)
                {
                    cmb_Addr.Items.Add(group.unitLst[i].Name);
                }
            }
        }

        private void tabControl1_SelectedIndexChanged(object sender, System.EventArgs e)
        {
            UpdateAddrCmb(tabControl1.SelectedIndex);
        }

        private void btn_read_Click(object sender, System.EventArgs e)
        {
            int nSelGroup = tabControl1.SelectedIndex;
            int addrIndex = cmb_Addr.SelectedIndex;
            PlcConfigs cfg = DevManage.Instance().plcpfg;
            if (addrIndex!=-1)
            {
                DataUint unit = cfg.addrGroupLst[nSelGroup].unitLst[addrIndex];
                try
                {
                    if (!cfg.ReadUnit(ref unit))
                    {
                        MessageBox.Show("读取失败", "错误提示");
                    }
                }catch(Exception ex)
                {

                }
                txt_data.Text = unit.Data;
            }
        }

        private void btn_write_Click(object sender, System.EventArgs e)
        {
            int nSelGroup = tabControl1.SelectedIndex;
            int addrIndex = cmb_Addr.SelectedIndex;
            PlcConfigs cfg = DevManage.Instance().plcpfg;
            if (addrIndex != -1)
            {
                DataUint unit = cfg.addrGroupLst[nSelGroup].unitLst[addrIndex];
                unit.Data = txt_data.Text.Trim();
                try
                {
                    if (!cfg.WriteUnit(ref unit))
                    {
                        MessageBox.Show("写入失败", "错误提示");
                    }
                }catch(Exception ex)
                {

                }
            }
        }

        private void saveCurrent_Click(object sender, System.EventArgs e)
        {
            PlcConfigs cfg = DevManage.Instance().plcpfg;
            for (int i = 0; i < tabControl1.TabPages.Count; i++)
            {
                TabPage page = (tabControl1.TabPages[i]);
                GroupAdrr settingPage = (GroupAdrr)(page.Controls[0]);
                AddrGroups group = settingPage.GetGroupData();
                cfg.ReadGroup(ref group);
                cfg.addrGroupLst[i] = group;
            }
            if(cfg.Save())
            {
                MessageBox.Show("保存成功");
            }
        }

        private void tabControl1_DrawItem(object sender, DrawItemEventArgs e)
        {


            //标签背景填充颜色
            SolidBrush BackBrush = new SolidBrush(Color.Blue);
            //标签文字填充颜色
            SolidBrush FrontBrush = new SolidBrush(Color.White);
            StringFormat StringF = new StringFormat();
            StringF.Alignment = StringAlignment.Center;
            StringF.LineAlignment = StringAlignment.Center;

            for (int i = 0; i < tabControl1.TabPages.Count; i++)
            {
                //获取标签头工作区域
                Rectangle Rec = tabControl1.GetTabRect(i);
                //绘制标签头背景颜色
                e.Graphics.FillRectangle(BackBrush, Rec);
                //绘制标签头文字
                e.Graphics.DrawString(tabControl1.TabPages[i].Text, new Font("宋体", 12), FrontBrush, Rec, StringF);
            }
        }

        //private void 添加地址段ToolStripMenuItem_Click(object sender, EventArgs e)
        //{
        //    PlcConfigs cfg = DevManage.Instance().plcpfg;

        //    cfg.addrGroupLst.Add(new AddrGroups());
        //    AddrGroups group = cfg.addrGroupLst[cfg.addrGroupLst.Count-1];
        //    TabPage tab = new TabPage();
        //    tab.Text = group.name;
        //    tab.Name = group.name;
        //    GroupAdrr page = new Pro.GroupAdrr(group);
        //    page.Dock = DockStyle.Fill;
        //    page.Name = group.name;
        //    page.TopLevel = false;
        //    tab.Controls.Add(page);
        //    tabControl1.TabPages.Add(tab);
        //    page.Show();
        //}
    }
}
