﻿namespace Pro
{
    partial class LeftForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.leftBar = new UtilityLibrary.WinControls.OutlookBar();
            this.SuspendLayout();
            // 
            // leftBar
            // 
            this.leftBar.AnimationSpeed = 20;
            this.leftBar.BackgroundBitmap = null;
            this.leftBar.BandColor = System.Drawing.SystemColors.ButtonFace;
            this.leftBar.BandFont = new System.Drawing.Font("宋体", 15F);
            this.leftBar.BandImage = null;
            this.leftBar.BorderType = UtilityLibrary.WinControls.BorderType.None;
            this.leftBar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.leftBar.FlatArrowButtons = false;
            this.leftBar.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.World);
            this.leftBar.LeftTopColor = System.Drawing.Color.Empty;
            this.leftBar.Location = new System.Drawing.Point(0, 0);
            this.leftBar.Name = "leftBar";
            this.leftBar.PressedColor = System.Drawing.Color.FromArgb(((int)(((byte)(199)))), ((int)(((byte)(227)))), ((int)(((byte)(255)))));
            this.leftBar.RightBottomColor = System.Drawing.Color.Empty;
            this.leftBar.Size = new System.Drawing.Size(154, 331);
            this.leftBar.TabIndex = 6;
            this.leftBar.Text = "leftBar";
            this.leftBar.ItemClicked += new UtilityLibrary.WinControls.OutlookBarItemClickedHandler(this.leftBar_ItemClicked);
            // 
            // Left
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(154, 331);
            this.Controls.Add(this.leftBar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Left";
            this.Text = "Left";
            this.Load += new System.EventHandler(this.Left_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private UtilityLibrary.WinControls.OutlookBar leftBar;
    }
}