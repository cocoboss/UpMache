﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ProBLL;
using ProModel;
using Apriso.MIPlugins.Communication.Clients.WcfServiceAPI;

namespace Pro
{
    public partial class Login : Form
    {
        DevManage uf = DevManage.Instance();
        MainForm mains;
        List<string> userRight = new List<string>();
        public Login(MainForm main)
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            //this.FormBorderStyle = FormBorderStyle.FixedDialog;
            //this.MinimizeBox = false;
            //this.MaximizeBox = false;
            mains = main;
        }

        private void btn_login_Click(object sender, System.EventArgs e)
        {
            if (userRight[com_group.SelectedIndex].Contains(Em_UserRight.administrator.ToString()))
            {
                bool temp = uf.userMgn.Login(txt_user.Text, txt_pwd.Text);
                if (temp)
                {
                    if (!com_group.SelectedItem.ToString().Contains(uf.userMgn.role.remark))
                    {
                        MessageBox.Show($"该用户只有{uf.userMgn.role.name}权限，权限选择出错");
                    }
                    mains.Show();
                    this.Close();
                    mains.UserChange(temp, e);
                }
                else
                {
                    MessageBox.Show($"请检查用户或者密码是否正确！");
                }
            }else
            {
                string right = uf.userMgn.groupRole[userRight[com_group.SelectedIndex]].remark;
                string mesage = "";
                string name = txt_user.Text.Trim();
                string pwd = txt_pwd.Text.Trim();
                //bool ret = DevManage.Instance().SendACUSERINFO(Em_MES.ACUSERINFO, txt_user.Text.Trim(), txt_pwd.Text.Trim(), right, out mesage);
                bool ret = DevManage.Instance().SendACUSERINFO(Em_MES.ACUSERINFO, name, pwd, right, out mesage);
                if (ret)
                {
                    uf.userMgn.UpdatePerCurrent(uf.userMgn.groupRole[userRight[com_group.SelectedIndex]].groupID);
                    uf.userMgn.currentUser.userName = txt_user.Text.Trim();
                    uf.userMgn.currentUser.remark = right;
                    uf.userMgn.role.name = uf.userMgn.groupRole[userRight[com_group.SelectedIndex]].name;
                    mains.Show();
                    this.Close();
                    mains.UserChange(ret, e);
                }
                else
                {
                    MessageBox.Show(mesage);
                }
            }

        }

        private void btn_exit_Click(object sender, System.EventArgs e)
        {
            if (DevManage.Instance().isDebug)
            {
                uf.userMgn.Login("admin", "admin");
                mains.Show();
                this.Close();
                mains.UserChange(false, e);
                return;
            }
            
            Environment.Exit(0);

        }

        private void Login_Load(object sender, System.EventArgs e)
        {
            //if(DevManage.Instance().mainForm!=null)
            //{
            //    this.btn_exit.Enabled = false;
            //    return;
            //}
            com_group.Items.Clear();
            userRight.Clear();
            foreach (var val in uf.userMgn.groupRole)
            {
                com_group.Items.Add(val.Value.remark);
                userRight.Add(val.Key);
            }
            txt_user.Text = uf.sysParam.sysParam[Em_DefineVariable.EmployeeNo.ToString()];
        }
    }
}
