﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ProModel;

namespace Pro
{
    public partial class UserMgnForm : Form
    {
        DevManage dev = DevManage.Instance();
        List<int> dataViewGroup = new List<int>();
        Dictionary<int, int> id_index = new Dictionary<int, int>();
        public UserMgnForm()
        {
            InitializeComponent();
        }

        private void UserMgnForm_Load(object sender, System.EventArgs e)
        {
            if (DevManage.Instance().userMgn.perCurrent.rightBarItem.Keys.Contains(this.Name))
            {
                if (DevManage.Instance().userMgn.perCurrent.rightBarItem[this.Name] != Em_Right.Write)
                {
                    DevManage.Instance().ControlEnable(false, this.Controls);
                }
                else
                {
                    DevManage.Instance().ControlEnable(true, this.Controls);
                }
            }
            cmd_group.Items.Clear();
            id_index.Clear();
            dataViewGroup.Clear();
            foreach (var val in dev.userMgn.group)
            {
                id_index.Add(val.Key, cmd_group.Items.Count);
                cmd_group.Items.Add(val.Value);
                dataViewGroup.Add(val.Key);
            }
            UpdateData();
        }

        public void UpdateData()
        {
            if(dev.userMgn.GetAllUsers())
            {
                InveokeCls.DoInvokeRequired(dateView, () =>
                {
                    dateView.Rows.Clear();
                    dateView.AllowUserToAddRows = true;
                    foreach (var val in dev.userMgn.AllUser)
                    {
                        dateView.Rows.Add(val.userName, val.pwd, dev.userMgn.group[val.groupID], val.remark);
                    }
                });
            }
        }
        public void ClearText()
        {
            cmd_user.Text="";
            cmd_pwd.Text="";
            cmd_group.SelectedIndex=0;
            cmd_remark.Text="";
        }

        private void btn_add_Click(object sender, System.EventArgs e)
        {
            DialogResult result = MessageBox.Show("是否确认添加该用户！", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (result == DialogResult.No)
            {
                return;
            }
            if(string.IsNullOrEmpty(cmd_user.Text.Trim()) || string.IsNullOrEmpty(cmd_pwd.Text.Trim()))
            {
                MessageBox.Show("用户名或者密码不能为空");
                return;
            }
            User tempUser = new User();
            tempUser.userName = cmd_user.Text.Trim();
            tempUser.pwd = cmd_pwd.Text.Trim();
            tempUser.groupID = dataViewGroup[cmd_group.SelectedIndex];
            tempUser.remark = cmd_remark.Text.Trim();
            if (dev.userMgn.Add(tempUser) > 0)
            {
                UpdateData();
                ClearText();
            }
            else
                MessageBox.Show("用户名已经存在，请重新命名");
        }

        private void btn_upd_Click(object sender, System.EventArgs e)
        {
            DialogResult result = MessageBox.Show("是否确认修改该用户！", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (result == DialogResult.No)
            {
                return;
            }
            if (string.IsNullOrEmpty(cmd_user.Text.Trim()) || string.IsNullOrEmpty(cmd_pwd.Text.Trim()))
            {
                MessageBox.Show("用户名或者密码不能为空");
                return;
            }
            User tempUser = new User();
            tempUser.userName = cmd_user.Text.Trim();
            tempUser.pwd = cmd_pwd.Text.Trim();
            tempUser.groupID = dataViewGroup[cmd_group.SelectedIndex];
            tempUser.remark = cmd_remark.Text.Trim();
            if (dev.userMgn.Update(tempUser) > 0)
            {
                UpdateData();
                ClearText();
            }
            else
                MessageBox.Show("用户名修改失败，不存在该用户名");
        }

        private void btn_del_Click(object sender, System.EventArgs e)
        {

            DialogResult result = MessageBox.Show("是否确认删除该用户！", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (result == DialogResult.No)
            {
                return;
            }
            if (string.IsNullOrEmpty(cmd_user.Text.Trim()))
            {
                MessageBox.Show("用户名不能为空");
                return;
            }
            User tempUser = new User();
            tempUser.userName = cmd_user.Text.Trim();
            tempUser.pwd = cmd_pwd.Text.Trim();
            tempUser.groupID = dataViewGroup[cmd_group.SelectedIndex];
            tempUser.remark = cmd_remark.Text.Trim();
            if (dev.userMgn.Delete(tempUser) > 0)
            {
                UpdateData();
                ClearText();
            }
            else
                MessageBox.Show("该用户名已删除");
        }

        private void dateView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (!(e.RowIndex > 0))
                return;
            ClearText();
            cmd_user.Text = dev.userMgn.AllUser[e.RowIndex].userName;
            cmd_pwd.Text = dev.userMgn.AllUser[e.RowIndex].pwd;
            cmd_group.SelectedIndex = id_index[dev.userMgn.AllUser[e.RowIndex].groupID];
            cmd_remark.Text = dev.userMgn.AllUser[e.RowIndex].remark;
        }
    }
}
