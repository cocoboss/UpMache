﻿namespace Pro
{
    partial class UserMgnForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dateView = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.cmd_user = new System.Windows.Forms.TextBox();
            this.cmd_pwd = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.cmd_group = new System.Windows.Forms.ComboBox();
            this.btn_add = new System.Windows.Forms.Button();
            this.btn_del = new System.Windows.Forms.Button();
            this.btn_upd = new System.Windows.Forms.Button();
            this.cmd_remark = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.用户名 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.密码 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.组别 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.备注 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dateView)).BeginInit();
            this.SuspendLayout();
            // 
            // dateView
            // 
            this.dateView.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.dateView.BackgroundColor = System.Drawing.Color.White;
            this.dateView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dateView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.用户名,
            this.密码,
            this.组别,
            this.备注});
            this.dateView.Location = new System.Drawing.Point(2, 1);
            this.dateView.Name = "dateView";
            this.dateView.RowTemplate.Height = 23;
            this.dateView.Size = new System.Drawing.Size(400, 302);
            this.dateView.TabIndex = 0;
            this.dateView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dateView_CellContentClick);
            this.dateView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dateView_CellContentClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(419, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 1;
            this.label1.Text = "用户名：";
            // 
            // cmd_user
            // 
            this.cmd_user.Location = new System.Drawing.Point(506, 22);
            this.cmd_user.Name = "cmd_user";
            this.cmd_user.Size = new System.Drawing.Size(121, 21);
            this.cmd_user.TabIndex = 2;
            // 
            // cmd_pwd
            // 
            this.cmd_pwd.Location = new System.Drawing.Point(506, 65);
            this.cmd_pwd.Name = "cmd_pwd";
            this.cmd_pwd.Size = new System.Drawing.Size(121, 21);
            this.cmd_pwd.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(419, 68);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 12);
            this.label2.TabIndex = 3;
            this.label2.Text = "密码：";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(419, 114);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 12);
            this.label3.TabIndex = 5;
            this.label3.Text = "组别：";
            // 
            // cmd_group
            // 
            this.cmd_group.FormattingEnabled = true;
            this.cmd_group.Location = new System.Drawing.Point(506, 111);
            this.cmd_group.Name = "cmd_group";
            this.cmd_group.Size = new System.Drawing.Size(121, 20);
            this.cmd_group.TabIndex = 6;
            // 
            // btn_add
            // 
            this.btn_add.Location = new System.Drawing.Point(410, 270);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(75, 23);
            this.btn_add.TabIndex = 7;
            this.btn_add.Text = "增加";
            this.btn_add.UseVisualStyleBackColor = true;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // btn_del
            // 
            this.btn_del.Location = new System.Drawing.Point(583, 270);
            this.btn_del.Name = "btn_del";
            this.btn_del.Size = new System.Drawing.Size(75, 23);
            this.btn_del.TabIndex = 8;
            this.btn_del.Text = "删除";
            this.btn_del.UseVisualStyleBackColor = true;
            this.btn_del.Click += new System.EventHandler(this.btn_del_Click);
            // 
            // btn_upd
            // 
            this.btn_upd.Location = new System.Drawing.Point(496, 270);
            this.btn_upd.Name = "btn_upd";
            this.btn_upd.Size = new System.Drawing.Size(75, 23);
            this.btn_upd.TabIndex = 9;
            this.btn_upd.Text = "修改";
            this.btn_upd.UseVisualStyleBackColor = true;
            this.btn_upd.Click += new System.EventHandler(this.btn_upd_Click);
            // 
            // cmd_remark
            // 
            this.cmd_remark.Location = new System.Drawing.Point(506, 159);
            this.cmd_remark.Name = "cmd_remark";
            this.cmd_remark.Size = new System.Drawing.Size(121, 21);
            this.cmd_remark.TabIndex = 11;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(419, 162);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 12);
            this.label4.TabIndex = 10;
            this.label4.Text = "备注：";
            // 
            // 用户名
            // 
            this.用户名.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.用户名.HeaderText = "用户名";
            this.用户名.Name = "用户名";
            this.用户名.ReadOnly = true;
            this.用户名.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.用户名.Width = 47;
            // 
            // 密码
            // 
            this.密码.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.密码.HeaderText = "密码";
            this.密码.Name = "密码";
            this.密码.ReadOnly = true;
            this.密码.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.密码.Width = 35;
            // 
            // 组别
            // 
            this.组别.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.组别.HeaderText = "组别";
            this.组别.Name = "组别";
            this.组别.ReadOnly = true;
            this.组别.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.组别.Width = 35;
            // 
            // 备注
            // 
            this.备注.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.备注.HeaderText = "备注";
            this.备注.Name = "备注";
            this.备注.ReadOnly = true;
            this.备注.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.备注.Width = 35;
            // 
            // UserMgnForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(663, 305);
            this.Controls.Add(this.cmd_remark);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btn_upd);
            this.Controls.Add(this.btn_del);
            this.Controls.Add(this.btn_add);
            this.Controls.Add(this.cmd_group);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cmd_pwd);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cmd_user);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dateView);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "UserMgnForm";
            this.Text = "UserManage";
            this.Load += new System.EventHandler(this.UserMgnForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dateView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dateView;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox cmd_user;
        private System.Windows.Forms.TextBox cmd_pwd;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cmd_group;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.Button btn_del;
        private System.Windows.Forms.Button btn_upd;
        private System.Windows.Forms.TextBox cmd_remark;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridViewTextBoxColumn 用户名;
        private System.Windows.Forms.DataGridViewTextBoxColumn 密码;
        private System.Windows.Forms.DataGridViewTextBoxColumn 组别;
        private System.Windows.Forms.DataGridViewTextBoxColumn 备注;
    }
}