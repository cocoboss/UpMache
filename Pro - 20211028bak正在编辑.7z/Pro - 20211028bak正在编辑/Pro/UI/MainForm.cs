﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Reflection;
using MySql.Data.MySqlClient;
using ProModel;
using ProDAL;
using System.Threading;

namespace Pro
{
    public partial class MainForm : Form
    {
        //Form centerPage;

        public DevManage devMgn = DevManage.Instance();
        Point mousePosition;
        Point fromPosition;
        bool isMoseDown = false;
        bool isMoseIn = false;
        //public bool isModelChange = false;
        
        public MainForm()
        {
            
            InitializeComponent();
            devMgn.userMgn.evenHand.event_userSwitch += UserChange;
            devMgn.userMgn.evenHand.event_statusChange += StatusChange;
            devMgn.InitDev();
            devMgn.CreateSwitch();
            LeftForm leftPage = new LeftForm(this);
            leftPage.TopLevel = false;
            leftPanel.Controls.Add(leftPage);
            leftPage.Dock = DockStyle.Fill;
            leftPage.Show();
        }

        public void StatusChange(object sender, System.EventArgs e)
        {
            SigStatusEventArgs ags = (SigStatusEventArgs)e;
            try {
                switch (ags.type)
                {
                    case Em_SigName.plcStatus:
                        InveokeCls.DoInvokeRequired(plcStatus, () =>
                         {
                             plcStatus.Text = ags.val;
                             if (ags.val.Contains("OK"))
                             {
                                 plcStatus.BackColor = Color.LimeGreen;
                             }
                             else
                             {
                                 plcStatus.BackColor = Color.Red;
                             }

                         });

                        break;
                    case Em_SigName.mesStatus:
                        InveokeCls.DoInvokeRequired(mesStatus, () =>
                        {
                            mesStatus.Text = ags.val;
                            if (ags.val.Contains("OK"))
                            {
                                mesStatus.BackColor = Color.LimeGreen;
                            }
                            else
                            {
                                mesStatus.BackColor = Color.Red;
                            }
                        });
                        break;
                    case Em_SigName.mesModel:
                        //mesModel.Text = ags.val;
                        ModelChange(ags.val);
                        break;
                    case Em_SigName.equipmentStatusID:
                        InveokeCls.DoInvokeRequired(equipmentStatusID, () =>
                        {
                            equipmentStatusID.Text = ags.val;
                            if (ags.val.Contains("300-"))
                            {
                                equipmentStatusID.BackColor = Color.LimeGreen;
                            }
                            else if(ags.val.Contains("900-"))
                            {
                                equipmentStatusID.BackColor = Color.Red;
                            }
                            else
                            {
                                equipmentStatusID.BackColor = Color.Yellow;
                            }
                        });
                        break;
                    case Em_SigName.equipmentIsRun:
                        InveokeCls.DoInvokeRequired(equipmentIsRun, () =>
                        {
                            equipmentIsRun.Text = ags.val;
                        });
                        break;
                    default:
                        break;
                }
            }catch(Exception ex)
            {
                devMgn.WriteErrorLog(ex.Message);
            }
        }
        public void UserChange(object sender, System.EventArgs e)
        {
            //CurUserEventArge user = (CurUserEventArge)e;
            try {
                if (sender is bool)
                {
                    devMgn.userMgn.isLogin = (bool)sender;
                }

                if (devMgn.userMgn.isLogin)
                {

                    lab_user.Text = devMgn.userMgn.currentUser.userName;
                    lab_right.Text = devMgn.userMgn.role.remark;
                }
                else
                {
                    lab_user.Text = "未登录";
                    lab_right.Text = "无权限";

                }
                devMgn.sysParam.sysParam[Em_DefineVariable.EmployeeNo.ToString()] = devMgn.userMgn.currentUser.userName;
                devMgn.sysParam.Save();
            }catch(Exception ex)
            {
                devMgn.WriteErrorLog(ex.Message);
            }
            //LeftForm leftPage = new LeftForm(this);
            //leftPage.TopLevel = false;
            //leftPanel.Controls.Add(leftPage);
            //leftPage.Dock = DockStyle.Fill;
            //leftPage.Show();
        }
        public void SwitchPage(Form centerPage,string per)
        {
            try {
                lab_per.Text = per;
                centerPage.TopLevel = false;
                mainPanel.Controls.Clear();
                mainPanel.Controls.Add(centerPage);
                centerPage.Dock = DockStyle.Fill;
                centerPage.Show();
            }catch(Exception ex)
            {
                devMgn.WriteErrorLog($"{ex.Message}");
            }

        }
        private void btn_max_Click(object sender, System.EventArgs e)
        {
            if(this.WindowState== FormWindowState.Maximized)
            {
                this.WindowState = FormWindowState.Normal;
            }else if(this.WindowState== FormWindowState.Normal)
            {
                this.WindowState = FormWindowState.Maximized;
            }
        }

        private void btn_close_Click(object sender, System.EventArgs e)
        {
            this.Close();
        }

        private void btn_Min_Click(object sender, System.EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }


        #region 移动窗体


        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            isMoseDown = true;
            mousePosition = Control.MousePosition;
            fromPosition = Location;
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            Point nowPosition = Control.MousePosition;
            if (isMoseDown && isMoseIn)
                this.Location = new Point(nowPosition.X - mousePosition.X + fromPosition.X, nowPosition.Y - mousePosition.Y + fromPosition.Y);
        }

        private void panel1_MouseUp(object sender, MouseEventArgs e)
        {
            isMoseDown = false;
        }

        private void panel1_MouseEnter(object sender, System.EventArgs e)
        {
            isMoseIn = true;
        }

        private void panel1_MouseLeave(object sender, System.EventArgs e)
        {
            isMoseIn = false;
        }
        #endregion

        private void btn_user_Exit_Click(object sender, System.EventArgs e)
        {

            devMgn.userMgn.Login("admin", "admin");
            UserChange(false, e);
            //RolesAccess ra = new RolesAccess();
            //ra.Insert("admins");
            //Dictionary<string, Roles> dr= ra.SelectAll();
            //if(dr.Count>0)
            //{
            //    //Roles rs = dr[Em_Right.oper.ToString()];
            //    ////rs = ra.SelectName(Em_Right.oper);
            //    //rs.mesOrLocal = 1;

            //    return ;
            //}

        }

        private void MainForm_Load(object sender, System.EventArgs e)
        {
            devMgn.mainForm = this;
            Login login = new Pro.Login(this);
            this.Hide();
            login.Show();
            //temp = ;
            verLab.Text = devMgn.sysParam.sysParam[Em_DefineVariable.Version.ToString()];
            ModelChange(devMgn.sysParam.sysParam[Em_DefineVariable.EquipmentModel.ToString()]);
        }
        public void ModelChange(string model)
        {
            //if ()
            {
                switch (model)
                {
                    case "CONT":
                    case "管控模式":
                        devMgn.CurrentModel = Em_EquipmentModelZH.管控模式.ToString();
                        devMgn.sysParam.sysParam[Em_DefineVariable.EquipmentModel.ToString()] = Em_EquipmentModel.CONT.ToString();
                        break;
                    case "MONT":
                    case "监控模式":
                        devMgn.CurrentModel = Em_EquipmentModelZH.监控模式.ToString();
                        devMgn.sysParam.sysParam[Em_DefineVariable.EquipmentModel.ToString()] = Em_EquipmentModel.MONT.ToString();
                        break;
                    default:
                        devMgn.CurrentModel = Em_EquipmentModelZH.离线模式.ToString();
                        devMgn.sysParam.sysParam[Em_DefineVariable.EquipmentModel.ToString()] = Em_EquipmentModel.MANU.ToString();
                        break;
                }
            }
            InveokeCls.DoInvokeRequired(mesModel, () =>
            {
                this.mesModel.Text = devMgn.CurrentModel;
            });
            devMgn.sysParam.Save();
        }
        private void button3_Click(object sender, System.EventArgs e)
        {
            //devMgn.CurrentModel = this.mesModel.Text.ToString().Trim();
            DeviceStatusForm df = new Pro.DeviceStatusForm();
            df.StartPosition = FormStartPosition.CenterScreen;
           
            df.Show();
           
        }
    }
}
