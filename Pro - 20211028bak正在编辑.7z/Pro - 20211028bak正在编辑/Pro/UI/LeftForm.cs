﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using UtilityLibrary.WinControls;
using System.Reflection;
using ProDAL;
using ProModel;

namespace Pro
{
    public partial class LeftForm : Form
    {


        MainForm parentForm;
        List<string> defaaultpage = new List<string>();
        public LeftForm(MainForm mainForm)
        {
            InitializeComponent();
            parentForm = mainForm;
            parentForm.devMgn.userMgn.evenHand.event_bandsSwitch += Left_Load;
        }

        private void leftBar_ItemClicked(OutlookBarBand band, OutlookBarItem item)
        {
            this.Focus();
            //this.ForeColor = Color.Blue;
            band.BackColor = Color.Red;
            
            string temp = band.Text;
            string temp1 = item.Text;
            if(temp1.Contains("退出"))
            {

                if (MessageBox.Show("是否退出程序？", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    Environment.Exit(0);
                }

                return;
            }

            parentForm.SwitchPage(parentForm.devMgn.userMgn.perCurrent.strForm[item.ImageIndex.ToString()], temp+">>"+ temp1);
            //if (parentForm.devMgn.userMgn.perCurrent.rightBarItem.Keys.Contains(temp1))
            //    parentForm.devMgn.currentFormRgiht = parentForm.devMgn.userMgn.perCurrent.rightBarItem[temp1];
            //else
            //    parentForm.devMgn.currentFormRgiht = Em_Right.Write;
        }

        private void Left_Load(object sender, EventArgs e)
        {
            defaaultpage.Clear();
            GetBar(parentForm.devMgn.userMgn.perCurrent.preBands, parentForm.devMgn.userMgn.perCurrent.preBarItem);
            if(defaaultpage.Count==3)
            parentForm.SwitchPage(parentForm.devMgn.userMgn.perCurrent.strForm[defaaultpage[0]], defaaultpage[1] + ">>" + defaaultpage[2]);
        }
        public void GetBar(List<PerBand> curBands, List<PerBand> curBarItem)
        {
            leftBar.Bands.Clear();
            OutlookBarBand bar;
            for (int j = 0; j < curBands.Count; j++)
            {
                //if (curBands[j].userRight != Em_Right.NotRW)
                {
                    bar = new OutlookBarBand(curBands[j].per.description);
                    for (int k = 0; k < curBarItem.Count; k++)
                    {
                        if (curBarItem[k].per.parentID == curBands[j].per.id)
                        {
                            //if (curBarItem[k].userRight != Em_Right.NotRW)
                                bar.Items.Add(new OutlookBarItem(curBarItem[k].per.description,curBarItem[k].per.id, (object)curBarItem[k].per.name));
                            if (!string.IsNullOrEmpty(curBarItem[k].per.remark) && curBarItem[k].per.remark.Contains("1"))
                            {
                                defaaultpage.Add(curBarItem[k].per.id.ToString());
                                defaaultpage.Add(curBands[j].per.description);
                                defaaultpage.Add(curBarItem[k].per.description);
                            }
                        }
                    }
                    bar.Background = Color.White;
                    leftBar.Bands.Add(bar);
                }
            }
            
            leftBar.ContextMenu = null;
            leftBar.Font = new Font("宋体", 12);
            leftBar.BandFont = new Font("宋体", 18, FontStyle.Bold);
        }
    }
}
