﻿namespace Pro
{
    partial class MainForm
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btn_close = new System.Windows.Forms.Button();
            this.btn_Max = new System.Windows.Forms.Button();
            this.btn_Min = new System.Windows.Forms.Button();
            this.panel = new System.Windows.Forms.Panel();
            this.verLab = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.mainPanel = new System.Windows.Forms.Panel();
            this.leftPanel = new System.Windows.Forms.Panel();
            this.topPanel = new System.Windows.Forms.Panel();
            this.lab_per = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.btn_user_Exit = new System.Windows.Forms.Button();
            this.lab_right = new System.Windows.Forms.Label();
            this.lab_user = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_SoftName = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.equipmentStatusID = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.equipmentIsRun = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.mesModel = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.mesStatus = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.plcStatus = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel.SuspendLayout();
            this.panel4.SuspendLayout();
            this.topPanel.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.LightSkyBlue;
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel);
            this.panel1.Location = new System.Drawing.Point(3, 4);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1157, 32);
            this.panel1.TabIndex = 0;
            this.panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown);
            this.panel1.MouseEnter += new System.EventHandler(this.panel1_MouseEnter);
            this.panel1.MouseLeave += new System.EventHandler(this.panel1_MouseLeave);
            this.panel1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseMove);
            this.panel1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseUp);
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.Controls.Add(this.btn_close);
            this.panel3.Controls.Add(this.btn_Max);
            this.panel3.Controls.Add(this.btn_Min);
            this.panel3.Location = new System.Drawing.Point(1031, 0);
            this.panel3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(123, 32);
            this.panel3.TabIndex = 2;
            // 
            // btn_close
            // 
            this.btn_close.BackgroundImage = global::Pro.Properties.Resources.Close;
            this.btn_close.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_close.Enabled = false;
            this.btn_close.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn_close.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_close.Location = new System.Drawing.Point(93, 5);
            this.btn_close.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_close.Name = "btn_close";
            this.btn_close.Size = new System.Drawing.Size(27, 24);
            this.btn_close.TabIndex = 7;
            this.btn_close.UseVisualStyleBackColor = true;
            this.btn_close.Click += new System.EventHandler(this.btn_close_Click);
            // 
            // btn_Max
            // 
            this.btn_Max.BackgroundImage = global::Pro.Properties.Resources.Max;
            this.btn_Max.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Max.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn_Max.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Max.Location = new System.Drawing.Point(63, 5);
            this.btn_Max.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_Max.Name = "btn_Max";
            this.btn_Max.Size = new System.Drawing.Size(27, 24);
            this.btn_Max.TabIndex = 6;
            this.btn_Max.UseVisualStyleBackColor = true;
            this.btn_Max.Click += new System.EventHandler(this.btn_max_Click);
            // 
            // btn_Min
            // 
            this.btn_Min.BackgroundImage = global::Pro.Properties.Resources.Min;
            this.btn_Min.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Min.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn_Min.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Min.Location = new System.Drawing.Point(31, 5);
            this.btn_Min.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_Min.Name = "btn_Min";
            this.btn_Min.Size = new System.Drawing.Size(27, 24);
            this.btn_Min.TabIndex = 5;
            this.btn_Min.UseVisualStyleBackColor = true;
            this.btn_Min.Click += new System.EventHandler(this.btn_Min_Click);
            // 
            // panel
            // 
            this.panel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.panel.Controls.Add(this.verLab);
            this.panel.Location = new System.Drawing.Point(4, 0);
            this.panel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel.Name = "panel";
            this.panel.Size = new System.Drawing.Size(341, 32);
            this.panel.TabIndex = 1;
            // 
            // verLab
            // 
            this.verLab.AutoSize = true;
            this.verLab.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.verLab.Location = new System.Drawing.Point(7, 5);
            this.verLab.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.verLab.Name = "verLab";
            this.verLab.Size = new System.Drawing.Size(118, 24);
            this.verLab.TabIndex = 0;
            this.verLab.Text = "Ver 0.0.1";
            // 
            // panel4
            // 
            this.panel4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel4.Controls.Add(this.mainPanel);
            this.panel4.Controls.Add(this.leftPanel);
            this.panel4.Controls.Add(this.topPanel);
            this.panel4.Location = new System.Drawing.Point(7, 38);
            this.panel4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1153, 586);
            this.panel4.TabIndex = 1;
            // 
            // mainPanel
            // 
            this.mainPanel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.mainPanel.BackColor = System.Drawing.Color.White;
            this.mainPanel.Location = new System.Drawing.Point(220, 82);
            this.mainPanel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.mainPanel.Name = "mainPanel";
            this.mainPanel.Size = new System.Drawing.Size(928, 500);
            this.mainPanel.TabIndex = 2;
            // 
            // leftPanel
            // 
            this.leftPanel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.leftPanel.Location = new System.Drawing.Point(4, 82);
            this.leftPanel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.leftPanel.Name = "leftPanel";
            this.leftPanel.Size = new System.Drawing.Size(208, 504);
            this.leftPanel.TabIndex = 1;
            // 
            // topPanel
            // 
            this.topPanel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.topPanel.Controls.Add(this.lab_per);
            this.topPanel.Controls.Add(this.panel6);
            this.topPanel.Controls.Add(this.txt_SoftName);
            this.topPanel.Controls.Add(this.pictureBox1);
            this.topPanel.Location = new System.Drawing.Point(4, 2);
            this.topPanel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.topPanel.Name = "topPanel";
            this.topPanel.Size = new System.Drawing.Size(1149, 76);
            this.topPanel.TabIndex = 0;
            // 
            // lab_per
            // 
            this.lab_per.AutoSize = true;
            this.lab_per.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lab_per.Location = new System.Drawing.Point(249, 48);
            this.lab_per.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_per.Name = "lab_per";
            this.lab_per.Size = new System.Drawing.Size(0, 24);
            this.lab_per.TabIndex = 1;
            // 
            // panel6
            // 
            this.panel6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.panel6.Controls.Add(this.btn_user_Exit);
            this.panel6.Controls.Add(this.lab_right);
            this.panel6.Controls.Add(this.lab_user);
            this.panel6.Controls.Add(this.label4);
            this.panel6.Controls.Add(this.label3);
            this.panel6.Location = new System.Drawing.Point(852, 4);
            this.panel6.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(292, 69);
            this.panel6.TabIndex = 2;
            // 
            // btn_user_Exit
            // 
            this.btn_user_Exit.Location = new System.Drawing.Point(223, 15);
            this.btn_user_Exit.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_user_Exit.Name = "btn_user_Exit";
            this.btn_user_Exit.Size = new System.Drawing.Size(69, 44);
            this.btn_user_Exit.TabIndex = 5;
            this.btn_user_Exit.Text = "退出";
            this.btn_user_Exit.UseVisualStyleBackColor = true;
            this.btn_user_Exit.Click += new System.EventHandler(this.btn_user_Exit_Click);
            // 
            // lab_right
            // 
            this.lab_right.AutoSize = true;
            this.lab_right.BackColor = System.Drawing.Color.LimeGreen;
            this.lab_right.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lab_right.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lab_right.Location = new System.Drawing.Point(107, 42);
            this.lab_right.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_right.Name = "lab_right";
            this.lab_right.Size = new System.Drawing.Size(62, 18);
            this.lab_right.TabIndex = 4;
            this.lab_right.Text = "无权限";
            // 
            // lab_user
            // 
            this.lab_user.AutoSize = true;
            this.lab_user.BackColor = System.Drawing.Color.LimeGreen;
            this.lab_user.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lab_user.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lab_user.Location = new System.Drawing.Point(107, 11);
            this.lab_user.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_user.Name = "lab_user";
            this.lab_user.Size = new System.Drawing.Size(62, 18);
            this.lab_user.TabIndex = 3;
            this.lab_user.Text = "未登录";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(4, 42);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 18);
            this.label4.TabIndex = 2;
            this.label4.Text = "用户权限:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(4, 10);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 18);
            this.label3.TabIndex = 1;
            this.label3.Text = "当前用户:";
            // 
            // txt_SoftName
            // 
            this.txt_SoftName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.txt_SoftName.AutoSize = true;
            this.txt_SoftName.Font = new System.Drawing.Font("宋体", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_SoftName.Location = new System.Drawing.Point(475, 6);
            this.txt_SoftName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.txt_SoftName.Name = "txt_SoftName";
            this.txt_SoftName.Size = new System.Drawing.Size(372, 44);
            this.txt_SoftName.TabIndex = 1;
            this.txt_SoftName.Text = "上位机尺寸测量机";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::Pro.Properties.Resources.远景;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(3, -2);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(241, 75);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel5
            // 
            this.panel5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel5.Controls.Add(this.equipmentStatusID);
            this.panel5.Controls.Add(this.label9);
            this.panel5.Controls.Add(this.equipmentIsRun);
            this.panel5.Controls.Add(this.label8);
            this.panel5.Controls.Add(this.mesModel);
            this.panel5.Controls.Add(this.label7);
            this.panel5.Controls.Add(this.mesStatus);
            this.panel5.Controls.Add(this.label6);
            this.panel5.Controls.Add(this.plcStatus);
            this.panel5.Controls.Add(this.label5);
            this.panel5.Location = new System.Drawing.Point(11, 628);
            this.panel5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1149, 40);
            this.panel5.TabIndex = 2;
            // 
            // equipmentStatusID
            // 
            this.equipmentStatusID.BackColor = System.Drawing.Color.LimeGreen;
            this.equipmentStatusID.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.equipmentStatusID.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.equipmentStatusID.Location = new System.Drawing.Point(1003, 6);
            this.equipmentStatusID.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.equipmentStatusID.Name = "equipmentStatusID";
            this.equipmentStatusID.Size = new System.Drawing.Size(124, 29);
            this.equipmentStatusID.TabIndex = 9;
            this.equipmentStatusID.Text = "OK";
            this.equipmentStatusID.UseVisualStyleBackColor = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label9.Location = new System.Drawing.Point(876, 10);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(119, 20);
            this.label9.TabIndex = 8;
            this.label9.Text = "设备状态ID:";
            // 
            // equipmentIsRun
            // 
            this.equipmentIsRun.BackColor = System.Drawing.Color.LimeGreen;
            this.equipmentIsRun.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.equipmentIsRun.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.equipmentIsRun.Location = new System.Drawing.Point(773, 6);
            this.equipmentIsRun.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.equipmentIsRun.Name = "equipmentIsRun";
            this.equipmentIsRun.Size = new System.Drawing.Size(85, 29);
            this.equipmentIsRun.TabIndex = 7;
            this.equipmentIsRun.Text = "OK";
            this.equipmentIsRun.UseVisualStyleBackColor = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label8.Location = new System.Drawing.Point(621, 10);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(139, 20);
            this.label8.TabIndex = 6;
            this.label8.Text = "设备允许运行:";
            // 
            // mesModel
            // 
            this.mesModel.BackColor = System.Drawing.Color.LimeGreen;
            this.mesModel.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.mesModel.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.mesModel.Location = new System.Drawing.Point(473, 6);
            this.mesModel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.mesModel.Name = "mesModel";
            this.mesModel.Size = new System.Drawing.Size(128, 29);
            this.mesModel.TabIndex = 5;
            this.mesModel.Text = "控制模式";
            this.mesModel.UseVisualStyleBackColor = false;
            this.mesModel.Click += new System.EventHandler(this.button3_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label7.Location = new System.Drawing.Point(377, 10);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(89, 20);
            this.label7.TabIndex = 4;
            this.label7.Text = "MES模式:";
            // 
            // mesStatus
            // 
            this.mesStatus.BackColor = System.Drawing.Color.LimeGreen;
            this.mesStatus.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.mesStatus.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.mesStatus.Location = new System.Drawing.Point(287, 6);
            this.mesStatus.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.mesStatus.Name = "mesStatus";
            this.mesStatus.Size = new System.Drawing.Size(75, 29);
            this.mesStatus.TabIndex = 3;
            this.mesStatus.Text = "OK";
            this.mesStatus.UseVisualStyleBackColor = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.Location = new System.Drawing.Point(188, 10);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(89, 20);
            this.label6.TabIndex = 2;
            this.label6.Text = "MES连接:";
            // 
            // plcStatus
            // 
            this.plcStatus.BackColor = System.Drawing.Color.LimeGreen;
            this.plcStatus.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.plcStatus.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.plcStatus.Location = new System.Drawing.Point(101, 6);
            this.plcStatus.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.plcStatus.Name = "plcStatus";
            this.plcStatus.Size = new System.Drawing.Size(77, 29);
            this.plcStatus.TabIndex = 1;
            this.plcStatus.Text = "OK";
            this.plcStatus.UseVisualStyleBackColor = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(5, 10);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(89, 20);
            this.label5.TabIndex = 0;
            this.label5.Text = "PLC连接:";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1165, 669);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "MainForm";
            this.Text = "Form1";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.panel1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel.ResumeLayout(false);
            this.panel.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.topPanel.ResumeLayout(false);
            this.topPanel.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btn_Max;
        private System.Windows.Forms.Button btn_Min;
        private System.Windows.Forms.Panel panel;
        private System.Windows.Forms.Label verLab;
        private System.Windows.Forms.Button btn_close;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel topPanel;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Button btn_user_Exit;
        private System.Windows.Forms.Label lab_right;
        private System.Windows.Forms.Label lab_user;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label txt_SoftName;
        private System.Windows.Forms.Panel leftPanel;
        private System.Windows.Forms.Panel mainPanel;
        private System.Windows.Forms.Label lab_per;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button equipmentStatusID;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button equipmentIsRun;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button mesModel;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button mesStatus;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button plcStatus;
        private System.Windows.Forms.Label label5;
    }
}

