﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ProModel;

namespace Pro
{
    public partial class FileSettingForm : Form
    {
        public FileSettingForm()
        {
            InitializeComponent();

        }

        private void read_btn_Click(object sender, EventArgs e)
        {
            folderBrowserDialog1.SelectedPath = log_txt.Text;
            if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
                log_txt.Text = folderBrowserDialog1.SelectedPath;
        }

        private void FileSettingForm_Load(object sender, EventArgs e)
        {
            if (DevManage.Instance().userMgn.perCurrent.rightBarItem.Keys.Contains(this.Name))
            {
                if (DevManage.Instance().userMgn.perCurrent.rightBarItem[this.Name] != Em_Right.Write)
                {
                    DevManage.Instance().ControlEnable(false, this.Controls);
                }
                else
                {
                    DevManage.Instance().ControlEnable(true, this.Controls);
                }
            }
        }
    }
}
