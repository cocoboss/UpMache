﻿using ProModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pro
{
    public partial class DeviceStatusForm : Form
    {
        public string model = "离线模式";
        //MainForm main = null;
        public DeviceStatusForm()
        {
            //main = temps;
            //model = main.temp;
            InitializeComponent();
            //if (DevManage.Instance().currentFormRgiht != Em_Right.Write)
            //{
            //    DevManage.Instance().ControlEnable(false, this.Controls);
            //}
            //else
            //{
            //    DevManage.Instance().ControlEnable(true, this.Controls);
            //}
        }

        private void btn_control_Click(object sender, EventArgs e)
        {
            this.btn_control.Focus();
            model = btn_control.Text.ToString().Trim();
        }

        private void btn_monitor_Click(object sender, EventArgs e)
        {
            this.btn_monitor.Focus();
            model = btn_monitor.Text.ToString().Trim();
        }

        private void btn_out_Click(object sender, EventArgs e)
        {
            this.btn_out.Focus();
            model = btn_out.Text.ToString().Trim();
        }

        private void DeviceStatusForm_Load(object sender, EventArgs e)
        {
            //if (DevManage.Instance().userMgn.perCurrent.rightBarItem.Keys.Contains(this.Name))
            //{
            //    if (DevManage.Instance().userMgn.role.remark.Contains( Em_UserRightCH.操作工.ToString()))
            //    {
            //        DevManage.Instance().ControlEnable(false, this.Controls);
            //    }
            //    else
            //    {
            //        DevManage.Instance().ControlEnable(true, this.Controls);
            //    }
            //}
            //if (btn_control.Text.ToString().Trim().Contains(model))
            //    this.btn_control.Focus();
            //else if (btn_monitor.Text.ToString().Trim().Contains(model))
            //    this.btn_monitor.Focus();
            //else
            //    this.btn_out.Focus();
        }

        private void btn_ok_Click(object sender, EventArgs e)
        {
            if(!model.Contains(DevManage.Instance().CurrentModel))
            {
                DevManage.Instance().CurrentModel = model.Replace("MES", "").Trim();
                DevManage.Instance().RaiseSigStatus(Em_SigName.mesModel, DevManage.Instance().CurrentModel);
                try
                {
                    if (DevManage.Instance().Plc.IsConnect)
                    {
                        int plcStatus = int.Parse(DevManage.Instance().Read("PLC设备状态"));
                        string message = "";
                        bool ret = DevManage.Instance().SendACEQPTSTUS(Em_MES.ACEQPTSTUS, "1", plcStatus, out message);

                        if (ret)
                            DevManage.Instance().WriteLog($"设备模式上传成功");
                        else
                            DevManage.Instance().WriteLog($"设备模式出错;原因：{message}");
                    }
                }
                catch(Exception ex)
                {
                    DevManage.Instance().WriteErrorLog("设备模式上传出错："+ex.Message);
                }
            }
            this.Close();
        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
