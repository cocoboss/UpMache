﻿using ProModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pro
{
    public partial class LogForm : Form
    {
        public LogForm()
        {
            InitializeComponent();
            DevManage.Instance().userMgn.evenHand.event_LogMessage += LogMessageReveiver;
        }

        public void LogMessageReveiver(object sender,EventArgs e)
        {
            LogEventArgs le = (LogEventArgs)e;
            string szContent = "[" + DateTime.Now.ToString("yyyy/MM/dd HH-mm-ss.fff") + "]: " + le.message+"/r/n";
            InveokeCls.DoInvokeRequired(logList, () =>
            {
                if(logList.Items.Count>=500)
                {
                    logList.Items.Remove(logList.Items[0]);
                }
                logList.Items.Add(szContent);
                logList.TopIndex = logList.Items.Count - 1;
            });
        }
    }
}
