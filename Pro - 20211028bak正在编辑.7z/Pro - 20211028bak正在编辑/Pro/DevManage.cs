﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProBLL;
using System.Reflection;
using UtilityLibrary.WinControls;
using ProModel;
using System.Windows.Forms;
using ProDAL;
using System.Threading;
using Apriso.MIPlugins.Communication.Clients.WcfServiceAPI;

namespace Pro
{
    public class DevManage
    {
        private volatile static DevManage instance = null;

        private static object objAlarmLock = new object();

        public PLCBase Plc = null;
        public AsyncTcpServer mfgSocketA = new AsyncTcpServer(0);
        public AsyncTcpServer mfgSocketB = new AsyncTcpServer(1);

        private Thread ScanPlcThread = null;
        private Thread TimerThread = null;
        private static object objLock = new object();
        public UserManage userMgn = new UserManage();
        public PlcConfigs plcpfg = null;
        public SystemParam sysParam = new SystemParam();
        public bool isPLCRun = false;
        public bool exit = false;
        public string CurrentModel = "";
        public Em_Right currentFormRgiht;
        public MainForm mainForm = null;
        public bool isDebug = true;
        //public bool isDebug = false;


        public ACEQPTINIT.ACEQPTINITRequestEquipmentInfo currentParamInit = null;
        public ACEQPTINIT.ACEQPTINITRequestEquipmentInfo tempParamInit = null;
        public Dictionary<string, ACEQPTINIT.ACEQPTINITRequestParameterInfo> tempInfo = new Dictionary<string, ACEQPTINIT.ACEQPTINITRequestParameterInfo>();
        public Dictionary<string, ACEQPTINIT.ACEQPTINITRequestParameterInfo> currentInfo = new Dictionary<string, ACEQPTINIT.ACEQPTINITRequestParameterInfo>();
        public Dictionary<string, ProdectionData> dataDic = new Dictionary<string, ProdectionData>();
        public Dictionary<string, ACEQPTALRT.ACEQPTALRTRequestAlertInfo> currentAlarmRecord = new Dictionary<string, ACEQPTALRT.ACEQPTALRTRequestAlertInfo>();



        #region
        //public EventHand evenHand = new EventHand();

        #endregion
        public static DevManage Instance()
        {
            if (instance == null)
            {
                lock (objLock)
                {
                    if (instance == null)
                    {
                        instance = new DevManage();
                    }
                }
            }
            return instance;
        }

        public void InitDev()
        {
            //FileSave.WriteExceptionLog("链接mes开始");
            MseManager.Instance().Init(sysParam, userMgn);
            plcpfg = new PlcConfigs(new OmronNjFins(),sysParam);
            Plc = plcpfg.plc;
            //Plc.Open("192.168.250.1");
            //MseManager.Instance().userMsg = userMgn;
            string tempCode= sysParam.sysParam[Em_DefineVariable.ProcessCode.ToString()];
            if (!string.IsNullOrEmpty(tempCode))
            {
                currentParamInit = Common.FormJson<ACEQPTINIT.ACEQPTINITRequestEquipmentInfo>(sysParam.paramInit[tempCode].json);
                if(currentParamInit.StepInfo.Count>0)
                {
                    foreach (var item in currentParamInit.StepInfo[0].ParameterInfo)
                    {
                        currentInfo.Add(item.ParameterCode, item);
                    }
                }
              
            }

            ScanPlcThread = new Thread(new ThreadStart(ScanPlcThreadEntry));
            ScanPlcThread.Start();

            TimerThread = new Thread(new ThreadStart(TimerThreadEntry));
            TimerThread.Start();
        }
        private void TimerThreadEntry()
        {
            DateTime nowTime = DateTime.Now;
            int tempPlcCount = 0;
            int tempMesCount = 0;
            int tempAlarm = 0;
            while (!exit)
            {
                if (Plc.IsConnect)
                {
                   
                    ReadTimer(tempAlarm);
                    if(tempPlcCount != 1)
                        RaiseSigStatus(Em_SigName.plcStatus, Em_OtherStatus.OK.ToString());
                    tempPlcCount = 1;
                }
                else
                {
                    if (tempPlcCount != 2)
                        RaiseSigStatus(Em_SigName.plcStatus, Em_OtherStatus.NG.ToString());
                    tempPlcCount = 2;
                }
                if(MseManager.Instance().isConnect)
                {
                    if (tempMesCount != 1)
                        RaiseSigStatus(Em_SigName.mesStatus, Em_OtherStatus.OK.ToString());
                    tempMesCount = 1;
                }else
                {
                    if (tempMesCount != 2)
                        RaiseSigStatus(Em_SigName.mesStatus, Em_OtherStatus.NG.ToString());
                    tempMesCount = 2;

                }

            }
        }
        private void ScanPlcThreadEntry()
        {
            WriteLog("开启扫描线程");
            while (!exit)
            {
                if (Plc.IsConnect && userMgn.currentUser!=null)
                {

                    ReadSigGroup();
                }
                   
                Thread.Sleep(10);
            }
        }
        public void ReadSigGroup()
        {
            AddrGroups group = plcpfg.dirGroup[sysParam.sysParam["trigger"]];


            if (Plc.ReadGroup(ref group))
            {
                plcpfg.dirGroup[sysParam.sysParam["trigger"]] = group;
                for (int i = 0; i < group.unitLst.Count; i++)
                {
                    if (group.unitLst[i].Data != group.unitLst[i].OldData)
                    {
                        string strLog = $"{group.unitLst[i].Name}:{group.unitLst[i].OldData}-->{group.unitLst[i].Data}";
                        WriteLog(strLog);
                        group.unitLst[i].OldData = group.unitLst[i].Data;
                        if (group.unitLst[i].Data == "1")
                        {
                            StatusActionAsync(group.unitLst[i]);
                            RaiseSigStatus(group.unitLst[i].Name, EM_SigStatus.ON.ToString());
                        }
                        else
                        {
                            RaiseSigStatus(group.unitLst[i].Name, EM_SigStatus.OFF.ToString());
                        }
                    }
                }
            }

        }

        public void RaiseSigStatus(object name, string data)
        {
            if (name is Enum)
            {
                userMgn.evenHand.UpdateStatus(new SigStatusEventArgs((Em_SigName)name, data));
            }else
            {
                //触发信号可以加在这里
            }
        }

        public async void StatusActionAsync(DataUint unit)
        {
            await Task.Run(() =>
            {
                StatusAction(unit);
            });
        }

        public void StatusAction(DataUint unit)
        {
            switch (unit.Name.Trim())
            {
                case "上料触发信号":
                    BarCodeOn();
                    break;
                case "下料触发信号":
                    BarCodeOff();
                    break;
                case "PLC用户登录触发":
                    PlcLogin();
                    Write(unit.Name.Trim(),((int) Em_OtherStatus.Reset).ToString());
                    break;

                case "设备请求触发信号":
                    EquipmentRun();
                    Write(unit.Name.Trim(), ((int)Em_OtherStatus.Reset).ToString());
                    break;
                default:
                    break;
            }
        }

        public void PlcLogin()
        {
            WriteLog("PLC用户登录触发");
            try
            {
                string message = "";
                string name = Read("PLC登录用户");
                string pwd = Read("PLC登录密码");
                string right = Read("PLC登录权限");
                string level = ((Em_UserRightCH)int.Parse(right)).ToString();
                WriteLog($"读取PLC成功，用户名:{name};密码：{pwd};权限:{level}");
                bool ret = SendACUSERINFO(Em_MES.ACUSERINFO, name, pwd, level, out message);
                //bool ret = true;
                if (ret)
                {
                    Write("下发PLC登录结果", right);
                    Write("PLC登录用户","");
                    Write("PLC登录密码","");
                    WriteLog($"PLC用户登录成功，用户名:{name};密码：{pwd};权限:{level}");
                    Task.Run(() => { MessageBox.Show($"PLC用户登录成功，用户名:{name};密码：{pwd};权限:{level}"); });
                }
                else
                {
                    Write("下发PLC登录结果", "0");
                    //Write("PLC登录用户", "");
                    //Write("PLC登录密码", "");
                    WriteLog($"PLC用户登录失败，原因：{message}");
                    Task.Run(() =>
                    {
                        MessageBox.Show($"PLC用户登录失败，原因：{message}");
                    });
                }
            }catch (Exception ex)
            {
                WriteErrorLog(ex.Message);
            }


        }
        public void BarCodeOff()
        {
            ProdectionData tempData = new ProdectionData();
            string barCell = "";
            string message = "";
            bool isReturnPlc = false;
            bool ret = false;
            try {
                for (int i = 0; i < 3; i++)
                {
                    if (string.IsNullOrEmpty(barCell))
                    {
                        plcpfg.Read("出站条码", ref barCell);
                    }
                    else
                    {
                        tempData.barCode = barCell;
                        break;
                    }
                    Thread.Sleep(100);
                }
                #region 获取出站数据包
                AddrGroups group = plcpfg.dirGroup[sysParam.sysParam[Em_DefineVariable.byCell.ToString()]];
                List<ACLOGOFF.ACLOGOFFRequestParameters> offParams = new List<ACLOGOFF.ACLOGOFFRequestParameters>();
                if (Plc.ReadGroup(ref group))
                {

                    for (int i = 0; i < group.unitLst.Count; i++)
                    {
                        ACLOGOFF.ACLOGOFFRequestParameters parm = new ACLOGOFF.ACLOGOFFRequestParameters();
                        switch (group.unitLst[i].Name)
                        {
                            case "电芯左肩高":
                                tempData.shoulderHeightL = float.Parse( group.unitLst[i].Data);
                                parm = SetACLOGOFFRequestParameters(group.unitLst[i].Data, "结果_电芯正极肩高度", group.unitLst[i].bandField);
                                
                                //parm.TargetValue = "204.66";
                                //parm.UpperLimit = "205.26";
                                //parm.LowerLomit = "204.06";
                                break;
                            case "电芯左柱高":
                                tempData.PoleHeightL = float.Parse(group.unitLst[i].Data);
                                parm = SetACLOGOFFRequestParameters(group.unitLst[i].Data, "结果_电芯正极柱高度", group.unitLst[i].bandField);
                                //parm.TargetValue = "204.66";
                                //parm.UpperLimit = "205.26";
                                //parm.LowerLomit = "204.06";
                                break;
                            case "电芯宽度":
                                tempData.bycellWidth = float.Parse(group.unitLst[i].Data);
                                parm = SetACLOGOFFRequestParameters(group.unitLst[i].Data, "结果_电芯宽度", group.unitLst[i].bandField);
                                //parm.TargetValue = "173.93";
                                //parm.UpperLimit = "174.53";
                                //parm.LowerLomit = "173.33";
                                break;
                            case "电芯厚度":
                                tempData.bycellPlies = float.Parse(group.unitLst[i].Data);
                                parm = SetACLOGOFFRequestParameters(group.unitLst[i].Data, "结果_电芯厚度", group.unitLst[i].bandField);

                                //parm.TargetValue = "71.65";
                                //parm.UpperLimit = "72.25";
                                //parm.LowerLomit = "71.05";
                                break;
                            case "测厚压力":
                                tempData.testPliesPress = float.Parse(group.unitLst[i].Data);
                                parm = SetACLOGOFFRequestParameters(group.unitLst[i].Data, "结果_测厚压力值", group.unitLst[i].bandField);
                                //parm.TargetValue = "300";
                                //parm.UpperLimit = "320";
                                //parm.LowerLomit = "280";
                                break;
                            case "电芯右柱高":
                                tempData.PoleHeightR = float.Parse(group.unitLst[i].Data);
                                parm = SetACLOGOFFRequestParameters(group.unitLst[i].Data, "结果_电芯负极柱高度", group.unitLst[i].bandField);
                                //parm.TargetValue = "207.23";
                                //parm.UpperLimit = "207.83";
                                //parm.LowerLomit = "206.63";
                                break;
                            case "电芯右肩高":
                                tempData.shoulderHeightR = float.Parse(group.unitLst[i].Data);
                                parm = SetACLOGOFFRequestParameters(group.unitLst[i].Data, "结果_电芯负极肩高度", group.unitLst[i].bandField);

                                //parm.TargetValue = "207.23";
                                //parm.UpperLimit = "207.83";
                                //parm.LowerLomit = "206.63";
                                break;
                            case "工位号":
                                tempData.cavity = (group.unitLst[i].Data);
                                parm = null;
                                break;
                            default:
                                parm = null;
                                break;
                        }
                        if (parm != null)
                        {
                            offParams.Add(parm);
                        }
                            
                    }
                }
                sysParam.sysParam[Em_DefineVariable.all.ToString()] = Read("总产量");
                sysParam.sysParam[Em_DefineVariable.OK.ToString()] = Read("OK数量");

                #endregion
                switch (sysParam.sysParam[Em_DefineVariable.EquipmentModel.ToString()])
                {
                    case "CONT":
                        ret = SendACLOGOFF(Em_MES.ACLOGOFF, barCell, out message, offParams);
                        break;
                    case "MONT":
                        Task.Run(() => { SendACLOGOFF(Em_MES.ACLOGOFF, barCell, out message, offParams); });
                        ret = true;
                        break;
                    default:
                        ret = true;
                        break;
                }
                //ret = SendACLOGOFF(Em_MES.ACLOGOFF, barCell, out message, offParams);

                if (offParams.Count > 0)
                {
                    foreach (var item in offParams)
                    {
                        if (item.ParameterResult.Contains("NG"))
                        {
                            ret = false;
                            message += $"{item.ParameterDescription}的值不在下发范围[{item.LowerLomit},{item.UpperLimit}]内";
                        }
                    }
                }
                if (ret)
                {
                    tempData.out_result = "OK";
                    isReturnPlc=Write("下料结果反馈", "2");
                    WriteLog($"电芯条码:{barCell};出站结果反馈——返回PLC:2");
                    //sysParam.sysParam[Em_DefineVariable.OK.ToString()] = (int.Parse(string.IsNullOrEmpty(sysParam.sysParam[Em_DefineVariable.OK.ToString()]) ? "0" : sysParam.sysParam[Em_DefineVariable.OK.ToString()]) + 1).ToString();
                }
                else
                {
                    tempData.out_result = "NG";
                    isReturnPlc =Write("下料结果反馈", "1");
                    WriteLog($"电芯条码:{barCell};出站结果反馈——返回PLC:1;原因：{message}");
                    if(!MseManager.Instance().isConnect)
                    {
                        tempData.remark = "1";
                    }else
                    {
                        tempData.remark = "0";
                    }
                }
                tempData.out_message = message;
                tempData.out_time = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                if (dataDic.Keys.Contains(tempData.barCode))
                {
                    tempData.model = dataDic[tempData.barCode].model;
                    tempData.in_message = dataDic[tempData.barCode].in_message;
                    tempData.in_result = dataDic[tempData.barCode].in_result;
                    tempData.in_time = dataDic[tempData.barCode].in_time;
                    dataDic.Remove(tempData.barCode);
                }
                else
                {
                    dataDic.Add(tempData.barCode, tempData);
                }
                string allcount=sysParam.sysParam[Em_DefineVariable.all.ToString()];
                string okcount=sysParam.sysParam[Em_DefineVariable.OK.ToString()];
                userMgn.evenHand.UpdataData(new DataEventArgs(Em_Data.dataOut, tempData, ret,allcount,okcount)); //更新界面显示
                DataBll db = new DataBll(Em_Data.dataOut, tempData);
                db.SaveDb();                //保存数据库
            }
            catch(Exception ex)
            {
                if (!isReturnPlc)
                {
                    Write("下料结果反馈", "1");
                    WriteLog($"电芯条码:{barCell};出站结果反馈——返回PLC:1;原因：{message}");
                }
                WriteErrorLog($"出站出错：{ex.Message}");
            }
        }
        public ACLOGOFF.ACLOGOFFRequestParameters SetACLOGOFFRequestParameters(string data,string decription,string paraCode)
        {
            ACLOGOFF.ACLOGOFFRequestParameters parm = new ACLOGOFF.ACLOGOFFRequestParameters();
            if (currentInfo.Keys.Contains(paraCode))
            {
                //parm.ParameterResult = "OK";
                parm.ParameterResult = (double.Parse(currentInfo[paraCode].LowerControlLimit) > double.Parse(data) || double.Parse(currentInfo[paraCode].UpperControlLimit) < double.Parse(data)) ? "NG":"OK";
                parm.TargetValue = currentInfo[paraCode].TargetValue;
                parm.ParamterCode = paraCode;
                parm.Location = "";
                parm.Value = data;
                parm.ParameterDescription = decription;
                parm.UpperLimit = currentInfo[paraCode].UpperControlLimit;
                parm.LowerLomit = currentInfo[paraCode].LowerControlLimit;
                parm.DefectCode = "";
                parm.ParameterMessage = "";
            }
            else
            {
                parm.TargetValue = "";
                parm.ParamterCode = paraCode;
                parm.Location = "";
                parm.Value = data;
                parm.ParameterDescription = decription;
                parm.UpperLimit = "";
                parm.LowerLomit = "";
                parm.DefectCode = "";
                parm.ParameterResult = "OK";
                parm.ParameterMessage = "";
            }
            return parm;
        }

        public void EquipmentRun()
        {
            try
            {
                //if (MseManager.Instance().isConnect)
                //{
                    string message = "";
                bool ret = false;
                if (sysParam.sysParam[Em_DefineVariable.EquipmentModel.ToString()].Contains("CONT"))
                    ret = SendACEQUPTRUN(out message);
                else
                    ret = true;
                    if (ret)
                    {
                        Write("设备请求反馈","1");
                        WriteLog($"可以开机,设备请求反馈，返回1，允许开机运行");
                        RaiseSigStatus(Em_SigName.equipmentIsRun, Em_OtherStatus.OK.ToString());


                    //Task.Run(() =>
                    //{
                    //    MessageBox.Show("可以开机");
                    //});
                    }
                    else
                    {
                        Write("设备请求反馈", "0");
                        WriteLog($"不可以开机,设备请求反馈，返回0，不允许开机运行，原因{message}");
                        RaiseSigStatus(Em_SigName.equipmentIsRun, Em_OtherStatus.NG.ToString());
                    Task.Run(() => { MessageBox.Show($"不可以开机,原因：{message}"); });
                    }
                //}
                //else
                //{
                //    Task.Run(() => { MessageBox.Show("MES未连接成功，请连接成功后重试！"); });
                //}
            }
            catch (Exception ex)
            {
                DevManage.Instance().WriteErrorLog("设备运行请求上传出错:" + ex.Message);
            }
        }


        public void test()
        {
            int i = 0;
            while(i<15)
            {
                if(i%2==0)
                {
                    test1(i);
                }else if(i>10)
                {
                    //Thread.Sleep(120000);
                    test2(i-5);
                }
                else
                {
                    test2(i);
                }
                i++;
                Thread.Sleep(2000);
            }
        }
        public void test1(int i)
        {
            ProdectionData tempData = new ProdectionData();
            tempData.barCode = "test"+i.ToString();
            tempData.in_result = "OK";
            tempData.in_message = "test";
            tempData.model = sysParam.sysParam[Em_DefineVariable.EquipmentModel.ToString()];
            tempData.in_time = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            string allcount = sysParam.sysParam[Em_DefineVariable.all.ToString()];
            string okcount = sysParam.sysParam[Em_DefineVariable.OK.ToString()];
            userMgn.evenHand.UpdataData(new DataEventArgs(Em_Data.dataIn, tempData,true, allcount, okcount)); //更新界面显示
            DataBll db = new DataBll(Em_Data.dataIn, tempData);
            db.SaveDb(); 
        }
        public void test2(int i)
        {
            ProdectionData tempData = new ProdectionData();
            tempData.barCode = "test"+i.ToString();
            tempData.out_result = "NG";
            tempData.out_message = "test";
            tempData.model = sysParam.sysParam[Em_DefineVariable.EquipmentModel.ToString()];
            tempData.out_time = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            string allcount = sysParam.sysParam[Em_DefineVariable.all.ToString()];
            string okcount = sysParam.sysParam[Em_DefineVariable.OK.ToString()];
            userMgn.evenHand.UpdataData(new DataEventArgs(Em_Data.dataOut, tempData,false,allcount,okcount)); //更新界面显示
            DataBll db=new DataBll(Em_Data.dataOut, tempData);
            db.SaveDb();
        }

        public void BarCodeOn()
        {
            ProdectionData tempData = new ProdectionData();
           
             //sysParam.sysParam[Em_DefineVariable.OK.ToString()]= string.IsNullOrEmpty(sysParam.sysParam[Em_DefineVariable.all.ToString()]) ? "0" : sysParam.sysParam[Em_DefineVariable.all.ToString()];
            string barCell = "";
            string message = "";
            bool ret = false;
            bool isReturnPlc = false;
            try {
                sysParam.sysParam[Em_DefineVariable.all.ToString()] = (int.Parse(string.IsNullOrEmpty(sysParam.sysParam[Em_DefineVariable.all.ToString()]) ? "0" : sysParam.sysParam[Em_DefineVariable.all.ToString()]) + 1).ToString();
                for (int i = 0; i < 3; i++)
                {
                    if (string.IsNullOrEmpty(barCell))
                    {
                        plcpfg.Read("进站条码", ref barCell);
                    }
                    else
                    {
                        tempData.barCode = barCell;
                        break;
                    }
                    Thread.Sleep(100);
                }

                sysParam.sysParam[Em_DefineVariable.all.ToString()] = Read("总产量");
                sysParam.sysParam[Em_DefineVariable.OK.ToString()] = Read("OK数量");
                switch (sysParam.sysParam[Em_DefineVariable.EquipmentModel.ToString()])
                {
                    case "CONT":
                        ret = SendACLOGONCHECK(Em_MES.ACLOGONCHECK, barCell, out message);
                        break;
                    case "MONT":
                        Task.Run(() => { SendACLOGONCHECK(Em_MES.ACLOGONCHECK, barCell, out message); });
                        ret = true;
                        break;
                    default:
                        ret = true;
                        break;
                }
                //bool ret = SendACLOGONCHECK(Em_MES.ACLOGONCHECK, barCell, out message);
                //ret = true;
                if (ret)
                {
                    isReturnPlc=Write("上料结果反馈", "2");
                    WriteLog($"电芯条码:{barCell};进站结果反馈——返回PLC:2");
                    tempData.in_result = "OK";

                }
                else
                {
                    isReturnPlc=Write("上料结果反馈", "1");
                    WriteLog($"电芯条码:{barCell};进站结果反馈——返回PLC:1;原因：{message}");
                    tempData.in_result = "NG";
                }
                tempData.in_message = message;
                tempData.model = sysParam.sysParam[Em_DefineVariable.EquipmentModel.ToString()];
                tempData.in_time = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                if (dataDic.Keys.Contains(tempData.barCode))
                {
                    if (tempData.in_result.Contains("OK"))
                        dataDic[tempData.barCode] = tempData;
                } else if(tempData.in_result.Contains("OK"))
                {
                    dataDic.Add(tempData.barCode, tempData);
                }

               
                string allcount = sysParam.sysParam[Em_DefineVariable.all.ToString()];
                string okcount = sysParam.sysParam[Em_DefineVariable.OK.ToString()];
                userMgn.evenHand.UpdataData(new DataEventArgs(Em_Data.dataIn, tempData,ret,allcount,okcount)); //更新界面显示
                DataBll db = new DataBll(Em_Data.dataIn, tempData);
                db.SaveDb();                //保存数据库
            }catch(Exception ex)
            {
                if(!isReturnPlc)
                {
                    Write("上料结果反馈", "1");
                    WriteLog($"电芯条码:{barCell};进站结果反馈——返回PLC:1;原因：{message}");
                }
                WriteErrorLog($"进站出错：{ex.Message}");
            }
        }

        public bool SendACEQPTPARM(string code,string version,out string message)
        {
            bool ret = false;
            message = "";
            //string right = uf.userMgn.groupRole[userRight[com_group.SelectedIndex]].name;
            //string model = sysParam.sysParam[Em_DefineVariable.EquipmentModel.ToString()];
            string temp = MseManager.Instance().GetACEQPTPARMRequestJson(userMgn.currentUser.userName,code,version);
            //WriteLog(temp);
            MseManager.Instance().SendMessageRequest(Em_MES.ACEQPTPARM, temp, out ret, out message);
            return ret;
        }
        public bool SendACEQUPTRUN(out string message)
        {
            bool ret = false;
            message = "";
            //string right = uf.userMgn.groupRole[userRight[com_group.SelectedIndex]].name;
            string model = sysParam.sysParam[Em_DefineVariable.EquipmentModel.ToString()];
            string temp = MseManager.Instance().GetACEQUPTRUNRequestJson(userMgn.currentUser.userName,model);
            //WriteLog(temp);
            MseManager.Instance().SendMessageRequest(Em_MES.ACEQUPTRUN, temp, out ret, out message);
            return ret;
        }



        public void SendRetuenInitParam(Guid guid,bool ret)
        {
            ACEQPTINIT.ACEQPTINITResponseJson json = new ACEQPTINIT.ACEQPTINITResponseJson();
            //ACEQPTINIT.ACEQPTINITResponseEquipmentInfo info = new ACEQPTINIT.ACEQPTINITResponseEquipmentInfo();
            json.EquipmentInfo.Add(new ACEQPTINIT.ACEQPTINITResponseEquipmentInfo() { Message = "", Result = ret, EquipmentCode = sysParam.sysParam[Em_DefineVariable.EquipmentCode.ToString()]});
            json.Software = sysParam.sysParam[Em_DefineVariable.Software.ToString()];
            //item.CommandResponseJson = json;
            //ACEQPTINIT.response = item;
            string items = Common.ToJSON(json);

            MseManager.Instance().SendParamInitResponse(items, guid);
            
        }

        public bool SendACEQPTALRT(List<ACEQPTALRT.ACEQPTALRTRequestAlertInfo> lst,out string message)
        {
            bool ret = false;
            message = "";
            //string right = uf.userMgn.groupRole[userRight[com_group.SelectedIndex]].name;
            //string model = sysParam.sysParam[Em_DefineVariable.EquipmentModel.ToString()];
            string temp = MseManager.Instance().GetACEQPTALRTRequestJson(userMgn.currentUser.userName, lst);
            //WriteLog(temp);
            MseManager.Instance().SendMessageRequest(Em_MES.ACEQPTALRT, temp, out ret, out message);
            return ret;
        }

        public bool SendACLOGONCHECK(Em_MES type, string badCode, out string message)
        {
            bool ret = false;
            message = "";
            //string right = uf.userMgn.groupRole[userRight[com_group.SelectedIndex]].name;
            string temp = MseManager.Instance().GetACLOGONCHECKRequestJson(badCode, userMgn.currentUser.userName);
            //WriteLog(temp);
            MseManager.Instance().SendMessageRequest(Em_MES.ACLOGONCHECK, temp, out ret, out message);
            return ret;
        }
        public bool SendACEQPTSTUS(Em_MES type, string opFalg,int eqpID, out string message)
        {
            //opFalg =1 上传设备模式；=2上传设备状态
            bool ret = false;
            message = "";
            string model = sysParam.sysParam[Em_DefineVariable.EquipmentModel.ToString()];
            string id = sysParam.sysParam[Em_DefineVariable.EquipmentStatusID.ToString()];
            string descrp = sysParam.epStatus[eqpID].description;
            //string right = uf.userMgn.groupRole[userRight[com_group.SelectedIndex]].name;
            string temp = MseManager.Instance().GetACEQPTSTUSRequestJson(userMgn.currentUser.userName,model,opFalg,id, descrp);
            //WriteLog(temp);
            MseManager.Instance().SendMessageRequest(Em_MES.ACEQPTSTUS, temp, out ret, out message);
            return ret;
        }

        public bool SendACLOGOFF(Em_MES type, string badCode,out string message, List<ACLOGOFF.ACLOGOFFRequestParameters> offParams)
        {
            bool ret = false;
            message = "";
            //string right = uf.userMgn.groupRole[userRight[com_group.SelectedIndex]].name;
            string temp = MseManager.Instance().GetACLOGOFFRequestJson(badCode,userMgn.currentUser.userName, offParams);
            WriteLog(temp);
            MseManager.Instance().SendMessageRequest(Em_MES.ACLOGOFF, temp, out ret, out message);
            return ret;
        }


        public bool SendACUSERINFO(Em_MES type,string name,string pwd,string right,out string message)
        {
            bool ret = false;
            message = "";
            //string right = uf.userMgn.groupRole[userRight[com_group.SelectedIndex]].name;
            string temp = MseManager.Instance().GetACUSERINFORequestJson(name, pwd, right);
            WriteLog(temp);
            MseManager.Instance().SendMessageRequest(Em_MES.ACUSERINFO, temp,out ret,out message);
            return ret;
        }


        public string Read(string name)
        {
            string right = "";
            plcpfg.Read(name, ref right);
            return right;
        }
        public bool Write(string name,string data)
        {
           
            return plcpfg.Write(name, data);
           
        }

        #region     定时读取写入PLC信息

        public void ReadTimer(int counts)
        {
            try {
                if (!sysParam.sysParam[Em_DefineVariable.EquipmentModel.ToString()].Contains(Em_EquipmentModel.MANU.ToString()))
                    WritePlcHeart();
                if (MseManager.Instance().isConnect)
                    ReadPlcStatus();
                if (userMgn.isLogin)
                {
                    ReadPlcAlarm(counts);
                    if (DateTime.Now.Minute % 15 == 0)
                    {
                        if (userMgn.role.remark.Contains(Em_UserRightCH.技术员.ToString()) || userMgn.role.remark.Contains(Em_UserRightCH.管理员.ToString()))
                        {
                            LogOut();
                        }
                    }
                }

                if (DateTime.Now.Hour % 3 == 0 && sysParam.sysParam[Em_DefineVariable.isClearData.ToString()].Contains("1"))
                {
                    DataBll db = new DataBll();
                    string time = DateTime.Now.AddDays(-(int.Parse(sysParam.sysParam[Em_DefineVariable.cleraDataTime.ToString()]))).ToString("yyyy-MM-dd HH:mm:ss");
                    if (db.ClearData(time))
                    {
                        //定期清楚数据
                    }
                }
            }catch(Exception ex)
            {
                WriteErrorLog($"定时器里出错：{ex.Message}");
            }
        }


        public void LogOut()
        {
            userMgn.Login("admin", "admin");
            userMgn.isLogin = false;
            userMgn.currentUser.userName = "";
            userMgn.role.remark = "";
            userMgn.evenHand.UpdateLeftForm(userMgn.isLogin);
        }
        public void ReadPlcAlarm(int cont)
        {
            lock(objAlarmLock)
            {
                try {
                    AddrGroups group = plcpfg.dirGroup[sysParam.sysParam[Em_DefineVariable.alarmCell.ToString()]];
                    if (Plc.ReadGroup(ref group))
                    {
                        List<ACEQPTALRT.ACEQPTALRTRequestAlertInfo> allLst = new List<ACEQPTALRT.ACEQPTALRTRequestAlertInfo>();
                        for (int i = 0; i < group.unitLst.Count; i++)
                        {
                            if (group.unitLst[i].Data != group.unitLst[i].OldData)
                            {
                                //string temp=Convert.ToString( Convert.ToInt16(group.unitLst[i].Data),2);
                                List<ACEQPTALRT.ACEQPTALRTRequestAlertInfo> temp = SetACEQPTALRTRequestEquipmentInfo(group.unitLst[i]);
                                allLst = allLst.Concat(temp).ToList();
                            }
                        }
                        string message = "";
                        bool ret = false;

                        if (!sysParam.sysParam[Em_DefineVariable.isUploadAlarm.ToString()].Contains("0") && allLst.Count>0)
                        {
                            ret = SendACEQPTALRT(allLst, out message);
                            if (ret)
                            {
                                if (cont != 2)
                                    WriteLog($"PLC设备报警上传成功");
                                cont = 2;
                            } 
                            else
                            {
                                if(cont!=1)
                                    WriteLog($"PLC设备报警上传出错;原因：{message}");
                                cont = 1;
                            }    
                        } 
                        
                    }
                }catch(Exception ex)
                {
                    WriteErrorLog($"报警上传出错：{ex.Message}");
                }
                }
        }

        public List<ACEQPTALRT.ACEQPTALRTRequestAlertInfo> SetACEQPTALRTRequestEquipmentInfo(DataUint unit)
        {
            List<ACEQPTALRT.ACEQPTALRTRequestAlertInfo> lst = new List<ACEQPTALRT.ACEQPTALRTRequestAlertInfo>();
            if (!string.IsNullOrEmpty(unit.bandField))
            {
                string subStr = "AlarmCode";
                int id = Convert.ToInt32(unit.bandField.Replace(subStr, ""));
                //List<int> ls = new List<int>();
                Int16 temp = Convert.ToInt16(unit.Data);
                for (int i = 0; i < 16; i++)
                {
                    ACEQPTALRT.ACEQPTALRTRequestAlertInfo info = new ACEQPTALRT.ACEQPTALRTRequestAlertInfo();
                    string tempAlarmCode = subStr + ((i + id).ToString()).PadLeft(5, '0');
                    if (((temp >> i) & 1) == 1)
                    {
                        
                        if (sysParam.alarmConfigLists.Keys.Contains(tempAlarmCode))
                        {
                            info.AlertCode = tempAlarmCode;
                            info.AlertCount = "1";
                            info.AlertDescription = sysParam.alarmConfigLists[tempAlarmCode].alarmDescript;
                            info.AlertLevel = sysParam.alarmConfigLists[tempAlarmCode].level;
                            info.AlertReset = "1";
                            if (currentAlarmRecord.Keys.Contains(tempAlarmCode))
                                currentAlarmRecord[tempAlarmCode] = info;
                            else
                                currentAlarmRecord.Add(tempAlarmCode, info);
                            lst.Add(info);
                        }
                        //ls.Add(i);
                    }else
                    {
                        if (currentAlarmRecord.Keys.Contains(tempAlarmCode))
                        {
                            currentAlarmRecord.Remove(tempAlarmCode);
                            info.AlertCode = tempAlarmCode;
                            info.AlertCount = "1";
                            info.AlertDescription = sysParam.alarmConfigLists[tempAlarmCode].alarmDescript;
                            info.AlertLevel = sysParam.alarmConfigLists[tempAlarmCode].level;
                            info.AlertReset = "0";
                            lst.Add(info);
                        }
                            
                    }
                }
            }
            return lst;
        }


        public void ReadPlcStatus()
        {
            if (DateTime.Now.Second % 2 == 0)
            {
                try
                {
                    string data = Read("PLC设备状态");
                    if (!plcpfg.dirDataUint["PLC设备状态"].OldData.Contains(data))
                    {
                        plcpfg.dirDataUint["PLC设备状态"].OldData = data;
                        int plcStatus = int.Parse(data);
                        sysParam.sysParam[Em_DefineVariable.EquipmentStatusID.ToString()] = sysParam.epStatus[plcStatus].statusID;
                        RaiseSigStatus(Em_SigName.equipmentStatusID, sysParam.epStatus[plcStatus].statusID);
                        string message = "";
                        bool ret = SendACEQPTSTUS(Em_MES.ACEQPTSTUS, "2", plcStatus, out message);

                        if (ret)
                            WriteLog($"PLC设备状态上传成功");
                        else
                            WriteLog($"PLC设备状态上传出错;原因：{message}");
                    }
                }
                catch (Exception ex)
                {
                    WriteErrorLog("设备状态处理出错：" + ex.Message);
                }
            }
        }
        public void WritePlcHeart()
        {
            if (DateTime.Now.Second % 2 == 0)
            {
                if (!Write("MES心跳", "1"))
                {
                    WriteLog("定时写入1到PLC心跳失败，检查地址和数据类型");
                }
            }
        }


        #endregion
        public void CreateSwitch()
        {
            List<Permissions> lstPer = userMgn.perCurrent.GetAllBands();
            foreach(Permissions val in lstPer)
            {
                if(!string.IsNullOrEmpty(val.code))
                {
                    Assembly asb = Assembly.GetExecutingAssembly();
                    Form centerPage = (Form)asb.CreateInstance(val.code);
                    if (centerPage != null)
                        userMgn.perCurrent.strForm.Add(val.id.ToString(), centerPage);
                }
            }
        }

        public void WriteLog(string log,Em_LogPath type= Em_LogPath.Run_Log)
        {
            FileSave.WriteLog(log, type.ToString());
            userMgn.evenHand.UpdataLog(new LogEventArgs(type, log));
        }

        public void WriteErrorLog(string log, Em_LogPath type = Em_LogPath.Error_Log)
        {
            FileSave.WriteExceptionLog(log, type.ToString());
        }
        public void WriteMesLog(string log, Em_LogPath type = Em_LogPath.MES_Log)
        {
            FileSave.WriteLog(log, type.ToString());
        }

        public void ControlEnable(bool type, Control.ControlCollection item)
        {
            if (item.Count > 0)
            {
                for (int i = 0; i < item.Count; i++)
                {
                    item[i].Enabled = type;
                    ControlEnable(type, item[i].Controls);
                }
            }
        }
    }
}
