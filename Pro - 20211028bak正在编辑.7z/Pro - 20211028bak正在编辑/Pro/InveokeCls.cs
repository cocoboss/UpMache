﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pro
{
    public class InveokeCls
    {
        public static void DoInvokeRequired(Control control, Action act)
        {
            if (control.InvokeRequired)
                control.Invoke(act);
            else
                act();
        }
    }
}
