﻿using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using System.Threading;
using System.IO;
using System.Collections.Generic;
using System.Net;
using System.Text;
using ProDAL;

namespace Pro
{
    public partial class PLCDataForm : Form
    {
        public OmronNxEip Plc = new OmronNxEip();//PLC对象
        //private TcpClientConn tcp = new TcpClientConn(0);
        public AsyncTcpServer mfgSocketA = new AsyncTcpServer(0);
        public AsyncTcpServer mfgSocketB = new AsyncTcpServer(1);
        bool bExit = false;
        bool bSuc = false;//PLC连接状态标识
        bool bIPCSucA = false;//IPCA连接标志
        bool bIPCSucB = false;//IPCB连接标志
        string time;//时间
        string fullPath;//文件保存路径
        string logPath;
        string createDirectory;//文件保存的文件夹
        string dateFlag;//日期标志用来判定是否更换日期，更换日期需要重新建立表格
        private delegate void SafeCallDelegate(string text);
        PLCTemperatureData m_PLCDataT = new PLCTemperatureData();
        Thread Scanthread = null;
        ShowType m_curType = ShowType.ShowA_Normal;
        List<PLCTemperatureData> m_curData = new List<PLCTemperatureData>();//当前数据

        #region 初始化
        public PLCDataForm()
        {
            InitializeComponent();
            
            dateFlag = DateTime.Now.ToString("yyyy-MM-dd");
            //fullPath = Directory.GetCurrentDirectory();
            fullPath = "D:";
            fullPath = fullPath + "\\温度";
            logPath = "D:\\温度软件日志";
            createDirectory = "";
            Directory.CreateDirectory(fullPath);
            Directory.CreateDirectory(logPath);
            //温度文件夹
            if (Directory.Exists(fullPath) == false)
            {
                Directory.CreateDirectory(fullPath);
            }
            if(File.Exists(fullPath+"\\"+dateFlag+"温度.csv")==false)//程序启动时查询文件是否存在
            {
                InitCSV(fullPath + "\\" + dateFlag + "温度.csv");
            }
            if (!PLCConnect())
            {
                RecordLog("连接PLC异常");
            }
            //开启服务端A
            mfgSocketA = new AsyncTcpServer(IPAddress.Parse("127.0.0.1"), 1999, 0);
            mfgSocketA.Encoding = Encoding.UTF8;
            mfgSocketA.ClientConnected +=
              new EventHandler<TcpClientConnectedEventArgs>(server_ClientConnectedA);
            mfgSocketA.ClientDisconnected +=
              new EventHandler<TcpClientDisconnectedEventArgs>(server_ClientDisconnectedA);
            mfgSocketA.PlaintextReceived +=
              new EventHandler<TcpDatagramReceivedEventArgs<string>>(server_PlaintextReceivedA);
            mfgSocketA.Start();

            //开启服务端B
            mfgSocketB = new AsyncTcpServer(IPAddress.Parse("192.168.250.6"), 2999, 0);
            mfgSocketB.Encoding = Encoding.UTF8;
            mfgSocketB.ClientConnected +=
              new EventHandler<TcpClientConnectedEventArgs>(server_ClientConnectedB);
            mfgSocketB.ClientDisconnected +=
              new EventHandler<TcpClientDisconnectedEventArgs>(server_ClientDisconnectedB);
            mfgSocketB.PlaintextReceived +=
              new EventHandler<TcpDatagramReceivedEventArgs<string>>(server_PlaintextReceivedB);
            mfgSocketB.Start();


            Scanthread = new Thread(new ThreadStart(LoopThread));
            Scanthread.Start();
            this.ShowAButton.Enabled = false;
            string time = DateTime.Now.ToString("yyyy-MM-dd") + " " + DateTime.Now.ToLongTimeString();

            comboBox1.SelectedIndex = 0;
            comboBox2.SelectedIndex = 0;

        }
        public void server_PlaintextReceivedA(object sender, TcpDatagramReceivedEventArgs<string> e)
        {
            string reccvString = e.Datagram;
            RecordLog(reccvString);
            bool ret = false;
            //分项 1：Error，2：tab换卷
            string []strArray = reccvString.Split(',');
            switch (strArray[0])
            {
                case "1":
                    ret = WriteErrorcode(1, 1,strArray[1]);
                    if (ret)
                    {
                        RecordLog("A写入Errorcode:" + strArray[1] + "成功");
                        //反馈给IPC 0K
                        mfgSocketA.SendAll("OK");
                    }
                    else
                    {
                        RecordLog("A写入Errorcode:" + strArray[1] + "失败");
                        //反馈给IPC NG
                        mfgSocketA.SendAll("NG");
                    }
                    break;
                case "2":
                    ret = WriteErrorcode(1, 2,strArray[1]);
                    if (ret)
                    {
                        RecordLog("A写入Errorcode:" + strArray[1] + "成功");
                        //反馈给IPC 0K
                        mfgSocketA.SendAll("OK");
                    }
                    else
                    {
                        RecordLog("A写入Errorcode:" + strArray[1] + "失败");
                        //反馈给IPC NG
                        mfgSocketA.SendAll("NG");
                    }
                    break;
            }


        }
        public void server_ClientConnectedA(object sender, TcpClientConnectedEventArgs e)
        {
            bIPCSucA = true;
            RecordLog("IPC-A连接成功");
        }
        public void server_ClientDisconnectedA(object sender, TcpClientDisconnectedEventArgs e)
        {
            bIPCSucA = false;
            RecordLog("IPC-A断开");
        }

        public void server_PlaintextReceivedB(object sender, TcpDatagramReceivedEventArgs<string> e)
        {
            string reccvString = e.Datagram;
            RecordLog(reccvString);
            bool ret = WriteErrorcode(2,1, reccvString);
            if (ret)
            {
                RecordLog("b写入Errorcode:" + reccvString + "成功");
                //反馈给IPC 0K
                mfgSocketB.SendAll("OK");
            }
            else
            {
                RecordLog("B写入Errorcode:" + reccvString + "失败");
                //反馈给IPC NG
                mfgSocketB.SendAll("NG");
            }
        }
        public void server_ClientConnectedB(object sender, TcpClientConnectedEventArgs e)
        {
            bIPCSucB = true;
            RecordLog("IPC-B连接成功");
        }
        public void server_ClientDisconnectedB(object sender, TcpClientDisconnectedEventArgs e)
        {
            bIPCSucB = false;
            RecordLog("IPC-B断开");
        }
        #endregion
        #region 线程
        private void LoopThread()
        {
            while (!bExit)
            {
                ShowPLCConnectState("");
                ShowIPCConnectStateA("");
                ShowIPCConnectStateB("");
                Thread.Sleep(5000);
                int dataCount = 100;
                byte[] buf = new byte[dataCount];
                string name = "E5CC温控器.显示温度";
                try
                {
                    if (bSuc)
                    {
                        //if (Plc.PLCReadBlock(name, dataCount, ref buf))
                        //{
                        //    //数据处理
                        //    DataAnaliysis(buf);
                        //    //数据添加
                        //    AddSingle();
                        //    //数据保存csv
                        //    if (saveFileByCSV(buf))
                        //    {
                        //        RecordLog("写入成功");
                        //    }
                        //    else
                        //    {
                        //        RecordLog("写入失败");
                        //    }
                        //}
                        //else
                        //{
                        //    RecordLog("读取失败");
                        //}
                           
                    }
                    else
                    {
                        RecordLog("连接PLC异常");
                        if (!PLCConnect())
                        {
                            RecordLog("重接PLC失败");
                        }
                        else
                        {
                            RecordLog("重接PLC成功");
                        }
                    }
                       
                }
                catch
                {
                    RecordLog("读取异常");                
                }
            }
        }
        #endregion
        #region PLC连接
        public bool PLCConnect()
        {
            if (!Plc.Open("192.168.250.1", null))
            {
                bSuc = false;
            }
            else
            {
                bSuc = true;
            }
            return bSuc;
        }
        public void PLCDisConnect()
        {
            if (bSuc)
            {
                Plc.Close();
            }
        }
        public void IPCDisConnect()
        {
            mfgSocketA.Stop();
        }
        public void ShowPLCConnectState(string errorinfo)
        {
            if (textBox1.InvokeRequired)
            {
                var d = new SafeCallDelegate(ShowPLCConnectState);
                textBox1.Invoke(d, new object[] { errorinfo });
            }
            else
            {
                if (bSuc)
                {
                    errorinfo = "已连接";
                    textBox1.Text = errorinfo;
                    textBox1.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    errorinfo = "未连接";
                    textBox1.Text = errorinfo;
                    textBox1.BackColor = System.Drawing.Color.Red;
                }
            }
        }
        public void ShowIPCConnectStateA(string errorinfo)
        {
            if (textBox4.InvokeRequired)
            {
                var d = new SafeCallDelegate(ShowIPCConnectStateA);
                textBox4.Invoke(d, new object[] { errorinfo });
            }
            else
            {
                if (bIPCSucA)
                {
                    errorinfo = "已连接";
                    textBox4.Text = errorinfo;
                    textBox4.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    errorinfo = "未连接";
                    textBox4.Text = errorinfo;
                    textBox4.BackColor = System.Drawing.Color.Red;
                }
            }
        }

        public void ShowIPCConnectStateB(string errorinfo)
        {
            if (textBox2.InvokeRequired)
            {
                var d = new SafeCallDelegate(ShowIPCConnectStateB);
                textBox2.Invoke(d, new object[] { errorinfo });
            }
            else
            {
                if (bIPCSucB)
                {
                    errorinfo = "已连接";
                    textBox2.Text = errorinfo;
                    textBox2.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    errorinfo = "未连接";
                    textBox2.Text = errorinfo;
                    textBox2.BackColor = System.Drawing.Color.Red;
                }
            }
        }
        #endregion
        #region 释放
        private void MainFrom_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult result = MessageBox.Show("请确认是否关闭软件！！！", "警告", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);

            if (result == DialogResult.Yes)
            {
                PLCDisConnect();
                IPCDisConnect();
                Application.ExitThread();
                Thread.Sleep(100);
                Environment.Exit(0);
            }
            else
            {
                e.Cancel = true;
            }
        }
        #endregion
        #region 日志
        public void RecordLog(string errorinfo)
        {
            string dayTime = DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss");
            string dayTimeData = DateTime.Now.ToString("yyyy-MM-dd");
            if (listBox_Log.InvokeRequired)
            {
                var d = new SafeCallDelegate(RecordLog);
                listBox_Log.Invoke(d, new object[] { errorinfo });
            }
            else
            {
                errorinfo = dayTime + "：" + errorinfo;
                if (listBox_Log.Items.Count > 200)
                {
                    listBox_Log.Items.Clear();
                }
                listBox_Log.Items.Add(errorinfo);
                listBox_Log.TopIndex = listBox_Log.Items.Count - 1;

                StreamWriter sw = new StreamWriter(logPath + "\\" + dayTimeData + "日志.txt", true);

                sw.WriteLine(errorinfo);
                sw.Flush();
                sw.Close();
            }
        }
        #endregion
        #region 数据处理及显示
        public void DataAnaliysis(byte[] buf)
        {
            PLCTemperatureData PLCDataT = new PLCTemperatureData();
            m_PLCDataT.preGlueTUp = Convert.ToInt32(buf[1]);//预粘合上板温度
            m_PLCDataT.preGlueTDome = Convert.ToInt32(buf[2]);//预粘合下板温度

            m_PLCDataT.A1BoardTUp = Convert.ToInt32(buf[5]);//A1上板温度
            m_PLCDataT.A1BoardTDomn = Convert.ToInt32(buf[6]);//A1下板温度
            m_PLCDataT.A1preHotT = Convert.ToInt32(buf[30]);//A1预热温度

            m_PLCDataT.A2BoardTUp = Convert.ToInt32(buf[7]);//A2上板温度
            m_PLCDataT.A2BoardTDomn = Convert.ToInt32(buf[8]);//A2下板温度
            m_PLCDataT.A2preHotT = Convert.ToInt32(buf[31]);//A2预热温度

            m_PLCDataT.A3BoardTUp = Convert.ToInt32(buf[9]);//A3上板温度
            m_PLCDataT.A3BoardTDomn = Convert.ToInt32(buf[10]);//A3下板温度
            m_PLCDataT.A3preHotT = Convert.ToInt32(buf[32]);//A3预热温度

            m_PLCDataT.A4BoardTUp = Convert.ToInt32(buf[11]);//A4上板温度
            m_PLCDataT.A4BoardTDomn = Convert.ToInt32(buf[12]);//A4下板温度
            m_PLCDataT.A4preHotT = Convert.ToInt32(buf[33]);//A4预热温度

            m_PLCDataT.A5BoardTUp = Convert.ToInt32(buf[13]);//A5上板温度
            m_PLCDataT.A5BoardTDomn = Convert.ToInt32(buf[14]);//A5下板温度
            m_PLCDataT.A5preHotT = Convert.ToInt32(buf[34]);//A5预热温度

            m_PLCDataT.A6BoardTUp = Convert.ToInt32(buf[15]);//A6上板温度
            m_PLCDataT.A6BoardTDomn = Convert.ToInt32(buf[16]);//A6下板温度
            m_PLCDataT.A6preHotT = Convert.ToInt32(buf[35]);//A6预热温度

            m_PLCDataT.B1BoardTUp = Convert.ToInt32(buf[17]);//B1上板温度
            m_PLCDataT.B1BoardTDomn = Convert.ToInt32(buf[18]);//B1下板温度
            m_PLCDataT.B1preHotT = Convert.ToInt32(buf[38]);//B1预热温度

            m_PLCDataT.B2BoardTUp = Convert.ToInt32(buf[19]);//B2上板温度
            m_PLCDataT.B2BoardTDomn = Convert.ToInt32(buf[20]);//B2下板温度
            m_PLCDataT.B2preHotT = Convert.ToInt32(buf[39]);//B2预热温度

            m_PLCDataT.B3BoardTUp = Convert.ToInt32(buf[21]);//B3上板温度
            m_PLCDataT.B3BoardTDomn = Convert.ToInt32(buf[22]);//B3下板温度
            m_PLCDataT.B3preHotT = Convert.ToInt32(buf[40]);//B3预热温度

            m_PLCDataT.B4BoardTUp = Convert.ToInt32(buf[23]);//B4上板温度
            m_PLCDataT.B4BoardTDomn = Convert.ToInt32(buf[24]);//B4下板温度
            m_PLCDataT.B4preHotT = Convert.ToInt32(buf[41]);//B4预热温度

            m_PLCDataT.B5BoardTUp = Convert.ToInt32(buf[25]);//B5上板温度
            m_PLCDataT.B5BoardTDomn = Convert.ToInt32(buf[26]);//B5下板温度
            m_PLCDataT.B5preHotT = Convert.ToInt32(buf[42]);//B5预热温度

            m_PLCDataT.B6BoardTUp = Convert.ToInt32(buf[27]);//B6上板温度
            m_PLCDataT.B6BoardTDomn = Convert.ToInt32(buf[28]);//B6下板温度
            m_PLCDataT.B6preHotT = Convert.ToInt32(buf[43]);//B6预热温度


            //
            PLCDataT.preGlueTUp = Convert.ToInt32(buf[1]);//预粘合上板温度
            PLCDataT.preGlueTDome = Convert.ToInt32(buf[2]);//预粘合下板温度

            PLCDataT.A1BoardTUp = Convert.ToInt32(buf[5]);//A1上板温度
            PLCDataT.A1BoardTDomn = Convert.ToInt32(buf[6]);//A1下板温度
            PLCDataT.A1preHotT = Convert.ToInt32(buf[30]);//A1预热温度

            PLCDataT.A2BoardTUp = Convert.ToInt32(buf[7]);//A2上板温度
            PLCDataT.A2BoardTDomn = Convert.ToInt32(buf[8]);//A2下板温度
            PLCDataT.A2preHotT = Convert.ToInt32(buf[31]);//A2预热温度

            PLCDataT.A3BoardTUp = Convert.ToInt32(buf[9]);//A3上板温度
            PLCDataT.A3BoardTDomn = Convert.ToInt32(buf[10]);//A3下板温度
            PLCDataT.A3preHotT = Convert.ToInt32(buf[32]);//A3预热温度

            PLCDataT.A4BoardTUp = Convert.ToInt32(buf[11]);//A4上板温度
            PLCDataT.A4BoardTDomn = Convert.ToInt32(buf[12]);//A4下板温度
            PLCDataT.A4preHotT = Convert.ToInt32(buf[33]);//A4预热温度

            PLCDataT.A5BoardTUp = Convert.ToInt32(buf[13]);//A5上板温度
            PLCDataT.A5BoardTDomn = Convert.ToInt32(buf[14]);//A5下板温度
            PLCDataT.A5preHotT = Convert.ToInt32(buf[34]);//A5预热温度

            PLCDataT.A6BoardTUp = Convert.ToInt32(buf[15]);//A6上板温度
            PLCDataT.A6BoardTDomn = Convert.ToInt32(buf[16]);//A6下板温度
            PLCDataT.A6preHotT = Convert.ToInt32(buf[35]);//A6预热温度

            PLCDataT.B1BoardTUp = Convert.ToInt32(buf[17]);//B1上板温度
            PLCDataT.B1BoardTDomn = Convert.ToInt32(buf[18]);//B1下板温度
            PLCDataT.B1preHotT = Convert.ToInt32(buf[38]);//B1预热温度

            PLCDataT.B2BoardTUp = Convert.ToInt32(buf[19]);//B2上板温度
            PLCDataT.B2BoardTDomn = Convert.ToInt32(buf[20]);//B2下板温度
            PLCDataT.B2preHotT = Convert.ToInt32(buf[39]);//B2预热温度

            PLCDataT.B3BoardTUp = Convert.ToInt32(buf[21]);//B3上板温度
            PLCDataT.B3BoardTDomn = Convert.ToInt32(buf[22]);//B3下板温度
            PLCDataT.B3preHotT = Convert.ToInt32(buf[40]);//B3预热温度

            PLCDataT.B4BoardTUp = Convert.ToInt32(buf[23]);//B4上板温度
            PLCDataT.B4BoardTDomn = Convert.ToInt32(buf[24]);//B4下板温度
            PLCDataT.B4preHotT = Convert.ToInt32(buf[41]);//B4预热温度

            PLCDataT.B5BoardTUp = Convert.ToInt32(buf[25]);//B5上板温度
            PLCDataT.B5BoardTDomn = Convert.ToInt32(buf[26]);//B5下板温度
            PLCDataT.B5preHotT = Convert.ToInt32(buf[42]);//B5预热温度

            PLCDataT.B6BoardTUp = Convert.ToInt32(buf[27]);//B6上板温度
            PLCDataT.B6BoardTDomn = Convert.ToInt32(buf[28]);//B6下板温度
            PLCDataT.B6preHotT = Convert.ToInt32(buf[43]);//B6预热温度
            //数据存储
            if (m_curData.Count < 720)
            {
                m_curData.Add(PLCDataT);
            }
            else
            {
                m_curData.RemoveAt(0);
                m_curData.Add(PLCDataT);
            }
        }
        public void AddSingle()
        {
            if (m_curType == ShowType.ShowA_Normal || m_curType == ShowType.ShowB_Normal)
            {
                if (chart1.Series.ElementAt(0).Points.Count >= 720)
                {
                    chart1.Series.ElementAt(0).Points.RemoveAt(0);
                    chart1.Series.ElementAt(1).Points.RemoveAt(0);
                    chart1.Series.ElementAt(2).Points.RemoveAt(0);

                    chart2.Series.ElementAt(0).Points.RemoveAt(0);
                    chart2.Series.ElementAt(1).Points.RemoveAt(0);
                    chart2.Series.ElementAt(2).Points.RemoveAt(0);

                    chart3.Series.ElementAt(0).Points.RemoveAt(0);
                    chart3.Series.ElementAt(1).Points.RemoveAt(0);
                    chart3.Series.ElementAt(2).Points.RemoveAt(0);

                    chart4.Series.ElementAt(0).Points.RemoveAt(0);
                    chart4.Series.ElementAt(1).Points.RemoveAt(0);
                    chart4.Series.ElementAt(2).Points.RemoveAt(0);

                    chart5.Series.ElementAt(0).Points.RemoveAt(0);
                    chart5.Series.ElementAt(1).Points.RemoveAt(0);
                    chart5.Series.ElementAt(2).Points.RemoveAt(0);

                    chart6.Series.ElementAt(0).Points.RemoveAt(0);
                    chart6.Series.ElementAt(1).Points.RemoveAt(0);
                    chart6.Series.ElementAt(2).Points.RemoveAt(0);

                    chart7.Series.ElementAt(0).Points.RemoveAt(0);
                    chart7.Series.ElementAt(1).Points.RemoveAt(0);
                }
                if (m_curType == ShowType.ShowA_Normal)
                {
                    chart1.Series.ElementAt(0).Points.Add(m_PLCDataT.A1BoardTUp);
                    chart1.Series.ElementAt(1).Points.Add(m_PLCDataT.A1BoardTDomn);
                    chart1.Series.ElementAt(2).Points.Add(m_PLCDataT.A1preHotT);

                    chart2.Series.ElementAt(0).Points.Add(m_PLCDataT.A2BoardTUp);
                    chart2.Series.ElementAt(1).Points.Add(m_PLCDataT.A2BoardTDomn);
                    chart2.Series.ElementAt(2).Points.Add(m_PLCDataT.A2preHotT);

                    chart3.Series.ElementAt(0).Points.Add(m_PLCDataT.A3BoardTUp);
                    chart3.Series.ElementAt(1).Points.Add(m_PLCDataT.A3BoardTDomn);
                    chart3.Series.ElementAt(2).Points.Add(m_PLCDataT.A3preHotT);

                    chart4.Series.ElementAt(0).Points.Add(m_PLCDataT.A4BoardTUp);
                    chart4.Series.ElementAt(1).Points.Add(m_PLCDataT.A4BoardTDomn);
                    chart4.Series.ElementAt(2).Points.Add(m_PLCDataT.A4preHotT);

                    chart5.Series.ElementAt(0).Points.Add(m_PLCDataT.A5BoardTUp);
                    chart5.Series.ElementAt(1).Points.Add(m_PLCDataT.A5BoardTDomn);
                    chart5.Series.ElementAt(2).Points.Add(m_PLCDataT.A5preHotT);

                    chart6.Series.ElementAt(0).Points.Add(m_PLCDataT.A6BoardTUp);
                    chart6.Series.ElementAt(1).Points.Add(m_PLCDataT.A6BoardTDomn);
                    chart6.Series.ElementAt(2).Points.Add(m_PLCDataT.A6preHotT);
                }
                else
                {
                    chart1.Series.ElementAt(0).Points.Add(m_PLCDataT.B1BoardTUp);
                    chart1.Series.ElementAt(1).Points.Add(m_PLCDataT.B1BoardTDomn);
                    chart1.Series.ElementAt(2).Points.Add(m_PLCDataT.B1preHotT);

                    chart2.Series.ElementAt(0).Points.Add(m_PLCDataT.B2BoardTUp);
                    chart2.Series.ElementAt(1).Points.Add(m_PLCDataT.B2BoardTDomn);
                    chart2.Series.ElementAt(2).Points.Add(m_PLCDataT.B2preHotT);

                    chart3.Series.ElementAt(0).Points.Add(m_PLCDataT.B3BoardTUp);
                    chart3.Series.ElementAt(1).Points.Add(m_PLCDataT.B3BoardTDomn);
                    chart3.Series.ElementAt(2).Points.Add(m_PLCDataT.B3preHotT);

                    chart4.Series.ElementAt(0).Points.Add(m_PLCDataT.B4BoardTUp);
                    chart4.Series.ElementAt(1).Points.Add(m_PLCDataT.B4BoardTDomn);
                    chart4.Series.ElementAt(2).Points.Add(m_PLCDataT.B4preHotT);

                    chart5.Series.ElementAt(0).Points.Add(m_PLCDataT.B5BoardTUp);
                    chart5.Series.ElementAt(1).Points.Add(m_PLCDataT.B5BoardTDomn);
                    chart5.Series.ElementAt(2).Points.Add(m_PLCDataT.B5preHotT);

                    chart6.Series.ElementAt(0).Points.Add(m_PLCDataT.B6BoardTUp);
                    chart6.Series.ElementAt(1).Points.Add(m_PLCDataT.B6BoardTDomn);
                    chart6.Series.ElementAt(2).Points.Add(m_PLCDataT.B6preHotT);
                }
                chart7.Series.ElementAt(0).Points.Add(m_PLCDataT.preGlueTUp);
                chart7.Series.ElementAt(1).Points.Add(m_PLCDataT.preGlueTDome);
            }
            else//查询模式
            {
                if (m_curType == ShowType.ShowA_Select )
                {

                }
                else
                {

                }
            }
        }
        public void AddList(ShowType mType)
        {
            chart1.Series.ElementAt(0).Points.Clear();
            chart1.Series.ElementAt(1).Points.Clear();
            chart1.Series.ElementAt(2).Points.Clear();

            chart2.Series.ElementAt(0).Points.Clear();
            chart2.Series.ElementAt(1).Points.Clear();
            chart2.Series.ElementAt(2).Points.Clear();

            chart3.Series.ElementAt(0).Points.Clear();
            chart3.Series.ElementAt(1).Points.Clear();
            chart3.Series.ElementAt(2).Points.Clear();

            chart4.Series.ElementAt(0).Points.Clear();
            chart4.Series.ElementAt(1).Points.Clear();
            chart4.Series.ElementAt(2).Points.Clear();

            chart4.Series.ElementAt(0).Points.Clear();
            chart4.Series.ElementAt(1).Points.Clear();
            chart4.Series.ElementAt(2).Points.Clear();

            chart5.Series.ElementAt(0).Points.Clear();
            chart5.Series.ElementAt(1).Points.Clear();
            chart5.Series.ElementAt(2).Points.Clear();

            chart6.Series.ElementAt(0).Points.Clear();
            chart6.Series.ElementAt(1).Points.Clear();
            chart6.Series.ElementAt(2).Points.Clear();
            if (mType == ShowType.ShowA_Normal)
            {
                for (int i = 0; i < m_curData.Count; i++)
                {
                    chart1.Series.ElementAt(0).Points.Add(m_curData[i].A1BoardTUp);
                    chart1.Series.ElementAt(1).Points.Add(m_curData[i].A1BoardTDomn);
                    chart1.Series.ElementAt(2).Points.Add(m_curData[i].A1preHotT);

                    chart2.Series.ElementAt(0).Points.Add(m_curData[i].A2BoardTUp);
                    chart2.Series.ElementAt(1).Points.Add(m_curData[i].A2BoardTDomn);
                    chart2.Series.ElementAt(2).Points.Add(m_curData[i].A2preHotT);

                    chart3.Series.ElementAt(0).Points.Add(m_curData[i].A3BoardTUp);
                    chart3.Series.ElementAt(1).Points.Add(m_curData[i].A3BoardTDomn);
                    chart3.Series.ElementAt(2).Points.Add(m_curData[i].A3preHotT);

                    chart4.Series.ElementAt(0).Points.Add(m_curData[i].A4BoardTUp);
                    chart4.Series.ElementAt(1).Points.Add(m_curData[i].A4BoardTDomn);
                    chart4.Series.ElementAt(2).Points.Add(m_curData[i].A4preHotT);

                    chart5.Series.ElementAt(0).Points.Add(m_curData[i].A5BoardTUp);
                    chart5.Series.ElementAt(1).Points.Add(m_curData[i].A5BoardTDomn);
                    chart5.Series.ElementAt(2).Points.Add(m_curData[i].A5preHotT);

                    chart6.Series.ElementAt(0).Points.Add(m_curData[i].A6BoardTUp);
                    chart6.Series.ElementAt(1).Points.Add(m_curData[i].A6BoardTDomn);
                    chart6.Series.ElementAt(2).Points.Add(m_curData[i].A6preHotT);
                }
            }
            else if (mType == ShowType.ShowB_Normal)
            {
                for (int i = 0; i < m_curData.Count; i++)
                {
                    chart1.Series.ElementAt(0).Points.Add(m_curData[i].B1BoardTUp);
                    chart1.Series.ElementAt(1).Points.Add(m_curData[i].B1BoardTDomn);
                    chart1.Series.ElementAt(2).Points.Add(m_curData[i].B1preHotT);

                    chart2.Series.ElementAt(0).Points.Add(m_curData[i].B2BoardTUp);
                    chart2.Series.ElementAt(1).Points.Add(m_curData[i].B2BoardTDomn);
                    chart2.Series.ElementAt(2).Points.Add(m_curData[i].B2preHotT);

                    chart3.Series.ElementAt(0).Points.Add(m_curData[i].B3BoardTUp);
                    chart3.Series.ElementAt(1).Points.Add(m_curData[i].B3BoardTDomn);
                    chart3.Series.ElementAt(2).Points.Add(m_curData[i].B3preHotT);

                    chart4.Series.ElementAt(0).Points.Add(m_curData[i].B4BoardTUp);
                    chart4.Series.ElementAt(1).Points.Add(m_curData[i].B4BoardTDomn);
                    chart4.Series.ElementAt(2).Points.Add(m_curData[i].B4preHotT);

                    chart5.Series.ElementAt(0).Points.Add(m_curData[i].B5BoardTUp);
                    chart5.Series.ElementAt(1).Points.Add(m_curData[i].B5BoardTDomn);
                    chart5.Series.ElementAt(2).Points.Add(m_curData[i].B5preHotT);

                    chart6.Series.ElementAt(0).Points.Add(m_curData[i].B6BoardTUp);
                    chart6.Series.ElementAt(1).Points.Add(m_curData[i].B6BoardTDomn);
                    chart6.Series.ElementAt(2).Points.Add(m_curData[i].B6preHotT);
                }
            }
            else if(mType == ShowType.ShowA_Select)
            {

            }
            else
            {

            }
        }
        #endregion
        #region 保存CSV
        public bool saveFileByCSV(byte[] buf)
        {
            string dayTime = DateTime.Now.ToString("yyyy-MM-dd");
            try
            {
                if (dayTime == dateFlag)//日期没变
                {

                }
                else
                {
                    InitCSV(fullPath + "\\" + dayTime + "温度.csv");
                    dateFlag = dayTime;
                }

                StreamWriter sw = new StreamWriter(fullPath + "\\" + dayTime + "温度.csv", true);
                time = DateTime.Now.ToString("yyyy-MM-dd") + " " +DateTime.Now.ToLongTimeString(); //具体时间，精确到秒
                string temp = time;


                temp = temp + "," + Convert.ToString(buf[1]) + "," + Convert.ToString(buf[2]) ;
                temp = temp + "," + Convert.ToString(buf[5]) + "," + Convert.ToString(buf[6]) + "," + Convert.ToString(buf[30]);//A工位
                temp = temp + "," + Convert.ToString(buf[7]) + "," + Convert.ToString(buf[8]) + "," + Convert.ToString(buf[31]);
                temp = temp + "," + Convert.ToString(buf[9]) + "," + Convert.ToString(buf[10]) + "," + Convert.ToString(buf[32]);
                temp = temp + "," + Convert.ToString(buf[11]) + "," + Convert.ToString(buf[12]) + "," + Convert.ToString(buf[33]);
                temp = temp + "," + Convert.ToString(buf[13]) + "," + Convert.ToString(buf[14]) + "," + Convert.ToString(buf[34]) ;
                temp = temp + "," + Convert.ToString(buf[15]) + "," + Convert.ToString(buf[16]) + "," + Convert.ToString(buf[35]) ;
                temp = temp + "," + Convert.ToString(buf[17]) + "," + Convert.ToString(buf[18]) + "," + Convert.ToString(buf[38]) ;//B工位
                temp = temp + "," + Convert.ToString(buf[19]) + "," + Convert.ToString(buf[20]) + "," + Convert.ToString(buf[39]);
                temp = temp + "," + Convert.ToString(buf[21]) + "," + Convert.ToString(buf[22]) + "," + Convert.ToString(buf[40]) ;
                temp = temp + "," + Convert.ToString(buf[23]) + "," + Convert.ToString(buf[24]) + "," + Convert.ToString(buf[41]) ;
                temp = temp + "," + Convert.ToString(buf[25]) + "," + Convert.ToString(buf[26]) + "," + Convert.ToString(buf[42]) ;
                temp = temp + "," + Convert.ToString(buf[27]) + "," + Convert.ToString(buf[28]) + "," + Convert.ToString(buf[43]) ;
                
                sw.WriteLine(temp);
                sw.Flush();
                sw.Close();
                return true;
            }
            catch { return false;}
        }

        //初始化csv文件，每个温度对应的工位信息
        private void InitCSV(string fullPath)
        {
            string temp = "时间,"+"预粘合上板温度,"+" 预粘合下板温度,";//3，4，29，36，37为空
            string te = "板温度,";
            for(int i=1;i<=36;i++)
            {
                if(i<=18)//A工位
                {
                    if(i%3==1)//上板
                    {
                        temp = temp +"A" + Convert.ToString((i/3)+1) +"上板温度,";
                    }
                    else if(i%3==2)//下板
                    {
                        temp = temp + "A" + Convert.ToString((i / 3) + 1) + "下板温度,";
                    }
                    else//预热
                    {
                        temp = temp + "A" + Convert.ToString((i / 3) ) + "预热温度,";
                    }
                }
                else//B工位
                {
                    if (i % 3 == 1)//上板
                    {
                        temp = temp + "B" + Convert.ToString((i / 3) -5) + "上板温度,";
                    }
                    else if (i % 3 == 2)//下板
                    {
                        temp = temp + "B" + Convert.ToString((i / 3) -5) + "下板温度,";
                    }
                    else//预热
                    {
                        temp = temp + "B" + Convert.ToString((i / 3)-6) + "预热温度,";
                    }
                }
            }
            StreamWriter sw = new StreamWriter(fullPath, true, System.Text.Encoding.UTF8);
            sw.WriteLine(temp);
            sw.Flush();
            sw.Close();
        }
        #endregion
        #region chart初始化
        public void ChartInit()
        {

        }
        #endregion
        #region 切换面按钮
        private void ShowAButton_Click(object sender, EventArgs e)
        {
            m_curType = ShowType.ShowA_Normal;
            ShowBButton.Enabled = true;
            ShowAButton.Enabled = false;
            chart1.Titles.Clear();
            chart2.Titles.Clear();
            chart3.Titles.Clear();
            chart4.Titles.Clear();
            chart5.Titles.Clear();
            chart6.Titles.Clear();
            chart1.Titles.Add("A1");
            chart2.Titles.Add("A2");
            chart3.Titles.Add("A3");
            chart4.Titles.Add("A4");
            chart5.Titles.Add("A5");
            chart6.Titles.Add("A6");
            chart1.Titles[0].TextStyle = System.Windows.Forms.DataVisualization.Charting.TextStyle.Frame;
            chart2.Titles[0].TextStyle = System.Windows.Forms.DataVisualization.Charting.TextStyle.Frame;
            chart3.Titles[0].TextStyle = System.Windows.Forms.DataVisualization.Charting.TextStyle.Frame;
            chart4.Titles[0].TextStyle = System.Windows.Forms.DataVisualization.Charting.TextStyle.Frame;
            chart5.Titles[0].TextStyle = System.Windows.Forms.DataVisualization.Charting.TextStyle.Frame;
            chart6.Titles[0].TextStyle = System.Windows.Forms.DataVisualization.Charting.TextStyle.Frame;
            AddList(m_curType);
        }

        private void ShowBButton_Click(object sender, EventArgs e)
        {
            m_curType = ShowType.ShowB_Normal;
            ShowBButton.Enabled = false;
            ShowAButton.Enabled = true;
            chart1.Titles.Clear();
            chart2.Titles.Clear();
            chart3.Titles.Clear();
            chart4.Titles.Clear();
            chart5.Titles.Clear();
            chart6.Titles.Clear();
            chart1.Titles.Add("B1");
            chart2.Titles.Add("B2");
            chart3.Titles.Add("B3");
            chart4.Titles.Add("B4");
            chart5.Titles.Add("B5");
            chart6.Titles.Add("B6");
            chart1.Titles[0].TextStyle = System.Windows.Forms.DataVisualization.Charting.TextStyle.Frame;
            chart2.Titles[0].TextStyle = System.Windows.Forms.DataVisualization.Charting.TextStyle.Frame;
            chart3.Titles[0].TextStyle = System.Windows.Forms.DataVisualization.Charting.TextStyle.Frame;
            chart4.Titles[0].TextStyle = System.Windows.Forms.DataVisualization.Charting.TextStyle.Frame;
            chart5.Titles[0].TextStyle = System.Windows.Forms.DataVisualization.Charting.TextStyle.Frame;
            chart6.Titles[0].TextStyle = System.Windows.Forms.DataVisualization.Charting.TextStyle.Frame;
            AddList(m_curType);
        }
        #endregion
        #region 写错误代码
        public bool WriteErrorcode(int nDevice,int nType,string nInfo)
        {
            bool ret = false;
            byte[] bytes = null;
            string name = "";

            if (nDevice == 1 && nType == 1)
                name = "CCD报警代码A";
            else if (nDevice == 2 && nType == 1)
                name = "CCD报警代码B";
            else if (nDevice == 1 && nType == 2 && nInfo == "1")
            {
                name = "ST_上料Keep.INTCommon[61]";
            }
            else if (nDevice == 1 && nType == 2 && nInfo == "2")
            {
                name = "ST_上料Keep.INTCommon[62]";
            }
            else if (nDevice == 1 && nType == 2 && nInfo == "3")
            {
                name = "ST_上料Keep.INTCommon[63]";
            }
            else if (nDevice == 1 && nType == 2 && nInfo == "4")
            {
                name = "ST_上料Keep.INTCommon[64]";
            }
            else if (nDevice == 1 && nType == 3)
            {
                name = "ST_上料Keep.INTCommon[60]";
            }
            else
                return false;
            try
            {
                bytes = BitConverter.GetBytes((short)Single.Parse(nInfo));
                ret = Plc.PLCWriteBlock(name, 4, bytes);
            }
            catch (Exception ex)
            {
                ret = false;
            }
            return ret;
        }
        #endregion
        #region 测试错误代码
        private void button1_Click_1(object sender, EventArgs e)
        {
            string detail = "";
            detail = textBox3.Text;

            bool ret = WriteErrorcode(comboBox1.SelectedIndex+1,1, detail);
            if (ret)
                MessageBox.Show("写入成功");
            else
                MessageBox.Show("写入失败");
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            string name = "";
            int dataCount = 10;
            byte[] buf = new byte[dataCount];
            if(comboBox1.SelectedIndex == 0)
                name = "CCD报警代码A";
            else
                name = "CCD报警代码B";
            bool ret = Plc.PLCReadBlock(name, dataCount, ref buf);
            if (ret)
            {
                string detail = buf[0].ToString();
                MessageBox.Show("读取内容:" + detail);
            }
            else
                MessageBox.Show("读取异常");
        }
        #endregion
        #region 换卷通讯测试
        private void button3_Click(object sender, EventArgs e)
        {
            bool ret = WriteErrorcode(1, 2, (comboBox1.SelectedIndex + 1).ToString());
            if (ret)
                MessageBox.Show("写入成功");
            else
                MessageBox.Show("写入失败");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string name = "";
            int dataCount = 10;
            byte[] buf = new byte[dataCount];
            switch (comboBox1.SelectedIndex)
            {
                case 0:
                    name = "ST_上料Keep.INTCommon[61]";
                    break;
                case 1:
                    name = "ST_上料Keep.INTCommon[62]";
                    break;
                case 2:
                    name = "ST_上料Keep.INTCommon[63]";
                    break;
                case 3:
                    name = "ST_上料Keep.INTCommon[64]";
                    break;
            }
            bool ret = Plc.PLCReadBlock(name, dataCount, ref buf);
            if (ret)
            {
                string detail = buf[0].ToString();
                MessageBox.Show("读取内容:" + detail);
            }
            else
                MessageBox.Show("读取异常");
        }
        #endregion

        private void button5_Click(object sender, EventArgs e)
        {
            bool ret = WriteErrorcode(1, 3, "1");
            if (ret)
                MessageBox.Show("写入成功");
            else
                MessageBox.Show("写入失败");
        }

        private void button7_Click(object sender, EventArgs e)
        {
            bool ret = WriteErrorcode(1, 3, "0");
            if (ret)
                MessageBox.Show("写入成功");
            else
                MessageBox.Show("写入失败");
        }
        private void button6_Click(object sender, EventArgs e)
        {
            string name = "ST_上料Keep.INTCommon[60]";
            int dataCount = 10;
            byte[] buf = new byte[dataCount];

            bool ret = Plc.PLCReadBlock(name, dataCount, ref buf);
            if (ret)
            {
                string detail = buf[0].ToString();
                MessageBox.Show("读取内容:" + detail);
            }
            else
                MessageBox.Show("读取异常");
        }

        private void button8_Click(object sender, EventArgs e)
        {
            //TestForm test = new TestForm(this);
            //test.ShowDialog();

        }
    }
}
