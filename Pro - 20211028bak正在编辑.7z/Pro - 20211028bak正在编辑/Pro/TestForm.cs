﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ProModel;
using ProBLL;
using Apriso.MIPlugins.Communication.Clients.WcfServiceAPI;

namespace Pro
{
    public partial class TestForm : Form
    {
        public TestForm()
        {
            InitializeComponent();
        }

        private void TestForm_Load(object sender, System.EventArgs e)
        {
            if (DevManage.Instance().userMgn.perCurrent.rightBarItem.Keys.Contains(this.Name))
            {
                if (DevManage.Instance().userMgn.perCurrent.rightBarItem[this.Name] != Em_Right.Write)
                {
                    DevManage.Instance().ControlEnable(false, this.Controls);
                }
                else
                {
                    DevManage.Instance().ControlEnable(true, this.Controls);
                }
            }
            com_Mes.Items.AddRange(Enum.GetNames(typeof(Em_MES)));
            com_Mes.SelectedIndex = 0;
        }

        private void com_Mes_SelectedIndexChanged(object sender, System.EventArgs e)
        {
            txt_send.Text = Common.ToJSON(MseManager.Instance().GetMessageRequest((Em_MES)com_Mes.SelectedIndex, ""));
        }

        private void button1_Click(object sender, System.EventArgs e)
        {
            if (MseManager.Instance().isConnect || true)
            {
                MessageResponse rs=MseManager.Instance().client.SendMessage(Common.FormJson<MessageRequest>( txt_send.Text));
                txt_receive.Text = Common.ToJSON(rs);
            }
            else
            {
                MseManager.Instance().Reconnect();
            }
        }

    }
}
