﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pro
{
    public partial class CloseForm : Form
    {
        public CloseForm()
        {
            InitializeComponent();
            
            
        }

        private void CloseForm_Load(object sender, EventArgs e)
        {
            if(MessageBox.Show("是否退出程序？","",MessageBoxButtons.YesNo,MessageBoxIcon.Question)==DialogResult.Yes)
            {
                Environment.Exit(0);
            }
        }

        private void CloseForm_MouseUp(object sender, MouseEventArgs e)
        {
            //if (MessageBox.Show("是否退出程序？", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            //{
            //    Environment.Exit(0);
            //}
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("是否退出程序？", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Environment.Exit(0);
            }
        }
    }
}
