﻿namespace Pro
{
    partial class RoleMgeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.GroupGrid = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.角色 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.操作 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.创建时间 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.创建人 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.更新时间 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.更新人 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.GroupGrid)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // GroupGrid
            // 
            this.GroupGrid.BackgroundColor = System.Drawing.Color.White;
            this.GroupGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GroupGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.角色,
            this.操作,
            this.创建时间,
            this.创建人,
            this.更新时间,
            this.更新人});
            this.GroupGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.GroupGrid.Location = new System.Drawing.Point(0, 0);
            this.GroupGrid.Name = "GroupGrid";
            this.GroupGrid.RowTemplate.Height = 27;
            this.GroupGrid.Size = new System.Drawing.Size(964, 539);
            this.GroupGrid.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.GroupGrid);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(964, 539);
            this.panel1.TabIndex = 1;
            // 
            // 角色
            // 
            this.角色.HeaderText = "角色";
            this.角色.Name = "角色";
            this.角色.ReadOnly = true;
            this.角色.Width = 150;
            // 
            // 操作
            // 
            this.操作.HeaderText = "操作";
            this.操作.Name = "操作";
            this.操作.Width = 500;
            // 
            // 创建时间
            // 
            this.创建时间.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.创建时间.HeaderText = "创建时间";
            this.创建时间.Name = "创建时间";
            this.创建时间.ReadOnly = true;
            this.创建时间.Width = 96;
            // 
            // 创建人
            // 
            this.创建人.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.创建人.HeaderText = "创建人";
            this.创建人.Name = "创建人";
            this.创建人.ReadOnly = true;
            this.创建人.Width = 81;
            // 
            // 更新时间
            // 
            this.更新时间.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.更新时间.HeaderText = "更新时间";
            this.更新时间.Name = "更新时间";
            this.更新时间.ReadOnly = true;
            this.更新时间.Width = 96;
            // 
            // 更新人
            // 
            this.更新人.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.更新人.HeaderText = "更新人";
            this.更新人.Name = "更新人";
            this.更新人.ReadOnly = true;
            this.更新人.Width = 81;
            // 
            // RoleMgeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(964, 539);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "RoleMgeForm";
            this.Text = "RoleMgeForm";
            this.Load += new System.EventHandler(this.RoleMgeForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.GroupGrid)).EndInit();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView GroupGrid;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridViewTextBoxColumn 角色;
        private System.Windows.Forms.DataGridViewLinkColumn 操作;
        private System.Windows.Forms.DataGridViewTextBoxColumn 创建时间;
        private System.Windows.Forms.DataGridViewTextBoxColumn 创建人;
        private System.Windows.Forms.DataGridViewTextBoxColumn 更新时间;
        private System.Windows.Forms.DataGridViewTextBoxColumn 更新人;
    }
}