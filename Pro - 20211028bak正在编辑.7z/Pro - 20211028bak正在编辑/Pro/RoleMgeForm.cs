﻿using ProModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pro
{
    public partial class RoleMgeForm : Form
    {

        List<LinkLabel> viewLinkLst = new List<LinkLabel>();
        List<LinkLabel> editLinkLst = new List<LinkLabel>();
        List<LinkLabel> delLinkLst = new List<LinkLabel>();
        int rowNum = 0;
        int gridInitCtlNum = 0;
        int linkColumnIndex = 1;
        List<Roles> allRoles = null;
        public RoleMgeForm()
        {
            InitializeComponent();
            allRoles = DevManage.Instance().userMgn.AllRoles;

        }

        private void RoleMgeForm_Load(object sender, EventArgs e)
        {

            if (DevManage.Instance().userMgn.perCurrent.rightBarItem.Keys.Contains(this.Name))
            {
                if (DevManage.Instance().userMgn.perCurrent.rightBarItem[this.Name]!= Em_Right.Write)
                {
                    DevManage.Instance().ControlEnable(false, this.Controls);
                }
                else
                {
                    DevManage.Instance().ControlEnable(true, this.Controls);
                }
            }
            //List<Roles> 
            rowNum = allRoles.Count;
            for (int i=0;i<rowNum;i++)
            {
                AddRow(allRoles[i], i);
            }
        }

        public void AddRow(Roles role,int row)
        {
            GroupGrid.Rows.Add(new object[] { role.remark, null, role.createOper, role.createOper, role.updateTime, role.updateOper });
            AddControl(row);
        }
        private void AddControl(int row)
        {
            LinkLabel viewLink = new LinkLabel();
            viewLink.BackColor = System.Drawing.Color.Transparent;
            viewLink.Text = "查看";
            LinkLabel editLink = new LinkLabel();
            editLink.BackColor = System.Drawing.Color.Transparent;
            editLink.Text = "修改权限";
            //LinkLabel delLink = new LinkLabel();
            //delLink.BackColor = System.Drawing.Color.Transparent;
            //delLink.Text = "删除角色";

            GroupGrid.Controls.Add(viewLink);
            GroupGrid.Controls.Add(editLink);
            //GroupGrid.Controls.Add(delLink);
            //获取大小
            Rectangle rect = GroupGrid.GetCellDisplayRectangle(linkColumnIndex, row, true);
            //大小设置
            viewLink.Size = new Size((rect.Width / 3), rect.Height);
            editLink.Size = new Size((rect.Width / 3), rect.Height);
            //delLink.Size = new Size((rect.Width / 3), rect.Height);
            //位置设置
            viewLink.Location = new Point(rect.Left, rect.Top);
            editLink.Location = new Point(rect.Left+viewLink.Width, rect.Top);
            //delLink.Location = new Point(rect.Left+viewLink.Width+editLink.Width, rect.Top);
            //绑定事件
            viewLink.LinkClicked += new LinkLabelLinkClickedEventHandler(this.View_LinkClicked);
            editLink.LinkClicked += new LinkLabelLinkClickedEventHandler(this.Edit_LinkClicked);
            //delLink.LinkClicked += new LinkLabelLinkClickedEventHandler(this.Del_LinkClicked);

            viewLink.Tag = row;
            editLink.Tag = row;
            //delLink.Tag = row;

            viewLinkLst.Add(viewLink);
            viewLinkLst.Add(editLink);
            //viewLinkLst.Add(delLink);

        }
        private void View_LinkClicked(object sender,LinkLabelLinkClickedEventArgs e)
        {
            int curRow = Convert.ToInt32(((LinkLabel)sender).Tag);
            RoleForm roleForm = new RoleForm("查看权限", allRoles[curRow].name);
            roleForm.ShowDialog();
        }
        private void Edit_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            int curRow = Convert.ToInt32(((LinkLabel)sender).Tag);
            RoleForm roleForm = new RoleForm("修改权限", allRoles[curRow].name);
            roleForm.ShowDialog();
        }
        private void Del_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }






    }
}
