﻿using ProDAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProModel;

namespace ProBLL
{
    public class FileSave
    {
        public static void WriteLog(string log, string dir = "./log")
        {
            string filename = DateTime.Now.ToString("yyyy-MM-dd ") + "log.txt";
            LogHelper.writeLogByFileName(log, filename, dir);
        }
        public static void WriteExceptionLog(string strLog,string dir= "D:\\Exception",string fileName="")
        {
            string filename = "Exception" + DateTime.Now.ToString("yyyy-MM-dd") + ".txt";
            if (!string.IsNullOrEmpty(fileName))
                filename = fileName;
            LogHelper.writeLogByName(strLog + Environment.NewLine,dir , filename);
        }
        public static void Write(string strTemp, string path, string fileName)
        {
            LogHelper.writeLogByName(strTemp, path, fileName);
        }

    }
}
