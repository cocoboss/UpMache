﻿using ProModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using ProDAL;
using ProModel;

namespace ProBLL
{
    public class SystemParam
    {
        public string EquipmentCode;
        public string Software;
        public string mesDely;
        public string lineCode;
        public string logoutTime;
        public string mesMainIp;
        public string plcIp;
        public string mesBakIp;
        public string ftpIp;
        public string ftpName;
        public string ftpPwd;
        public bool isLogoutTimer;
        public bool isUploadAlarm;
        public Dictionary<string, string> sysParam = new Dictionary<string, string>();
        public Dictionary<int, EquipmentStatusID> epStatus = new Dictionary<int, EquipmentStatusID>();
        public Dictionary<string, ParamInit> paramInit = new Dictionary<string, ParamInit>();
        public Dictionary<string, AlarmConfig> alarmConfigLists = new Dictionary<string, AlarmConfig>();

        public SystemParam()
        {
            load();
            SetValue();
            SetEquipmentStatus();
            GetParamInit();
        }

        public void load()
        {
            sysParam.Clear();
            DefineVariableAccess da = new DefineVariableAccess();
            List<DefineVariable> items = da.SelectAll();
            foreach(var item in items)
            {
                sysParam.Add(item.sysKey, item.sysVal);
            }
            for(int i=0;i< (int)Em_DefineVariable.count;i++)
            {
                string temp = ((Em_DefineVariable)i).ToString();
                if (!sysParam.Keys.Contains(temp))
                {
                    if (da.Add(temp)<=0)
                    {
                        FileSave.WriteExceptionLog($"用户自定义表插入失败，检查是否已经包含{temp}或者数据库连接失败");
                    }
                    sysParam.Add(temp, "");
                }
            }
        }
        public void SetValue()
        {
            EquipmentCode = sysParam["EquipmentCode"];
            plcIp = sysParam["plcIp"];
            Software = sysParam["Software"];
            mesDely = sysParam["mesDely"];
            lineCode = sysParam["lineCode"];
            logoutTime = sysParam["logoutTime"];
            mesMainIp = sysParam["mesMainIp"];
            mesBakIp = sysParam["mesBakIp"];
            ftpIp = sysParam["ftpIp"];
            ftpName = sysParam["ftpName"];
            ftpPwd = sysParam["ftpPwd"];
            isLogoutTimer = (string.IsNullOrEmpty(sysParam["isLogoutTimer"]) || sysParam["isLogoutTimer"].Contains("0")) ? false : true;
            isUploadAlarm = (string.IsNullOrEmpty(sysParam["isUploadAlarm"]) || sysParam["isUploadAlarm"].Contains("0")) ? false : true;
        }

        public void SetEquipmentStatus()
        {
            epStatus.Clear();
            epStatus.Add(1, new EquipmentStatusID() { id = 1, statusID = "100-000", description = "Power Off(整机断电)" });
            epStatus.Add(2, new EquipmentStatusID() { id = 2, statusID = "100-001", description = "Control Off(设备断开控制电)" });
            epStatus.Add(3, new EquipmentStatusID() { id = 3, statusID = "200-001", description = "Manual_Debug(工程师调试模式)" });
            epStatus.Add(4, new EquipmentStatusID() { id = 4, statusID = "200-002", description = "Manual_Product(手动模式)" });
            epStatus.Add(5, new EquipmentStatusID() { id = 5, statusID = "200-003", description = "Auto-Ready(预备跑料)" });
            epStatus.Add(6, new EquipmentStatusID() { id = 6, statusID = "300-001", description = "Auto-Running(正常生产)" });
            epStatus.Add(7, new EquipmentStatusID() { id = 7, statusID = "300-002", description = "Auto-Running(调试生产)" });
            epStatus.Add(8, new EquipmentStatusID() { id = 8, statusID = "300-003", description = "Auto-Idel(设备等料)" });
            epStatus.Add(9, new EquipmentStatusID() { id = 9, statusID = "900-001", description = "Auto-Alarm_level1(严重报警)" });
            epStatus.Add(10, new EquipmentStatusID() { id = 10, statusID = "900-002", description = "Auto-Alarm_level2(轻微报警)" });
        }

        public void GetAlarmList()
        {
            alarmConfigLists.Clear();
            AlarmConfigAccess ac = new AlarmConfigAccess();
            List<AlarmConfig> lst = ac.SelectAll();
            if(lst!=null)
            {
                foreach(var item in lst)
                {
                    alarmConfigLists.Add(item.alarmCode, item);
                }
            }
        }

        public void GetParamInit()
        {
            paramInit.Clear();
            ParamInitAccess pa = new ParamInitAccess();
            List<ParamInit> lst= pa.SelectAll();
            if (lst!=null)
            {
                foreach (var item in lst)
                {
                    if (item.isable > 0)
                    {
                        sysParam[Em_DefineVariable.ProcessCode.ToString()] = item.processCode;
                    }
                    paramInit.Add(item.processCode, item);
                }
            }
        }
        public void SaveParamInit(ParamInit param=null)
        {
            
            ParamInitAccess pa = new ParamInitAccess();
            if (param != null)
            {
                if (paramInit.Keys.Contains(param.processCode))
                {
                    paramInit[param.processCode].json = param.json;
                    paramInit[param.processCode].remark = param.remark;
                    paramInit[param.processCode].employe = param.employe;
                    paramInit[param.processCode].isable = param.isable;
                    paramInit[param.processCode].entime = param.entime;
                }else
                {
                    paramInit.Add(param.processCode, param);
                    if (pa.Add(param) < 0)
                    {
                        FileSave.WriteExceptionLog($"参数下发工艺路线{param.processCode}加入失败");
                    }
                }
            }
            if (paramInit.Count == 0)
                return;
            foreach (var item in paramInit)
            {
                if (param.isable == 1)
                {
                    if (item.Key != param.processCode)
                    {
                        item.Value.isable = 0;

                        if (pa.Update(item.Value) < 0)
                        {
                            FileSave.WriteExceptionLog($"参数下发工艺路线{item.Key}更新失败");
                        }
                    }
                    else
                    {
                        if (pa.Update(param) < 0)
                        {
                            FileSave.WriteExceptionLog($"参数下发工艺路线{item.Key}更新失败");
                        }
                    }
                }
                    if (pa.Update(param) < 0)
                    {
                        FileSave.WriteExceptionLog($"参数下发工艺路线{item.Key}更新失败");
                    }
            }
        }


        public void Save()
        {

            sysParam["EquipmentCode"] = EquipmentCode;
            sysParam["plcIp"] = plcIp;
            sysParam["Software"] = Software;
            sysParam["mesDely"] = mesDely;
            sysParam["lineCode"] = lineCode;
            sysParam["logoutTime"] = logoutTime;
            sysParam["mesMainIp"] = mesMainIp;
            sysParam["mesBakIp"] = mesBakIp;
            sysParam["ftpIp"] = ftpIp;
            sysParam["ftpName"] = ftpName;
            sysParam["ftpPwd"] = ftpPwd;
            sysParam["isLogoutTimer"] = isLogoutTimer?"1":"0";
            sysParam["isUploadAlarm"] = isUploadAlarm?"1":"0";

            DefineVariableAccess da = new DefineVariableAccess();

            foreach(var item in sysParam)
            {
                if(da.Update(item.Key, item.Value)<0)
                {
                    FileSave.WriteExceptionLog($"用户自定义表插入失败，检查是否已经包含{item.Key}或者数据库连接失败");
                }
            }

        }
       

    }
}
