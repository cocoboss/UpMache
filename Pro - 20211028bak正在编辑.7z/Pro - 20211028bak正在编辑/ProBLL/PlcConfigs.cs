﻿using ProDAL;
using ProModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ProBLL
{
    public class PlcConfigs
    {
        public List<AddrGroups> addrGroupLst = new List<AddrGroups>();
        public Dictionary<string, AddrGroups> dirGroup = new Dictionary<string, AddrGroups>();
        public Dictionary<string, DataUint> dirDataUint = new Dictionary<string, DataUint>();
        public Thread ScanPlcThread = null;
        public PLCBase plc = null;
        public SystemParam sysParam;
        public PlcConfigs(PLCBase plcTemp,SystemParam param)
        {
            sysParam = param;
            plc = plcTemp;
            //string fins = "172.16.77.100:9600:192.168.3.40:9601:101";
            //string fins = "192.168.3.10:9600:192.168.3.40:9601:101";
            plc.Open(sysParam.plcIp, null);
            //plc.Open(fins, null);
            Load();
            //ScanPlcThread = new Thread(new ThreadStart(ScanPlcThreadEntry));
            //ScanPlcThread.Start();
        }
        private void ScanPlcThreadEntry()
        {
            string fileName = DateTime.Now.ToString("yyyy/MM/dd") + "data.csv";
            DataUint units = new DataUint();
            units.Name = "";
            units.vairsName = "数据上传";
            units.unitNum = 2;
            while (true)
            {
                if (plc.ReadUint(ref units))
                {
                    if(units.Data!=units.OldData)
                    {
                        units.OldData = units.Data;
                        if(units.Data=="1")
                        {
                            
                            try
                            {
                                for (int i = 0; i < addrGroupLst[0].unitLst.Count; i++)
                                {
                                    DataUint unit = addrGroupLst[0].unitLst[i];
                                    if (ReadUnit(ref unit))
                                    {
                                        FileSave.Write(unit.Name + ":" + unit.Data, "D:\\testLog", fileName);
                                    }
                                }
                            }
                            catch (Exception ex)
                            {
                                FileSave.WriteExceptionLog(ex.Message);
                            }
                            units.Data = "0";
                            plc.WirteUint(ref units);
                        }

                    }

                }
            }
        }
        public void Load()
        {
            
            PlcGroupConfigAccess pga = new PlcGroupConfigAccess();
            List<PlcGroupConfig> groups = pga.SelectAll();
            PlcConfigAccess pa = new PlcConfigAccess();
            List<PlcConfig> units = pa.SelectAll();
            for (int i=0;i< groups.Count;i++)
            {
                AddrGroups ag = new AddrGroups();
                ag.startAddr = groups[i].startAddr;
                ag.name = groups[i].name;
                ag.leng = groups[i].leng;
                ag.remark = groups[i].remark;
                ag.isRemark = groups[i].isRemark==0?false:true;
                
                for (int j=0;j< units.Count;j++)
                {
                    if (groups[i].groupId==units[j].parentId)
                    {
                        DataUint du = new DataUint();
                        du.Name = units[j].name;
                        du.Addr = int.Parse(string.IsNullOrEmpty(units[j].address)?"0": units[j].address.Substring(1));
                        du.Data = "";           // units[j].data;
                        du.OldData = "";        // units[j].oldData;
                        du.Prefix = string.IsNullOrEmpty(units[j].address) ? "D":units[j].address.Substring(0, 1);
                        du.type = (em_DataType)Enum.Parse(typeof(em_DataType), units[j].dataType);
                        du.unitNum = units[j].unitNum;
                        du.vairsName = units[j].remark;
                        du.bandField = units[j].paramId;
                        ag.unitLst.Add(du);
                        dirDataUint.Add(du.Name.Trim(), du);
                    }                      
                }
                addrGroupLst.Add(ag);
                dirGroup.Add(ag.name.Trim(), ag);
            }
        }

        public bool WriteUnit(ref DataUint unit)
        {
            return plc.WirteUint(ref unit);
        }
        public bool ReadUnit(ref DataUint unit)
        {
            return plc.ReadUint(ref unit);
        }
        public bool Write(string name,string data)
        {
            DataUint unit = dirDataUint[name];
            unit.Data = data;
            bool ret = WriteUnit(ref unit);
            if (ret)
            {
                dirDataUint[name] = unit;
                if (!name.Contains("心跳"))
                    FileSave.WriteLog($"向{name}地址写入{data}成功",Em_LogPath.Run_Log.ToString());
            }
            return ret;
        }


        public bool Read(string name, ref string data)
        {
            DataUint unit = dirDataUint[name];
            bool ret = ReadUnit(ref unit);

            //if (unit.Data.ToLower().Contains("error"))
            //    unit.Data = "";

            data = unit.Data;
            dirDataUint[name] = unit;
            return ret;
        }

        public bool Save()
        {
            bool rult = false;
            PlcConfigAccess pa = new PlcConfigAccess();
            foreach (var group in addrGroupLst)
            {
                for(int i=0;i<group.unitLst.Count;i++)
                {
                    PlcConfig pfg = new PlcConfig();
                    pfg.address = group.unitLst[i].Prefix+group.unitLst[i].Addr.ToString();
                    pfg.name = group.unitLst[i].Name;
                    pfg.paramId = group.unitLst[i].bandField;
                    pfg.oldData = group.unitLst[i].OldData;
                    pfg.data = group.unitLst[i].Data;
                    pfg.dataType = group.unitLst[i].type.ToString();
                    pfg.unitNum = group.unitLst[i].unitNum;
                    pfg.remark= group.unitLst[i].vairsName;
                    rult=pa.Update(pfg)>0?true:false;
                }
            }
            return rult;
        }





        public bool ReadGroup(ref AddrGroups group)
        {

            if (group.leng <= 0)
            {
                return false;
            }
            else
            {
                plc.ReadGroup(ref group);
                //plc.PLCReadStruct(ref group);
                //plc.ReadGroupTest(ref group);
            }
            return true;
        }

    }
}
