﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProDAL;
using ProModel;

namespace ProBLL
{
    public class UserManage
    {
        public PermissionsManage perCurrent = new ProBLL.PermissionsManage();
        public EventHand evenHand = new EventHand();
        public User currentUser;
        public List<User> AllUser;
        public Roles role;
       
        public List<Roles> AllRoles;
        public Dictionary<int, string> group = new Dictionary<int, string>();
        public Dictionary<string, Roles> groupRole = new Dictionary<string, Roles>();
        public bool isLogin = false;
        public UserManage()
        {
            GetAllGroup();
        }
        public bool Login(string name,string pwd)
        {
            UserAccess userA = new UserAccess();
            currentUser = userA.Login(name, pwd);
            if (currentUser == null)
            {
                isLogin = false;
                return false;
            }
            else
            {
                currentUser.state = 1;
                isLogin = true;
                if (GetCurrentGroup(currentUser.groupID))
                {
                    perCurrent.GetBands(role.rights);
                    perCurrent.GetBarItem(role.rights);
                    ParBandsEventArge bandEvent = new ParBandsEventArge(perCurrent.preBands, perCurrent.preBarItem);
                    CurUserEventArgs userEvent = new CurUserEventArgs(role, currentUser);
                    evenHand.UpdateLeftForm(isLogin);
                }

            }
            return true;
        }
        public void UpdatePerCurrent(int id)
        {
            currentUser = new User();
            currentUser.groupID = id;
            currentUser.state = 1;
            isLogin = true;
            if (GetCurrentGroup(id))
            {
                perCurrent.GetBands(role.rights);
                perCurrent.GetBarItem(role.rights);
                ParBandsEventArge bandEvent = new ParBandsEventArge(perCurrent.preBands, perCurrent.preBarItem);
                CurUserEventArgs userEvent = new CurUserEventArgs(role, currentUser);
                evenHand.UpdateLeftForm(isLogin);
            }
        }


        public void ExitLogin()
        {
            isLogin = false;
            if (GetCurrentGroup(role.name))
            {
                perCurrent.GetBands(role.rights);
                perCurrent.GetBarItem(role.rights);
                ParBandsEventArge bandEvent = new ParBandsEventArge(perCurrent.preBands, perCurrent.preBarItem);
                CurUserEventArgs userEvent = new CurUserEventArgs(role);
                evenHand.UpdateLeftForm(isLogin);
            }
        }
        public int Add(User userTemp)
        {
            UserAccess userA = new UserAccess();
            return userA.Add(userTemp.userName, userTemp.pwd, userTemp.groupID, userTemp.remark);
        }
        public int UpdateRoleRight(Roles role)
        {
            RolesAccess ra = new RolesAccess();
            int ret= ra.Update(role.rights, role.name);
            GetAllGroup();
            return ret;
        }
        public int Update(User userTemp)
        {
            UserAccess userA = new UserAccess();
            return userA.Update(userTemp.userName, userTemp.pwd, userTemp.groupID, userTemp.remark);
        }
        public int Delete(User userTemp)
        {
            UserAccess userA = new UserAccess();
            return userA.Delete(userTemp.userName);
        }
        public bool GetCurrentGroup(int id)
        {
            RolesAccess ra = new RolesAccess();
            role=ra.SelectFromId(id);
            if (role == null)
                return false;
            else
                return true;
        }
        public bool GetCurrentGroup(string name)
        {
            RolesAccess ra = new RolesAccess();
            role = ra.SelectFromName(name);
            if (role == null)
                return false;
            else
                return true;
        }

        public bool GetAllGroup()
        {
            RolesAccess ra = new RolesAccess();
            AllRoles = ra.SelectAll();
            if (AllRoles == null)
                return false;
            else
            {
                group.Clear();
                groupRole.Clear();
                foreach (var val in AllRoles)
                {
                    group.Add(val.groupID, val.name);
                    groupRole.Add(val.name, val);

                }
            }
                return true;
        }
        public bool GetAllUsers()
        {
            UserAccess ra = new UserAccess();
            AllUser = ra.SelectAll();
            if (AllUser == null)
                return false;
            else
                return true;
        }


    }
}
