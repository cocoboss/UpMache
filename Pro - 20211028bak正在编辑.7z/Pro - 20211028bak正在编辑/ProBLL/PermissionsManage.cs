﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProModel;
using ProDAL;
using System.Reflection;
//using UtilityLibrary.WinControls;
using System.Windows.Forms;

namespace ProBLL
{
    public class PermissionsManage
    {
        public Dictionary<string, Form> strForm = new Dictionary<string, Form>();
        //Dictionary<string, PermissionDir> barBands = new Dictionary<string, PermissionDir>();
        public List<PerBand> preBands=new List<PerBand> () ;
        public List<PerBand> preBarItem = new List<PerBand>();
        public PermissionsAccess pa = new PermissionsAccess();
        public Dictionary<string, Em_Right> rightBarItem = new Dictionary<string, Em_Right>();
        public PermissionsManage()
        {
            pa.GetBand();
            pa.GetBarItem();
        }


        public void GetBands(string rightStr)
        {
            preBands.Clear();
            
            List<Permissions> band=pa.GetBand();;
            string[] rightArr = rightStr.Split(';');
            for (int i = 0; i < band.Count; i++)
            {
                if (rightArr.Length >1)
                {
                    PerBand parBand = new PerBand();
                    parBand.per = band[i];
                    for (int k = 0; k < rightArr.Length; k++)
                    {
                        if (rightArr[k].Contains(band[i].name))
                        {
                            if (rightArr[k].Contains(':'))
                                parBand.userRight = (Em_Right)int.Parse(rightArr[k].Split(':')[1]);
                            else
                                parBand.userRight = Em_Right.Write;
                        }
                    }
                    preBands.Add(parBand);
                }
                else
                {
                    PerBand parBand = new PerBand();
                    parBand.per = band[i];
                    parBand.userRight = Em_Right.Write;
                    preBands.Add(parBand);
                }

            }
        }


        public void GetBarItem(string rightStr)
        {
            preBarItem.Clear();
            rightBarItem.Clear();
            List<Permissions> barItem = pa.GetBarItem();
            string[] rightArr = rightStr.Split(';');
            for (int j = 0; j < barItem.Count; j++)
            {
                if (rightArr.Length > 1)
                {
                    PerBand parBand = new PerBand();
                    for (int k = 0; k < rightArr.Length; k++)
                    {
                        if (rightArr[k].Contains(barItem[j].name))
                        {
                            
                            if (rightArr[k].Contains(':'))
                                parBand.userRight = (Em_Right)int.Parse(rightArr[k].Split(':')[1]);
                            else
                                parBand.userRight = Em_Right.Write;
                            
                            rightBarItem.Add(barItem[j].name, parBand.userRight);
                        }
                    }
                    parBand.per = barItem[j];
                    preBarItem.Add(parBand);
                }
                else
                {
                    PerBand parBand = new PerBand();
                    parBand.per = barItem[j];
                    parBand.userRight = Em_Right.Write;
                    preBarItem.Add(parBand);
                    rightBarItem.Add(barItem[j].name, parBand.userRight);
                }

            }
        }

        public List<Permissions> GetAllBands()
        {
            return pa.SelectAll();
        }


    }

    //public class ListPer
    //{
    //    //public string userName="未登录";
    //    //public string userGroupName;
    //    List<PerAndForm> perForm=new List<PerAndForm> ();
    //    public int bandId;
    //    public string bandName;
    //}
}
