﻿using ProDAL;
using ProModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProBLL
{
    public class EventHand
    {
        public event EventHandler event_userSwitch;
        public event EventHandler event_bandsSwitch;
        public event EventHandler event_statusChange;
        public event EventHandler event_MesMessage;
        public event EventHandler event_DataOut;
        public event EventHandler event_LogMessage;
        public event EventHandler event_ParamInit;

        public void UpdateLeftForm(bool isLogin)
        {
            if (event_bandsSwitch != null)
                event_bandsSwitch(isLogin, null);

            if (event_userSwitch != null)
                event_userSwitch(isLogin, null);
        }

        public void UpdateStatus(SigStatusEventArgs sig)
        {
            if (event_statusChange != null)
                event_statusChange(this, sig);
        }

        public void UpdataMesMessage(MesDataEventArgs msg)
        {
            if (event_MesMessage != null)
                event_MesMessage(this, msg);
        }

        public void UpdataData(DataEventArgs msg)
        {
            if (event_DataOut != null)
                event_DataOut(this, msg);
        }
        public void UpdataLog(LogEventArgs msg)
        {
            if (event_LogMessage != null)
                event_LogMessage(this, msg);
        }

        public void UpdataParamInit(ParamInitEventArgs msg)
        {
            if (event_ParamInit != null)
                event_ParamInit(this, msg);
        }

    }
}
