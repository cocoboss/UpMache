﻿using ProModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProDAL;
using System.Data;

namespace ProBLL
{
    public class DataBll
    {
        public Em_Data type;
        public ProdectionData data;

        public DataBll(Em_Data typeTemp, ProdectionData temp)
        {
            type = typeTemp;
            data = temp;
        }
        public DataBll()
        {

        }
        public void SaveDb()
        {
            ProdectionDataAccess pa = new ProdectionDataAccess();
            switch (type)
            {
                case Em_Data.dataIn:
                    Task.Run(() =>
                    {
                        string tempStr = $"{data.barCode},{data.in_result},{data.in_message},{data.in_time},{data.model}";
                        FileSave.WriteLog(tempStr, Em_LogPath.In_Data.ToString());
                    });
                    int ret= pa.Insert(data.barCode, data.in_result, data.in_message, data.model, data.in_time);
                    if(ret>0)
                    {
                        FileSave.WriteLog("保存上料数据成功",Em_LogPath.Run_Log.ToString());
                    }
                    else
                    {
                        FileSave.WriteLog("保存上料数据失败", Em_LogPath.Run_Log.ToString());
                    }
                    
                    break;
                case Em_Data.dataOut:
                    Task.Run(() =>
                    {
                        string tempStr1 = $"{data.barCode},{data.in_time},{data.in_result},{data.in_message},{data.out_time},{data.out_result},{data.out_message},{data.PoleHeightL},{data.shoulderHeightL},{data.bycellWidth},{data.bycellPlies},{data.PoleHeightR},{data.shoulderHeightR},{data.testPliesPress},{data.model}";
                        FileSave.WriteLog(tempStr1, Em_LogPath.Out_Data.ToString());
                    });
                    int temp=pa.SelectBarCode(data.barCode);
                    if(temp>0)
                    {
                        if(pa.Update(data)>0)
                        {
                            FileSave.WriteLog("保存下料数据成功", Em_LogPath.Run_Log.ToString());
                        }else
                        {
                            FileSave.WriteLog("保存下料数据失败", Em_LogPath.Run_Log.ToString());
                        }
                    }else
                    {
                        int pi=pa.Insert(data.barCode, data.in_result, data.in_message, data.model, data.in_time);
                        if(pi>0)
                        {
                            if (pa.Update(data) > 0)
                            {
                                FileSave.WriteLog("保存下料数据成功", Em_LogPath.Run_Log.ToString());
                            }
                            else
                            {
                                FileSave.WriteLog("保存下料数据失败", Em_LogPath.Run_Log.ToString());
                            }
                        }else
                        {
                            FileSave.WriteLog("保存下料数据失败,检查数据库是否正确连接", Em_LogPath.Run_Log.ToString());
                        }
                    }
                   
                    break;
                default:
                    break;
            }
        }
        //public void UpdateForm()
        //{

        //}

        public DataTable SelectData(string parms,string where)
        {
            ProdectionDataAccess pa = new ProdectionDataAccess();
            string sql = $"select {parms} from prodectiondata {where}";
            return pa.SelectData(sql);
        }
        public bool ClearData(string dateTime)
        {
            bool isclear = false;
            ProdectionDataAccess pa = new ProdectionDataAccess();
            int ret=pa.Delete(dateTime);
            if(ret>0)
            {
                isclear = true;
                //FileSave.WriteLog("定期清除数据成功", Em_LogPath.Run_Log.ToString());
            }else
            {
                isclear = false;
                //FileSave.WriteLog("定期清除数据失败", Em_LogPath.Run_Log.ToString());
            }
            return isclear;
        }

    }
}
