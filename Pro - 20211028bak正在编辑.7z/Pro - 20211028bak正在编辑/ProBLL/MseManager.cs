﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProModel;
using Apriso.MIPlugins.Communication.Clients;
using Apriso.MIPlugins.Communication.Clients.WcfServiceAPI;
using Newtonsoft.Json;
using System.Threading;
using ProDAL;

namespace ProBLL
{
    public class MseManager
    {
        public List<string> localIp = new List<string>();
        public List<string> mesIp = new List<string> ();
        public List<string> mesIpBak = new List<string> ();
        private static object objLock = new object();
        private static object conLock = new object();
        private static MseManager instance = null;
        public WcfClient client = null;
        public SystemParam sysParam = null;
        public bool isConnect=false;
        public UserManage userMsg = null;
        public string ParamInitStr = "";
        private int timeOut = 5000;
        public static MseManager Instance()
        {
            if (instance == null)
            {
                lock (objLock)
                {
                    if (instance == null)
                    {
                        instance = new MseManager();
                    }
                }
            }
            return instance;
        }

        public bool Init(SystemParam param, UserManage user)
        {
            sysParam = param;
            userMsg = user;
            try
            {
                timeOut = int.Parse(string.IsNullOrEmpty(sysParam.mesDely) ? "5" : sysParam.mesDely) * 1000;
            }
            catch (Exception ex)
            {
                FileSave.WriteLog($"mes超时设置为非数值，不生效，请修改", Em_LogPath.Error_Log.ToString());
                //Task.Run(() => { MessageBox.Show($"不可以开机,原因：{message}"); });
            }
            return Connect();
        }

        public bool Reconnect()
        {
           if(client!=null)
            {
                client.Close();
                client.Dispose();
            }
            client = null;
            return Connect();
        }

        public bool Connect()
        {
            try {

                //FileSave.WriteExceptionLog("链接mes服务器开始");
                client = new WcfClient(
                  //"P1FE-R1G7801", 
                  sysParam.EquipmentCode,
                  Receive
                  //, "10.202.8.26:8007"
                  //, "10.202.12.36:8007"
                  , sysParam.mesMainIp
                  );

                //FileSave.WriteExceptionLog("链接mes服务器结束");
                Task.Run(() =>
                {
                    //ACEQPTCONN.ACEQPTCONNRequestJson jsons = new ACEQPTCONN.ACEQPTCONNRequestJson();
                    //jsons.AutoFlag = true;
                    //jsons.Software = "DDM";
                    //jsons.EquipmentInfo.Add(new ACEQPTCONN.ACEQPTCONNRequestEquipmentInfo() { EquipmentCode = "P1FE-R1G7801" });
                    //string json = MesAccess.ToJSON(jsons);
                    //FileSave.WriteExceptionLog($"链接mes服务器链接测试{json}");
                    bool temp = false;
                    string mesage = "";
                    MessageResponse rs = SendMessageRequest(Em_MES.ACEQPTCONN, GetACEQPTCONNRequestJson(), out temp,out mesage);

                    //FileSave.WriteExceptionLog($"链接mes服务器链接结束：{rs.ToString()}");
                    if (rs != null)
                    {
                        ACEQPTCONN.response = MesAccess.SetACEQPTCONNResponse(rs);
                        if (ACEQPTCONN.response.CommandResponseJson.EquipmentInfo[0].Result)
                            isConnect = true;
                        else
                            isConnect = false;
                    }
                    else
                    {
                        isConnect = false;
                    }
                    //FileSave.WriteExceptionLog($"链接mes服务器链接结束：{isConnect}");
                });
            }catch (Exception ex)
            {
                isConnect = false;
                FileSave.WriteExceptionLog($"MES链接报错：{ex.Message}");
            }
            return isConnect;
        }
        public MessageResponse SendMessageRequest(Em_MES type,string json,out bool ret,out string message)
        {

            message = "";
            ret = false;
            MessageRequest rqt = GetMessageRequest(type, json);
            MessageResponse rs = null;
            if (rqt != null)
            {
                FileSave.WriteLog(Common.ToJSON(rqt), Em_LogPath.MES_Log.ToString());
                //userMsg.evenHand.UpdataMesMessage(new MesDataEventArgs( Em_MesMessage.send, type, Common.ToJSON(rqt)));
                lock (this)
                {
                    //rs = client.SendMessage(rqt);
                    try
                    {
                        Common.CallWithTimeout(() => { rs = client.SendMessage(rqt); }, timeOut);
                    }
                    catch (TimeoutException ex)
                    {
                        message = ex.Message;
                    }
                    catch (Exception ex)
                    {
                        message = ex.Message;
                    }
                }
                if (rs == null)
                {
                    ret = false;
                    return rs;
                }
                FileSave.WriteLog(Common.ToJSON(rs),Em_LogPath.MES_Log.ToString());
                //userMsg.evenHand.UpdataMesMessage(new MesDataEventArgs(Em_MesMessage.receiver, type, Common.ToJSON(rs)));
                switch (type)
                {
                    case Em_MES.ACEQPTCONN:
                        ACEQPTCONN.response = MesAccess.SetACEQPTCONNResponse(rs);
                        //ACEQPTCONN.response = MesAccess.SetACEQPTCONNResponse(rs);
                        if (ACEQPTCONN.response.CommandResponseJson.EquipmentInfo.Count > 0)
                        {
                            foreach (var item in ACEQPTCONN.response.CommandResponseJson.EquipmentInfo)
                            {
                                ret = item.Result;
                                message = item.Message;
                            }
                        }
                        else
                        {
                            ret = false;
                            message = ACEQPTCONN.response.ErrorMessage;
                        }
                        break;

                    case Em_MES.ACEQPTALRT:
                        ACEQPTALRT.response = MesAccess.SetACEQPTALRTResponse(rs);
                        if (ACEQPTALRT.response.CommandResponseJson.EquipmentInfo.Count > 0)
                        {
                            foreach (var item in ACEQPTALRT.response.CommandResponseJson.EquipmentInfo)
                            {
                                ret = item.Result;
                                message = item.Message;
                            }
                        }
                        else
                        {
                            ret = false;
                            message = ACEQPTALRT.response.ErrorMessage;
                        }
                        break;

                    case Em_MES.ACEQPTSTUS:
                        ACEQPTSTUS.response = MesAccess.SetACEQPTSTUSResponse(rs);
                        if (ACEQPTSTUS.response.CommandResponseJson.EquipmentInfo.Count > 0)
                        {
                            foreach (var item in ACEQPTSTUS.response.CommandResponseJson.EquipmentInfo)
                            {
                                ret = item.Result;
                                message = item.Message;
                            }
                        }
                        else
                        {
                            ret = false;
                            message = ACEQPTSTUS.response.ErrorMessage;
                        }
                        break;

                    case Em_MES.ACEQUPTRUN:
                        ACEQUPTRUN.response = MesAccess.SetACEQUPTRUNResponse(rs);
                        if (ACEQUPTRUN.response.CommandResponseJson.EquipmentInfo.Count > 0)
                        {
                            foreach (var item in ACEQUPTRUN.response.CommandResponseJson.EquipmentInfo)
                            {
                                ret = item.ResultFlag;
                                message = item.Message;
                            }
                        }
                        else
                        {
                            ret = false;
                            message = ACEQUPTRUN.response.ErrorMessage;
                        }
                        break;
                    case Em_MES.ACLOGOFF:
                        userMsg.evenHand.UpdataMesMessage(new MesDataEventArgs(Em_MesMessage.send, type, Common.ToJSON(rqt)));
                        userMsg.evenHand.UpdataMesMessage(new MesDataEventArgs(Em_MesMessage.receiver, type, Common.ToJSON(rs)));
                        ACLOGOFF.response = MesAccess.SetACLOGOFFResponse(rs);

                        if (ACLOGOFF.response.CommandResponseJson.EquipmentInfo.Count > 0)
                        {
                            foreach (ACLOGOFF.ACLOGOFFResponseEquipmentInfo item in ACLOGOFF.response.CommandResponseJson.EquipmentInfo)
                            {
                                if(item.Products!=null && item.Products.Count>0)
                                {
                                    foreach (var serialNo in item.Products)
                                    {
                                        ret = serialNo.OutputFlag;
                                        message = serialNo.OutputMessage;
                                    }
                                }else
                                {
                                    ret = item.ResultFlag;
                                    message = item.Message;
                                }
                            }
                        }
                        else
                        {
                            ret = false;
                            message = ACLOGOFF.response.ErrorMessage;
                        }

                        break;
                    case Em_MES.ACLOGONCHECK:
                        userMsg.evenHand.UpdataMesMessage(new MesDataEventArgs(Em_MesMessage.send, type, Common.ToJSON(rqt)));
                        userMsg.evenHand.UpdataMesMessage(new MesDataEventArgs(Em_MesMessage.receiver, type, Common.ToJSON(rs)));
                        ACLOGONCHECK.response = MesAccess.SetACLOGONCHECKResponse(rs);
                        if (ACLOGONCHECK.response.CommandResponseJson.EquipmentInfo.Count > 0)
                        {
                            foreach (ACLOGONCHECK.ACLOGONCHECKResponseEquipmentInfo item in ACLOGONCHECK.response.CommandResponseJson.EquipmentInfo)
                            {
                                if(item.SerialNos.Count>0)
                                {
                                    foreach(var serialNo in item.SerialNos)
                                    {
                                        ret = serialNo.Result;
                                        message = serialNo.Message;
                                    }
                                }
                            }
                        }
                        else
                        {
                            ret = false;
                            message = ACLOGONCHECK.response.ErrorMessage;
                        }
                        break;
                    case Em_MES.ACUSERINFO:
                        ACUSERINFO.response = MesAccess.SetACUSERINFOResponse(rs);
                        if(ACUSERINFO.response.CommandResponseJson.EquipmentInfo.Count>0)
                        {
                            foreach (var item in ACUSERINFO.response.CommandResponseJson.EquipmentInfo)
                            {
                                ret = item.ResultFlag;
                                message = item.Message;
                            }
                        }
                        else
                        {
                            ret = false;
                            message = ACUSERINFO.response.ErrorMessage;
                        }
                        break;

                    case Em_MES.ACEQPTPARM:
                        ACEQPTPARM.response = MesAccess.SetACEQPTPARMResponse(rs);
                        if (ACEQPTPARM.response.CommandResponseJson.EquipmentInfo.Count > 0)
                        {
                            //foreach (var item in ACEQPTPARM.response.CommandResponseJson.EquipmentInfo)
                            //{
                            ret = true;
                            message =Common.ToJSON(ACEQPTPARM.response.CommandResponseJson.EquipmentInfo[0]);
                            //}
                        }
                        else
                        {
                            ret = false;
                            message = ACEQPTPARM.response.ErrorMessage;
                        }
                        break;
                    default:
                        break;
                }
            }

                return rs;
        }
        public MessageRequest GetMessageRequest(Em_MES type, string json)
        {
            MessageRequest rqt = null;
            switch (type)
            {
                case Em_MES.ACEQPTCONN:
                    rqt = MesAccess.GetACEQPTCONNRequest(json);
                    break;

                case Em_MES.ACEQPTALRT:
                    rqt = MesAccess.GetACEQPTALRTRequest(json);
                    break;

                case Em_MES.ACEQPTSTUS:
                    rqt = MesAccess.GetACEQPTSTUSRequest(json);
                    break;

                case Em_MES.ACEQUPTRUN:
                    rqt = MesAccess.GetACEQUPTRUNRequest(json);
                    break;
                case Em_MES.ACLOGOFF:
                    rqt = MesAccess.GetACLOGOFFRequest(json);
                    break;
                case Em_MES.ACLOGONCHECK:
                    rqt = MesAccess.GetACLOGONCHECKRequest(json);
                    break;
                case Em_MES.ACUSERINFO:
                    rqt = MesAccess.GetACUSERINFORequest(json);
                    break;

                case Em_MES.ACEQPTPARM:
                    rqt = MesAccess.GetACEQPTPARMRequest(json);
                    break;
                default:
                    //rqt = GetACEQPTCONNMessageRequest();
                    break;
            }
            return rqt;
        }
        public MessageRequest GetACEQPTCONNMessageRequest()
        {
            ACEQPTCONN.request = new ACEQPTCONN.ACEQPTCONNRequest();
            MessageRequest rqt = new MessageRequest();
            rqt.CommandId = ACEQPTCONN.request.CommandId;
            rqt.MessageGuid = ACEQPTCONN.request.MessageGuid;
            rqt.RequestDate = ACEQPTCONN.request.RequestDate;
            rqt.CommandRequestJson = JsonConvert.SerializeObject(ACEQPTCONN.request.CommandRequestJson);
            return rqt;
        }


        public string GetACEQPTPARMRequestJson(string name,string processCode,string version)
        {
            Dictionary<string, string> item = new Dictionary<string, string>();
            Common.CurrentDic(ref item, "EmployeeNo", name);
            Common.CurrentDic(ref item, "ProcessCode", processCode);
            Common.CurrentDic(ref item, "Version", version);
            Common.CurrentDic(ref item, Em_DefineVariable.EquipmentCode.ToString(), sysParam.EquipmentCode);
            Common.CurrentDic(ref item, Em_DefineVariable.Software.ToString(), sysParam.Software);
            return Common.ToJSON(MesAccess.SetACEQPTPARMRequestJson(item));
        }
        public string GetACEQPTCONNRequestJson()
        {
            Dictionary<string, string> item = new Dictionary<string, string>(); 
            Common.CurrentDic(ref item, Em_DefineVariable.EquipmentCode.ToString(), sysParam.EquipmentCode);
            Common.CurrentDic(ref item, Em_DefineVariable.Software.ToString(), sysParam.Software);
            return Common.ToJSON(MesAccess.SetACEQPTCONNRequestJson(item));
        }
        public string GetACEQPTALRTRequestJson(string name , List<ACEQPTALRT.ACEQPTALRTRequestAlertInfo> lst)
        {
            Dictionary<string, string> item = new Dictionary<string, string>();
            Common.CurrentDic(ref item, "EmployeeNo", name);
            Common.CurrentDic(ref item, Em_DefineVariable.EquipmentCode.ToString(), sysParam.EquipmentCode);
            Common.CurrentDic(ref item, Em_DefineVariable.Software.ToString(), sysParam.Software);
            return Common.ToJSON(MesAccess.SetACEQPTALRTRequestJson(item,lst));
        }

        public string GetACEQUPTRUNRequestJson(string name,string model)
        {
            Dictionary<string, string> item = new Dictionary<string, string>();
            Common.CurrentDic(ref item, "EmployeeNo", name);
            Common.CurrentDic(ref item, "StateCode", "Run");
            Common.CurrentDic(ref item, "EquipmentModel", model);
            Common.CurrentDic(ref item, Em_DefineVariable.EquipmentCode.ToString(), sysParam.EquipmentCode);
            Common.CurrentDic(ref item, Em_DefineVariable.Software.ToString(), sysParam.Software);
            return Common.ToJSON(MesAccess.SetACEQUPTRUNRequestJson(item));
        }

        public string GetACEQPTSTUSRequestJson(string name,string model,string opFlag,string equipmentStatusID,string description)
        {
            Dictionary<string, string> item = new Dictionary<string, string>();
            Common.CurrentDic(ref item, "EmployeeNo", name);
            Common.CurrentDic(ref item, "EquipmentModel", model);
            Common.CurrentDic(ref item, "OpFlag", opFlag);
            Common.CurrentDic(ref item, "Location", "0");
            Common.CurrentDic(ref item, "EquipmentStatusID", equipmentStatusID);
            Common.CurrentDic(ref item, "ReasonCode", "");
            Common.CurrentDic(ref item, "Description", description);
            //Common.CurrentDic(ref item, "EmployeeNo", name);
            Common.CurrentDic(ref item, Em_DefineVariable.EquipmentCode.ToString(), sysParam.EquipmentCode);
            Common.CurrentDic(ref item, Em_DefineVariable.Software.ToString(), sysParam.Software);
            return Common.ToJSON(MesAccess.SetACEQPTSTUSRequestJson(item));
        }

        public string GetACLOGONCHECKRequestJson(string barCode,string name)
        {
            Dictionary<string, string> item = new Dictionary<string, string>(); ;
            Common.CurrentDic(ref item, "EmployeeNo", name);
            Common.CurrentDic(ref item, "SerialNo", barCode);
            Common.CurrentDic(ref item, "SlotID", "1");
            Common.CurrentDic(ref item, "RequestType", "1");
            Common.CurrentDic(ref item, "Container", "");
            Common.CurrentDic(ref item, "OpFlag", "0");
            Common.CurrentDic(ref item, Em_DefineVariable.EquipmentCode.ToString(), sysParam.EquipmentCode);
            Common.CurrentDic(ref item, Em_DefineVariable.Software.ToString(), sysParam.Software);

            return Common.ToJSON(MesAccess.SetACLOGONCHECKRequestJson(item));
        }
        public string GetACLOGOFFRequestJson(string barCode, string name, List<ACLOGOFF.ACLOGOFFRequestParameters> offParams)
        {
            Dictionary<string, string> item = new Dictionary<string, string>(); ;
            Common.CurrentDic(ref item, "EmployeeNo", name);
            Common.CurrentDic(ref item, "SerialNo", barCode);
            Common.CurrentDic(ref item, "OpFlag", "0");
            Common.CurrentDic(ref item, "Container", "");
            Common.CurrentDic(ref item, "ProcessMessage", "");
            Common.CurrentDic(ref item, "PreSerialNo", "");
            Common.CurrentDic(ref item, "SlotID", "");
            Common.CurrentDic(ref item, "ProductType", "A");
            //Common.CurrentDic(ref item, "PassFlag", "true");
            Common.CurrentDic(ref item, "ProcessFlag", "1");
            Common.CurrentDic(ref item, "Quantity", "");
            Common.CurrentDic(ref item, "LotNo", "");
            Common.CurrentDic(ref item, "ProductNo", "");
            Common.CurrentDic(ref item, "UomCode", "");
            //Common.CurrentDic(ref item, "SerialNo", "");
            Common.CurrentDic(ref item, "ProductDesc", "");
            Common.CurrentDic(ref item, "LabelNo", "");
            Common.CurrentDic(ref item, "ProductID", "");
            Common.CurrentDic(ref item, "StationID", "");
            Common.CurrentDic(ref item, "StepID", "");
            Common.CurrentDic(ref item, Em_DefineVariable.EquipmentCode.ToString(), sysParam.EquipmentCode);
            Common.CurrentDic(ref item, Em_DefineVariable.Software.ToString(), sysParam.Software);
             //= new List<ACLOGOFF.ACLOGOFFRequestParameters>();
            return Common.ToJSON(MesAccess.SetACLOGOFFRequestJson(item, offParams));
        }
        public string GetACUSERINFORequestJson(string name,string pwd,string right)
        {
            Dictionary<string, string> item = new Dictionary<string, string>();;
            Common.CurrentDic(ref item, "EmployeeNo", name);
            Common.CurrentDic(ref item, "Password", pwd);
            Common.CurrentDic(ref item, "RoleID", right);
            Common.CurrentDic(ref item, Em_DefineVariable.EquipmentCode.ToString(), sysParam.EquipmentCode);
            Common.CurrentDic(ref item, Em_DefineVariable.Software.ToString(), sysParam.Software);
            return Common.ToJSON(MesAccess.SetACUSERINFORequestJson(item));
        }
        public void SendParamInitResponse(string items,Guid guid)
        {
            MessageResponse ret = MesAccess.GetACEQPTINITMessageResponse(guid, items);
             MesAccess.ToJSON(ret);
        }


        public string GetParamInit()
        {
            while(!string.IsNullOrEmpty( ParamInitStr))
            {
                break;
            }
            return ParamInitStr;
        }
        public MessageResponse Receive(MessageRequest mesRqt)
        {
            string log =$"接收命令：{mesRqt.CommandId},数据：{ MesAccess.ToJSON(mesRqt)}";
            FileSave.WriteLog(log, Em_LogPath.MES_Log.ToString());
            string response = "";
            switch (mesRqt.CommandId.ToUpper())
            {
                case "ACEQPTINIT":
                    ParamInitStr = "";
                    response = InitProcess(MesAccess.ToJSON(mesRqt));
                    break;
                default:
                    break;
            }

            return MesAccess.FormJson<MessageResponse>(response);

            //return new MessageResponse()
            //{
            //    Success = true,
            //    MessageGuid = mesRqt.MessageGuid,
            //    CommandResponseJson = "I am response for server request. MessageGuid : " + mesRqt.MessageGuid
            //};
        }


        public string InitProcess(string receData)
        {
            //MessageRequest rqt= MesAccess.FormJson<MessageRequest>(receData);

            //ACEQPTINIT.ACEQPTINITRequest itemRequest = new ACEQPTINIT.ACEQPTINITRequest();
            //itemRequest.CommandId = rqt.CommandId;
            //itemRequest.CommandRequestJson = MesAccess.FormJson<ACEQPTINIT.ACEQPTINITRequestJson>(rqt.CommandRequestJson);
            //itemRequest.MessageGuid = rqt.MessageGuid;
            //itemRequest.RequestDate = rqt.RequestDate;
            string tempInitStr = "";
            ACEQPTINIT.request = MesAccess.SetACEQPTINITRequest(receData);
            Func<string> asy = GetParamInit;
            AsyncCallback callback = c => FileSave.WriteLog(ParamInitStr, Em_LogPath.MES_Log.ToString());
            IAsyncResult retsultAsy = asy.BeginInvoke(callback, "下发参数返回");
            userMsg.evenHand.UpdataParamInit(new ParamInitEventArgs(Em_MES.ACEQPTINIT, MesAccess.ToJSON(ACEQPTINIT.request), 0));

          

            //ACEQPTINIT.ACEQPTINITResponse item = new ACEQPTINIT.ACEQPTINITResponse();
            //item.MessageGuid = ACEQPTINIT.request.MessageGuid;
            ACEQPTINIT.ACEQPTINITResponseJson json = new ACEQPTINIT.ACEQPTINITResponseJson();
            //ACEQPTINIT.ACEQPTINITResponseEquipmentInfo info = new ACEQPTINIT.ACEQPTINITResponseEquipmentInfo();
            json.EquipmentInfo.Add(new ACEQPTINIT.ACEQPTINITResponseEquipmentInfo() { Message = "", Result = true, EquipmentCode = "" });
            json.Software = "DDM";
            //item.CommandResponseJson = json;
            //ACEQPTINIT.response = item;
            string items = MesAccess.ToJSON(json);


            MessageResponse ret = MesAccess.GetACEQPTINITMessageResponse(ACEQPTINIT.request.MessageGuid, items);

            //MessageResponse ret = new MessageResponse();
            //ret.CommandId = item.CommandId;
            //ret.CommandId = item.CommandId;
            //ret.CommandResponseJson =MesAccess.ToJSON(item.CommandResponseJson);
            //ret.MessageGuid = item.MessageGuid;
            //ret.ResponseDate = item.ResponseDate;
            //ret.ErrorCode = item.ErrorCode;
            //ret.ErrorMessage = item.ErrorMessage;
            //ret.Success = item.Success;

            if (retsultAsy.AsyncWaitHandle.WaitOne(-1))
            {
                if (ParamInitStr != "")
                    ret = MesAccess.FormJson<MessageResponse>(ParamInitStr);
            }

            return MesAccess.ToJSON(ret);
        }
       
    }
}
