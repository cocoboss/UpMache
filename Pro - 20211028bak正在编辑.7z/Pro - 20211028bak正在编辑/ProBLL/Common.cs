﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProDAL;
using System.Threading;

namespace ProBLL
{
    public static class Common
    {
        public static T FormJson<T>(this string json)
        {
            return MesAccess.FormJson<T>(json);
        }
        public static string ToJSON(this object o)
        {
            return MesAccess.ToJSON(o);
        }

        public static void CurrentDic(ref Dictionary<string, string> item, string key, string val)
        {
            if (item.Keys.Contains(key))
                item[key] = val;
            else
                item.Add(key, val);
        }
        public static void CallWithTimeout(Action action, int timeoutMilliseconds)
        {
            Thread threadToKill = null;
            Action wrappedAction = () =>
            {
                threadToKill = Thread.CurrentThread;
                action();
            };

            IAsyncResult result = wrappedAction.BeginInvoke(null, null);
            if (result.AsyncWaitHandle.WaitOne(timeoutMilliseconds))
            {
                wrappedAction.EndInvoke(result);
            }
            else
            {
                threadToKill.Abort();
                throw new TimeoutException();
            }
        }
    }
}
