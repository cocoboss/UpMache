﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ProDAL
{
    public class TcpClientGivenLocalIP
    {
        private byte[] recvBuf = new byte[1024];
        private byte[] recvBuffer = new byte[1024];
        public int recvLen = 0;
        private static object dataLock = new object();

        private IPAddress ServerIpAddress;
        private IPEndPoint serverEP;
        private int serverPort;
        private int portId = 0;

        private IPAddress localIpAddress;
        private int localPort;
        private IPEndPoint localEp;
        public TcpClient tcpClient = null;
        public event EventHandler event_Receive;
        public event EventHandler event_Connect;
        private bool isConnect = false;
        private bool bSwitchPort = false;


        public TcpClientGivenLocalIP(int portId)
        {
            this.portId = portId;
        }

        public bool IsConnect
        {
            get { return isConnect; }
            set
            {
                if (value != isConnect)
                {
                    SetConnectStatus(value);
                }
                isConnect = value;
            }
        }

        public void RaiseReceiveData(string strData, Socket socket)
        {
            if (event_Receive != null)
            {
                try
                {
                    event_Receive(this, new ReceiveArgs(strData, portId));
                }
                catch
                {
                    //MessageBox.Show("数据解析异常：" + strData);
                }
            }
        }

        public void SetConnectStatus(bool connect)
        {
            if (event_Connect != null)
            {
                event_Connect(this, new PortStatusArgs(connect, portId));
            }
        }
        public void Init(string serverIp, int serverPort, string localIP, int localPort)
        {
            this.serverPort = serverPort;
            this.localPort = localPort;
            ServerIpAddress = IPAddress.Parse(serverIp);
            serverEP = new IPEndPoint(ServerIpAddress, serverPort);

            localIpAddress = IPAddress.Parse(localIP);
            try
            {
                localEp = new IPEndPoint(localIpAddress, localPort);
            }
            catch (Exception e)
            {
                //MessageBox.Show(e.Message);
            }
            CreateConnectAsync();
        }

        public async void CreateConnectAsync()
        {
            await Task.Run(() =>
            {
                CreateConnect();
            });
        }

        public void Close()
        {
            try
            {
                if (tcpClient != null)
                {
                    tcpClient.Close();
                }
            }
            catch
            {
            }
        }

        public void CreateConnect()
        {
            Thread.Sleep(1000);
            IsConnect = false;
            if (!isConnect)
            {
                if (tcpClient != null)
                {
                    tcpClient.Close();
                    tcpClient = null;
                    Console.WriteLine("关闭成功:");
                }
            }

            try
            {
                if (tcpClient == null)
                {
                    try
                    {
                        if (bSwitchPort)
                        {
                            //localEp = new IPEndPoint(localIpAddress, localPort + 1);
                            localEp = new IPEndPoint(localIpAddress, localPort + 1);
                        }
                        else
                        {
                            localEp = new IPEndPoint(localIpAddress, localPort);
                        }
                        bSwitchPort = !bSwitchPort;
                    }
                    catch (Exception e)
                    {
                        //MessageBox.Show(e.Message);
                    }
                    tcpClient = new TcpClient(localEp);
                    tcpClient.ReceiveTimeout = 1000;
                    tcpClient.SendTimeout = 1000;
                }
            }
            catch
            {
            }

            //tcpClient.BeginConnect(ServerIpAddress,serverPort, new AsyncCallback(ConnectServer), tcpClient);
            //tcpClient.Client.BeginConnect(serverEP, new AsyncCallback(ConnectServer), tcpClient.Client);
            if (tcpClient != null)
            {
                try
                {
                    tcpClient.Client.BeginConnect(serverEP, new AsyncCallback(ConnectServer), tcpClient.Client);
                }
                catch
                {

                    CreateConnect();
                }
            }
            else
            {
                CreateConnect();
            }
        }

        public void ReceiveMessage(IAsyncResult ar)
        {
            try
            {
                var socket = ar.AsyncState as Socket;
                var length = socket.EndReceive(ar);
                if (length > 0)
                {
                    var message = Encoding.ASCII.GetString(recvBuf, 0, length);
                    UpDataRecvData(length);
                    RaiseReceiveData(message, socket);
                    tcpClient.Client.BeginReceive(recvBuf, 0, recvBuf.Length, SocketFlags.None, new AsyncCallback(ReceiveMessage), socket);
                }
                else
                {
                    IsConnect = false;
                    CreateConnect();
                }
            }
            catch (Exception ex)
            {
                IsConnect = false;
                CreateConnect();
                Console.WriteLine("ReceiveMessage:" + ex.Message);
            }
        }

        public void ConnectServer(IAsyncResult ar)
        {
            try
            {
                var socket = ar.AsyncState as Socket;
                socket.EndConnect(ar);
                IsConnect = true;
                socket.BeginReceive(recvBuf, 0, recvBuf.Length, SocketFlags.None, new AsyncCallback(ReceiveMessage), socket);

            }
            catch (Exception ex)
            {
                IsConnect = false;
                CreateConnect();
                Console.WriteLine("ConnectServer" + ex.Message);
            }
        }

        public void SendData(IAsyncResult ar)
        {
            try
            {
                var socket = ar.AsyncState as Socket;
                socket.EndSend(ar);
            }
            catch (Exception ex)
            {
                IsConnect = false;
                CreateConnect();
                Console.WriteLine("SendData " + ex.Message);
            }
        }

        public bool SendString(string strSend)
        {
            return SendData(Encoding.ASCII.GetBytes(strSend));
            
        }

        public bool SendData(byte []  datas)
        {
            bool ret = false;
            
            if (tcpClient != null)
            {
                try
                {
                    if (IsConnect)
                    {
                        if (datas.Length == tcpClient.Client.Send(datas, 0, datas.Length, SocketFlags.None))
                        {
                            ret = true;
                        }
                    }
                    else
                    {
                        CreateConnect();
                    }
                }
                catch
                {
                    IsConnect = false;
                    CreateConnect();
                }
            }
            return ret;
        }

        public void ClearRecv()
        {
            lock(dataLock)
            {
                recvLen = 0;
            }
        }

        public void UpDataRecvData(int len)
        {
            lock (dataLock)
            {
                if (len + recvLen < recvBuffer.Length)
                {
                    Array.Copy(recvBuf, 0, recvBuffer, recvLen, len);
                    recvLen += len;
                }
                else
                {
                    Array.Copy(recvBuf, recvBuffer, len);
                    recvLen = len;

                }

            }
        }

        public byte [] GetDatas()
        {
            lock (dataLock)
            {
                return recvBuffer;
            }

        }
    }
}