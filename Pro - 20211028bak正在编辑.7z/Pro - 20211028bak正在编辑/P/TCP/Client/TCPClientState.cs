﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Sockets;
namespace ProDAL
{
    public class TcpDatagramReceivedEventArgs<T>
    {
        public T Datagram;
        public TcpClient client;
        public int PortIndex;
        public TcpDatagramReceivedEventArgs(int portIndex, TcpClient client, T obj)
        {
            this.PortIndex = portIndex;
            this.Datagram = obj;
            this.client = client;
        }
    }

    public class TcpClientConnectedEventArgs : EventArgs
    {
        public TcpClient TcpClient;
        public int PortIndex;
        public TcpClientConnectedEventArgs(int portIndex, TcpClient client)
        {
            this.PortIndex = portIndex;
            this.TcpClient = client;
        }
    }

    public class TcpClientDisconnectedEventArgs : EventArgs
    {
        public TcpClient client;
        public int PortIndex;
        public TcpClientDisconnectedEventArgs(int portIndex, TcpClient client)
        {
            this.PortIndex = portIndex;
            this.client = client;
        }
    }

    public class AsyncEventArgs : EventArgs
    {
        public string _msg;
        public TcpClientState _state;
        public bool IsHandled { get; set; }

        public AsyncEventArgs(string msg)
        {
            this._msg = msg;
            IsHandled = false;
        }

        public AsyncEventArgs(TcpClientState state)
        {
            this._state = state;
            IsHandled = false;
        }

        public AsyncEventArgs(string msg, TcpClientState state)
        {
            this._msg = msg;
            this._state = state;
            IsHandled = false;
        }

    }

    public class TcpClientState
    {
        public TcpClient TcpClient { get; private set; }
        public byte[] Buffer { get; private set; }

        public NetworkStream NetworkStream
        {
            get
            {
                return TcpClient.GetStream();
            }
        }

        public TcpClientState(TcpClient tcpClient, byte[] buffer)
        {
            if (tcpClient == null)
                throw new ArgumentNullException("tcpClient");
            if (buffer == null)
                throw new ArgumentNullException("buffer");
            this.TcpClient = tcpClient;
            this.Buffer = buffer;
        }

        /// <summary>        /// 关闭        /// </summary>        
        public void Close()
        {            //关闭数据的接受和发送            
            TcpClient.Close();
            Buffer = null;
        }
    }
}