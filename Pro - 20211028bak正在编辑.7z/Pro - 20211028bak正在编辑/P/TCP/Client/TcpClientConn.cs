﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace ProDAL
{
    public class PortStatusArgs : EventArgs
    {
        private bool isConnect;

        public bool IsConnect
        {
            get { return isConnect; }
            set { isConnect = value; }
        }
        private int portId;

        public int PortId
        {
            get { return portId; }
            set { portId = value; }
        }

        public PortStatusArgs(bool isconn, int portId)
        {
            this.portId = portId;
            this.isConnect = isconn;
        }
    }

    public class TcpClientConn
    {
        private byte[] recvBuf = new byte[1024];
        private IPAddress ipAddress;
        private IPEndPoint remoteEP;
        public Socket client = null;
        public event EventHandler event_Receive;
        public event EventHandler event_Connect;
        //private bool isConnect = false;
        public bool isConnect = false;
        private int portId = 0;
        private static object recvLock = new object();
        private string recvString = "";


        public TcpClientConn(int portId)
        {
            this.portId = portId;
        }

        public bool IsConnect
        {
            get { return isConnect; }
            set
            {
                if (value != isConnect)
                {
                    SetConnectStatus(value);
                }
                isConnect = value;
            }
        }

        public void RaiseReceiveData(string strData, Socket socket)
        {
            if (event_Receive != null)
            {
                try
                {
                    event_Receive(this, new ReceiveArgs(strData, portId));
                }
                catch
                {
                    //MessageBox.Show("数据解析异常：" + strData);
                }
            }
        }

        public void SetConnectStatus(bool connect)
        {
            if (event_Connect != null)
            {
                event_Connect(this, new PortStatusArgs(connect, portId));
            }
        }
        public void Init(string serverIp, int serverPort)
        {
            ipAddress = IPAddress.Parse(serverIp);
            remoteEP = new IPEndPoint(ipAddress, serverPort);
            CreateConnect();
        }
        public void Close()
        {
            try
            {
                if (client != null)
                {
                    client.Shutdown(SocketShutdown.Both);
                    client.Close();

                }
            }
            catch
            {
            }
        }

        public void CreateConnect()
        {
            //if (!isConnect)
            //{
            //    if (client != null)
            //    {
            //        client.Shutdown(SocketShutdown.Both);
            //        client.Close();                   
            //        IsConnect = false;
            //        Console.WriteLine("关闭成功:");
            //    }
            //}
            if (isConnect)
                return;
            try
            {
                client = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                //client.SetSocketOption(SocketOptionLevel.Tcp, SocketOptionName.KeepAlive, 3000);
                client.ReceiveTimeout = 1000;
                client.SendTimeout = 1000;
                client.BeginConnect(remoteEP, new AsyncCallback(ConnectServer), client);
            }
            catch (Exception ex)
            {
                IsConnect = false;
            }
        }

        public string GetRecvString()
        {
            lock (recvLock)
            {
                return recvString;
            }
        }

        public void ClearRecv()
        {
            lock (recvLock)
            {
                recvString = "";
            }
        }

        public void ReceiveMessage(IAsyncResult ar)
        {
            try
            {
                var socket = ar.AsyncState as Socket;
                var length = socket.EndReceive(ar);
                if (length > 0)
                {
                    var message = Encoding.ASCII.GetString(recvBuf, 0, length);
                    lock (recvLock)
                    {
                        recvString += message;
                    }
                    RaiseReceiveData(message, socket);
                    client.BeginReceive(recvBuf, 0, recvBuf.Length, SocketFlags.None, new AsyncCallback(ReceiveMessage), socket);
                }
                else
                {
                    IsConnect = false;
                    CreateConnect();
                }
            }
            catch (Exception ex)
            {
                IsConnect = false;
                CreateConnect();
                Console.WriteLine("ReceiveMessage:" + ex.Message);
            }
        }

        public void ConnectServer(IAsyncResult ar)
        {
            try
            {
                var socket = ar.AsyncState as Socket;
                socket.EndConnect(ar);
                IsConnect = true;
                socket.BeginReceive(recvBuf, 0, recvBuf.Length, SocketFlags.None, new AsyncCallback(ReceiveMessage), socket);

            }
            catch (Exception ex)
            {
                IsConnect = false;
                CreateConnect();
                Console.WriteLine("ConnectServer" + ex.Message);
            }
        }

        public void SendData(IAsyncResult ar)
        {
            try
            {
                var socket = ar.AsyncState as Socket;
                socket.EndSend(ar);
            }
            catch (Exception ex)
            {
                IsConnect = false;
                CreateConnect();
                Console.WriteLine("SendData " + ex.Message);
            }
        }

        public bool SendString(string strSend)
        {
            bool ret = false;
            byte[] sendBuf = Encoding.ASCII.GetBytes(strSend);
            if (client != null)
            {
                try
                {
                    if (IsConnect)
                    {
                        if (sendBuf.Length == client.Send(sendBuf, 0, sendBuf.Length, SocketFlags.None))
                        {
                            ret = true;
                        }
                    }
                    else
                    {
                        CreateConnect();
                    }
                }
                catch
                {
                    IsConnect = false;
                    CreateConnect();
                }
            }
            return ret;
        }
    }
}