﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace ProDAL
{
    public class ReceiveArgs : EventArgs
    {
        private string recvString;
        private int portIndex;

        public int PortIndex
        {
            get { return portIndex; }
            set { portIndex = value; }
        }
        public string RecvString
        {
            get { return recvString; }
            set { recvString = value; }
        }

        public ReceiveArgs(string strRecv, int portIndex)
        {
            this.recvString = strRecv;
            this.portIndex = portIndex;
        }
    }

    public class TcpServer
    {
        private byte[] recvBuf = new byte[1024];
        public event EventHandler event_Receive;
        public event EventHandler event_Connect;
        private bool isConnect = false;

        public bool IsConnect
        {
            get { return isConnect; }
            set
            {
                if (value != isConnect)
                {
                    SetConnectStatus(value);
                }
                isConnect = value;
            }
        }

        public void Init(string localIp, int localPort)
        {
            var socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            socket.Bind(new IPEndPoint(IPAddress.Parse(localIp), localPort));
            socket.Listen(4);
            socket.BeginAccept(new AsyncCallback(ClientAccepted), socket);
        }

        public void RaiseReceiveData(string strData, Socket socket)
        {
            if (event_Receive != null)
            {
                event_Receive(this, new ReceiveArgs(strData, 0));
            }
        }

        public void ClientAccepted(IAsyncResult ar)
        {
            var socket = ar.AsyncState as Socket;
            var client = socket.EndAccept(ar);
            var timer = new System.Timers.Timer();
            timer.Interval = 2000;
            timer.Enabled = true;
            timer.Elapsed += (o, a) =>
            {
                //检测客户端Socket的状态
                if (client.Connected)
                {
                    IsConnect = true;
                    try
                    {
                        //client.Send(Encoding.Unicode.GetBytes("Alive"));
                    }
                    catch (SocketException ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                }
                else
                {
                    IsConnect = false;
                    timer.Stop();
                    timer.Enabled = false;
                    Console.WriteLine("Client is disconnected, the timer is stop.");
                }
            };
            timer.Start();

            client.BeginReceive(recvBuf, 0, recvBuf.Length, SocketFlags.None, new AsyncCallback(ReceiveMessage), client);
            socket.BeginAccept(new AsyncCallback(ClientAccepted), socket);
        }


        public void SetConnectStatus(bool connect)
        {
            if (event_Connect != null)
            {
                event_Connect(connect, null);
            }
        }
        public void ReceiveMessage(IAsyncResult ar)
        {
            try
            {
                var socket = ar.AsyncState as Socket;
                var length = socket.EndReceive(ar);
                var message = Encoding.ASCII.GetString(recvBuf, 0, length);
                RaiseReceiveData(message, socket);
                socket.BeginReceive(recvBuf, 0, recvBuf.Length, SocketFlags.None, new AsyncCallback(ReceiveMessage), socket);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public void SendData(IAsyncResult ar)
        {
            try
            {
                var socket = ar.AsyncState as Socket;
                socket.EndSend(ar);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

    }
}