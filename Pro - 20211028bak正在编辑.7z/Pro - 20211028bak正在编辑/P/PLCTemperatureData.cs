﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProDAL
{
    public enum ShowType
    {
        ShowA_Normal,
        ShowB_Normal,
        ShowA_Select,
        ShowB_Select,
    }
   public class PLCTemperatureData
    {

        public int preGlueTUp = 0;//预粘合上板温度
        public int preGlueTDome = 0;//预粘合下板温度

        public int A1BoardTUp = 0;//A1上板温度
        public int A1BoardTDomn = 0;//A1下板温度
        public int A1preHotT = 0;//A1预热温度

        public int A2BoardTUp = 0;//A2上板温度
        public int A2BoardTDomn = 0;//A2下板温度
        public int A2preHotT = 0;//A2预热温度

        public int A3BoardTUp = 0;//A3上板温度
        public int A3BoardTDomn = 0;//A3下板温度
        public int A3preHotT = 0;//A3预热温度

        public int A4BoardTUp = 0;//A4上板温度
        public int A4BoardTDomn = 0;//A4下板温度
        public int A4preHotT = 0;//A4预热温度

        public int A5BoardTUp = 0;//A5上板温度
        public int A5BoardTDomn = 0;//A5下板温度
        public int A5preHotT = 0;//A5预热温度

        public int A6BoardTUp = 0;//A6上板温度
        public int A6BoardTDomn = 0;//A6下板温度
        public int A6preHotT = 0;//A6预热温度

        public int B1BoardTUp = 0;//B1上板温度
        public int B1BoardTDomn = 0;//B1下板温度
        public int B1preHotT = 0;//B1预热温度

        public int B2BoardTUp = 0;//B2上板温度
        public int B2BoardTDomn = 0;//B2下板温度
        public int B2preHotT = 0;//B2预热温度

        public int B3BoardTUp = 0;//B3上板温度
        public int B3BoardTDomn = 0;//B3下板温度
        public int B3preHotT = 0;//B3预热温度

        public int B4BoardTUp = 0;//B4上板温度
        public int B4BoardTDomn = 0;//B4下板温度
        public int B4preHotT = 0;//B4预热温度

        public int B5BoardTUp = 0;//B5上板温度
        public int B5BoardTDomn = 0;//B5下板温度
        public int B5preHotT = 0;//B5预热温度

        public int B6BoardTUp = 0;//B6上板温度
        public int B6BoardTDomn = 0;//B6下板温度
        public int B6preHotT = 0;//B6预热温度
    }
}
