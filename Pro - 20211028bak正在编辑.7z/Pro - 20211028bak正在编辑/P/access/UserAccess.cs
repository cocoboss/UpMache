﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProModel;
using MySql.Data.MySqlClient;

namespace ProDAL
{
    public class UserAccess:BaseAccess
    {
        public User Login(string name,string pwd)
        {
            
            string sql = "select * from user where userName=@name and pwd=@pwd";
            List<Dictionary<string, string>> drs = mysql.ExecuteReader(sql,
                new MySqlParameter("@name", name), new MySqlParameter("@pwd", pwd));
            if (drs.Count > 0)
                return GetUser(drs[0]);
            else
                return null;
        }
        public int Add(string name,string pwd,int groupId,string remark="")
        {
            string sql = "insert into user(userName,pwd,groupID,remark) values(@name,@pwd,@groupID,@remark)";

            return mysql.ExecuteNonQuery(sql,
                new MySqlParameter("@name", name), new MySqlParameter("@pwd", pwd),
                new MySqlParameter("@groupID", groupId), new MySqlParameter("@remark", remark));
        }
        public int Delete(string name)
        {
            string sql = "delete from  user where userName=@name";

            return mysql.ExecuteNonQuery(sql,
                new MySqlParameter("@name", name));
        }
        public int Update(string name, string pwd, int groupId, string remark = "")
        {
            //string sql = $"update user set pwd='{pwd}',groupID={groupId},remark='{remark}' where userName='{name}'";

            //return mysql.ExecuteNonQuery(sql);


            string sql = "update user set pwd=@pwd,groupID=@groupID,remark=@remark where userName=@name";

            return mysql.ExecuteNonQuery(sql,
                new MySqlParameter("@name", name), new MySqlParameter("@pwd", pwd),
                new MySqlParameter("@groupID", groupId), new MySqlParameter("@remark", remark));
        }


        public List<User> SelectAll()
        {
            string sql = $"select * from user";
            List<Dictionary<string, string>> drs = mysql.ExecuteReader(sql);
            List<User> lst = new List<User>();
            if (drs.Count > 0)
            {
                for (int i = 0; i < drs.Count; i++)
                {
                    User temp = GetUser(drs[i]);
                    lst.Add(temp);
                }
            }
            else
            {
                lst = null;
            }
            return lst;
        }
        public User GetUser(Dictionary<string, string> dr)
        {
            User item = new User();
            item.groupID = int.Parse(dr["groupID"]);
            item.userName = dr["userName"].ToString();
            item.pwd = dr["pwd"].ToString();
            item.id = int.Parse(dr["id"]);
            item.state = int.Parse(dr["state"]);
            item.remark = dr["remark"].ToString();
            return item;
        }
    }
}
