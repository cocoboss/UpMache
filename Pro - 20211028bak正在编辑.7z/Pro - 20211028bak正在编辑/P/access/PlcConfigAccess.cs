﻿using MySql.Data.MySqlClient;
using ProModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProDAL
{
    public class PlcConfigAccess:BaseAccess
    {

        public List<PlcConfig> SelectAll()
        {
            string sql = $"select * from plcconfig";
            List<Dictionary<string, string>> drs = mysql.ExecuteReader(sql);
            List<PlcConfig> lst = new List<PlcConfig>();
            if (drs.Count > 0)
            {
                for (int i = 0; i < drs.Count; i++)
                {
                    PlcConfig temp = GetPlcConfig(drs[i]);
                    lst.Add(temp);
                }
            }
            else
            {
                lst = null;
            }
            return lst;
        }
        public int Update(PlcConfig pfg)
        {
            //string sql = $"update plcconfig set unitNum={pfg.unitNum},dataType='{pfg.dataType}',oldData='{pfg.oldData}',data='{pfg.data}',remark='{pfg.remark}',address='{pfg.address}',paramId='{pfg.paramId}' where name='{pfg.name}'";

            //return mysql.ExecuteNonQuery(sql);
            string sql = "update plcconfig set unitNum=@unitNum,dataType=@dataType,oldData=@oldData,data=@data,remark=@remark,address=@address,paramId=@paramId where name=@name";

            return mysql.ExecuteNonQuery(sql,
                new MySqlParameter("@name", pfg.name), new MySqlParameter("@data", pfg.data),
                new MySqlParameter("@oldData", pfg.oldData), new MySqlParameter("@dataType", pfg.dataType),
                new MySqlParameter("@address", pfg.address), new MySqlParameter("@unitNum", pfg.unitNum),
                new MySqlParameter("@paramId", pfg.paramId), new MySqlParameter("@remark", pfg.remark));
        }

        public PlcConfig GetPlcConfig(Dictionary<string, string> dr)
        {
            PlcConfig item = new PlcConfig();
            item.id = int.Parse(dr["id"]);
            item.parentId = int.Parse(dr["parentId"]);
            item.name = dr["name"].ToString();
            item.data = dr["data"].ToString();
            item.oldData = dr["oldData"].ToString();
            item.unitNum = int.Parse(dr["unitNum"]);
            item.dataType = dr["dataType"].ToString();
            item.address = dr["address"].ToString();
            item.paramId = dr["paramId"].ToString();
            item.remark = dr["remark"].ToString();
            return item;
        }

    }
}
