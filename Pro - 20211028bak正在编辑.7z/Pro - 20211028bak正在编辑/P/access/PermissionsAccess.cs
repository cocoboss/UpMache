﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProModel;

namespace ProDAL
{
    public class PermissionsAccess:BaseAccess
    {
        //SqlHelper mysql;
        //public PermissionsAccess()
        //{
        //    mysql = new SqlHelper();
        //}
        public List<Permissions> GetBand()
        {
            string sql = $"select * from permissions where parentID=0 group by parentOrder asc";
            return Select(sql);
        }
        public List<Permissions> GetBarItem()
        {
            string sql = $"select * from permissions where parentID!=0 order by childOrder asc";
            return Select(sql);
        }
        public List<Permissions> SelectAll()
        {
            string sql = $"select * from permissions";
            return Select(sql);
        }

        public List<Permissions> Select(string sql)
        {
            List<Dictionary<string, string>> drs = mysql.ExecuteReader(sql);
            List<Permissions> lst = new List<Permissions>();
            if (drs.Count > 0)
            {
                for (int i = 0; i < drs.Count; i++)
                {
                    Permissions temp = GetPermissions(drs[i]);
                    lst.Add(temp);
                }
            }
            else
            {
                lst = null;
            }
            return lst;
        }
        public Permissions GetPermissions(Dictionary<string, string> dr)
        {
            Permissions item = new Permissions();
            item.id = int.Parse(dr["id"]);
            item.name = dr["name"].ToString();
            item.parentID = int.Parse(dr["parentID"]);
            item.parentOrder = int.Parse(dr["parentOrder"]);
            item.childOrder = int.Parse(dr["childOrder"]);
            item.code = dr["code"].ToString();
            item.description = dr["description"].ToString();
            item.remark = dr["remark"].ToString();
            return item;
        }
       
    }
}
