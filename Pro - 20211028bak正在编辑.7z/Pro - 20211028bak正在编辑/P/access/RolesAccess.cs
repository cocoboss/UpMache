﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProModel;
using MySql.Data.MySqlClient;

namespace ProDAL
{
    public class RolesAccess:BaseAccess
    {
        public Roles SelectFromName(string name)
        {
            string sql = $"select * from roles where name=@name";
            List<Dictionary<string, string>> drs = mysql.ExecuteReader(sql,new MySqlParameter("@name", name));
            Roles temp;
            if (drs.Count > 0)
                temp = GetRoles(drs[0]);
            else
                temp = null;
            return temp;
        }
        public Roles SelectFromId(int id)
        {
            string sql = $"select * from roles where groupID=@id";
            List<Dictionary<string, string>> drs = mysql.ExecuteReader(sql, new MySqlParameter("@id", id));
            Roles temp;
            if (drs.Count > 0)
                temp = GetRoles(drs[0]);
            else
                temp = null;
            return temp;
        }

        public int Update(string right,string name)
        {
            string sql= $"update roles set rights='{right}' where name='{name}'";
            return mysql.ExecuteNonQuery(sql);
        }
        public List<Roles> SelectAll()
        {
            string sql = $"select * from roles";
            List<Dictionary<string, string>> drs = mysql.ExecuteReader(sql);
            List< Roles> lRoles = new List< Roles>();
            if(drs.Count>0)
            {
                for(int i=0;i<drs.Count;i++)
                {
                    Roles temp = GetRoles(drs[i]);
                    lRoles.Add(temp);
                }
            }else
            {
                lRoles = null;
            }
            return lRoles;
        }

        public int Insert(string role)
        {
            if (string.IsNullOrEmpty(role))
                return -1;
            //string sql = "insert into roles(name,right,mesOrLocal,createOper,createTime,remark) values('@name','@right',@mesOrLocal,'@createOper','@createTime','@remark')";
            string sql = "insert into roles(name) values(@name)";
            return mysql.ExecuteNonQuery(sql, 
                //new MySqlParameter("@name", role.name),
                //new MySqlParameter("@right", role.right),
                //new MySqlParameter("@mesOrLocal", role.mesOrLocal),
                //new MySqlParameter("@createOper", role.createOper),
                //new MySqlParameter("@createTime", role.createTime),
                new MySqlParameter("@name", role));
        }
        public Roles GetRoles(Dictionary<string, string> dr)
        {
            Roles item = new Roles();
            item.groupID = int.Parse(dr["groupID"]);
            item.name = dr["name"].ToString();
            item.rights = dr["rights"].ToString();
            item.mesOrLocal = int.Parse(dr["mesOrLocal"]);
            item.createOper = dr["createOper"].ToString();
            item.updateOper = dr["updateOper"].ToString();
            item.createTime = dr["createTime"].ToString();
            item.updateTime = dr["updateTime"].ToString();
            item.remark = dr["remark"].ToString();
            return item;
        }
    }
}
