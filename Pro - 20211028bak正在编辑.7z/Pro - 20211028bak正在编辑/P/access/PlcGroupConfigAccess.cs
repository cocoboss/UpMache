﻿using ProModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProDAL
{
    public class PlcGroupConfigAccess:BaseAccess
    {
        public List<PlcGroupConfig> SelectAll()
        {
            string sql = $"select * from plcgroupconfig";
            List<Dictionary<string, string>> drs = mysql.ExecuteReader(sql);
            List<PlcGroupConfig> lst = new List<PlcGroupConfig>();
            if (drs.Count > 0)
            {
                for (int i = 0; i < drs.Count; i++)
                {
                    PlcGroupConfig temp = GetPlcGroup(drs[i]);
                    lst.Add(temp);
                }
            }
            else
            {
                lst = null;
            }
            return lst;
        }
        public PlcGroupConfig GetPlcGroup(Dictionary<string, string> dr)
        {
            PlcGroupConfig item = new PlcGroupConfig();
            item.groupId = int.Parse(dr["groupId"]);
            item.name = dr["name"].ToString();
            item.startAddr = dr["startAddr"].ToString();
            item.leng = int.Parse(dr["leng"]);
            item.remark = dr["remark"].ToString();
            item.isRemark = int.Parse(dr["isRemark"]);
            return item;
        }
    }
}
