﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProModel;
using MySql.Data.MySqlClient;

namespace ProDAL
{
    public class DefineVariableAccess: BaseAccess
    {
        public List<DefineVariable> SelectAll()
        {
            string sql = $"select * from definevariable";
            List<Dictionary<string, string>> drs = mysql.ExecuteReader(sql);
            List<DefineVariable> lst = new List<DefineVariable>();
            if (drs.Count > 0)
            {
                for (int i = 0; i < drs.Count; i++)
                {
                    DefineVariable temp = GetPlcGroup(drs[i]);
                    lst.Add(temp);
                }
            }
            else
            {
                lst = null;
            }
            return lst;
        }

        public int Update(string sysKey,string sysVal)
        {
            //string sql = $"update plcconfig set unitNum={pfg.unitNum},dataType='{pfg.dataType}',oldData='{pfg.oldData}',data='{pfg.data}',remark='{pfg.remark}',address='{pfg.address}',paramId='{pfg.paramId}' where name='{pfg.name}'";

            //return mysql.ExecuteNonQuery(sql);
            string sql = "update definevariable set sysVal=@value where sysKey=@key";

            return mysql.ExecuteNonQuery(sql,
                new MySqlParameter("@value", sysVal), new MySqlParameter("@key", sysKey));
                //new MySqlParameter("@oldData", pfg.oldData), new MySqlParameter("@dataType", pfg.dataType),
                //new MySqlParameter("@address", pfg.address), new MySqlParameter("@unitNum", pfg.unitNum),
                //new MySqlParameter("@paramId", pfg.paramId), new MySqlParameter("@remark", pfg.remark));
        }
        public int Add(string key)
        {
            string sql = "insert into definevariable(sysKey) values(@key)";

            return mysql.ExecuteNonQuery(sql,
                //new MySqlParameter("@name", name), new MySqlParameter("@pwd", pwd),
                new MySqlParameter("@key", key));
        }


        public DefineVariable GetPlcGroup(Dictionary<string, string> dr)
        {
            DefineVariable item = new DefineVariable();
            item.id = int.Parse(dr["id"]);
            item.sysKey = dr["sysKey"].ToString();
            item.sysVal = dr["sysVal"].ToString();
            item.remark = dr["remark"].ToString();
            item.description = dr["description"].ToString();
            return item;
        }
    }
}
