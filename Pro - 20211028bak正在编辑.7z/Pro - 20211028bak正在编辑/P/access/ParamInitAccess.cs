﻿using MySql.Data.MySqlClient;
using ProModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace ProDAL
{
    public class ParamInitAccess:BaseAccess
    {
        public List<ParamInit> SelectAll()
        {
            string sql = $"select * from paraminit";
            List<Dictionary<string, string>> drs = mysql.ExecuteReader(sql);
            List<ParamInit> lst = new List<ParamInit>();
            if (drs.Count > 0)
            {
                for (int i = 0; i < drs.Count; i++)
                {
                    ParamInit temp = GetParamInit(drs[i]);
                    lst.Add(temp);
                }
            }
            else
            {
                lst = null;
            }
            return lst;
        }
        //public IList<ParamInit> GetAll()
        //{
        //    string sql = $"select * from paraminit";
        //    mysql.q
        //}
        public int Update(ParamInit pfg)
        {
            //string sql = $"update plcconfig set unitNum={pfg.unitNum},dataType='{pfg.dataType}',oldData='{pfg.oldData}',data='{pfg.data}',remark='{pfg.remark}',address='{pfg.address}',paramId='{pfg.paramId}' where name='{pfg.name}'";
            //update paraminit set json='hh' where processCode='test'
            //return mysql.ExecuteNonQuery(sql);
            string sql = $"update paraminit set isable={pfg.isable},remark='{pfg.remark}',employe='{pfg.employe}',entime='{pfg.entime}',json='{pfg.json}' where processCode='{pfg.processCode}'";

            return mysql.ExecuteNonQuery(sql);
                //new MySqlParameter("@json", pfg.json), new MySqlParameter("@employe", pfg.employe),
                //new MySqlParameter("@enable", pfg.isable), new MySqlParameter("@processCode", pfg.processCode),
                ////new MySqlParameter("@address", pfg.address), new MySqlParameter("@unitNum", pfg.unitNum),
                //new MySqlParameter("@datetime", pfg.entime), new MySqlParameter("@remark", pfg.remark));
        }

        public int Add(ParamInit pfg)
        {
            //string sql = $"update plcconfig set unitNum={pfg.unitNum},dataType='{pfg.dataType}',oldData='{pfg.oldData}',data='{pfg.data}',remark='{pfg.remark}',address='{pfg.address}',paramId='{pfg.paramId}' where name='{pfg.name}'";
            //update paraminit set json='hh' where processCode='test'
            //return mysql.ExecuteNonQuery(sql);
            //string sql = "update paraminit set json=@json,enable=@enable,remark=@remark,employe=@employe,datetime=@datetime where processCode=@processCode";
            string sql = $"insert into paraminit(processCode,employe,isable,entime,remark,json) values('{pfg.processCode}','{pfg.employe}',{pfg.isable},'{pfg.entime}','{pfg.remark}','{pfg.json}')";

            return mysql.ExecuteNonQuery(sql);
                //new MySqlParameter("@json", pfg.json), new MySqlParameter("@employe", pfg.employe),
                //new MySqlParameter("@isable", pfg.isable), new MySqlParameter("@processCode", pfg.processCode),
                ////new MySqlParameter("@address", pfg.address), new MySqlParameter("@unitNum", pfg.unitNum),
                //new MySqlParameter("@entime", pfg.entime), new MySqlParameter("@remark", pfg.remark));
        }

        public ParamInit GetParamInit(Dictionary<string, string> dr)
        {
            ParamInit item = new ParamInit();
            item.id = int.Parse(dr["id"]);
            item.processCode = dr["processCode"].ToString();
            item.json = dr["json"].ToString();
            item.isable = int.Parse(dr["isable"]);
            item.remark = dr["remark"].ToString();
            item.employe = dr["employe"].ToString();
            item.entime = dr["entime"].ToString();
            //item.updateTime = dr["updateTime"].ToString();
            //item.remark = dr["remark"].ToString();
            return item;
        }
    }
}
