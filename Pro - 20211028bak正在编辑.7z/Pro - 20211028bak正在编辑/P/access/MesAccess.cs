﻿using Apriso.MIPlugins.Communication.Clients.WcfServiceAPI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProModel;
using Newtonsoft.Json;

namespace ProDAL
{
    public static class MesAccess
    {
        //public MessageRequest request = null;
        //public MessageResponse response = null;

        public static T FormJson<T>(this string json)
        {
            try
            {
                return JsonConvert.DeserializeObject<T>(json);
            }
            catch (Exception ex)
            {
                string strMsg = ex.Message + "\r\n" + ex.StackTrace;
                LogHelper.WriteExceptionLog(strMsg);
                return default(T);
            }
        }
        public static string ToJSON(this object o)
        {
            if (o == null)
            {
                return null;
            }
            return JsonConvert.SerializeObject(o);
        }
        #region ACEQPTINIT

       
        public static MessageResponse GetACEQPTINITMessageResponse(Guid guid,string json="")
        {

            ACEQPTINIT.ACEQPTINITResponse item = new ACEQPTINIT.ACEQPTINITResponse(guid,string.IsNullOrEmpty(json) ? null : FormJson<ACEQPTINIT.ACEQPTINITResponseJson>(json));
            MessageResponse ret = new MessageResponse();
            ret.CommandId = item.CommandId;


            ret.CommandResponseJson = ToJSON(item.CommandResponseJson);
            ret.MessageGuid = item.MessageGuid;
            ret.ResponseDate = item.ResponseDate;
            ret.ErrorCode = item.ErrorCode;
            ret.ErrorMessage = item.ErrorMessage;
            ret.Success = item.Success;
            return ret;
        }
        public static ACEQPTINIT.ACEQPTINITRequest SetACEQPTINITRequest(string json)
        {
            MessageRequest rqt = MesAccess.FormJson<MessageRequest>(json);

            ACEQPTINIT.ACEQPTINITRequest itemRequest = new ACEQPTINIT.ACEQPTINITRequest();
            itemRequest.CommandId = rqt.CommandId;
            itemRequest.CommandRequestJson = MesAccess.FormJson<ACEQPTINIT.ACEQPTINITRequestJson>(rqt.CommandRequestJson);
            itemRequest.MessageGuid = rqt.MessageGuid;
            itemRequest.RequestDate = rqt.RequestDate;
            return itemRequest;
        }


        #endregion


        #region ACEQPTALRT

        public static ACEQPTALRT.ACEQPTALRTRequestJson SetACEQPTALRTRequestJson(Dictionary<string, string> item, List<ACEQPTALRT.ACEQPTALRTRequestAlertInfo> infoAlarm)
        {
            ACEQPTALRT.ACEQPTALRTRequestJson json = new ACEQPTALRT.ACEQPTALRTRequestJson();
            json.AutoFlag = true;
            json.Software = item["Software"];
            json.EmployeeNo = item["EmployeeNo"];
            json.EquipmentInfo.Clear();
            ACEQPTALRT.ACEQPTALRTRequestEquipmentInfo info = new ACEQPTALRT.ACEQPTALRTRequestEquipmentInfo();
            info.EquipmentCode = item["EquipmentCode"];
            info.AlertInfo.Clear();
            //info.AlertInfo.Add(new ACEQPTALRT.ACEQPTALRTRequestAlertInfo()
            //{
            //    AlertCode = item["AlertCode"],
            //    AlertReset = item["AlertReset"],
            //    AlertDescription = item["AlertDescription"],
            //    AlertLevel = item["AlertLevel"],
            //    AlertCount = item["AlertCount"],
            //});
            info.AlertInfo.AddRange(infoAlarm);
            json.EquipmentInfo.Add(info);

            return json;
        }

        public static MessageRequest GetACEQPTALRTRequest(string  json = "")
        {
            //ACEQPTALRT.request = new ACEQPTALRT.ACEQPTALRTRequest(FormJson<ACEQPTALRT.ACEQPTALRTRequestJson>(json));
            //return FormJson<MessageRequest> (ACEQPTALRT.request.ToJSON());

            ACEQPTALRT.ACEQPTALRTRequest item = new ACEQPTALRT.ACEQPTALRTRequest(string.IsNullOrEmpty(json) ? null : FormJson<ACEQPTALRT.ACEQPTALRTRequestJson>(json));
            ACEQPTALRT.request = item;
            MessageRequest ret = new MessageRequest();
            ret.CommandId = item.CommandId;
            ret.CommandRequestJson = item.CommandRequestJson.ToJSON();
            ret.MessageGuid = item.MessageGuid;
            ret.RequestDate = item.RequestDate;
            return ret;
        }
        public static ACEQPTALRT.ACEQPTALRTResponse SetACEQPTALRTResponse(MessageResponse item)
        {
            ACEQPTALRT.ACEQPTALRTResponse ret = new ACEQPTALRT.ACEQPTALRTResponse();
            ret.CommandId = item.CommandId;
            ret.CommandResponseJson = FormJson<ACEQPTALRT.ACEQPTALRTResponseJson>(item.CommandResponseJson);
            ret.MessageGuid = item.MessageGuid;
            ret.ResponseDate = item.ResponseDate;
            ret.ErrorCode = item.ErrorCode;
            ret.ErrorMessage = item.ErrorMessage;
            ret.Success = item.Success;
            ACEQPTALRT.response = ret;
            return ret;
        }

        #endregion

        #region ACEQPTCONN

        public static ACEQPTCONN.ACEQPTCONNRequestJson SetACEQPTCONNRequestJson(Dictionary<string, string> item)
        {
            ACEQPTCONN.ACEQPTCONNRequestJson json = new ACEQPTCONN.ACEQPTCONNRequestJson();
            json.AutoFlag = true;
            json.Software = item["Software"];
            json.EquipmentInfo.Clear();
            json.EquipmentInfo.Add(new ACEQPTCONN.ACEQPTCONNRequestEquipmentInfo()
            {
                EquipmentCode = item["EquipmentCode"],
            });
            
            return json;
        }

        public static MessageRequest GetACEQPTCONNRequest(string json="")
        {

            ACEQPTCONN.ACEQPTCONNRequest item = new ACEQPTCONN.ACEQPTCONNRequest(string.IsNullOrEmpty(json) ? null : FormJson<ACEQPTCONN.ACEQPTCONNRequestJson>(json));
            ACEQPTCONN.request = item;
            MessageRequest ret = new MessageRequest();
            ret.CommandId = item.CommandId;
            ret.CommandRequestJson = item.CommandRequestJson.ToJSON();
            ret.MessageGuid = item.MessageGuid;
            ret.RequestDate = item.RequestDate;
            return ret;
        }
        public static ACEQPTCONN.ACEQPTCONNResponse SetACEQPTCONNResponse(MessageResponse item)
        {
            ACEQPTCONN.ACEQPTCONNResponse ret = new ACEQPTCONN.ACEQPTCONNResponse();
            ret.CommandId = item.CommandId;
            ret.CommandResponseJson = FormJson<ACEQPTCONN.ACEQPTCONNResponseJson> (item.CommandResponseJson);
            ret.MessageGuid = item.MessageGuid;
            ret.ResponseDate = item.ResponseDate;
            ret.ErrorCode = item.ErrorCode;
            ret.ErrorMessage = item.ErrorMessage;
            ret.Success = item.Success;
            ACEQPTCONN.response = ret;
            return ret;
        }
        #endregion
        #region ACEQPTSTUS

        public static ACEQPTSTUS.ACEQPTSTUSRequestJson SetACEQPTSTUSRequestJson(Dictionary<string, string> item)
        {
            ACEQPTSTUS.ACEQPTSTUSRequestJson json = new ACEQPTSTUS.ACEQPTSTUSRequestJson();
            json.AutoFlag = true;
            json.Software = item["Software"];
            json.EmployeeNo = item["EmployeeNo"];
            json.EquipmentInfo.Clear();
            json.EquipmentInfo.Add(new ACEQPTSTUS.ACEQPTSTUSRequestEquipmentInfo()
            {
                EquipmentCode = item["EquipmentCode"],
                OpFlag = item["OpFlag"],
                Location = item["Location"],
                EquipmentModel = item["EquipmentModel"],
                EquipmentStatusID = item["EquipmentStatusID"],
                ReasonCode = item["ReasonCode"],
                Description = item["Description"],
            });
            
            return json;
        }


        public static MessageRequest GetACEQPTSTUSRequest(string json = "")
        {
            //ACEQPTSTUS.request = new ACEQPTSTUS.ACEQPTSTUSRequest(FormJson<ACEQPTSTUS.ACEQPTSTUSRequestJson>(json));
            //return FormJson<MessageRequest>(ACEQPTALRT.request.ToJSON());

            ACEQPTSTUS.ACEQPTSTUSRequest item = new ACEQPTSTUS.ACEQPTSTUSRequest(string.IsNullOrEmpty(json) ? null : FormJson<ACEQPTSTUS.ACEQPTSTUSRequestJson>(json));
            ACEQPTSTUS.request = item;
            MessageRequest ret = new MessageRequest();
            ret.CommandId = item.CommandId;
            ret.CommandRequestJson = item.CommandRequestJson.ToJSON();
            ret.MessageGuid = item.MessageGuid;
            ret.RequestDate = item.RequestDate;
            return ret;

        }


        public static ACEQPTSTUS.ACEQPTSTUSResponse SetACEQPTSTUSResponse(MessageResponse item)
        {
            ACEQPTSTUS.ACEQPTSTUSResponse ret = new ACEQPTSTUS.ACEQPTSTUSResponse();
            ret.CommandId = item.CommandId;
            ret.CommandResponseJson = FormJson<ACEQPTSTUS.ACEQPTSTUSResponseJson>(item.CommandResponseJson);
            ret.MessageGuid = item.MessageGuid;
            ret.ResponseDate = item.ResponseDate;
            ret.ErrorCode = item.ErrorCode;
            ret.ErrorMessage = item.ErrorMessage;
            ret.Success = item.Success;
            ACEQPTSTUS.response = ret;
            return ret;
        }

        #endregion


        #region ACEQUPTRUN

        public static ACEQUPTRUN.ACEQUPTRUNRequestJson SetACEQUPTRUNRequestJson(Dictionary<string, string> item)
        {
            ACEQUPTRUN.ACEQUPTRUNRequestJson json = new ACEQUPTRUN.ACEQUPTRUNRequestJson();
            json.AutoFlag = true;
            json.Software = item["Software"];
            json.EmployeeNo = item["EmployeeNo"];
            json.EquipmentInfo.Clear();
            json.EquipmentInfo.Add(new ACEQUPTRUN.ACEQUPTRUNRequestEquipmentInfo()
            {
                EquipmentCode = item["EquipmentCode"],
                StateCode = item["StateCode"],
                EquipmentModel = item["EquipmentModel"],
            });
            
            return json;
        }


        public static MessageRequest GetACEQUPTRUNRequest(string json = "")
        {

            ACEQUPTRUN.ACEQUPTRUNRequest item = new ACEQUPTRUN.ACEQUPTRUNRequest(string.IsNullOrEmpty(json) ? null : FormJson<ACEQUPTRUN.ACEQUPTRUNRequestJson>(json));
            ACEQUPTRUN.request = item;
            MessageRequest ret = new MessageRequest();
            ret.CommandId = item.CommandId;
            ret.CommandRequestJson = item.CommandRequestJson.ToJSON();
            ret.MessageGuid = item.MessageGuid;
            ret.RequestDate = item.RequestDate;
            return ret;
        }
        public static ACEQUPTRUN.ACEQUPTRUNResponse SetACEQUPTRUNResponse(MessageResponse item)
        {
            ACEQUPTRUN.ACEQUPTRUNResponse ret = new ACEQUPTRUN.ACEQUPTRUNResponse();
            ret.CommandId = item.CommandId;
            ret.CommandResponseJson = FormJson<ACEQUPTRUN.ACEQUPTRUNResponseJson>(item.CommandResponseJson);
            ret.MessageGuid = item.MessageGuid;
            ret.ResponseDate = item.ResponseDate;
            ret.ErrorCode = item.ErrorCode;
            ret.ErrorMessage = item.ErrorMessage;
            ret.Success = item.Success;
            ACEQUPTRUN.response = ret;
            return ret;
        }

        #endregion

        #region ACLOGOFF

        public static ACLOGOFF.ACLOGOFFRequestJson SetACLOGOFFRequestJson(Dictionary<string, string> item, List<ACLOGOFF.ACLOGOFFRequestParameters> offParams)
        {
            ACLOGOFF.ACLOGOFFRequestJson json = new ACLOGOFF.ACLOGOFFRequestJson();
            json.AutoFlag = true;
            json.Software = item["Software"];
            json.EmployeeNo = item["EmployeeNo"];
            json.EquipmentInfo.Clear();
            ACLOGOFF.ACLOGOFFRequestEquipmentInfo info = new ACLOGOFF.ACLOGOFFRequestEquipmentInfo();
            info.EquipmentCode = item["EquipmentCode"];
            info.OpFlag = item["OpFlag"];
            info.Container = item["Container"];
            info.ProcessMessage = item["ProcessMessage"];
            info.ProcessResult = true;
            info.Outputs.Clear();
            ACLOGOFF.ACLOGOFFRequestOutputs outputs = new ACLOGOFF.ACLOGOFFRequestOutputs();
            outputs.SerialNo = item["SerialNo"];
            outputs.PreSerialNo = item["PreSerialNo"];
            outputs.SlotID = item["SlotID"];
            outputs.ProductType = item["ProductType"];
            outputs.PassFlag = true;
            outputs.ProcessFlag = item["ProcessFlag"];
            outputs.IsRealFlag = true;
            outputs.CounterfeitFlag = true;
            outputs.StationInfo.Clear();
            outputs.SpartInfo.Clear();
            outputs.MaterialInfo.Clear();
            outputs.Parameters.Clear();
            outputs.StationInfo.Add(new ACLOGOFF.ACLOGOFFRequestStationInfo()
            {
                StationID = !string.IsNullOrEmpty(item["StationID"]) ? item["StationID"] : "",
                StepID = !string.IsNullOrEmpty(item["StepID"]) ? item["StepID"] : "",

            });
            //outputs.SpartInfo.Add(new ACLOGOFF.ACLOGOFFRequestSpartInfo()
            //{
            //});
            //outputs.MaterialInfo.Add(new ACLOGOFF.ACLOGOFFRequestMaterialInfo()
            //{
            //    Quantity = !string.IsNullOrEmpty(item["Quantity"]) ? item["Quantity"] : "",
            //    LotNo = !string.IsNullOrEmpty(item["LotNo"]) ? item["LotNo"] : "",
            //    ProductNo = !string.IsNullOrEmpty(item["ProductNo"]) ? item["ProductNo"] : "",
            //    UomCode = !string.IsNullOrEmpty(item["UomCode"]) ? item["UomCode"] : "",
            //    SerialNo = !string.IsNullOrEmpty(item["SerialNo"]) ? item["SerialNo"] : "",
            //    ProductDesc = !string.IsNullOrEmpty(item["ProductDesc"]) ? item["ProductDesc"] : "",
            //    LabelNo = !string.IsNullOrEmpty(item["LabelNo"]) ? item["LabelNo"] : "",
            //    ProductID = !string.IsNullOrEmpty(item["ProductID"]) ? item["ProductID"] : "",
            //});
            outputs.Parameters.AddRange(offParams);
            //outputs.Parameters.Add(new ACLOGOFF.ACLOGOFFRequestParameters()
            //{
            //    TargetValue = item["TargetValue"],
            //    ParamterCode = item["ParamterCode"],
            //    Location = item["Location"],
            //    Value = item["Value"],
            //    ParameterDescription = item["ParameterDescription"],
            //    UpperLimit = item["UpperLimit"],
            //    LowerLomit = item["LowerLomit"],
            //    ParameterResult = item["ParameterResult"],
            //    DefectCode = item["DefectCode"],
            //    ParameterMessage = item["ParameterMessage"],
            //});

            info.Outputs.Add(outputs);
            json.EquipmentInfo.Add(info);
            
            return json;
        }


        public static MessageRequest GetACLOGOFFRequest(string json = "")
        {

            ACLOGOFF.ACLOGOFFRequest item = new ACLOGOFF.ACLOGOFFRequest(string.IsNullOrEmpty(json) ? null : FormJson<ACLOGOFF.ACLOGOFFRequestJson>(json));
            ACLOGOFF.request = item;
            MessageRequest ret = new MessageRequest();
            ret.CommandId = item.CommandId;
            ret.CommandRequestJson = item.CommandRequestJson.ToJSON();
            ret.MessageGuid = item.MessageGuid;
            ret.RequestDate = item.RequestDate;
            return ret;
        }
        public static ACLOGOFF.ACLOGOFFResponse SetACLOGOFFResponse(MessageResponse item)
        {
            ACLOGOFF.ACLOGOFFResponse ret = new ACLOGOFF.ACLOGOFFResponse();
            ret.CommandId = item.CommandId;
            ret.CommandResponseJson = FormJson<ACLOGOFF.ACLOGOFFResponseJson>(item.CommandResponseJson);
            ret.MessageGuid = item.MessageGuid;
            ret.ResponseDate = item.ResponseDate;
            ret.ErrorCode = item.ErrorCode;
            ret.ErrorMessage = item.ErrorMessage;
            ret.Success = item.Success;
            ACLOGOFF.response = ret;
            return ret;
        }
        #endregion

        #region ACLOGONCHECK
        public static ACLOGONCHECK.ACLOGONCHECKRequestJson SetACLOGONCHECKRequestJson(Dictionary<string, string> item)
        {
            ACLOGONCHECK.ACLOGONCHECKRequestJson json = new ACLOGONCHECK.ACLOGONCHECKRequestJson();
            json.AutoFlag = true;
            json.Software = item["Software"];
            json.EmployeeNo = item["EmployeeNo"];
            json.EquipmentInfo.Clear();

            ACLOGONCHECK.ACLOGONCHECKRequestEquipmentInfo info = new ACLOGONCHECK.ACLOGONCHECKRequestEquipmentInfo();
            info.EquipmentCode = item["EquipmentCode"];
            info.OpFlag = item["OpFlag"];
            info.Container = item["Container"];
            info.RequestType = item["RequestType"];
            info.SerialNos.Clear();
            //json.EquipmentInfo = new List<ACUSERINFO.ACUSERINFORequestEquipmentInfo>();
            info.SerialNos.Add(new ACLOGONCHECK.ACLOGONCHECKSerialNos()
            {
                SerialNo = item["SerialNo"],
                SlotID = item["SlotID"],
            });
            json.EquipmentInfo.Add(info);
           
            return json;
        }
        public static MessageRequest GetACLOGONCHECKRequest(string json = "")
        {

            ACLOGONCHECK.ACLOGONCHECKRequest item = new ACLOGONCHECK.ACLOGONCHECKRequest(string.IsNullOrEmpty(json) ? null : FormJson<ACLOGONCHECK.ACLOGONCHECKRequestJson>(json));
            ACLOGONCHECK.request = item;
            MessageRequest ret = new MessageRequest();
            ret.CommandId = item.CommandId;
            ret.CommandRequestJson = item.CommandRequestJson.ToJSON();
            ret.MessageGuid = item.MessageGuid;
            ret.RequestDate = item.RequestDate;
            return ret;
        }
        public static ACLOGONCHECK.ACLOGONCHECKResponse SetACLOGONCHECKResponse(MessageResponse item)
        {
            ACLOGONCHECK.ACLOGONCHECKResponse ret = new ACLOGONCHECK.ACLOGONCHECKResponse();
            ret.CommandId = item.CommandId;
            ret.CommandResponseJson = FormJson<ACLOGONCHECK.ACLOGONCHECKResponseJson>(item.CommandResponseJson);
            ret.MessageGuid = item.MessageGuid;
            ret.ResponseDate = item.ResponseDate;
            ret.ErrorCode = item.ErrorCode;
            ret.ErrorMessage = item.ErrorMessage;
            ret.Success = item.Success;
            ACLOGONCHECK.response = ret;
            return ret;
        }
        #endregion


        #region ACUSERINFO

        public static ACUSERINFO.ACUSERINFORequestJson SetACUSERINFORequestJson(Dictionary<string,string> item)
        {
            ACUSERINFO.ACUSERINFORequestJson json = new ACUSERINFO.ACUSERINFORequestJson();
            json.AutoFlag = true;
            json.Software = item["Software"];
            json.EmployeeNo = item["EmployeeNo"];
            json.EquipmentInfo.Clear();
            //json.EquipmentInfo = new List<ACUSERINFO.ACUSERINFORequestEquipmentInfo>();
            json.EquipmentInfo.Add(new ACUSERINFO.ACUSERINFORequestEquipmentInfo()
            {
                EquipmentCode = item["EquipmentCode"],
                EmployeeNo = item["EmployeeNo"],
                Password = item["Password"],
                RoleID = item["RoleID"],
            });
          
            return json;
        }

        public static MessageRequest GetACUSERINFORequest(string json = "")
        {

            ACUSERINFO.ACUSERINFORequest item = new ACUSERINFO.ACUSERINFORequest(string.IsNullOrEmpty(json) ? null : FormJson<ACUSERINFO.ACUSERINFORequestJson>(json));
            ACUSERINFO.request = item;
            MessageRequest ret = new MessageRequest();
            ret.CommandId = item.CommandId;
            ret.CommandRequestJson = item.CommandRequestJson.ToJSON();
            ret.MessageGuid = item.MessageGuid;
            ret.RequestDate = item.RequestDate;
            return ret;
        }
        public static ACUSERINFO.ACUSERINFOResponse SetACUSERINFOResponse(MessageResponse item)
        {
            ACUSERINFO.ACUSERINFOResponse ret = new ACUSERINFO.ACUSERINFOResponse();
            ret.CommandId = item.CommandId;
            ret.CommandResponseJson = FormJson<ACUSERINFO.ACUSERINFOResponseJson>(item.CommandResponseJson);
            ret.MessageGuid = item.MessageGuid;
            ret.ResponseDate = item.ResponseDate;
            ret.ErrorCode = item.ErrorCode;
            ret.ErrorMessage = item.ErrorMessage;
            ret.Success = item.Success;
            ACUSERINFO.response = ret;
            return ret;
        }
        #endregion

        #region ACEQPTPARM

        public static ACEQPTPARM.ACEQPTPARMRequestJson SetACEQPTPARMRequestJson(Dictionary<string, string> item)
        {
            ACEQPTPARM.ACEQPTPARMRequestJson json = new ACEQPTPARM.ACEQPTPARMRequestJson();
            json.AutoFlag = true;
            json.Software = item["Software"];
            json.EmployeeNo = item["EmployeeNo"];
            json.EquipmentInfo.Clear();
            //json.EquipmentInfo = new List<ACUSERINFO.ACUSERINFORequestEquipmentInfo>();
            json.EquipmentInfo.Add(new ACEQPTPARM.ACEQPTPARMRequestEquipmentInfo()
            {
                EquipmentCode = item["EquipmentCode"],
                Version = item["Version"],
                ProcessCode = item["ProcessCode"],
                //RoleID = item["RoleID"],
            });
          
            return json;
        }

        public static MessageRequest GetACEQPTPARMRequest(string json = "")
        {

            ACEQPTPARM.ACEQPTPARMRequest item = new ACEQPTPARM.ACEQPTPARMRequest(string.IsNullOrEmpty(json) ? null : FormJson<ACEQPTPARM.ACEQPTPARMRequestJson>(json));
            ACEQPTPARM.request = item;
            MessageRequest ret = new MessageRequest();
            ret.CommandId = item.CommandId;
            ret.CommandRequestJson = item.CommandRequestJson.ToJSON();
            ret.MessageGuid = item.MessageGuid;
            ret.RequestDate = item.RequestDate;
            return ret;
        }
        public static ACEQPTPARM.ACEQPTPARMResponse SetACEQPTPARMResponse(MessageResponse item)
        {
            ACEQPTPARM.ACEQPTPARMResponse ret = new ACEQPTPARM.ACEQPTPARMResponse();
            ret.CommandId = item.CommandId;
            ret.CommandResponseJson = FormJson<ACEQPTPARM.ACEQPTPARMResponseJson>(item.CommandResponseJson);
            ret.MessageGuid = item.MessageGuid;
            ret.ResponseDate = item.ResponseDate;
            ret.ErrorCode = item.ErrorCode;
            ret.ErrorMessage = item.ErrorMessage;
            ret.Success = item.Success;
            ACEQPTPARM.response = ret;
            return ret;
        }
        #endregion

        //public static MessageRequest GetACEQPTALRTRequest(string json)
        //{
        //    ACEQPTALRT.request = new ACEQPTALRT.ACEQPTALRTRequest(FormJson<ACEQPTALRT.ACEQPTALRTRequestJson>(json));
        //    return FormJson<MessageRequest>(ACEQPTALRT.request.ToJSON());
        //}

    }
}
