﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProModel;
using MySql.Data.MySqlClient;
using System.Data;

namespace ProDAL
{
    public class ProdectionDataAccess:BaseAccess
    {
        public List<ProdectionData> SelectAll()
        {
            string sql = $"select * from prodectiondata";
            List<Dictionary<string, string>> drs = mysql.ExecuteReader(sql);
            List<ProdectionData> lst = new List<ProdectionData>();
            if (drs.Count > 0)
            {
                for (int i = 0; i < drs.Count; i++)
                {
                    ProdectionData temp = GetPlcGroup(drs[i]);
                    lst.Add(temp);
                }
            }
            else
            {
                lst = null;
            }
            return lst;
        }


        public DataTable SelectData(string sql)
        {
            return mysql.DataAdapter(sql);
        }
        public int Delete(string dateTime)
        {
            //delete from  prodectiondata where out_time<'2021-10-30 20:43:16' order by id asc limit 2
            string sql = "delete from  prodectiondata where out_time<@out_time order by out_time asc limit 1000";

            return mysql.ExecuteNonQuery(sql,
                new MySqlParameter("@out_time", dateTime));
        }
        public int Insert(string barCode,string in_result,string in_message,string model,string time)
        {
            if (string.IsNullOrEmpty(barCode))
                return -1;
            //string sql = "insert into roles(name,right,mesOrLocal,createOper,createTime,remark) values('@name','@right',@mesOrLocal,'@createOper','@createTime','@remark')";
            string sql = $"insert into prodectiondata(barCode,in_result,in_message,model,in_time) values('{barCode}','{in_result}','{in_message}','{model}','{time}')";
            return mysql.ExecuteNonQuery(sql);
                //new MySqlParameter("@barCode", barCode),
                //new MySqlParameter("@in_result", in_result),
                //new MySqlParameter("@in_message", in_message),
                //new MySqlParameter("@in_time", time),
                ////new MySqlParameter("@createTime", role.createTime),
                //new MySqlParameter("@model", model));
        }

        public int SelectBarCode(string barCode)
        {
            //select id from prodectiondata where barCode='123' order by id desc
            string sql = $"select id,out_result from prodectiondata where barCode=@barCode order by id desc limit 1";
            List<Dictionary<string, string>> drs = mysql.ExecuteReader(sql, new MySqlParameter("@barCode", barCode));
            int temp = 0;
            if (drs.Count > 0)
            {
                temp = string.IsNullOrEmpty(drs[0]["out_result"]) ? 1 : 0;
            }
            else
                temp = 0;
            return temp;
        }

        public int Update(ProdectionData pfg)
        {
            //string sql = $"update plcconfig set unitNum={pfg.unitNum},dataType='{pfg.dataType}',oldData='{pfg.oldData}',data='{pfg.data}',remark='{pfg.remark}',address='{pfg.address}',paramId='{pfg.paramId}' where name='{pfg.name}'";

            //return mysql.ExecuteNonQuery(sql);

            //update prodectiondata set out_result='2NG' where barCode='123' order by id desc limit 1
            string sql = $"update prodectiondata set out_result='{pfg.out_result}',cavity='{pfg.cavity}',out_message='{pfg.out_message}',testPliesPress='{pfg.testPliesPress}',shoulderHeightL='{pfg.shoulderHeightL}',shoulderHeightR='{pfg.shoulderHeightR}',PoleHeightL='{pfg.PoleHeightL}',PoleHeightR='{pfg.PoleHeightR}',bycellPlies='{pfg.bycellPlies}',bycellWidth='{pfg.bycellWidth}',out_time='{pfg.out_time}',remark='{pfg.remark}' where barCode='{pfg.barCode}' order by id desc limit 1";

            return mysql.ExecuteNonQuery(sql);
            //    new MySqlParameter("@barCode", pfg.barCode), new MySqlParameter("@out_result", pfg.out_result),
            //new MySqlParameter("@cavity", pfg.cavity), new MySqlParameter("@out_message", pfg.out_message),
            //new MySqlParameter("@shoulderHeightR", pfg.shoulderHeightR), new MySqlParameter("@PoleHeightL", pfg.PoleHeightL),
            //new MySqlParameter("@PoleHeightR", pfg.PoleHeightR), new MySqlParameter("@bycellPlies", pfg.bycellPlies),
            //new MySqlParameter("@bycellWidth", pfg.bycellWidth), new MySqlParameter("@out_time", pfg.out_time),
            //new MySqlParameter("@remark", pfg.remark), new MySqlParameter("@model", pfg.model),
            //new MySqlParameter("@testPliesPress", pfg.testPliesPress), new MySqlParameter("@shoulderHeightL", pfg.shoulderHeightL));
        }
        public ProdectionData GetPlcGroup(Dictionary<string, string> dr)
        {
            ProdectionData item = new ProdectionData();
            item.id = int.Parse(dr["id"]);
            item.barCode = dr["barCode"].ToString();
            item.in_result = dr["in_result"].ToString();
            item.out_result = dr["out_result"].ToString();
            item.cavity = dr["cavity"].ToString();
            item.model = dr["model"].ToString();
            item.in_message = dr["in_message"].ToString();
            item.out_message = dr["out_message"].ToString();
            item.testPliesPress = float.Parse(dr["testPliesPress"]);
            item.shoulderHeightL = float.Parse(dr["shoulderHeightL"]);
            item.shoulderHeightR = float.Parse(dr["shoulderHeightR"]);
            item.PoleHeightL = float.Parse(dr["PoleHeightL"]);
            item.PoleHeightR = float.Parse(dr["PoleHeightR"]);
            item.bycellPlies = float.Parse(dr["bycellPlies"]);
            item.bycellWidth = float.Parse(dr["bycellWidth"]);
            item.bycellPlies = float.Parse(dr["bycellPlies"]);
            item.bycellPlies = float.Parse(dr["bycellPlies"]);
            item.in_time = dr["in_time"].ToString();
            item.out_time = dr["out_time"].ToString();
            item.remark = dr["remark"].ToString();
            return item;
        }
    }
}
