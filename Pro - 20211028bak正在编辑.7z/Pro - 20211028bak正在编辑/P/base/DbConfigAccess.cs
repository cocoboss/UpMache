﻿using ProModel;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProDAL
{
    public class DbConfigAccess
    {
        public  DbConfig localDb = null;

        public DbConfigAccess()
        {
            //if (string.IsNullOrEmpty(Constant.connStr))
            //    Load();
        }
        public  void Load()
        {

            DbConfigAccess cfg = new DbConfigAccess();
            string cfgFilePath = Constant.dbConfigPath;
            if (File.Exists(cfgFilePath))
            {
                cfg = XmlTemplateUtil<DbConfigAccess>.Read(cfgFilePath);
                if (cfg != null)
                {
                    localDb = cfg.localDb;
                    Constant.connStr = $"server={localDb.server};database={localDb.database};uid={localDb.uid};pwd={localDb.pwd};port = {localDb.port};Persist Security Info=True;Charset={localDb.Charset};Allow User Variables=True;";
                }
            }
            else
            {
                localDb = new DbConfig();
                SaveDb();
            }


        }
        public void SaveDb()
        {
            string cfgFilePath = Constant.dbConfigPath;
            XmlTemplateUtil<DbConfigAccess>.Write(this, cfgFilePath);
        }
    }
}
