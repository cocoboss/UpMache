﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProDAL
{
    //public class EnumDefine
    
        /// <summary>
        ///分组权限人员： 操作员（operator），维护人员（maintain），管理员（administrator），本地管理员（admin）
        /// </summary>
        //public enum Em_Right
        //{
        //    NotRW,
        //    Read,
        //    Write
        //}
    
}
