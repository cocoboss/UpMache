﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Data;
using System.Threading;
using ProModel;

namespace ProDAL
{
    public class BaseAccess
    {
        public SqlHelper mysql;
        public DbConfigAccess da = new DbConfigAccess();
        public BaseAccess()
        {
            if (string.IsNullOrEmpty(Constant.connStr))
                da.Load();
            mysql = new SqlHelper(Constant.connStr);
        }
        public List<Dictionary<string, string>> SelectAll(string table)
        {
            string sql = $"select * from {table}";
            return  mysql.ExecuteReader(sql);
        }
    }

    public class PerBand
    {
        public Em_Right userRight = Em_Right.NotRW;
        public Permissions per;
    }
}
