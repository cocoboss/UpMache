﻿
using ProModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProDAL
{
    #region PlcStatusArgs
    public enum EM_PlcStatus
    {
        Connect,
        DisConnect,
    }

    public class PlcStatusArgs : System.EventArgs
    {
        private EM_PlcStatus status;
        public int PlcIndex;

        public EM_PlcStatus Status
        {
            get { return status; }
            set { status = value; }
        }

        public PlcStatusArgs(EM_PlcStatus status)
        {
            this.status = status;
        }

        public PlcStatusArgs(EM_PlcStatus status, int index)
        {
            this.status = status;
            this.PlcIndex = index;
        }
    }
    #endregion
    public abstract class PLCBase
    {
        private bool _IsConnect = false;
        public static object Lock_Plc = new object();
        public event EventHandler event_PlcStatus;
        public int PlcIndex = 0;

        public bool IsConnect
        {
            get
            {
                return _IsConnect;
            }
            set
            {
                if (value != _IsConnect)
                {
                    if (event_PlcStatus != null)
                    {
                        event_PlcStatus(this, new PlcStatusArgs(value ? EM_PlcStatus.Connect : EM_PlcStatus.DisConnect, PlcIndex));
                    }
                }
                _IsConnect = value;
            }
        }

        public abstract bool Open(string connString, Object axAct = null);
        public abstract void Close();
        public abstract bool ReadGroup(ref AddrGroups group);
        public abstract void ReConnect();
        public abstract bool WirteUint(ref DataUint unit);
        public abstract bool ReadUint(ref DataUint unit);

        public bool WriteAny<T>(string variesName, T tdata)
        {
            return true;
        }

        public T ReadAny<T>(string variesName)
        {
            T tdata = default(T);
            return tdata;
        }

        public abstract byte[] PLCReadStruct(string variesName);
        
    }
}