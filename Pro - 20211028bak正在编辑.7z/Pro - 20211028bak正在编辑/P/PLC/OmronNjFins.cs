﻿using ProModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ProDAL
{
    public class OmronNjFins : PLCBase
    {
        private TcpClientGivenLocalIP tcp = new TcpClientGivenLocalIP(0);
        private string connString;
        private int FailCount = 0;
        private byte clientNodeId = 0;
        private byte serverNodeId = 0;
        private Thread connectThread = null;
        private bool IsExit = false;

        public OmronNjFins(int index=0)
        {
            PlcIndex = index;
        }
        public override bool Open(string connString, Object axAct = null)
        {
            this.connString = connString;
            try
            {
                string[] strArr = connString.Split(':');
                if (strArr.Length <2)
                {
                    LogHelper.WriteExceptionLog("NJ PLC 连接配置非法：" + connString);
                    return false;
                }
                string strIp = strArr[0];
                int serverPort = Convert.ToInt32(strArr[1]);
                int localPort = Convert.ToInt32(strArr[3]);
                this.clientNodeId = Convert.ToByte(strArr[4]);
                int npos = strArr[0].LastIndexOf(".");
                if (npos != -1)
                {
                    string strTemp = strArr[0].Substring(npos + 1, strArr[0].Length - npos - 1);
                    this.serverNodeId = Convert.ToByte(strTemp);
                }
                tcp.Init(strArr[0], serverPort, strArr[2], localPort);
                tcp.event_Connect += ConnChangeRecviver;

                connectThread = new Thread(new ThreadStart(connectThreadEntry));
                connectThread.Start();
            }
            catch
            {
                IsConnect = false;
            }
            return IsConnect;
        }

        public void connectThreadEntry()
        {
            DateTime lastDt = DateTime.Now;
            while (!IsExit)
            {
                Thread.Sleep(10);
                if (tcp.IsConnect && !IsConnect)
                {
                    if ((DateTime.Now - lastDt).TotalMilliseconds > 3000)
                    {
                        IsConnect = HandShake();
                        lastDt = DateTime.Now;
                    }
                }
            }
        }
        public void ConnChangeRecviver(object sender, System.EventArgs e)
        {
            //PortStatusArgs status = (PortStatusArgs)e;
            //IsConnect = status.IsConnect;
        }

        public override byte[] PLCReadStruct(string variesName)
        {
            return null;
        }

        private bool HandShake()
        {
            if (!tcp.IsConnect)
            {
                return false;
            }
            bool ret = false;
            byte[] buf ={
                            0x46,0x49,0x4E,0x53,
                            0x00,0x00,0x00,0x0C,
                            0x00,0x00,0x00,0x00,
                            0x00,0x00,0x00,0x00,
                            0x00,0x00,0x00,0x02
                        };
            //buf[15] = 15;
            buf[19] = clientNodeId;
            lock (Lock_Plc)
            {
                DateTime dtStart = DateTime.Now;
                tcp.ClearRecv();
                tcp.SendData(buf);
                while ((DateTime.Now - dtStart).TotalMilliseconds < 2000)
                {
                    //if (tcp.SendData(buf))
                    //{
                    //    ret = true;
                    //    break;
                    //}

                    Thread.Sleep(1);
                    if (tcp.recvLen >= 20)
                    {
                        byte[] recvBuf = tcp.GetDatas();
                        if (recvBuf[15] == 0 && recvBuf[19] == clientNodeId)
                        {
                            int time = (int)(DateTime.Now - dtStart).TotalMilliseconds;
                            ret = true;
                            break;
                        }
                    }
                }
            }
            return ret;
        }

        public override void Close()
        {
            IsExit = true;
            Thread.Sleep(20);
            if (connectThread.IsAlive)
            {
                connectThread.Abort();
                connectThread = null;
            }
            CloseHandShake();
            tcp.Close();
        }

        private void CloseHandShake()
        {
            if (!IsConnect) return;

            lock (Lock_Plc)
            {
                byte[] buf ={
                                0x46,0x49,0x4E,0x53,
                                0x00,0x00,0x00,0x0C,
                                0x00,0x00,0x00,0x00,
                                0x00,0x00,0x00,0x00,
                                0x00,0x00,0x00,0x02
                               };
                buf[19] = clientNodeId;
                tcp.SendData(buf);

            }
        }

        public override bool ReadGroup(ref AddrGroups group)
        {
            short[] shDataArr = new short[group.leng];
            try
            {
                if (PLCReadBlock(int.Parse(group.startAddr), group.leng, ref shDataArr))
                {
                    for (int i = 0; i < group.unitLst.Count; i++)
                    {
                        try
                        {
                            DataUint unit = group.unitLst[i];
                            if (unit.unitNum == 0)
                            {
                                continue;
                            }
                            short[] unitData = new short[unit.unitNum];
                            Array.Copy(shDataArr, unit.Addr - int.Parse(group.startAddr), unitData, 0, unitData.Length);
                            byte[] buf = new byte[unit.unitNum * 2];
                            for (int j = 0; j < unitData.Length; j++)
                            {
                                byte[] temp = BitConverter.GetBytes(unitData[j]);
                                buf[j * 2] = temp[0];
                                buf[j * 2 + 1] = temp[1];
                            }
                            string strData = "";
                            switch (unit.type)
                            {
                                case em_DataType.Int16Address:
                                    strData = BitConverter.ToInt16(buf, 0).ToString();
                                    break;
                                case em_DataType.Int32Address:
                                    strData = BitConverter.ToInt32(buf, 0).ToString();
                                    break;
                                case em_DataType.Int64Address:
                                    //strData = BitConverter.ToInt64(unitData, 0).ToString();
                                    strData = BitConverter.ToInt16(buf, 2).ToString() + "," + BitConverter.ToInt16(buf, 0).ToString();
                                    break;
                                case em_DataType.SingleAddress:
                                    strData = BitConverter.ToSingle(buf, 0).ToString("0.00");
                                    break;
                                case em_DataType.DoubleAddress:
                                    strData = BitConverter.ToDouble(buf, 0).ToString("0.00");
                                    break;
                                case em_DataType.StringAddress:
                                    List<byte> btLst = new List<byte>();
                                    for (int i1 = 0; i1 < buf.Length; i1++)
                                    {
                                        if (buf[i1] != 0)
                                        {
                                            btLst.Add(buf[i1]);
                                        }
                                        else
                                        {
                                            break;
                                        }
                                    }
                                    strData = Encoding.Default.GetString(btLst.ToArray());
                                    break;

                            }
                            group.unitLst[i].Data = strData;
                        }
                        catch
                        {
                            return false;
                        }
                    }
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                return false;
            }
        }

        public override void ReConnect()
        {
            IsConnect = false;
            FailCount = 0;
        }

        public byte[] ObjectToByteArray(object obj)
        {
            if (obj is Array)
            {
                Array arr = obj as Array;
                Byte[] bin = new Byte[arr.Length];
                for (int i = 0; i < bin.Length; i++)
                {
                    bin[i] = Convert.ToByte(arr.GetValue(i));
                }
                return bin;
            }
            else if (obj is string)
            {
                Byte[] bin = Encoding.Default.GetBytes((string)obj);
                return bin;
            }
            else
            {
                return new Byte[1] { Convert.ToByte(obj) };
            }
        }
        public bool PLCReadBlock(int startAddr, int iSize, ref short[] sData)
        {
            if (FailCount > 3)
            {
                ReConnect();
            }
            if (!IsConnect)
            {
                return false;
            }
            if (iSize > 450)
            {
                LogHelper.WriteExceptionLog("超出最大读取长度：" + iSize + "  开始地址：" + startAddr);
                return false;
            }
            bool ret = false;
            byte[] buf ={
                            0x46,0x49,0x4E,0x53,
                            0x00,0x00,0x00,0x1A,
                            0x00,0x00,0x00,0x02,
                            0x00,0x00,0x00,0x00,

                            0x80,0x00,0x02,
                            0x00,0x01,0x00,
                            0x00,0x06,0x00,0x00,
                            0x01,0x01,
                            0x82,0x00,0x00,0x00,
                            0x00,0x01
                        };
            buf[20] = serverNodeId;
            buf[23] = clientNodeId;
            byte[] bufAddr = new byte[2];
            byte[] bufItems = new byte[2];
            bufAddr = BitConverter.GetBytes(IPAddress.HostToNetworkOrder((short)startAddr));
            buf[29] = bufAddr[0];
            buf[30] = bufAddr[1];

            bufItems = BitConverter.GetBytes(IPAddress.HostToNetworkOrder((short)iSize));
            buf[32] = bufItems[0];
            buf[33] = bufItems[1];
            lock (Lock_Plc)
            {
                DateTime dtStart = DateTime.Now;
                tcp.ClearRecv();
                tcp.SendData(buf);
                while ((DateTime.Now - dtStart).TotalMilliseconds < 2000)
                {
                    Thread.Sleep(1);
                    if (tcp.recvLen >= iSize * 2 + 30)
                    {
                        byte[] recvBuf = tcp.GetDatas();
                        if (recvBuf[15] == 0 && recvBuf[28] == 0)
                        {
                            for (int i = 0; i < iSize; i++)
                            {
                                sData[i] = (short)(recvBuf[2 * i + 31] + recvBuf[2 * i + 30] * 256);
                            }
                            ret = true;
                        }
                        break;
                    }
                }
            }
            if (ret)
            {
                FailCount = 0;
            }
            else
            {
                FailCount++;
            }

            return ret;
        }

        public override bool WirteUint(ref DataUint unit)
        {
            if (unit.unitNum == 0 || unit.Addr == 0)
            {
                return true;
            }
            byte[] bytes = null;
            switch (unit.type)
            {
                case em_DataType.Byte8Address:
                    bytes = BitConverter.GetBytes(char.Parse(unit.Data));
                    break;
                case em_DataType.Int16Address:
                    bytes = BitConverter.GetBytes((short)Single.Parse(unit.Data));
                    break;
                case em_DataType.Int32Address:
                    bytes = BitConverter.GetBytes((int)Single.Parse(unit.Data));
                    break;
                case em_DataType.Int64Address:
                    {
                        string[] strArr = unit.Data.Split(',');
                        if (strArr.Length > 1)
                        {
                            long lVal = Convert.ToInt16(strArr[0]);
                            lVal = lVal << 16;
                            lVal += Convert.ToInt16(strArr[1]);
                            bytes = BitConverter.GetBytes(lVal);
                        }
                        else
                        {
                            bytes = BitConverter.GetBytes((long)Single.Parse(unit.Data));
                        }
                    }
                    break;
                case em_DataType.SingleAddress:
                    bytes = BitConverter.GetBytes(Single.Parse(unit.Data));
                    break;
                case em_DataType.DoubleAddress:
                    bytes = BitConverter.GetBytes(double.Parse(unit.Data));
                    break;
                case em_DataType.StringAddress:
                    if (unit.Data.Length % 2 == 1)   //字符串为奇数，补0
                    {
                        unit.Data = unit.Data + "\0";
                    }
                    bytes = Encoding.Default.GetBytes(unit.Data);
                    //byte [] databuf = Encoding.Default.GetBytes(unit.Data);
                    //bytes = new byte[unit.unitNum];
                    //Array.Copy(databuf, bytes, databuf.Length);
                    break;
            }
            if (bytes == null || bytes.Length == 0) return false;

            return PLCWriteBlock(unit.Addr, unit.unitNum, bytes);
        }

        public override bool ReadUint(ref DataUint unit)
        {
            bool bRet = false;
            if (unit.unitNum == 0 || unit.Addr == 0)
            {
                return false;
            }
            short[] shDataArr = new short[unit.unitNum];
            byte[] unitData = new byte[2 * unit.unitNum];
            string strData = "";
            if (PLCReadBlock(unit.Addr, shDataArr.Length, ref shDataArr))
            {
                for (int j = 0; j < shDataArr.Length; j++)
                {
                    byte[] temp = BitConverter.GetBytes(shDataArr[j]);
                    unitData[j * 2] = temp[0];
                    unitData[j * 2 + 1] = temp[1];
                }
                switch (unit.type)
                {
                    case em_DataType.Int16Address:
                        strData = BitConverter.ToInt16(unitData, 0).ToString();
                        break;
                    case em_DataType.Int32Address:
                        strData = BitConverter.ToInt32(unitData, 0).ToString();
                        break;
                    case em_DataType.Int64Address:
                        //strData = BitConverter.ToInt64(unitData, 0).ToString();
                        strData = BitConverter.ToInt16(unitData, 2).ToString() + "," + BitConverter.ToInt16(unitData, 0).ToString();
                        break;
                    case em_DataType.SingleAddress:
                        strData = BitConverter.ToSingle(unitData, 0).ToString("0.000");
                        break;
                    case em_DataType.DoubleAddress:
                        strData = BitConverter.ToDouble(unitData, 0).ToString("0.000");
                        break;
                    case em_DataType.StringAddress:
                        List<byte> btLst = new List<byte>();
                        for (int i = 0; i < unitData.Length; i++)
                        {
                            if (unitData[i] != 0)
                            {
                                btLst.Add(unitData[i]);
                            }
                            else
                            {
                                break;
                            }
                        }
                        strData = Encoding.Default.GetString(btLst.ToArray());
                        break;
                }
                unit.Data = strData;
                bRet = true;
            }
            return bRet;
        }

        public bool PLCWriteBlock(int startAddr, int iSize, byte[] bytes)
        {
            if (FailCount > 3)
            {
                ReConnect();
            }
            if (startAddr == 0)
                return false;
            if (!IsConnect)
            {
                return false;
            }
            if (iSize > 450)
            {
                LogHelper.WriteExceptionLog("超出最大读取长度：" + iSize + "  开始地址：" + startAddr);
                return false;
            }
            bool ret = false;
            byte[] buf ={
                            0x46,0x49,0x4E,0x53,
                            0x00,0x00,0x00,0x1A,
                            0x00,0x00,0x00,0x02,
                            0x00,0x00,0x00,0x00,

                            0x80,0x00,0x02,
                            0x00,0x01,0x00,
                            0x00,0x06,0x00,0x00,
                            0x01,0x02,
                            0x82,0x00,0x00,0x00,
                            0x00,0x01
                        };
            buf[20] = serverNodeId;
            buf[23] = clientNodeId;
            byte[] bufAddr = new byte[2];
            bufAddr = BitConverter.GetBytes(IPAddress.HostToNetworkOrder((short)startAddr));
            buf[29] = bufAddr[0];
            buf[30] = bufAddr[1];

            byte[] bufItems = new byte[2];
            bufItems = BitConverter.GetBytes(IPAddress.HostToNetworkOrder((short)iSize));
            buf[32] = bufItems[0];
            buf[33] = bufItems[1];

            int iLen = 16 + 18 + iSize * 2;
            buf[4] = (byte)((iLen - 8) >> 24);
            buf[5] = (byte)((iLen - 8) >> 16);
            buf[6] = (byte)((iLen - 8) >> 8);
            buf[7] = (byte)((iLen - 8));
            byte[] sendBuf = new byte[iLen];
            Array.Copy(buf, sendBuf, buf.Length);

            for (int i = 0; i < bytes.Length / 2; i++)
            {
                byte bt = bytes[2 * i];
                bytes[2 * i] = bytes[2 * i + 1];
                bytes[2 * i + 1] = bt;
            }

            //Array.Copy(bytes,0, sendBuf, buf.Length, iLen - buf.Length);
            Array.Copy(bytes, 0, sendBuf, buf.Length, bytes.Length);
            lock (Lock_Plc)
            {
                DateTime dtStart = DateTime.Now;
                tcp.ClearRecv();
                tcp.SendData(sendBuf);
                while ((DateTime.Now - dtStart).TotalMilliseconds < 2000)
                {
                    Thread.Sleep(1);
                    if (tcp.recvLen >= 13)
                    {
                        byte[] recvBuf = tcp.GetDatas();
                        if (recvBuf[12] == 0)
                        {
                            ret = true;
                        }
                        break;
                    }
                }
            }
            if (ret)
            {
                FailCount = 0;
            }
            else
            {
                FailCount++;
            }
            return ret;
        }
    }
}
