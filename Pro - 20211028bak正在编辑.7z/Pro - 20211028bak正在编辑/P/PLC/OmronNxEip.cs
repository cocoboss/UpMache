﻿
using OMRON.Compolet.CIP;
using ProModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ProDAL
{
    public class OmronNxEip : PLCBase
    {
        private System.ComponentModel.IContainer components = new System.ComponentModel.Container();
        private CommonCompolet compolet;
        private string netId;
        private int reconnctCount = 0;

        public override bool Open(string connString, Object axAct = null)
        {
            netId = connString;
            try
            {
                compolet = new OMRON.Compolet.CIP.CommonCompolet(this.components);
                compolet.ConnectionType = OMRON.Compolet.CIP.ConnectionType.Class3;
                this.compolet.LocalPort = Convert.ToInt16(2);
                this.compolet.PeerAddress = connString;
                this.compolet.ReceiveTimeLimit = ((long)(750));
                Connect();
            }
            catch
            {
                IsConnect = false;
            }
            return IsConnect;
        }

        private void Connect()
        {
            compolet.Active = true;
            IsConnect = compolet.IsConnected;
        }

        public override void Close()
        {
            if (components != null)
            {
                components.Dispose();
            }
            compolet.Dispose();
        }

        public bool ReadGroupTest(ref AddrGroups group)
        {
            int dataCount = group.leng;
            //for (int i = 0; i < group.uintLst.Count; i++)
            //{
            //    dataCount += group.uintLst[i].unitNum;
            //}

            byte[] buf = new byte[dataCount];
            try
            {
                string name = "";
                if (group.isRemark)
                    name = group.remark;
                else
                    name = group.unitLst[0].Prefix + group.startAddr;
                if (PLCReadBlock(name, dataCount, ref buf))
                {
                    int offset = 0;
                    for (int i = 0; i < group.unitLst.Count; i++)
                    {
                        DataUint unit = group.unitLst[i];
                        if (unit.unitNum == 0)
                        {
                            continue;
                        }
                        byte[] unitData = new byte[unit.unitNum];
                        Array.Copy(buf, offset, unitData, 0, unitData.Length);
                        offset = offset + unit.unitNum;
                        string strData = "";
                        switch (unit.type)
                        {
                            case em_DataType.Byte8Address:
                                strData = ((int)(unitData[0])).ToString();
                                break;
                            case em_DataType.Int16Address:
                                strData = BitConverter.ToInt16(unitData, 0).ToString();
                                break;
                            case em_DataType.Int32Address:
                                strData = BitConverter.ToInt32(unitData, 0).ToString();
                                break;
                            case em_DataType.Int64Address:
                                //strData = BitConverter.ToInt64(unitData, 0).ToString();
                                strData = BitConverter.ToInt32(unitData, 0).ToString() + "," + BitConverter.ToInt32(unitData, 4).ToString();
                                break;
                            case em_DataType.SingleAddress:
                                strData = BitConverter.ToSingle(unitData, 0).ToString("0.000");
                                break;
                            case em_DataType.DoubleAddress:
                                strData = BitConverter.ToDouble(unitData, 0).ToString("0.000");
                                break;
                            case em_DataType.StringAddress:
                                strData = Encoding.Default.GetString(unitData);
                                strData = (strData.Replace("\0", ""));
                                //strData = Bytes2String(unitData);
                                break;
                        }
                        group.unitLst[i].Data = strData;
                    }
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                return false;
            }
        }

        public override bool ReadGroup(ref AddrGroups group)
        {
            int dataCount = 0;
            for (int i = 0; i < group.unitLst.Count; i++)
            {
                dataCount += group.unitLst[i].unitNum;
            }
            
            byte[] buf = new byte[dataCount];
            try
            {
                string name = group.unitLst[0].vairsName;
                if (PLCReadBlock(name, dataCount, ref buf))
                {
                    int offset = 0;
                    for (int i = 0; i < group.unitLst.Count; i++)
                    {
                        DataUint unit = group.unitLst[i];
                        if (unit.unitNum == 0)
                        {
                            continue;
                        }
                        byte[] unitData = new byte[unit.unitNum];
                        Array.Copy(buf, offset, unitData, 0, unitData.Length);
                        offset = offset + unit.unitNum;
                        string strData = "";
                        switch (unit.type)
                        {
                            case em_DataType.Byte8Address:
                                strData = ((int)(unitData[0])).ToString();
                                break;
                            case em_DataType.Int16Address:
                                strData = BitConverter.ToInt16(unitData, 0).ToString();
                                break;
                            case em_DataType.Int32Address:
                                strData = BitConverter.ToInt32(unitData, 0).ToString();
                                break;
                            case em_DataType.Int64Address:
                                //strData = BitConverter.ToInt64(unitData, 0).ToString();
                                strData = BitConverter.ToInt32(unitData, 0).ToString() + "," + BitConverter.ToInt32(unitData, 4).ToString();
                                break;
                            case em_DataType.SingleAddress:
                                strData = BitConverter.ToSingle(unitData, 0).ToString("0.000");
                                break;
                            case em_DataType.DoubleAddress:
                                strData = BitConverter.ToDouble(unitData, 0).ToString("0.000");
                                break;
                            case em_DataType.StringAddress:
                                strData = Encoding.Default.GetString(unitData);
                                strData = (strData.Replace("\0", ""));
                                //strData = Bytes2String(unitData);
                                break;
                        }
                        group.unitLst[i].Data = strData;
                    }
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                return false;
            }
        }

        public string Bytes2String(byte[] arr)
        {
            byte[] strArr = new byte[arr.Length];
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i] == 0)
                {
                    strArr[i] = 32;
                }
                else
                {
                    strArr[i] = arr[i];
                }
            }
            string strRet = Encoding.Default.GetString(strArr, 0, arr.Length).Trim();
            return strRet;
        }

        public override void ReConnect()
        {
            compolet.Active = false;
            Thread.Sleep(100);
            compolet.Active = true;
            reconnctCount++;
            if (reconnctCount > 30)
            {
                IsConnect = false;
            }
            //IsConnect = compolet.IsConnected;
        }
        public byte[] ObjectToByteArray(object obj)
        {
            if (obj is Array)
            {
                Array arr = obj as Array;
                Byte[] bin = new Byte[arr.Length];
                for (int i = 0; i < bin.Length; i++)
                {
                    bin[i] = Convert.ToByte(arr.GetValue(i));
                }
                return bin;
            } 
            else if(obj is string)
            {
                Byte[] bin = Encoding.Default.GetBytes((string)obj);
                return bin;
            }
            else
            {
                return new Byte[1] { Convert.ToByte(obj) };
            }
        }
        public bool PLCReadBlock(string variesName, int iSize, ref byte[] dataBuf)
        {
            if (variesName.Length == 0)
                return false;
            bool bRet = false;
            try
            {
                lock (Lock_Plc)
                {
                    for (int i = 0; i < 3; i++)
                    {
                        try
                        {
                            object data = compolet.ReadVariable(variesName);
                            dataBuf = ObjectToByteArray(data);
                            reconnctCount = 0;
                            bRet = true;
                            IsConnect = true;
                        }
                        catch (Exception e)
                        {
                           bRet = false;
                        }
                        if (bRet)
                        {
                            break;
                        }
                        if (!bRet)
                        {
                            ReConnect();
                        }
                    }
                }
            }
            catch
            {
            }
            return bRet;
        }
        public bool PLCReadBlock(string variesName, int iSize, ref object dataBuf)
        {
            if (variesName.Length == 0)
                return false;
            bool bRet = false;
            try
            {
                lock (Lock_Plc)
                {
                    for (int i = 0; i < 3; i++)
                    {
                        try
                        {
                            //object data = compolet.ReadVariable(variesName);
                            object data = compolet.ReadVariable(variesName, iSize);
                            dataBuf = data;
                            reconnctCount = 0;
                            bRet = true;
                            IsConnect = true;
                        }
                        catch (Exception e)
                        {
                            bRet = false;
                        }
                        if (bRet)
                        {
                            break;
                        }
                        if (!bRet)
                        {
                            ReConnect();
                        }
                    }
                }
            }
            catch
            {
            }
            return bRet;
        }

        public override byte[] PLCReadStruct(string variesName)
        {
            byte[] data = null;
            if (variesName.Length == 0)
                return data;
            bool bRet = false;
            try
            {
                lock (Lock_Plc)
                {
                    for (int i = 0; i < 3; i++)
                    {
                        try
                        {
                            data = compolet.ReadRawData(variesName);
                            //object datas = compolet.ReadVariable(group.remark);
                            //data = BitConverter.GetBytes((short)datas);
                            reconnctCount = 0;
                            bRet = true;
                            IsConnect = true;
                        }
                        catch (Exception e)
                        {
                            bRet = false;
                        }
                        if (bRet)
                        {
                            break;
                        }
                        if (!bRet)
                        {
                            ReConnect();
                        }
                    }
                }
            }
            catch
            {
            }
            return data;
        }
        public byte [] PLCReadStruct(ref AddrGroups group)
        {
            byte[] data = null;
            if (group.remark.Length == 0)
                return data;
            bool bRet = false;
            try
            {
                lock (Lock_Plc)
                {
                    for (int i = 0; i < 3; i++)
                    {
                        try
                        {
                            //data = compolet.ReadRawData(variesName);
                            object datas = compolet.ReadVariable(group.remark);
                            data = ObjectToByteArray(datas);
                            reconnctCount = 0;
                            bRet = true;
                            IsConnect = true;
                        }
                        catch (Exception e)
                        {
                            bRet = false;
                        }
                        if (bRet)
                        {
                            break;
                        }
                        if (!bRet)
                        {
                            ReConnect();
                        }
                    }
                }
            }
            catch
            {
            }
            return data;
        }
        public override bool WirteUint(ref DataUint unit)
        {
            if (unit.vairsName.Length == 0 || unit.unitNum == 0)
            {
                return false;
            }
            return PLCWriteBlock(unit.vairsName, unit.unitNum, unit.Data);
        }
        public override bool ReadUint(ref DataUint unit)
        {
            if (unit.vairsName.Length == 0 || unit.unitNum==0)
            {
                return false;
            }
            bool bRet = false;
            object unitData = new object();
            string strData = "";
            if (PLCReadBlock(unit.vairsName, unit.unitNum, ref unitData))
            {
                switch (unit.type)
                {
                    case em_DataType.Byte8Address:
                        strData = ((int)(unitData)).ToString();
                        break;
                    case em_DataType.Int16Address:
                        strData = Convert.ToInt16(unitData).ToString();
                        break;
                    case em_DataType.Int32Address:
                        strData = Convert.ToInt32(unitData).ToString();
                        break;
                    case em_DataType.Int64Address:
                        //strData = BitConverter.ToInt64(unitData, 0).ToString();
                        strData = Convert.ToInt64(unitData).ToString();
                        break;
                    case em_DataType.SingleAddress:
                        strData = Convert.ToSingle(unitData).ToString("0.000");
                        break;
                    case em_DataType.DoubleAddress:
                        strData = Convert.ToDouble(unitData).ToString("0.000");
                        break;
                    case em_DataType.StringAddress:
                        strData = unitData.ToString();
                        strData = (strData.Replace("\0", ""));
                        //strData = Bytes2String(unitData);
                        break;
                }
                unit.Data = strData;
                bRet = true;
            }
            return bRet;
        }
        public bool PLCWriteBlock(string variesName, int iSize, byte[] bytes)
        {
            if (variesName.Length == 0)
                return false;
            bool bRet = false;
            try
            {
                lock (Lock_Plc)
                {
                    for (int i = 0; i < 3; i++)
                    {
                        try
                        {
                            compolet.WriteRawData(variesName, bytes);
                            //compolet.WriteVariable(variesName, bytes, iSize);
                            reconnctCount = 0;
                            bRet = true;
                            IsConnect = true;
                        }
                        catch (Exception e)
                        {
                            bRet = false;
                        }

                        if (bRet)
                        {
                            break;
                        }
                        if (!bRet)
                        {
                            ReConnect();
                        }

                    }
                }
            }
            catch
            {
            }
            return bRet;
        }

        public bool PLCWriteBlock(string variesName, int iSize, object bytes)
        {
            if (variesName.Length == 0)
                return false;
            bool bRet = false;
            try
            {
                lock (Lock_Plc)
                {
                    for (int i = 0; i < 3; i++)
                    {
                        try
                        {
                            //compolet.WriteVariable(variesName, bytes);可以不管长度
                            compolet.WriteVariable(variesName, bytes, iSize);
                            reconnctCount = 0;
                            bRet = true;
                            IsConnect = true;
                        }
                        catch (Exception e)
                        {
                            bRet = false;
                        }

                        if (bRet)
                        {
                            break;
                        }
                        if (!bRet)
                        {
                            ReConnect();
                        }

                    }
                }
            }
            catch
            {
            }
            return bRet;
        }
    }
}