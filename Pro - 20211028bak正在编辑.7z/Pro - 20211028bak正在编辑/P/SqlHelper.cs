﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Data;
using System.Threading;

namespace ProDAL
{
    public class SqlHelper
    {
        //string connStr = "server=127.0.0.1;database=tesst1;uid=root;pwd=root;port = 3306;Persist Security Info=True;Charset=utf8;Allow User Variables=True;";
        string connStr = "";

        public SqlHelper(string connStrs="")
        {
            if (!string.IsNullOrEmpty(connStrs))
            {
                this.connStr = connStrs;
            }
        }
        public MySqlConnection Open(string connStrs = "")
        {
            if (!string.IsNullOrEmpty(connStrs))
            {
                connStr = connStrs;
            }  
            MySqlConnection conn = new MySqlConnection(connStr);
            try
            {
                conn.Open();
            }catch
            {
            }
            return conn;
        }
        public void Close(ref MySqlConnection con)
        {
            if(con!=null)
            {
                if (con.State == ConnectionState.Connecting || con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }else
                {
                    Thread.Sleep(100);
                    con.Close();
                    con.Dispose();
                }
            }

        }
        public DataTable DataAdapter(string sql,params MySqlParameter[] paramss)
        {
            DataTable dt = new DataTable();
            lock(this)
            {
                using (MySqlConnection conn = Open())
                {
                    using (MySqlCommand com = new MySqlCommand(sql, conn))
                    {
                        try
                        {
                            
                            if (paramss != null && paramss.Length > 0)
                                com.Parameters.AddRange(paramss);
                            MySqlDataAdapter da = new MySqlDataAdapter(com);
                            da.Fill(dt);
                            com.Parameters.Clear();
                        }
                        catch
                        {
                            dt = null;
                            com.Dispose();
                            conn.Close();
                            return dt;
                        }
                    }
                }
            }
            return dt;
        }
        /// <summary>
        /// 增删改
        /// </summary>
        /// <param name="sql"></param>
        /// <param name="paramss"></param>
        /// <returns></returns>
        public int ExecuteNonQuery(string sql, params MySqlParameter[] paramss)
        {
            int tenpInt = -1;
            lock (this)
            {
                using (MySqlConnection conn = Open())
                {
                    using (MySqlCommand com = new MySqlCommand(sql, conn))
                    {
                        try
                        {
                            com.CommandType = CommandType.Text;
                            if (paramss != null && paramss.Length > 0)
                                com.Parameters.AddRange(paramss);
                            tenpInt = com.ExecuteNonQuery();
                            com.Parameters.Clear();
                        }
                        catch
                        {
                            tenpInt = -1;
                            com.Dispose();
                            conn.Close();
                            return tenpInt;
                        }
                    }
                }
            }
            return tenpInt;
        }

        public List<Dictionary<string,string>> ExecuteReader(string sql, params MySqlParameter[] paramss)
        {
            List<Dictionary<string, string>> lst = new List<Dictionary<string, string>>();
            lock (this)
            {
                using (MySqlConnection conn = Open())
                {
                    using (MySqlCommand com = new MySqlCommand(sql, conn))
                    {
                        try
                        {
                            if (paramss != null && paramss.Length > 0)
                                com.Parameters.AddRange(paramss);
                            MySqlDataReader drs = com.ExecuteReader();
                            com.Parameters.Clear();
                            int row = 0;
                            if (drs.HasRows)
                            {
                                while (drs.Read())
                                {
                                    Dictionary<string, string> ls = new Dictionary<string, string>();
                                    for (int i = 0; i < drs.FieldCount; i++)
                                    {
                                        ls.Add(drs.GetName(i), drs[i].ToString());
                                    }
                                    lst.Add(ls);
                                    row++;
                                }
                            }
                        }
                        catch
                        {
                            com.Dispose();
                            conn.Close();
                            return lst;
                        }
                    }
                }
            }
            return lst;
        }


        public object ExecuteScalar(string sql, params MySqlParameter[] paramss)
        {
            object obj = null;
            lock (this)
            {
                using (MySqlConnection conn = Open())
                {
                    using (MySqlCommand com = new MySqlCommand(sql, conn))
                    {
                        try
                        {
                            if (paramss != null && paramss.Length > 0)
                                com.Parameters.AddRange(paramss);
                            obj = com.ExecuteScalar();
                            com.Parameters.Clear();
                        }
                        catch
                        {
                            obj = null;
                            com.Dispose();
                            conn.Close();
                            return obj;
                        }
                    }
                }
            }
            return obj;
        }


    }
}
