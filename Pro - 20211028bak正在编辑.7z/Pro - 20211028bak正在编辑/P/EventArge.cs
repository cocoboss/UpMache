﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProModel;

namespace ProDAL
{
    /// <summary>
    /// 当前用户
    /// </summary>
    /// 

    #region  当前用户信息记录
    public class CurUserEventArgs : System.EventArgs
    {
        public User curUser;
        public Roles curRole;
        public User lastUser;
        public Roles lastRole;
        public bool isLogin = false;
        //public User CurUser
        //{
        //    get { return curUser; }
        //    set { curUser = value; }
        //}
        //public Roles CurRole
        //{
        //    get { return curRole; }
        //    set { curRole = value; }
        //}
        //public User LastUser
        //{
        //    get { return curUser; }
        //    set { curUser = value; }
        //}
        //public Roles LastRole
        //{
        //    get { return curRole; }
        //    set { curRole = value; }
        //}
        public CurUserEventArgs()
        {
            this.lastRole = null;
            this.lastUser = null;
            curUser = null;
            curRole = null;
            isLogin = false;
        }
        public CurUserEventArgs(Roles role, User user = null)
        {
            this.lastRole = curRole;
            this.lastUser = curUser;
            if (user == null)
                isLogin = false;
            else
                isLogin = true;
            this.curUser = user;
            this.curRole = role;
        }


    }

    #endregion

    public class ParBandsEventArge : System.EventArgs
    {
        public List<PerBand> curBands = new List<PerBand>();
        public List<PerBand> curBarItem = new List<PerBand>();
        public ParBandsEventArge(List<PerBand> preBands, List<PerBand> preBarItem)
        {
            curBands = preBands;
            curBarItem = preBarItem;
        }

    }


}
