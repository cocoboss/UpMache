﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProDAL
{
    public class LogHelper
    {

        public static string szDirectory = "D:\\Log";
        public static int iOclock = 8;
        public static string dateFormat = "yyyy-MM-dd";
        private static object mLogLock = new object();

        public static void writeLogByFileName(String szContent, String szFileName, string subDir = "log")
        {
            if (szContent != null && szFileName != null)
            {
                try
                {
                    lock (mLogLock)
                    {
                        //string strDir = szDirectory;
                        string strDir = szDirectory + "\\" + DateTime.Now.ToString("yyyyMMdd");
                        if (!string.IsNullOrEmpty(subDir))
                        {
                            strDir += ("\\" + subDir);
                        }
                        szContent = "[" + DateTime.Now.ToString("yyyy/MM/dd HH-mm-ss.fff") + "]: " + szContent;
                        if (!Directory.Exists(strDir))
                        {
                            Directory.CreateDirectory(strDir);
                        }
                        StreamWriter sw = new StreamWriter(strDir + "\\" + szFileName, true);
                        sw.WriteLine(szContent);
                        sw.WriteLine();
                        sw.Close();
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine("ATSLog.writeLogByPath exception for logging " + szContent + " at path: " + szDirectory + "\\" + szFileName + "->" + e.Message);
                }
                finally
                {

                }
            }
        }
        /// <summary>
        /// writing log into file path
        /// </summary>
        /// <param name="szContent">content to be written</param>
        /// <param name="szPath">file path</param>
        public static void writeLogByPath(String szContent, String szPath)
        {
            if (szContent != null && szPath != null)
            {
                try
                {
                    lock (mLogLock)
                    {
                        szContent = "[" + DateTime.Now.ToString("yyyy/MM/dd HH-mm-ss") + "]: " + szContent;
                        StreamWriter sw = new StreamWriter(szPath, true);
                        sw.WriteLine(szContent);
                        sw.Close();
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine("ATSLog.writeLogByPath exception for logging " + szContent + " at path: " + szPath + "->" + e.Message);
                }
                finally
                {

                }
            }
        }

        /// <summary>
        /// writing log into file with giving folder and file name
        /// the absolute file path will be current directory + folder + file
        /// </summary>
        /// <param name="szContent">content to be written</param>
        /// <param name="folderName">folder name</param>
        /// <param name="fileName">file name</param>
        public static void writeLogByName(string szContent, string folderName, string fileName)
        {
            //string strChildrenDirectory = szDirectory + ((folderName == null || folderName == "") ? "" : "\\" + folderName);
            string strChildrenDirectory =  ((folderName == null || folderName == "") ? szDirectory :  folderName);
            if (!Directory.Exists(strChildrenDirectory))
            {
                Directory.CreateDirectory(strChildrenDirectory);
            }
            if (fileName != null)
            {
                writeLogByPath(szContent, strChildrenDirectory + "\\" + fileName);
            }
        }

        public static void writeErrorCodeByName(string szContent, string path, string fileName)
        {
            string strChildrenDirectory = path + "\\" + DateTime.Now.ToString("yyyy-MM-dd");
            if (!Directory.Exists(strChildrenDirectory))
            {
                Directory.CreateDirectory(strChildrenDirectory);
            }
            if (fileName != null)
            {
                writeLogByPath(szContent, strChildrenDirectory + "\\" + fileName);
            }
        }
        public static void WriteExceptionLog(string strLog)
        {
            LogHelper.writeLogByName(strLog + Environment.NewLine, "D:\\Exception", "Exception" + DateTime.Now.ToString("yyyy-MM-dd") + ".txt");
        }



    }
}
