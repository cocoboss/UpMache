﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProModel;

namespace ProDAL
{
    public class AlarmConfigAccess:BaseAccess
    {
        public List<AlarmConfig> SelectAll()
        {
            string sql = $"select * from alarmconfig";
            List<Dictionary<string, string>> drs = mysql.ExecuteReader(sql);
            List<AlarmConfig> lst = new List<AlarmConfig>();
            if (drs.Count > 0)
            {
                for (int i = 0; i < drs.Count; i++)
                {
                    AlarmConfig temp = GetAlarmConfig(drs[i]);
                    lst.Add(temp);
                }
            }
            else
            {
                lst = null;
            }
            return lst;
        }


        public AlarmConfig GetAlarmConfig(Dictionary<string, string> dr)
        {
            AlarmConfig item = new AlarmConfig();
            item.id = int.Parse(dr["id"]);
            item.level = dr["level"].ToString();
            item.alarmCode = dr["alarmCode"].ToString();
            item.status = int.Parse(dr["status"]);
            item.remark = dr["remark"].ToString();
            item.alarmTime = dr["alarmTime"].ToString();
            item.alarmDescript = dr["alarmDescript"].ToString();
            //item.updateTime = dr["updateTime"].ToString();
            //item.remark = dr["remark"].ToString();
            return item;
        }

    }
}
