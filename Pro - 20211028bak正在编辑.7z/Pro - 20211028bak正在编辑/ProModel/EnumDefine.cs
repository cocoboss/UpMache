﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProModel
{
    class EnumDefine
    {
    }
    public enum Em_UserRight
    {
        administrator,
        Operator=1,
        Technician=2,
        Admin=3,
       
    }
    public enum Em_UserRightCH
    {
        本地管理员=0,
        操作工 = 1,
        技术员 = 2,
        管理员 = 3,

    }

    public enum Em_OpFlag
    {
        上传设备模式 = 1,
        上传设备状态 = 2,
        上传库位状态 = 3,
    }

    public enum Em_EquipmentModel
    {
        CONT,                   //MES管控模式，对应正常生产
        MONT,                   //MES监控模式，对应调试生产
        MANU,                   //MES离线模式
    }

    public enum Em_EquipmentModelZH
    {
        管控模式,                   //MES管控模式，对应正常生产
        监控模式,                   //MES监控模式，对应调试生产
        离线模式,                   //MES离线模式
    }

    public enum Em_EquipmentStatusID
    {
        

    }


    public enum Em_DefineVariable
    {
        trigger,
        logPath,
        EquipmentCode,
        Software,
        mesDely,
        lineCode,
        logoutTime,
        mesMainIp,
        plcIp,
        mesBakIp,
        ftpIp,
        ftpName,
        ftpPwd,
        isLogoutTimer,
        isUploadAlarm,
        EmployeeNo,
        EquipmentModel,
        byCell,
        EquipmentStatusID,
        Version,
        ProcessCode,
        ParamInit,
        alarmCell,
        all,
        OK,
        //NG,
        //rate,
        isClearData,
        cleraDataTime,
        count
    }
    
    public enum Em_MES
    {
        ACEQPTALRT,
        ACEQPTCONN,
        ACEQPTINIT,
        ACEQPTSTUS,
        ACEQUPTRUN,
        ACLOGOFF,
        ACLOGONCHECK,
        ACUSERINFO,
        ACEQPTPARM,
    }

    public enum Em_MesMessage
    {
        send,
        receiver,
    }
    public enum Em_Data
    {
        dataIn,
        dataOut,
    }

    public enum Em_LogPath
    {
        Run_Log,
        MES_Log,
        Error_Log,
        In_Data,
        Out_Data
    }

    public enum Em_Right
    {
        NotRW,
        Read,
        Write
    }
    public enum EM_SigStatus
    {
        ON,
        OFF,
    }
    public enum Em_SigName
    {
        plcStatus,
        mesStatus,
        mesModel,
        equipmentIsRun,
        equipmentStatusID,

    }
    public enum Em_OtherStatus
    {
        Reset,
        NG,
        OK,
        EqpStatus1,
        EqpStatus2,
        EqpStatus3,
        EqpStatus4,
        EqpStatus5,
        EqpStatus6,
        EqpStatus7,
        EqpStatus8,
        EqpStatus9,
        EqpStatus10,


    }

}
