﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProModel
{
    public class AlarmConfig
    {
        public int id { get; set; }

        public string alarmCode { get; set; }
        public string alarmDescript { get; set; }
        public string level { get; set; }
        public string alarmTime { get; set; }
        public string remark { get; set; }
        public int status { get; set; }             //0复位，1报警

    }
}

