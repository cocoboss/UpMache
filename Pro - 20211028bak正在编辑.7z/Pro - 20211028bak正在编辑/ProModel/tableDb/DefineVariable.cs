﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProModel
{
    public class DefineVariable
    {
        public int id { get; set; }                 //ID
        public string sysKey { get; set; }                 //变量名
        public string sysVal { get; set; }                 //值
        public string description { get; set; }                 //描述
        public string remark { get; set; }                 //备注



    }
}
