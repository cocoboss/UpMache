﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProModel
{
    public class Permissions
    {

        /// <summary>
        /// 菜单ID
        /// </summary>
        public int id { get; set; }
        /// <summary>
        /// 菜单名
        /// </summary>
        public string name { get; set; }

        /// <summary>
        /// 描述
        /// </summary>
        public string description { get; set; }
        /// <summary>
        /// 路径：命名空间.类名(Pro.TestForm)
        /// </summary>
        public string code { get; set; }
        /// <summary>
        /// 父菜单id
        /// </summary>
        public int parentID { get; set; }
        /// <summary>
        /// 子菜单排序
        /// </summary>
        public int childOrder { get; set; }
        /// <summary>
        /// 父菜单排序
        /// </summary>
        public int parentOrder { get; set; }

        /// <summary>
        /// 备注
        /// </summary>
        public string remark { get; set; }



    }
}
