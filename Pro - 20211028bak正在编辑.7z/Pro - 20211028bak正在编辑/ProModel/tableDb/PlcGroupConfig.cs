﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProModel
{
    public class PlcGroupConfig
    {
        public int groupId { get; set; }
        public string name { get; set; }
        public string startAddr { get; set; }

        public int leng { get; set; }

        public string remark { get; set; }

        public int isRemark { get; set; }

    }
}
