﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProModel
{
    public class PlcConfig
    {
        public int id { get; set; }

        public int parentId { get; set; }
        public string name { get; set; }
        public string data { get; set; }
        public string oldData { get; set; }
        public string dataType { get; set; }
        public string address { get; set; }
        public int unitNum { get; set; }
        public string remark { get; set; }

        public string paramId { get; set; }

    }
}
