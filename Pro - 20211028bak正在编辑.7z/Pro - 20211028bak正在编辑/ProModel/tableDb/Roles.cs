﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProModel
{
    public class Roles
    {
        /// <summary>
        /// 分组id
        /// </summary>
        public int groupID { get; set; }
        /// <summary>
        /// 组名：操作员（operator），维护人员（maintain），管理员（administrator），本地管理员（admin）
        /// </summary>
        public string name { get; set; }
        /// <summary>
        /// 权限：0无权限，1只读，2读写
        /// </summary>
        public string rights { get; set; }
        /// <summary>
        /// 是否上传mes或者本地效验
        /// </summary>
        public int mesOrLocal { get; set; }
        /// <summary>
        /// 创建者
        /// </summary>
        public string createOper { get; set; }
        /// <summary>
        /// 更新者
        /// </summary>
        public string updateOper { get; set; }
        /// <summary>
        /// 创建时间：DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
        /// </summary>
        public string createTime { get; set; }
        /// <summary>
        /// 更新时间：DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
        /// </summary>
        public string updateTime { get; set; }
        /// <summary>
        /// 备注
        /// </summary>
        public string remark { get; set; }
    }
}
