﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProModel
{
    public class ProdectionData
    {
        public int id { get; set; }                 //ID
        public string barCode { get; set; }            //  电芯条码
        public string in_result { get; set; }          //入站结果
        public string out_result { get; set; }         //出站结果
        public string cavity { get; set; }             //工位

        public string model { get; set; }             //模式：监控、管控、离线
        public string in_message { get; set; }         //入站NG原因

        public string out_message { get; set; }        //出站NG原因
        public float testPliesPress { get; set; }     //测厚压力值
        public float shoulderHeightL { get; set; }        //正极肩高（左正右负）
        public float shoulderHeightR { get; set; }        //
        public float PoleHeightL { get; set; }            //正极柱高（左正右负）
        public float PoleHeightR { get; set; }
        public float bycellPlies { get; set; }            //电芯厚度

        public float bycellWidth { get; set; }            //电芯宽度
        public string in_time { get; set; }                //入站时间 ("yyyy-MM-dd HH:mm:ss")
        public string out_time { get; set; }               //出站时间

        public string remark { get; set; }                 //备注
    }
}
