﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProModel
{
    public class MesLog
    {
        public int id { get; set; }

        public string guid { get; set; }

        public string commandId { get; set; }
        public string requestJson { get; set; }
        public string responseJson { get; set; }

        public string remark { get; set; }

        public string requestDate { get; set; }

        public string responseDate { get; set; }

    }
}
