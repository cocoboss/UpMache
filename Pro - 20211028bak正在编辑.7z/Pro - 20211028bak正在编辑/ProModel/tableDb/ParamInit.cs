﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProModel
{
    public class ParamInit
    {
        public int id { get; set; }

        public string processCode { get; set; }
        public string json { get; set; }

        public int isable { get; set; }
        public string remark { get; set; }
        public string employe { get; set; }

        public string entime { get; set; }


    }
}
