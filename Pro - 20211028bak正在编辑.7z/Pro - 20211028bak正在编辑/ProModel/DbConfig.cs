﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProModel
{
    public class DbConfig
    {
        public string server = "127.0.0.1";
        public string database = "tet1";
        public string uid = "root";
        public string pwd = "root";
        public string port = "3306";
        public string Charset = "utf8";

    }
}
