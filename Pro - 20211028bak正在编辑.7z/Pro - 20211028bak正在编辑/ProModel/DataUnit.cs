﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProModel
{
    public class AddrGroups
    {
        public string name = "";
        public string startAddr = "";
        public int leng = 0;
        public string remark = "";
        public List<DataUint> unitLst = new List<DataUint>();
        public bool isRemark = false;


    }
    public class DataUint
    {
        public string Prefix = "D";
        public string Name = "";
        public string Data = "";
        public string OldData = "";
        public em_DataType type = em_DataType.SingleAddress;
        public int unitNum = 4;
        public int Addr = 0;
        public string bandField = "";
        public string vairsName = "";
    }

    public enum em_DataType
    {
        Byte8Address,
        /// <summary>
        /// 整数，占用一个PLC地址。
        /// </summary>
        Int16Address,
        /// <summary>
        /// 整数，占用两个PLC地址。
        /// </summary>
        Int32Address,
        /// <summary>
        /// 整数，占用四个PLC地址。
        /// </summary>
        Int64Address,
        /// <summary>
        /// 小数，占用两个PLC地址。
        /// </summary>
        SingleAddress,
        /// <summary>
        /// 小数，占用四个PLC地址。
        /// </summary>
        DoubleAddress,
        /// <summary>
        /// 字符串，根据指定长度决定占用地址数。
        /// </summary>
        StringAddress,
    }
}
