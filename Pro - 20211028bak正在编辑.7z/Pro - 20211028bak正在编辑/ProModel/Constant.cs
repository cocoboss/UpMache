﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ProModel
{
    public class Constant
    {
        public static string dbConfigPath = "./DbConfig.xml";

        public static string connStr = "";
       
        
    }
}
