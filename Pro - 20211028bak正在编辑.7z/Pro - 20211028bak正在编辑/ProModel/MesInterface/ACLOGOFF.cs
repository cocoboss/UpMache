﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProModel
{
    /// <summary>
    /// 出站上传
    /// </summary>
    public class ACLOGOFF
    {

        public static ACLOGOFFRequest request = null;
        public static ACLOGOFFResponse response = null;

        #region

        public class ACLOGOFFRequestStationInfo
        {
            public string StationID = "";
            public string StepID = "";
        }
        public class ACLOGOFFRequestSpartInfo
        {

        }
        public class ACLOGOFFRequestMaterialInfo
        {
            public string Quantity = "";
            public string LotNo = "";
            public string ProductNo = "";
            public string UomCode = "";
            public string SerialNo = "";
            public string ProductDesc = "";
            public string LabelNo = "";
            public string ProductID = "";
        }
        public class ACLOGOFFRequestParameters
        {
            public string TargetValue = "";
            public string ParamterCode = "";
            public string Location = "";
            public string Value = "";
            public string ParameterDescription = "";
            public string UpperLimit = "";
            public string LowerLomit = "";
            public string ParameterResult = "";
            public string DefectCode = "";
            public string ParameterMessage = "";
        }


        public class ACLOGOFFRequestOutputs
        {
            public string SerialNo="";
            public string PreSerialNo = "";
            public string SlotID = "";
            public bool   IsRealFlag=true;
            public bool   CounterfeitFlag=true;
            public string ProductType = "";
            public bool     PassFlag = true;
            public string ProcessFlag = "";
            public List<ACLOGOFFRequestStationInfo>  StationInfo   ;//=new List<ACLOGOFFRequestStationInfo> ();
            public List<ACLOGOFFRequestSpartInfo>       SpartInfo  ;//=new List<ACLOGOFFRequestSpartInfo> ();
            public List<ACLOGOFFRequestMaterialInfo> MaterialInfo  ;//=new List<ACLOGOFFRequestMaterialInfo> ();
            public List<ACLOGOFFRequestParameters> Parameters;//=new List<ACLOGOFFRequestParameters> ();
            public ACLOGOFFRequestOutputs()
            {
                StationInfo = new List<ACLOGOFFRequestStationInfo>();
                SpartInfo = new List<ACLOGOFFRequestSpartInfo>();
                MaterialInfo = new List<ACLOGOFFRequestMaterialInfo>();
                Parameters = new List<ACLOGOFFRequestParameters>();
                //StationInfo.Add(new ACLOGOFFRequestStationInfo());
                //SpartInfo.Add(new ACLOGOFFRequestSpartInfo());
                //MaterialInfo.Add(new ACLOGOFFRequestMaterialInfo());
                //Parameters.Add(new ACLOGOFFRequestParameters());
            }
        }
        public class ACLOGOFFRequestEquipmentInfo
        {
            public string EquipmentCode = "";
            public string OpFlag = "";
            public string Container = "";
            public bool ProcessResult=true;
            public string ProcessMessage = "";
            public List<ACLOGOFFRequestOutputs> Outputs=new List<ACLOGOFFRequestOutputs> ();
            public ACLOGOFFRequestEquipmentInfo()
            {
                //Outputs.Add(new ACLOGOFFRequestOutputs());
            }
        }

        public class ACLOGOFFRequestJson : CommandRequestJson
        {
            public bool AutoFlag=true;
            public string Software = "";
            public string EmployeeNo="";
            public List<ACLOGOFFRequestEquipmentInfo> EquipmentInfo=new List<ACLOGOFFRequestEquipmentInfo>();
            public ACLOGOFFRequestJson()
            {
                //EquipmentInfo.Add(new ACLOGOFFRequestEquipmentInfo());
            }
        }
        public class ACLOGOFFRequest : MesRequestHeader
        {
            public ACLOGOFFRequest(ACLOGOFFRequestJson json=null)
            {
                MessageGuid = System.Guid.NewGuid();
                RequestDate = DateTime.Now;
                CommandId = "ACLOGOFF";
                //CommandRequestJson = new ACLOGOFFRequestJson();
                if (json == null)
                    CommandRequestJson = new ACLOGOFFRequestJson();
                else
                    CommandRequestJson = json;
            }
        }

        #endregion


        #region
        public class ACLOGOFFResponseParameters
        {
            public string ParamterCode;
            public string Value;
            public string UpperLimit;
            public string LowerLimit;
            public string TargetValue;
            public string DefectCode;
            public string KValue;
            public string ParameterResult;
            public string ParameterMessage;
        }
        public class ACLOGOFFResponseProducts
        {
            public string SerialNo;
            public string SlotID;
            public string CounterfeitFlag;
            public string ProductType;
            public bool OutputFlag;
            public string OutputMessage;
            public List<ACLOGOFFResponseParameters> Parameters=new List<ACLOGOFFResponseParameters> ();
        }
        public class ACLOGOFFResponseEquipmentInfo
        {
            public string EquipmentCode;
            public string Container;
            public bool ResultFlag;
            public string Message;
            //public string NGCode;
            public List<ACLOGOFFResponseProducts> Products=new List<ACLOGOFFResponseProducts> ();
        }
        public class ACLOGOFFResponseJson : CommandResponseJson
        {
            //public string Software;
            public List<ACLOGOFFResponseEquipmentInfo> EquipmentInfo=new List<ACLOGOFFResponseEquipmentInfo> ();
        }
        public class ACLOGOFFResponse : MesResponseHeader
        {
            public ACLOGOFFResponseJson CommandResponseJson;
            public ACLOGOFFResponse()
            {
                MessageGuid = System.Guid.NewGuid();
                ResponseDate = DateTime.Now;
                CommandId = "ACLOGOFF";
                CommandResponseJson = new ACLOGOFFResponseJson();
            }
        }

        #endregion
    }
}
