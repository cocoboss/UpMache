﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProModel
{
    /// <summary>
    /// 设备状态变更
    /// </summary>
    public class ACEQPTSTUS
    {

        public static ACEQPTSTUSRequest request = null;
        public static ACEQPTSTUSResponse response = null;

        #region

        public class ACEQPTSTUSRequestEquipmentInfo
        {

            public string EquipmentCode="";
            public string OpFlag = "";
            public string Location = "";
            public string EquipmentModel = "";
            public string EquipmentStatusID = "";
            public string ReasonCode = "";
            public string Description = "";
        }

        public class ACEQPTSTUSRequestJson : CommandRequestJson
        {
            public bool AutoFlag=true;
            public string Software="";
            public string EmployeeNo="";
            public List<ACEQPTSTUSRequestEquipmentInfo> EquipmentInfo=new List<ACEQPTSTUSRequestEquipmentInfo> ();
            public ACEQPTSTUSRequestJson()
            {
                //EquipmentInfo.Add(new ACEQPTSTUSRequestEquipmentInfo());
            }
            //public ACEQPTSTUSRequestJson(List<ACEQPTSTUSRequestEquipmentInfo> item)
            //{
            //    if (item != null)
            //        EquipmentInfo.AddRange(item);
            //}
        }
        public class ACEQPTSTUSRequest : MesRequestHeader
        {
            public ACEQPTSTUSRequest(ACEQPTSTUSRequestJson json=null)
            {
                MessageGuid = System.Guid.NewGuid();
                RequestDate = DateTime.Now;
                CommandId = "ACEQPTSTUS";
                //CommandRequestJson = new ACEQPTSTUSRequestJson();
                if (json == null)
                    CommandRequestJson = new ACEQPTSTUSRequestJson();
                else
                    CommandRequestJson = json;
            }
        }
        #endregion


        #region
        public class ACEQPTSTUSResponseEquipmentInfo
        {
            public string EquipmentCode;
            public bool Result;
            public string Message;
        }
        public class ACEQPTSTUSResponseJson : CommandResponseJson
        {
            //public string Software;
            public List<ACEQPTSTUSResponseEquipmentInfo> EquipmentInfo=new List<ACEQPTSTUSResponseEquipmentInfo> ();
        }
        public class ACEQPTSTUSResponse : MesResponseHeader
        {
            public ACEQPTSTUSResponseJson CommandResponseJson;
            public ACEQPTSTUSResponse()
            {
                MessageGuid = System.Guid.NewGuid();
                ResponseDate = DateTime.Now;
                CommandId = "ACEQPTSTUS";
                CommandResponseJson = new ACEQPTSTUSResponseJson();
            }
        }


        #endregion
    }
}
