﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProModel
{

    public class ACEQPTINIT
    {
        public static ACEQPTINITRequest request = null;
        public static ACEQPTINITResponse response = null;
        //public static MesResponseHeader 

        #region 01_ACEQPTINIT  Request

        public class ACEQPTINITRequestEquipmentInfo
        {
            public string EquipmentCode;
            public string WipOrder;
            public string WipOrderType;
            public string Customer;
            public string ProductNo;
            public string ProductDesc;
            public string ProcessID;
            public string Version;
            public string OprSequenceNo;
            public string OperationCode;
            public string OprSequenceDesc;
            public string FirstArticleNum;
            public string DebugNum;
            public string RecipeID;
            public string ModuleType;
            public List<ACEQPTINITRequestEquipmentStatus> EquipmentStatusList=new List<ACEQPTINITRequestEquipmentStatus> ();
            public List<ACEQPTINITRequestStepInfo> StepInfo=new List<ACEQPTINITRequestStepInfo> ();
        }
        public class ACEQPTINITRequestEquipmentStatus
        {
            public string EquipmentStatusID;
            public string ReasonCode;
            public string Description;
        }

        public class ACEQPTINITRequestStepInfo
        {
            public string StepID;
            public string StepType;
            public List<ACEQPTINITRequestParameterInfo> ParameterInfo=new List<ACEQPTINITRequestParameterInfo> ();
        }
        public class ACEQPTINITRequestParameterInfo
        {
            public string ParameterCode;
            public string ParameterType;
            public string TargetValue;
            public string UOMCode;
            public string UpperControlLimit;
            public string LowerControlLimit;
            public string Description;
            public bool UploadFlag=true;
            public bool Active=false;
        }

        public class ACEQPTINITRequestJson : CommandRequestJson
        {
            public string Software;
            public string AutoFlag;
            public string EmployeeNo;
            public List<ACEQPTINITRequestEquipmentInfo> EquipmentInfo=new List<ACEQPTINITRequestEquipmentInfo> ();
        }

        public class ACEQPTINITRequest : MesRequestHeader
        {

            public ACEQPTINITRequestJson CommandRequestJson;
            public ACEQPTINITRequest(ACEQPTINITRequestJson json=null)
            {
                MessageGuid = System.Guid.NewGuid();
                RequestDate = DateTime.Now;
                CommandId = "ACEQPTINIT";
                if (json == null)
                    CommandRequestJson = new ACEQPTINITRequestJson();
                else
                    CommandRequestJson = json;
            }
            //public ACEQPTINITRequest(ACEQPTINITRequestJson json,string comId="")
            //{
            //    MessageGuid = System.Guid.NewGuid();
            //    RequestDate = DateTime.Now;
            //    CommandId = "ACEQPTINIT";
            //    if (!string.IsNullOrEmpty(comId))
            //        CommandId = comId;
            //    CommandRequestJson = json;
            //}
        }
        #endregion

        #region 01_ACEQPTINIT  Response

        public class ACEQPTINITResponseEquipmentInfo
        {
            public string EquipmentCode;
            public bool Result;
            public string Message;
        }
        public class ACEQPTINITResponseJson : CommandResponseJson
        {
            public string Software="";
            public List<ACEQPTINITResponseEquipmentInfo> EquipmentInfo=new List<ACEQPTINITResponseEquipmentInfo> ();
            public ACEQPTINITResponseJson()
            {
                //EquipmentInfo.Add(new ACEQPTINITResponseEquipmentInfo());
            }
        }

        public class ACEQPTINITResponse : MesResponseHeader
        {
            public ACEQPTINITResponseJson CommandResponseJson;
            public ACEQPTINITResponse(Guid guid,ACEQPTINITResponseJson json =null)
            {
                MessageGuid = guid;
                ResponseDate = DateTime.Now;
                CommandId = "ACEQPTINIT";
                //CommandResponseJson = new ACEQPTINITResponseJson();
                if (json == null)
                    CommandResponseJson = new ACEQPTINITResponseJson();
                else
                    CommandResponseJson = json;
            }
        }

        #endregion

    }
}
