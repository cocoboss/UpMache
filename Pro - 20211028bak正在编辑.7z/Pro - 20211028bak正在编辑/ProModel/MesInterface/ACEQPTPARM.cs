﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProModel
{
    public class ACEQPTPARM
    {
        public static ACEQPTPARMRequest request = null;
        public static ACEQPTPARMResponse response = null;



        #region
        public class ACEQPTPARMRequestEquipmentInfo
        {
            public string EquipmentCode = "";
            public string Version = "";
            public string ProcessCode = "";
        }


        public class ACEQPTPARMRequestJson : CommandRequestJson
        {
            public bool AutoFlag = true;
            public string Software = "";
            public string EmployeeNo = "";
            public List<ACEQPTPARMRequestEquipmentInfo> EquipmentInfo = new List<ACEQPTPARMRequestEquipmentInfo>();
            public ACEQPTPARMRequestJson()
            {
                //EquipmentInfo.Add(new ACEQPTPARMRequestEquipmentInfo());
            }
        }

        public class ACEQPTPARMRequest : MesRequestHeader
        {
            public ACEQPTPARMRequest(ACEQPTPARMRequestJson json = null)
            {
                MessageGuid = System.Guid.NewGuid();
                RequestDate = DateTime.Now;
                CommandId = "ACEQPTPARM";
                //CommandRequestJson = new ACUSERINFORequestJson();
                if (json == null)
                    CommandRequestJson = new ACEQPTPARMRequestJson();
                else
                    CommandRequestJson = json;
            }
        }
        #endregion


        #region

        public class ACEQPTPARMResponseJson : CommandResponseJson
        {
            //public string Software;
            public List<ACEQPTINIT.ACEQPTINITRequestEquipmentInfo> EquipmentInfo = new List<ACEQPTINIT.ACEQPTINITRequestEquipmentInfo>();
        }
        public class ACEQPTPARMResponse : MesResponseHeader
        {
            public ACEQPTPARMResponseJson CommandResponseJson;
            public ACEQPTPARMResponse()
            {
                MessageGuid = System.Guid.NewGuid();
                ResponseDate = DateTime.Now;
                CommandId = "ACEQPTPARM";
                CommandResponseJson = new ACEQPTPARMResponseJson();
            }
        }



        #endregion

    }
}
