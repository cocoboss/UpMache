﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProModel
{
    /// <summary>
    /// 用户信息
    /// </summary>
    public class ACUSERINFO
    {

        public static ACUSERINFORequest request = null;
        public static ACUSERINFOResponse response = null;
        #region
        public class ACUSERINFORequestEquipmentInfo
        {
            public string EquipmentCode = "";
            public string EmployeeNo = "";
            public string Password = "";
            public string RoleID = "";
        }

        public class ACUSERINFORequestJson : CommandRequestJson
        {
            public bool AutoFlag=true;
            public string Software="";
            public string EmployeeNo="";
            public List<ACUSERINFORequestEquipmentInfo> EquipmentInfo=new List<ACUSERINFORequestEquipmentInfo> ();
            public ACUSERINFORequestJson()
            {
                //EquipmentInfo.Add(new ACUSERINFORequestEquipmentInfo());
            }
            //public ACUSERINFORequestJson(ACUSERINFORequestEquipmentInfo info)
            //{
            //    EquipmentInfo.Add(info);
            //}
        }
        public class ACUSERINFORequest : MesRequestHeader
        {
            public ACUSERINFORequest(ACUSERINFORequestJson json=null)
            {
                MessageGuid = System.Guid.NewGuid();
                RequestDate = DateTime.Now;
                CommandId = "ACUSERINFO";
                //CommandRequestJson = new ACUSERINFORequestJson();
                if (json == null)
                    CommandRequestJson = new ACUSERINFORequestJson();
                else
                    CommandRequestJson = json;
            }
        }

        #endregion


        #region

        public class ACUSERINFOResponseEquipmentInfo
        {
            public string EquipmentCode;
            public bool ResultFlag;
            public string Message;
        }
        public class ACUSERINFOResponseJson : CommandResponseJson
        {
            //public string Software;
            public List<ACUSERINFOResponseEquipmentInfo> EquipmentInfo=new List<ACUSERINFOResponseEquipmentInfo> ();
        }
        public class ACUSERINFOResponse : MesResponseHeader
        {
            public ACUSERINFOResponseJson CommandResponseJson;
            public ACUSERINFOResponse()
            {
                MessageGuid = System.Guid.NewGuid();
                ResponseDate = DateTime.Now;
                CommandId = "ACUSERINFO";
                CommandResponseJson = new ACUSERINFOResponseJson();
            }
        }

        #endregion


    }
}
