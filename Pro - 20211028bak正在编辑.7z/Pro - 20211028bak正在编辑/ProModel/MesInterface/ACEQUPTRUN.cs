﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProModel
{
    /// <summary>
    /// 设备运行请求
    /// </summary>
    public class ACEQUPTRUN
    {

        public static ACEQUPTRUNRequest request = null;
        public static ACEQUPTRUNResponse response = null;

        #region

        public class ACEQUPTRUNRequestEquipmentInfo
        {
            public string EquipmentCode = "";
            public string EquipmentModel = "";
            public string StateCode = "";
        }

        public class ACEQUPTRUNRequestJson : CommandRequestJson
        {
            public bool AutoFlag=true;
            public string Software = "";
            public string EmployeeNo="";
            public List<ACEQUPTRUNRequestEquipmentInfo> EquipmentInfo=new List<ACEQUPTRUNRequestEquipmentInfo> ();
            public ACEQUPTRUNRequestJson()
            {
                //EquipmentInfo.Add(new ACEQUPTRUNRequestEquipmentInfo());
            }
        }
        public class ACEQUPTRUNRequest : MesRequestHeader
        {
            public ACEQUPTRUNRequest(ACEQUPTRUNRequestJson json =null)
            {
                MessageGuid = System.Guid.NewGuid();
                RequestDate = DateTime.Now;
                CommandId = "ACEQUPTRUN";
                //CommandRequestJson = new ACEQUPTRUNRequestJson();
                if (json == null)
                    CommandRequestJson = new ACEQUPTRUNRequestJson();
                else
                    CommandRequestJson = json;
            }
        }
        #endregion


        #region


        public class ACEQUPTRUNResponseEquipmentInfo
        {
            public string EquipmentCode;
            public bool ResultFlag;
            public string Message;
        }
        public class ACEQUPTRUNResponseJson : CommandResponseJson
        {
            //public string Software;
            public List<ACEQUPTRUNResponseEquipmentInfo> EquipmentInfo;
        }
        public class ACEQUPTRUNResponse : MesResponseHeader
        {
            public ACEQUPTRUNResponseJson CommandResponseJson;
            public ACEQUPTRUNResponse()
            {
                MessageGuid = System.Guid.NewGuid();
                ResponseDate = DateTime.Now;
                CommandId = "ACEQUPTRUN";
                CommandResponseJson = new ACEQUPTRUNResponseJson();
            }
        }

        #endregion

    }
}
