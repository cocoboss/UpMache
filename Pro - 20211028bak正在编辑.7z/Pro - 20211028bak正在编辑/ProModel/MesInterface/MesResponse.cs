﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProModel
{
    public class MesResponseHeader
    {
        public Guid MessageGuid;
        public string CommandId;
        public bool Success;
        public string ErrorCode;
        public string ErrorMessage;
        public DateTime ResponseDate;
        //public CommandResponseJson CommandResponseJson;
    }
    public class CommandResponseJson
    {

    }
}
