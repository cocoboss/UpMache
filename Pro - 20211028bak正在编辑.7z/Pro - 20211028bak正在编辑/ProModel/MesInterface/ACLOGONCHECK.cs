﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProModel
{
    /// <summary>
    /// 入站校验
    /// </summary>
    public class ACLOGONCHECK
    {
        public static ACLOGONCHECKRequest request = null;
        public static ACLOGONCHECKResponse response = null;

        #region
        public class ACLOGONCHECKSerialNos
        {
            public string SerialNo = "";
            public bool GetProductTypeFlag=true;
            public string SlotID = "";

        }
        public class ACLOGONCHECKRequestEquipmentInfo
        {
            public string EquipmentCode = "";
            public string OpFlag = "";
            public string Container = "";
            public string RequestType = "";
            public List<ACLOGONCHECKSerialNos> SerialNos=new List<ACLOGONCHECKSerialNos> ();
            public ACLOGONCHECKRequestEquipmentInfo()
            {
                //SerialNos.Add(new ACLOGONCHECKSerialNos());
            }
        }
        public class ACLOGONCHECKRequestJson : CommandRequestJson
        {
            public bool AutoFlag=true;
            public string Software = "";
            public string EmployeeNo="";
            public List<ACLOGONCHECKRequestEquipmentInfo> EquipmentInfo=new List<ACLOGONCHECKRequestEquipmentInfo> ();
            public ACLOGONCHECKRequestJson()
            {
                //EquipmentInfo.Add(new ACLOGONCHECKRequestEquipmentInfo());
            }
        }
        public class ACLOGONCHECKRequest : MesRequestHeader
        {
            public ACLOGONCHECKRequest(ACLOGONCHECKRequestJson json=null)
            {
                MessageGuid = System.Guid.NewGuid();
                RequestDate = DateTime.Now;
                CommandId = "ACLOGONCHECK";
                //CommandRequestJson = new ACLOGONCHECKRequestJson();
                if (json == null)
                    CommandRequestJson = new ACLOGONCHECKRequestJson();
                else
                    CommandRequestJson = json;
            }
        }


        #endregion




        #region
        public class ACLOGONCHECKResponseParameterInfo
        {
            public string ParameterCode;
            public string TargetValue;
            public string UOMCode;
            public string UpperControlLimit;
            public string LowerControlLimit;
            public string Description;
            public bool UploadFlag;
            public bool Active;
        }
        public class ACLOGONCHECKResponseParameterValue
        {
            public string ParameterCode;
            public string TargetValue;
            public string UOMCode;
            public string UpperControlLimit;
            public string LowerControlLimit;
            public string Description;
            public string TestValue;
        }
        public class ACLOGONCHECKResponseStationInfos
        {

        }
        public class ACLOGONCHECKResponseSerialNos
        {
            public string SerialNo;
            public string SlotID;
            public bool Result;
            public string NGCode;
            public string Message;
            public bool Rework;
            public bool CounterfeitFlag;
            public string ProductType;
            public string WipOrder;
            public string WipOrderType;
            public string Customer;
            public string ProductNo;
            public string ProductDesc;
            public string ProcessID;
            public string Version;
            public string OprSequenceNo;
            public string OperationCode;
            public string OprSequenceDesc;
            public string RecipeID;
            public string StationCode;
            public string StationDesc;
            public string StationNumber;
            public List<ACLOGONCHECKResponseParameterInfo> ParameterInfo;
            public List<ACLOGONCHECKResponseParameterValue> ParameterValue;
            public List<ACLOGONCHECKResponseStationInfos> StationInfos;
        }


        public class ACLOGONCHECKResponseEquipmentInfo
        {
            public string EquipmentCode;
            public string Container;
            public bool Result;
            public string Message;
            public string NGCode;
            public List<ACLOGONCHECKResponseSerialNos> SerialNos;
        }

        public class ACLOGONCHECKResponseJson : CommandResponseJson
        {

            public List<ACLOGONCHECKResponseEquipmentInfo> EquipmentInfo;
        }
        public class ACLOGONCHECKResponse : MesResponseHeader
        {
            public ACLOGONCHECKResponseJson CommandResponseJson;
            public ACLOGONCHECKResponse()
            {
                MessageGuid = System.Guid.NewGuid();
                ResponseDate = DateTime.Now;
                CommandId = "ACLOGONCHECK";
                CommandResponseJson = new ACLOGONCHECKResponseJson();
            }
        }


        #endregion
    }
}
