﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProModel
{


    public class MesRequestHeader
    {
        public Guid MessageGuid;
        public DateTime RequestDate;
        public string CommandId;
        public CommandRequestJson CommandRequestJson;
    }
    public class CommandRequestJson
    {

    }
}
