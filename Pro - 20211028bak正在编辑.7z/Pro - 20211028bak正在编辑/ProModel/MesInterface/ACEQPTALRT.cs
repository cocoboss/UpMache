﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProModel
{
    /// <summary>
    /// 设备报警
    /// </summary>
    public class ACEQPTALRT
    {
        public static ACEQPTALRTRequest request = null;
        public static ACEQPTALRTResponse response = null;

        #region

        public class ACEQPTALRTRequestAlertInfo
        {
            public string AlertCode="";
            public string AlertReset = "";
            public string AlertDescription = "";
            public string AlertLevel = "";
            public string AlertCount = "";
        }
        public class ACEQPTALRTRequestEquipmentInfo
        {
            public string EquipmentCode = "";
            public List<ACEQPTALRTRequestAlertInfo> AlertInfo=new List<ACEQPTALRTRequestAlertInfo> ();
            public ACEQPTALRTRequestEquipmentInfo()
            {
                //EquipmentCode = "P1FE-R1G7801";
                //AlertInfo.Add(new ACEQPTALRTRequestAlertInfo());
            }
        }

        public class ACEQPTALRTRequestJson : CommandRequestJson
        {
            public bool AutoFlag=true;
            public string Software = "DDM";
            public string EmployeeNo = "";
            public List<ACEQPTALRTRequestEquipmentInfo> EquipmentInfo=new List<ACEQPTALRTRequestEquipmentInfo> ();
            public ACEQPTALRTRequestJson()
            {
                //EquipmentInfo.Add(new ACEQPTALRTRequestEquipmentInfo());
            }
        }
        public class ACEQPTALRTRequest : MesRequestHeader
        {
            public ACEQPTALRTRequest(ACEQPTALRTRequestJson json = null)
            {
                MessageGuid = System.Guid.NewGuid();
                RequestDate = DateTime.Now;
                CommandId = "ACEQPTALRT";
                //CommandRequestJson = new ACEQPTALRTRequestJson();
                if (json == null)
                    CommandRequestJson = new ACEQPTALRTRequestJson();
                else
                    CommandRequestJson = json;
            }
        }
        #endregion


        #region

        public class ACEQPTALRTResponseEquipmentInfo
        {
            public string EquipmentCode;
            public bool Result;
            public string Message;
        }

        public class ACEQPTALRTResponseJson : CommandResponseJson
        {
            //public string Software;
            public List<ACEQPTALRTResponseEquipmentInfo> EquipmentInfo=new List<ACEQPTALRTResponseEquipmentInfo> ();
        }
        public class ACEQPTALRTResponse : MesResponseHeader
        {
            public ACEQPTALRTResponseJson CommandResponseJson;
            public ACEQPTALRTResponse()
            {
                MessageGuid = System.Guid.NewGuid();
                ResponseDate = DateTime.Now;
                CommandId = "ACEQPTALRT";
                CommandResponseJson = new ACEQPTALRTResponseJson();
            }
        }
        #endregion


    }
}
