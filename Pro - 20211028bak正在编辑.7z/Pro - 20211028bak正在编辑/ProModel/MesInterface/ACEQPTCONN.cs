﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProModel
{
    /// <summary>
    /// 设备联机请求
    /// </summary>
    public class ACEQPTCONN
    {

        public static ACEQPTCONNRequest request = new ACEQPTCONNRequest ();
        public static ACEQPTCONNResponse response = new ACEQPTCONNResponse ();
        #region 
        public class ACEQPTCONNRequestEquipmentInfo
        {
            public string EquipmentCode = "P1FE-R1G7801";
        }

        public class ACEQPTCONNRequestJson: CommandRequestJson
        {
            public bool AutoFlag=true;
            public string Software= "DDM";
            public List<ACEQPTCONNRequestEquipmentInfo> EquipmentInfo=new List<ACEQPTCONNRequestEquipmentInfo> ();
            public ACEQPTCONNRequestJson()
            {
                //EquipmentInfo.Add(new ACEQPTCONNRequestEquipmentInfo());
            }
        }
        public class ACEQPTCONNRequest: MesRequestHeader
        {
            public ACEQPTCONNRequest(ACEQPTCONNRequestJson json=null)
            {
                MessageGuid = System.Guid.NewGuid();
                RequestDate = DateTime.Now;
                CommandId = "ACEQPTCONN";
                //CommandRequestJson = new ACEQPTCONNRequestJson();
                if (json == null)
                    CommandRequestJson = new ACEQPTCONNRequestJson();
                else
                    CommandRequestJson = json;
                Console.WriteLine("CommandRequestJson : " + CommandRequestJson.ToString());
            }
        }
        #endregion

        #region

        public class ACEQPTCONNResponseEquipmentInfo
        {
            public string EquipmentCode;
            public bool Result;
            public string Message;
        }
        public class ACEQPTCONNResponseJson : CommandResponseJson
        {
            //public string Software;
            public List<ACEQPTCONNResponseEquipmentInfo> EquipmentInfo=new List<ACEQPTCONNResponseEquipmentInfo> ();
        }
        public class ACEQPTCONNResponse : MesResponseHeader
        {
            public ACEQPTCONNResponseJson CommandResponseJson;
            public ACEQPTCONNResponse()
            {
                MessageGuid = System.Guid.NewGuid();
                ResponseDate = DateTime.Now;
                CommandId = "ACEQPTCONN";
                CommandResponseJson = new ACEQPTCONNResponseJson();
            }
        }

        #endregion

    }
}
