﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProModel
{
    public class SystemInfo
    {
        public string equipmentCode;
        public string softName;
        public string mesDely;
        public string lineCode;
        public string logoutTime;
        public string mesMainIp;
        public string mesBakIp;
        public string ftpIp;
        public string ftpName;
        public string ftpPwd;
        public bool isLogoutTimer;
        public bool isUploadAlarm;



    }
}
