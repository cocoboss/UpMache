﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProModel
{
    public class SigStatusEventArgs:EventArgs
    {
        public Em_SigName type { get; set; }
        public string val { get; set; }

        public SigStatusEventArgs(Em_SigName name,string data)
        {
            type = name;
            val = data;
        }
    }


    public class MesDataEventArgs : EventArgs
    {
        public Em_MesMessage type { get; set; }
        public Em_MES type2 { get; set; }
        public string val { get; set; }

        public MesDataEventArgs(Em_MesMessage name, Em_MES inter ,string data)
        {
            type = name;
            type2 = inter;
            val = data;
        }
    }
    public class DataEventArgs : EventArgs
    {
        public Em_Data type { get; set; }
        public bool status { get; set; }
        public string allCount { get; set; }
        public string okCount { get; set; }
        public ProdectionData val { get; set; }


        public DataEventArgs(Em_Data name, ProdectionData data,bool ret,string all,string ok)
        {
            type = name;
            val = data;
            status = ret;
            allCount = string.IsNullOrEmpty(all)?"0":all;
            okCount = string.IsNullOrEmpty(ok) ? "0" : ok;
        }
    }

    public class LogEventArgs : EventArgs
    {
        public Em_LogPath type;
        public string message;
        public LogEventArgs(Em_LogPath log,string msg)
        {
            type = log;
            message = msg;
        }
    }

    public class ParamInitEventArgs : EventArgs
    {
        public Em_MES type;
        public string json;
        public int isReturnMes;
        public ParamInitEventArgs(Em_MES init, string msg,int temp)
        {
            type = init;
            json = msg;
            isReturnMes = temp;
        }
    }




}
